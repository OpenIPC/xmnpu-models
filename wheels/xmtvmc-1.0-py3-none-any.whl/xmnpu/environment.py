# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""Configurable XMNPU Hareware Environment scope."""
# pylint: disable=invalid-name, exec-used
from __future__ import absolute_import as _abs

import os
import json
import copy
import tvm
from tvm import te
from . import intrin
import numpy as np

def get_xmnpu_hw_path():
    """Get the XMNPU HW path."""
    curr_path = os.path.dirname(os.path.abspath(os.path.expanduser(__file__)))
    xmnpu_hw_default = os.path.abspath(os.path.join(curr_path, "../../../xmnpu/instruction"))
    XMNPU_HW_PATH = os.getenv("XMNPU_HW_PATH", xmnpu_hw_default)
    return os.path.abspath(XMNPU_HW_PATH)

class DevContext(object):
    """Internal development context

    This contains all the non-user facing compiler
    internal context that is hold by the Environment.

    Parameters
    ----------
    env : Environment
        The environment hosting the DevContext

    Note
    ----
    This class is introduced so we have a clear separation
    of developer related, and user facing attributes.
    """

    # Memory id for DMA
    XM_SRAM_CALC = 0
    XM_SRAM_BIAS = 1
    XM_SRAM_LUT  = 2

    # NPU engine id (pipeline stage)
    XM_GEN_LOAD    = 1
    XM_GEN_STORE   = 3
    XM_GEN_COMPUTE = 2
    #QID_COMPUTE_POOL = 2

    # align mode
    XM_COMPACT_DDR   = 0
    XM_COMPACT_SRAM  = 1
    XM_KERNEL_ALIGN  = 2
    XM_HW256_ALIGN   = 3
    XM_PTCH_3D       = 4

    # npu data type
    XM_NPU_INT8   = 0
    XM_NPU_UINT8  = 1
    XM_NPU_INT16  = 2
    XM_NPU_UINT16 = 3
    XM_NPU_FP16   = 4
    XM_NPU_INT32  = 5
    XM_NPU_UINT32 = 6
    XM_NPU_FP32   = 7

    # NPU arith op type
    XM_NPU_OP_ADD    = 0
    XM_NPU_OP_SUB    = 1
    XM_NPU_OP_MUL    = 2
    XM_NPU_OP_MAC    = 3
    XM_NPU_OP_SHIFT  = 4
    XM_NPU_OP_AND    = 5
    XM_NPU_OP_OR     = 6
    XM_NPU_OP_XOR    = 7
    XM_NPU_OP_MIN    = 8
    XM_NPU_OP_MAX    = 9
    XM_NPU_OP_SE     = 10
    XM_NPU_OP_CMP1   = 11
    XM_NPU_OP_CMP2   = 12

    # NPU ISAcodes
    XM_ISA_ARITHMETIC   = 0
    XM_ISA_CONV         = 1
    XM_ISA_DEPTHWISE    = 2
    XM_ISA_DMA_LOAD     = 3
    XM_ISA_DMA_STORE    = 4
    XM_ISA_DMA_S2S      = 5
    XM_ISA_ELTWISEADD   = 6
    XM_ISA_FC           = 7
    XM_ISA_GLOBAL_POOL  = 8
    XM_ISA_AVG_MAX_POOL = 9
    XM_ISA_LUT          = 10
    XM_ISA_NEG          = 11
    XM_ISA_SCALE        = 12

    def __init__(self, env):
        self.xmnpu_axis = te.thread_axis("xmnpu")
        self.xmnpu_verify_op = tvm.tir.StringImm("XMNPUFinitOp")
        ctx = tvm.tir.call_intrin("handle", "tir.xmnpu.command_handle")
        self.command_handle = tvm.tir.Call("handle", "tir.tvm_thread_context", [ctx])
        self.DEBUG_NO_SYNC = False
        env._dev_ctx = self
        self.fc    = intrin.fc(env)
        self.arith = intrin.arith(env)
        self.conv  = intrin.conv(env)

    def get_task_qid(self, qid):
        """Get transformed queue index."""
        return 1 if self.DEBUG_NO_SYNC else qid


class Environment(object):
    """Hardware configuration object.

    This object contains all the information
    needed for compiling to a specific XMNPU backend.

    Parameters
    ----------
    cfg : dict of str to value.
        The configuration parameters.

    Example
    --------
    .. code-block:: python

      # the following code reconfigures the environment
      # temporarily to attributes specified in new_cfg.json
      with xmnpu.Environment():
          # env works on the new environment
          env = xmnpu.get_env()
    """

    current = None
    # memory scopes
    calc_scope   = "local.sram_calc"
    bias_scope   = "local.sram_bias"
    lut_scope    = "local.sram_lut"
    inline_scope = "local.sram_inline"

    # initialization function
    def __init__(self):
        # data type width
        self.BATCH   = 1
        self.C_WIDTH = 1 << 12
        self.H_WIDTH = 1 << 10
        self.W_WIDTH = 1 << 10
        self.H_WIDTH_2D = 1 << 21
        self.W_WIDTH_2D = 1 << 21
        # data align bytes in sram
        self.PTCH_ALIGN = 8
        # buffer size
        self.NPU_SRAM_LUT_SIZE  = 0x400        # 1k
        self.NPU_SRAM_BIAS_SIZE = 0x8000       # 32k
        self.NPU_SRAM_FW_SIZE = 0xC0000      # 768k
        self.DDR_NPU_REGION_SIZE  = 0x40000000   # 1G
        # dtypes
        self.int8_dtype = "int8" 
        self.int32_dtype = "int32"
        # bistream name
        self.TARGET = "cmodel"  # cmodel or libxm7205v500 or xmxxx TODO: use config automatic
        # lazy cached members
        self.mock_mode = False
        self._mock_env = None
        self._dev_ctx = None
        self._last_env = None

    def __enter__(self):
        self._last_env = Environment.current
        Environment.current = self
        return self

    def __exit__(self, ptype, value, trace):
        Environment.current = self._last_env

    @property
    def dev(self):
        """Developer context"""
        if self._dev_ctx is None:
            self._dev_ctx = DevContext(self)
        return self._dev_ctx

    @property
    def mock(self):
        """A mock version of the Environment

        The ALU, dma_copy and intrinsics will be
        mocked to be nop.
        """
        if self.mock_mode:
            return self
        if self._mock_env is None:
            self._mock_env = copy.copy(self)
            self._mock_env._dev_ctx = None
            self._mock_env.mock_mode = True
        return self._mock_env

    @property
    def align_ddr(self):
        """npu sram align mode"""
        return self.dev.XM_COMPACT_DDR

    @property
    def align_compact(self):
        """npu sram align mode"""
        return self.dev.XM_COMPACT_SRAM

    @property
    def align_kernel(self):
        """npu sram align mode"""
        return self.dev.XM_KERNEL_ALIGN

    @property
    def align_hw256(self):
        """npu sram align mode"""
        return self.dev.XM_HW256_ALIGN

    @property
    def align_ptch_3d(self):
        """npu sram align mode"""
        return self.dev.XM_PTCH_3D

    @property
    def dma_load(self):
        """DMA load pragma"""
        return "dma_load" if not self.mock_mode else "skip_dma_load"

    @property
    def dma_store(self):
        """DMA store pragma"""
        return "dma_store" if not self.mock_mode else "skip_dma_store"

    @property
    def dma_s2s(self):
        """DMA sram2sram pragma"""
        return "dma_s2s" if not self.mock_mode else "skip_dma_s2s"

    def test_load(self, mock = 0):
        """load pragma_key"""
        if mock == 1:
            return "test_load"
        elif mock == 2:
            return "skip_test_load"
        else:
            return "test_load" if not self.mock_mode else "skip_test_load"

    def test_store(self, mock = 0):
        """store pragma_key"""
        if mock == 1:
            return "test_store"
        elif mock == 2:
            return "skip_test_store"
        else:
            return "test_store" if not self.mock_mode else "skip_test_store"

    def arith(self, mock = 0):
        """arithmetic pragma_key"""
        if mock == 1:
            return "arith"
        elif mock == 2:
            return "skip_arith"
        else:
            return "arith" if not self.mock_mode else "skip_arith"

    def eltwiseadd(self, mock = 0):
        """eltwiseadd pragma_key"""
        if mock == 1:
            return "eltwiseadd"
        elif mock == 2:
            return "skip_eltwiseadd"
        else:
            return "eltwiseadd" if not self.mock_mode else "skip_eltwiseadd"

    def conv2d(self, mock = 0):
        """conv2d pragma_key"""
        if mock == 1:
            return "conv2d"
        elif mock == 2:
            return "skip_conv2d"
        else:
            return "conv2d" if not self.mock_mode else "skip_conv2d"

    def dense(self, mock = 0):
        """dense pragma_key"""
        if mock == 1:
            return "dense"
        elif mock == 2:
            return "skip_dense"
        else:
            return "dense" if not self.mock_mode else "skip_dense"

    def concat(self, mock = 0):
        """concat pragma_key"""
        if mock == 1:
            return "concat"
        elif mock == 2:
            return "skip_concat"
        else:
            return "concat" if not self.mock_mode else "skip_concat"

    def space_to_depth(self, mock = 0):
        """space_to_depth pragma_key"""
        if mock == 1:
            return "space_to_depth"
        elif mock == 2:
            return "skip_space_to_depth"
        else:
            return "space_to_depth" if not self.mock_mode else "skip_space_to_depth"

    def depth_to_space(self, mock = 0):
        """depth_to_space pragma_key"""
        if mock == 1:
            return "depth_to_space"
        elif mock == 2:
            return "skip_depth_to_space"
        else:
            return "depth_to_space" if not self.mock_mode else "skip_depth_to_space"
    
    def batch_to_space_nd(self, mock = 0):
        """batch_to_space_nd pragma_key"""
        if mock == 1:
            return "batch_to_space_nd"
        elif mock == 2:
            return "skip_batch_to_space_nd"
        else:
            return "batch_to_space_nd" if not self.mock_mode else "skip_batch_to_space_nd"

    def space_to_batch_nd(self, mock = 0):
        """space_to_batch_nd pragma_key"""
        if mock == 1:
            return "space_to_batch_nd"
        elif mock == 2:
            return "skip_space_to_batch_nd"
        else:
            return "space_to_batch_nd" if not self.mock_mode else "skip_space_to_batch_nd"

    def lut(self, mock = 0):
        """lut pragma_key"""
        if mock == 1:
            return "lut"
        elif mock == 2:
            return "skip_lut"
        else:
            return "lut" if not self.mock_mode else "skip_lut"

    def tile(self, mock = 0):
        """tile pragma_key"""
        if mock == 1:
            return "tile"
        elif mock == 2:
            return "skip_tile"
        else:
            return "tile" if not self.mock_mode else "skip_tile"

    def yuv2rgb(self, mock = 0):
        """yuv2rgb pragma_key"""
        if mock == 1:
            return "yuv2rgb"
        elif mock == 2:
            return "skip_yuv2rgb"
        else:
            return "yuv2rgb" if not self.mock_mode else "skip_yuv2rgb"

    def gap(self, mock = 0):
        """gap pragma_key"""
        if mock == 1:
            return "gap"
        elif mock == 2:
            return "skip_gap"
        else:
            return "gap" if not self.mock_mode else "skip_gap"

    def pool2d(self, mock = 0):
        """pool2d pragma_key"""
        if mock == 1:
            return "pool2d"
        elif mock == 2:
            return "skip_pool2d"
        else:
            return "pool2d" if not self.mock_mode else "skip_pool2d"

    def scale(self, mock = 0):
        """scale pragma_key"""
        if mock == 1:
            return "scale"
        elif mock == 2:
            return "skip_scale"
        else:
            return "scale" if not self.mock_mode else "skip_scale"

    def upsample(self, mock = 0):
        """upsample pragma_key"""
        if mock == 1:
            return "upsample"
        elif mock == 2:
            return "skip_upsample"
        else:
            return "upsample" if not self.mock_mode else "skip_upsample"

    def neg(self, mock = 0):
        """negative pragma_key"""
        if mock == 1:
            return "neg"
        elif mock == 2:
            return "skip_neg"
        else:
            return "neg" if not self.mock_mode else "skip_neg"

    def transpose(self, mock = 0):
        """transpose(permute) pragma_key"""
        if mock == 1:
            return "transpose"
        elif mock == 2:
            return "skip_transpose"
        else:
            return "transpose" if not self.mock_mode else "skip_transpose"

    def channel_shuffle(self, mock = 0):
        """channel_shuffle pragma_key"""
        if mock == 1:
            return "channel_shuffle"
        elif mock == 2:
            return "skip_channel_shuffle"
        else:
            return "channel_shuffle" if not self.mock_mode else "skip_channel_shuffle"

    def strided_slice(self, mock = 0):
        """strided_slice pragma_key"""
        if mock == 1:
            return "strided_slice"
        elif mock == 2:
            return "skip_strided_slice"
        else:
            return "strided_slice" if not self.mock_mode else "skip_strided_slice"

    def split(self, mock = 0):
        """split pragma_key"""
        if mock == 1:
            return "split"
        elif mock == 2:
            return "skip_split"
        else:
            return "split" if not self.mock_mode else "skip_split"

    def clip(self, mock = 0):
        """clip pragma_key"""
        if mock == 1:
            return "clip"
        elif mock == 2:
            return "skip_clip"
        else:
            return "clip" if not self.mock_mode else "skip_clip"

    def matmul(self, mock = 0):
        """matmul pragma_key"""
        if mock == 1:
            return "matmul"
        elif mock == 2:
            return "skip_matmul"
        else:
            return "matmul" if not self.mock_mode else "skip_matmul"

    def reduce_mean(self, mock = 0):
        """reduce_mean pragma_key"""
        if mock == 1:
            return "reduce_mean"
        elif mock == 2:
            return "skip_reduce_mean"
        else:
            return "reduce_mean" if not self.mock_mode else "skip_reduce_mean"

    @property
    def intrin_fc(self):
        """fc intrinsic"""
        return self.dev.fc

    @property
    def intrin_conv(self):
        """conv intrinsic"""
        return self.dev.conv

    @property
    def target(self):
        host = "llvm"
        if self.TARGET in ["libxm7205v500"]:
            host = "llvm -mtriple=armv7-none-linux-gnueabihf"
        if self.TARGET in ["cmodel"]:
            host = "llvm"
        return tvm.target.xmnpu(model=self.TARGET, host=host)

    @property
    def target_host(self):
        """The target host"""
        if self.TARGET in ["libxm7205v500"]:
            return "llvm -mtriple=armv7-none-linux-gnueabihf"
        if self.TARGET in ["cmodel"]:
            return "llvm"
        raise ValueError("Unknown target %s" % self.TARGET)

    @property
    def target_xmnpu_cpu(self):
        return tvm.target.arm_cpu(model=self.TARGET)

    def convert_npu_dtype(self, dtype="int8"):
        if dtype == "int8" or dtype == np.int8: 
            return self.dev.XM_NPU_INT8
        elif dtype == "uint8" or dtype == np.uint8:
            return self.dev.XM_NPU_UINT8
        elif dtype == "int16" or dtype == np.int16:
            return self.dev.XM_NPU_INT16
        elif dtype == "uint16" or dtype == np.uint16:
            return self.dev.XM_NPU_UINT16
        elif dtype == "float16" or dtype == np.float16:
            return self.dev.XM_NPU_FP16
        elif dtype == "int32" or dtype == np.int32:
            return self.dev.XM_NPU_INT32
        elif dtype == "uint32" or dtype == np.uint32:
            return self.dev.XM_NPU_UINT32
        elif dtype == "float" or dtype == "float32" or dtype == np.float:
            return self.dev.XM_NPU_FP32
        else:
            raise RuntimeError(
                "data type %s  not find" % (dtype)
            )

    def get_npu_quantize_multiplier(self, f_multiplier):
        f = tvm.get_global_func("xm7205v500.quantize_multiplier", True)
        if f:
            a = json.loads(f(f_multiplier))
            m = []
            for k, v in a.items():
                #print("\t{:<16}: {:>16}".format(k, v))
                m.append(v)
            return m
        else:
            raise RuntimeError(
                "function %s not find" % ("xm7205v500.quantize_multiplier")
            )

def get_env():
    """Get the current XMNPU Environment.

    Returns
    -------
    env : Environment
        The current environment.
    """
    return Environment.current

def _init_env():
    """Initialize the default global env"""
    return Environment()


Environment.current = _init_env()

from . import libinfo   # load lib and init
