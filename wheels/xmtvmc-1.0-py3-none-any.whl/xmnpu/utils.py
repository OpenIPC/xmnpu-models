# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

import copy
import copyreg
import ctypes
import functools
import logging
import os
import platform
import shutil
import sys
import time
import pickle
import pytest
import numpy as np

def data_compare(actual, desired, info="", delta=0):
    def _get_real_idx(idx, ndim):
        idx_info = "[%s"%(idx[0])
        for i in range(ndim - 1):
            idx_info += " %s"%(idx[i + 1])
        idx_info += "]"
        return idx_info


    shape = actual.shape
    shape2 = desired.shape
    assert shape == shape2
    ndim = len(shape)
    assert ndim <= 4
    shape_4d = [shape[x] for x in range(ndim)]
    for x in range(4 - ndim):
        shape_4d.append(1)
    
    actual  = actual.reshape((*shape_4d))
    desired = desired.reshape((*shape_4d))

    first_error = [[-1], 0, 0]     # idx actual desired
    max_error   = [[-1], 0, 0, 0]  # idx actual desired value
    mismatch_cnt = 0
    for nidx in range(shape_4d[0]):
        for cidx in range(shape_4d[1]):
            for hidx in range(shape_4d[2]):
                for widx in range(shape_4d[3]):
                    error = abs(actual[nidx][cidx][hidx][widx].astype("int32") - desired[nidx][cidx][hidx][widx].astype("int32"))
                    if error > 0:
                        if first_error[0][0] == -1:
                            first_error[0] = [nidx, cidx, hidx, widx]
                            first_error[1] = actual[nidx][cidx][hidx][widx]
                            first_error[2] = desired[nidx][cidx][hidx][widx]
                        if error > max_error[3]:
                            max_error[3] = error
                            max_error[0] = [nidx, cidx, hidx, widx]
                            max_error[1] = actual[nidx][cidx][hidx][widx]
                            max_error[2] = desired[nidx][cidx][hidx][widx]
                        mismatch_cnt += 1
                    if error > delta:
                        print("%s :   error        at idx %s, desired %s but get %s" \
                                %(info, _get_real_idx([nidx, cidx, hidx, widx], ndim), max_error[2], max_error[1]))
                        print("%s : first mismatch at idx %s, desired %s but get %s (delta %s)" \
                                %(info, _get_real_idx(max_error[0], ndim), max_error[2], max_error[1], delta))
                        print("%s : total mismatch at %s (delta %s)" \
                                %(info, mismatch_cnt, delta))
                        return False
    if max_error[0][0] != -1:
        print("%s : first mismatch at idx %s, desired %s but get %s (delta %s)" \
                %(info, _get_real_idx(first_error[0], ndim), first_error[2], first_error[1], delta))
        print("%s : max   mismatch at idx %s, desired %s but get %s (delta %s)" \
                %(info, _get_real_idx(max_error[0], ndim), max_error[2], max_error[1], delta))
        print("%s : total mismatch at i%s (delta %s)" \
                %(info, mismatch_cnt, delta))
    return True

def f2i_round(in_data):
    assert in_data.dtype == "float32" or in_data.dtype == "float64"
    in_data = in_data.astype("float32")
    shape = in_data.shape
    s_data = np.squeeze(in_data)
    if len(s_data.shape) == 0:
        s_data = np.where(s_data >= 0, np.floor(s_data + 0.5), np.ceil(s_data - 0.5))
    else:
        for i in range(s_data.shape[0]):
            s_data[i] = np.where(s_data[i] >= 0, np.floor(s_data[i] + 0.5), np.ceil(s_data[i] - 0.5))
    return s_data.reshape(shape).astype("int32")

def npu_relu(in_data, relu):
    assert in_data.dtype == "int32"
    shape = in_data.shape
    s_data = np.squeeze(in_data).astype("float32")
    alpha = 26.0/256 if relu == 2 else (3.0/256 if relu == 3 else (0 if relu == 1 else 1))
    if len(s_data.shape) == 0:
        s_data = np.where(s_data >= 0, s_data, s_data * alpha)
    else:
        for i in range(s_data.shape[0]):
            s_data[i] = np.where(s_data[i] >= 0, s_data[i], s_data[i] * alpha)
    s_data = f2i_round(s_data)
    return s_data.reshape(shape)

def get_data_checksum(data, slice_parts=[], info=""):
    shape = data.shape
    ndim  = len(shape)
    assert ndim <= 4
    shape_4d = [shape[x] for x in range(ndim)]
    for x in range(4 - ndim):
        shape_4d.append(1)
    data  = data.reshape((*shape_4d))
    assert len(data.shape) == 4

    # parts=[[0,10],[0,10],[0,10],[0,10]]
    # [0, 10]: 0:start idx, 10:slice len
    ndim = len(slice_parts)
    for x in range(4 - ndim):
        dim = x + ndim
        slice_parts.append([0, data.shape[dim]])

    # slice data
    sdata = data[slice_parts[0][0]: slice_parts[0][0] + slice_parts[0][1], \
                slice_parts[1][0]: slice_parts[1][0] + slice_parts[1][1], \
                slice_parts[2][0]: slice_parts[2][0] + slice_parts[2][1], \
                slice_parts[3][0]: slice_parts[3][0] + slice_parts[3][1]]

    fla_data = sdata.flatten()
    checksum = 0
    for i in range(fla_data.shape[0]):
        res = int(fla_data[i])
        res = res * (1 if i%2 else res)
        checksum += res
    print(" >> %8s for shape %s(%s) -> %s, ===> Checksum %s"\
        %(info, data.shape, slice_parts, sdata.shape, hex(checksum)))
    slice_parts.clear()

def read_tiling_config(filename=".tilingnode.log"):
    import json
    # tiling_json = {"unique_id": 0, "total_cycle":0, "attr_all_in_mem":0, "attr_inout_same_loc":0}

    readstr = []
    if not os.path.exists(filename):
        return []

    with open(filename, "r") as f:
        while True:
            rstr = f.readline()
            if not rstr:
                break
            readstr.append(rstr)

    tn_info_list = []
    for x in readstr:
        tiling_json = json.loads(x)
        tn_info_list.append(tiling_json)

    return tn_info_list

def write_tiling_config(tn_json, filename=".tilingnode.log"):
    import json
    json_str = json.dumps(tn_json)
    with open(filename, "a") as f:
        f.write(json_str + "\n")
