# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
# pylint: disable=unused-argument, invalid-name
"""XMNPU specific buildin for runtime."""
import tvm
from tvm.ir import register_intrin_lowering
from . import transform
from .environment import get_env, Environment


def EarlyRewrite():
    """Try to do storage rewrite in early pass."""

    def _transform(mod, ctx):
        try:
            return tvm.tir.transform.StorageRewrite()(mod)
        except tvm.error.TVMError:
            return mod

    return tvm.transform.module_pass(_transform, opt_level=0, name="tir.xmnpu.EarlyRewrite")

def build_config(build_mode=0, **kwargs):
    """Build a build config for XMNPU.

    Parameters
    ----------
    debug_flag : int
        The dbeug flag to be passed.

    kwargs : dict
        Additional configurations.

    Returns
    -------
    build_config: tvm.transform.PassContext
        The build config that can be used in TVM.

    Example
    --------
    .. code-block:: python

      # build a xmnpu module.
      with xmnpu.build_config():
          xmnpu_module = tvm.build(s, ...)
    """
    env = get_env()

    @tvm.tir.transform.prim_func_pass(opt_level=0)
    def add_debug(f, *_):
        debug = tvm.tir.call_extern("int32", "XMNPUSetDebugMode", env.dev.command_handle, build_mode)

        return f.with_body(tvm.tir.stmt_seq(debug, f.body))

    pass_list = [
        (0, transform.MergeReduceIntrin()),
        (0, transform.InjectNPUIntrin()),
        #(0, tvm.tir.transform.InjectNPUIntrin()),
        (1, transform.InjectNPUCoProcSync()),
    ]
    if build_mode:
        pass_list.append((1, add_debug))
    config = {"tir.add_lower_pass": pass_list}
    if kwargs.get("config"):
        config.update(kwargs["config"])
    
    if "config" in kwargs:
        del kwargs["config"]

    return tvm.transform.PassContext(config=config, **kwargs)

def build_config_old(build_mode=0, **kwargs):
    """Build a build config for XMNPU.

    Parameters
    ----------
    debug_flag : int
        The dbeug flag to be passed.

    kwargs : dict
        Additional configurations.

    Returns
    -------
    build_config: tvm.transform.PassContext
        The build config that can be used in TVM.

    Example
    --------
    .. code-block:: python

      # build a xmnpu module.
      with xmnpu.build_config():
          xmnpu_module = tvm.build(s, ...)
    """
    env = get_env()

    @tvm.tir.transform.prim_func_pass(opt_level=0)
    def add_debug(f, *_):
        debug = tvm.tir.call_extern("int32", "XMNPUSetDebugMode", env.dev.command_handle, build_mode)

        return f.with_body(tvm.tir.stmt_seq(debug, f.body))

    pass_list = [
        (0, transform.MergeReduceIntrin()),
        (1, transform.InjectDMALoadIntrin()),
        (1, transform.InjectDMAStoreIntrin()),
        #(1, transform.InjectSkipCopy()),
        (1, transform.AnnotateXMNPUCoProcScope()),
        (1, tvm.tir.transform.LiftAttrScope("coproc_uop_scope")),
        (0, transform.LiftAllocToScopeBegin()),
        (1, tvm.tir.transform.LiftAttrScope("coproc_scope")),
        (1, transform.InjectNPUCoProcSync()),
        (1, EarlyRewrite()),
    ]
    if build_mode:
        pass_list.append((0, add_debug))
    pass_list.append((2, transform.InjectConv2dIntrin()))
    pass_list.append((2, transform.InjectEltwiseAddIntrin()))
    pass_list.append((2, transform.InjectArithIntrin()))
    pass_list.append((2, transform.InjectConcatIntrin()))
    pass_list.append((2, transform.InjectNegIntrin()))
    pass_list.append((2, transform.InjectFCIntrin()))
    pass_list.append((2, transform.InjectGAPIntrin()))
    pass_list.append((2, transform.InjectPoolIntrin()))
    pass_list.append((2, transform.InjectUpsampleIntrin()))
    pass_list.append((2, transform.InjectScaleIntrin()))
    pass_list.append((2, transform.InjectSpaceToDepthIntrin()))
    pass_list.append((2, transform.InjectDepthToSpaceIntrin()))
    pass_list.append((2, transform.InjectBatchToSpaceNdIntrin()))
    pass_list.append((2, transform.InjectSpaceToBatchNdIntrin()))
    pass_list.append((2, transform.InjectLutIntrin()))
    pass_list.append((2, transform.InjectTileIntrin()))
    pass_list.append((2, transform.InjectTransposeIntrin()))
    pass_list.append((2, transform.InjectStridedSliceIntrin()))
    pass_list.append((2, transform.InjectYuv2rgbIntrin()))
    pass_list.append((3, tvm.tir.transform.LowerDeviceStorageAccessInfo()))
    #pass_list.append((3, transform.FoldUopLoop()))
    #pass_list.append((3, transform.CPUAccessRewrite()))
    config = {"tir.add_lower_pass": pass_list}
    if kwargs.get("config"):
        config.update(kwargs["config"])
    
    if "config" in kwargs:
        del kwargs["config"]

    return tvm.transform.PassContext(config=config, **kwargs)


def lower(*args, **kwargs):
    """Thin wrapper of tvm.lower

    This wrapper automatically applies XMNPU's build_config
    if there is no user specified build_config in context.

    See Also
    --------
    tvm.lower : The original TVM's lower function
    """
    pass_ctx = tvm.transform.PassContext.current()
    if not pass_ctx.config.get("add_lower_pass"):
        with build_config():
            return tvm.lower(*args, **kwargs)
    return tvm.lower(*args, **kwargs)


def build(*args, **kwargs):
    """Thin wrapper of tvm.build

    This wrapper automatically applies XMNPU's build_config
    if there is no user specified build_config in context.

    See Also
    --------
    tvm.build : The original TVM's build function
    """
    pass_ctx = tvm.transform.PassContext.current()
    mode = 0
    if not pass_ctx.config.get("tir.add_lower_pass"):
        if "build_mode" in kwargs:
            mode = kwargs["build_mode"]
            del kwargs["build_mode"]
        with build_config(build_mode=mode):
            return tvm.build(*args, **kwargs)
    return tvm.build(*args, **kwargs)


# Register key ops
tvm.ir.register_op_attr("tir.xmnpu.coproc_sync", "TCallEffectKind", tvm.tir.CallEffectKind.Opaque)
tvm.ir.register_op_attr("tir.xmnpu.coproc_dep_push", "TCallEffectKind", tvm.tir.CallEffectKind.Opaque)
tvm.ir.register_op_attr("tir.xmnpu.coproc_dep_pop", "TCallEffectKind", tvm.tir.CallEffectKind.Opaque)

tvm.ir.register_op_attr("tir.xmnpu.command_handle", "TGlobalSymbol", "XMNPUTLSCommandHandle")
tvm.ir.register_op_attr("tir.xmnpu.command_handle", "TCallEffectKind", tvm.tir.CallEffectKind.Opaque)

tvm.ir.register_op_attr("tir.xmnpu.yuv2rgb", "TCallEffectKind", tvm.tir.CallEffectKind.Opaque)
tvm.ir.register_op_attr("tir.xmnpu.yuv2rgb", "TGlobalSymbol", "XMNPUYuv2rgbOp")

'''
# The memory information for the compiler
@tvm.register_func("tvm.info.mem.%s" % Environment.inline_scope)
def mem_info_inp_buffer():
    spec = get_env()
    return tvm.ir.make_node(
        "MemoryInfo",
        unit_bits=0,
        max_simd_bits=0,
        max_num_bits=0,
        head_address=None,
    )
'''
# The memory information for the compiler
@tvm.register_func("tvm.info.mem.%s" % Environment.calc_scope)
def mem_info_inp_buffer():
    spec = get_env()
    return tvm.ir.make_node(
        "MemoryInfo",
        unit_bits=8,
        max_simd_bits=8,
        max_num_bits=spec.NPU_SRAM_FW_SIZE * 8,
        head_address=None,
    )


@tvm.register_func("tvm.info.mem.%s" % Environment.lut_scope)
def mem_info_wgt_buffer():
    spec = get_env()
    return tvm.ir.make_node(
        "MemoryInfo",
        unit_bits=8,
        max_simd_bits=8,
        max_num_bits=spec.NPU_SRAM_LUT_SIZE * 8,
        head_address=None,
    )


@tvm.register_func("tvm.info.mem.%s" % Environment.bias_scope)
def mem_info_acc_buffer():
    spec = get_env()
    return tvm.ir.make_node(
        "MemoryInfo",
        unit_bits=8,
        max_simd_bits=8,
        max_num_bits=spec.NPU_SRAM_BIAS_SIZE * 8,
        head_address=None,
    )


# TVM Op related registration
@register_intrin_lowering("tir.xmnpu.coproc_sync", "default")
def coproc_sync(op):
    _ = op
    return tvm.tir.call_extern(
        "int32",
        "XMNPUSynchronize",
        get_env().dev.command_handle,
        tvm.runtime.const(1 << 31, dtype="uint32"),
    )


@register_intrin_lowering("tir.xmnpu.coproc_dep_push", "default")
def coproc_dep_push(op):
    return tvm.tir.call_extern(
        "int32", "XMNPUDepPush", get_env().dev.command_handle, op.args[0], op.args[1]
    )


@register_intrin_lowering("tir.xmnpu.coproc_dep_pop", "default")
def coproc_dep_pop(op):
    return tvm.tir.call_extern(
        "int32", "XMNPUDepPop", get_env().dev.command_handle, op.args[0], op.args[1]
    )
