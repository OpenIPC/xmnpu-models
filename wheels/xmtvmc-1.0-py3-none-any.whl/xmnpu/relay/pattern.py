# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
# pylint: disable=invalid-name, unused-argument
"""Arm(R) Ethos(TM) -N NPU supported operators."""
from enum import Enum

import tvm.ir
from tvm import relay
from tvm.relay import transform
from tvm.relay.build_module import bind_params_by_name

from tvm.relay.dataflow_pattern import wildcard, is_op, is_constant, is_expr
from tvm.relay.op.contrib.register import register_pattern_table
from tvm.relay.dataflow_pattern import *
import xmnpu
import numpy as np
from tvm import topi

class Available(Enum):
    UNAVAILABLE = 0
    SW_ONLY = 1
    SW_AND_HW = 2

    def __bool__(self):
        return self != Available.UNAVAILABLE


def partition_for_xmnpu(mod, params=None, **opts):
    """Partition the graph greedily offloading supported
    operators to XMNPU NPU.

    Parameters
    ----------
    mod : Module
        The module to run passes on.
    params : Optional[Dict[str, NDArray]]
        Constant input parameters.

    Returns
    -------
    ret : annotated and partitioned module.
    """
    if params:
        mod["main"] = bind_params_by_name(mod["main"], params)

    seq = tvm.transform.Sequential(
        [
            transform.InferType(),
            transform.MergeComposite(pattern_table()),
            #transform.AnnotateTarget("xmnpu-105"),
            transform.MergeCompilerRegions(),
            transform.PartitionGraph(),
        ]
    )

    return seq(mod)

@register_pattern_table("xmnpu-105")
def pattern_table():
    """Get the XMNPU compiler pattern table."""

    def qnn_conv_pad_pattern():
        pattern = is_op("nn.pad")(wildcard(), wildcard())
        pattern = is_op("qnn.conv2d")(
            pattern, is_constant(), is_constant(), is_constant(), is_constant(), is_constant()
        )
        pattern = is_op("nn.bias_add")(pattern, is_constant()) | pattern
        pattern = is_op("nn.leaky_relu")(pattern) | pattern
        pattern = is_op("nn.relu")(pattern) | pattern
        pattern = is_op("qnn.requantize")(
            pattern, is_constant(), is_constant(), is_constant(), is_constant()
        )
        return pattern

    def qnn_conv_pattern():
        pattern = is_op("qnn.conv2d")(
            wildcard(), is_constant(), is_constant(), is_constant(), is_constant(), is_constant()
        )
        pattern = is_op("nn.bias_add")(pattern, is_constant()) | pattern
        pattern = is_op("nn.leaky_relu")(pattern) | pattern
        pattern = is_op("nn.relu")(pattern) | pattern
        pattern = is_op("qnn.requantize")(
            pattern, is_constant(), is_constant(), is_constant(), is_constant()
        )
        return pattern

    def qnn_dense_pattern():
        pattern = is_op("reshape")(wildcard()) | is_op("nn.batch_flatten")(wildcard()) | is_op("squeeze")(wildcard()) | wildcard()
        pattern = is_op("qnn.dense")(
            pattern, is_constant(), is_constant(), is_constant(), is_constant(), is_constant()
        )
        pattern = is_op("nn.bias_add")(pattern, is_constant()) | pattern
        pattern = is_op("qnn.requantize")(
            pattern, is_constant(), is_constant(), is_constant(), is_constant()
        )
        return pattern

    def qnn_eltwise_add_pattern():
        pattern = is_op("qnn.add")(
            wildcard(), wildcard(), is_constant(), is_constant(), is_constant(), is_constant(), is_constant(), is_constant()
        )
        return pattern

    def qnn_concat_pattern():
        pattern = is_op("qnn.concatenate")
        return pattern

    def qnn_avg_pool2d_pattern():
        # normal avg or global avg pool
        pattern_avg = is_op("cast")(wildcard())
        pattern_avg = is_op("nn.avg_pool2d")(pattern_avg)
        pattern_avg = is_op("cast")(pattern_avg)

        pattern_avg2 = is_op("cast")(wildcard())
        pattern_avg2 = is_op("mean")(pattern_avg2)
        pattern_avg2 = is_op("qnn.requantize")(
            pattern_avg2, is_constant(), is_constant(), is_constant(), is_constant()
        )

        pattern_avg3 = is_op("cast")(wildcard())
        pattern_avg3 = is_op("nn.global_avg_pool2d")(pattern_avg3)
        pattern_avg3 = is_op("cast")(pattern_avg3)

        return pattern_avg | pattern_avg2 | pattern_avg3

    def qnn_max_pool2d_pattern():
        pattern_max = is_op("nn.max_pool2d")(wildcard())
        return pattern_max

    def qnn_softmax_pattern():
        pattern = is_op("qnn.dequantize")(wildcard(), is_constant(), is_constant())
        pattern = is_op("nn.softmax")(pattern)
        pattern = is_op("qnn.quantize")(pattern, is_constant(), is_constant())

        return pattern

    return [
        ("xmnpu-105.conv2d_pad", qnn_conv_pad_pattern()),
        ("xmnpu-105.conv2d", qnn_conv_pattern()),
        ("xmnpu-105.dense",  qnn_dense_pattern()),
        ("xmnpu-105.avg_pool2d", qnn_avg_pool2d_pattern()),
        ("xmnpu-105.max_pool2d", qnn_max_pool2d_pattern()),
        #("xmnpu-105.concat", qnn_concat_pattern()),
        #("xmnpu-105.softmax", qnn_softmax_pattern()),
    ]

def UpdateNewWeight(weight, k_zp):
    weight_data = weight.data.asnumpy()
    k_zp        = k_zp.data.asnumpy()
    weight_data = weight_data.astype("int32") - k_zp
    weight_data = np.clip(weight_data, -128, 127)
    weight_data = weight_data.astype("int8")
    
    weight = relay.Constant(tvm.nd.array(weight_data))
    k_zp   = relay.Constant(tvm.nd.array(0))
    return weight, k_zp

def ReWriteRelayConv2d(post):
    conv_input      = post.args
    body_requantize = post.op.body
    body_relu, isc, i_zp, out_scale, o_zp = body_requantize.args
    relu_type = 0
    if body_relu.op.name == "nn.leaky_relu":
        import math
        alpha = body_relu.attrs.alpha
        body_bias_add = body_relu.args[0]
        if math.isclose(alpha, 0.1, abs_tol=1e-5):
            relu_type = 2
            print("Warning: we use leaky_relu's alpha is 26/256, but original alpha is %s"%(alpha))
        elif math.isclose(alpha, 0.01, abs_tol=1e-5) or math.isclose(alpha, 3.0/256, abs_tol=1e-5):
            relu_type = 3
            print("Warning: we use leaky_relu's alpha is 3/256, but original alpha is %s"%(alpha))
        else:
            assert 0
    elif body_relu.op.name == "nn.relu":
        relu_type = 1
        body_bias_add = body_relu.args[0]
    else:
        body_bias_add = body_relu

    using_bias = 0
    if body_bias_add.op.name == "nn.bias_add":
        using_bias = 1
        body_conv2d, bias              = body_bias_add.args
    else:
        body_conv2d = body_bias_add
        bias = relay.Constant(tvm.nd.array(0))
    body_padding, weight, i_zp, k_zp, input_scale, kernel_scale = body_conv2d.args

    if isinstance(conv_input, tvm.ir.container.Array):
        #if len(conv_input) > 1:
            #print(conv_input[0])
            #assert isinstance(conv_input[0], relay.Var)
        conv_input = conv_input[0]


    if isinstance(conv_input, relay.expr.Var):
        # set NHWC to NCHW
        if body_conv2d.attrs.data_layout == "NHWC":
            assert isinstance(conv_input, relay.expr.Var)
            new_shape = (conv_input.type_annotation.shape[0],
                        conv_input.type_annotation.shape[3],
                        conv_input.type_annotation.shape[1],
                        conv_input.type_annotation.shape[2])
            conv_input = relay.var(
                            name_hint=conv_input.name_hint,
                            shape=new_shape,
                            dtype=conv_input.type_annotation.dtype)
        elif body_conv2d.attrs.data_layout != "NCHW":
            # TODO
            print(body_conv2d.attrs.data_layout)
            assert 0
        #else:
        #    print(body_conv2d.attrs.data_layout)
        #    assert 0

    # get padding node info
    total_padding = list()
    for i in range(len(body_conv2d.attrs.padding)):
        total_padding.append(body_conv2d.attrs.padding[i])
    if isinstance(body_padding, relay.Call):
        padding = body_padding.attrs.pad_width
        assert body_conv2d.attrs.data_layout in ("NHWC", "NCHW")
        if body_conv2d.attrs.data_layout == "NHWC":
            assert padding[0][0] == 0 and padding[0][1] == 0 # padding n
            assert padding[3][0] == 0 and padding[3][1] == 0 # padding c
            padding = (padding[1][0], padding[2][0], padding[1][1], padding[2][1])
        elif body_conv2d.attrs.data_layout == "NCHW":
            assert padding[0][0] == 0 and padding[0][1] == 0 # padding n
            assert padding[1][0] == 0 and padding[1][1] == 0 # padding c
            padding = (padding[2][0], padding[3][0], padding[2][1], padding[3][1])
        assert len(padding) == len(body_conv2d.attrs.padding)
        for i in range(len(padding)):
            total_padding[i] += padding[i]

    weight, k_zp = UpdateNewWeight(weight, k_zp)
    if body_conv2d.attrs.kernel_layout == "HWIO":
        new_weight_data = np.transpose(weight.data.asnumpy(), axes=[3, 2, 0, 1])
        weight = relay.Constant(tvm.nd.array(new_weight_data))
        if len(bias.data.shape) != 1:
            assert 0
    elif body_conv2d.attrs.kernel_layout == "HWOI":
        new_weight_data = np.transpose(weight.data.asnumpy(), axes=[2, 3, 0, 1])
        weight = relay.Constant(tvm.nd.array(new_weight_data))
        if len(bias.data.shape) != 1:
            assert 0
    elif body_conv2d.attrs.kernel_layout == "OIHW":
        weight = weight
    else:
        print(body_conv2d.attrs.kernel_layout)
        assert 0
    #print("weight:", weight.data)
    #assert 0
    '''
    np_weight = weight.data.asnumpy()
    print(np_weight.shape)
    if np_weight.shape[0] == 128 and np_weight.shape[1] == 64:
        tmp_res = np_weight
        print("tmp_res: ", tmp_res.shape)
        for c in range(64):
            print(tmp_res[85][c][0][0], end=", ")
        print()
        print("bias: ", bias.data.asnumpy()[85])
        print(i_zp.data.asnumpy(), k_zp.data.asnumpy(), o_zp.data.asnumpy())
        print(scale.data.asnumpy().dtype, scale, float(i_s.data.asnumpy()), float(k_s.data.asnumpy()), float(osc.data.asnumpy()))

        scale2 = float(i_s.data.asnumpy()) * float(k_s.data.asnumpy()) / float(osc.data.asnumpy())
        print("%.20f" % scale2 )

        assert 0
    '''

    if isinstance(conv_input._checked_type_, tvm.ir.tensor_type.TensorType):
        in_shape = conv_input._checked_type_.shape
        weight_shape = weight.data.asnumpy().shape
        in_h = None
        in_w = None
        if body_conv2d.attrs.data_layout == "NHWC":
            in_h = in_shape[1]
            in_w = in_shape[2]
        elif body_conv2d.attrs.data_layout == "NCHW":
            in_h = in_shape[2]
            in_w = in_shape[3]
        k_h = weight_shape[2]
        k_w = weight_shape[3]
        if in_h == 1 and in_w == 1 and k_h == 1 and k_w == 1: # use dense
            weight = weight.data.asnumpy().reshape(weight_shape[0], weight_shape[1])
            weight = relay.Constant(tvm.nd.array(weight))

            xm_dense = xmnpu.relay.dense(
                            conv_input,
                            weight,
                            bias,
                            input_scale,
                            kernel_scale,
                            out_scale,
                            int(i_zp.data.asnumpy()),
                            int(k_zp.data.asnumpy()),
                            int(o_zp.data.asnumpy()),
                            using_bias,
                            body_requantize.attrs.out_dtype,
                            )
            return xm_dense

    weight_shape = weight.data.asnumpy().shape
    if body_conv2d.attrs.groups != 1 and \
            body_conv2d.attrs.groups != body_conv2d.attrs.channels and \
            body_conv2d.attrs.groups == weight_shape[0]:
        depth_multiplier = int(body_conv2d.attrs.channels // body_conv2d.attrs.groups)
        assert depth_multiplier == weight_shape[1]

        expr_list = []
        weight = weight.data.asnumpy().reshape(weight_shape[1], weight_shape[0],weight_shape[2], weight_shape[3])
        weight = weight.transpose((1,0,2,3))
        for i in range(depth_multiplier):
            new_weight = relay.Constant(tvm.nd.array(weight[:, slice(i, i+1), :, :]))
            new_bias   = relay.Constant(tvm.nd.array(
                    bias.data.asnumpy()[slice(i*body_conv2d.attrs.groups, (i+1)*body_conv2d.attrs.groups),]))
            xm_conv2d = xmnpu.relay.conv2d(
                            conv_input,
                            new_weight,
                            new_bias,
                            input_scale,
                            kernel_scale,
                            out_scale,
                            int(i_zp.data.asnumpy()),
                            int(k_zp.data.asnumpy()),
                            int(o_zp.data.asnumpy()),
                            body_conv2d.attrs.kernel_size,
                            body_conv2d.attrs.strides,
                            total_padding,
                            body_conv2d.attrs.dilation,
                            (0, 0),
                            using_bias,  # using bias
                            relu_type,   # relu_type
                            body_conv2d.attrs.groups,
                            "NCHW", # body_conv2d.attrs.data_layout,
                            "OIHW", # body_conv2d.attrs.kernel_layout,
                            "NCHW", # body_conv2d.attrs.out_layout,
                            body_requantize.attrs.out_dtype,
                            )
            expr_list.append(xm_conv2d)

        input_args0 = relay.Tuple(expr_list)
        new_expr  =  relay.op.concatenate(input_args0, axis=1)
        return new_expr


    xm_conv2d = xmnpu.relay.conv2d(
                    conv_input,
                    weight,
                    bias,
                    input_scale,
                    kernel_scale,
                    out_scale,
                    int(i_zp.data.asnumpy()),
                    int(k_zp.data.asnumpy()),
                    int(o_zp.data.asnumpy()),
                    body_conv2d.attrs.kernel_size,
                    body_conv2d.attrs.strides,
                    total_padding,
                    body_conv2d.attrs.dilation,
                    (0, 0),
                    using_bias,  # using bias
                    relu_type,   # relu_type
                    body_conv2d.attrs.groups,
                    "NCHW", # body_conv2d.attrs.data_layout,
                    "OIHW", # body_conv2d.attrs.kernel_layout,
                    "NCHW", # body_conv2d.attrs.out_layout,
                    body_requantize.attrs.out_dtype,
                    )
    return xm_conv2d


class XMEltwiseaddRelayRewrite(DFPatternCallback):
    def __init__(self):
        super(XMEltwiseaddRelayRewrite, self).__init__()
        pattern = is_op("qnn.add")(
            wildcard(), wildcard(), is_constant(), is_constant(), \
                is_constant(), is_constant(), is_constant(), is_constant()
        )
        self.pattern = pattern

    def callback(self, pre, post, node_map):
        lhs, rhs, lhs_scale, l_zp, rhs_scale, r_zp, out_scale, o_zp = post.args

        if isinstance(rhs, relay.Constant):
            if isinstance(lhs._checked_type_, tvm.ir.tensor_type.TensorType):
                data_shape  = topi.utils.get_const_tuple(lhs._checked_type_.shape)
            elif isinstance(lhs, tvm.relay.Call) and \
                    isinstance(lhs.args[0]._checked_type_, tvm.ir.tensor_type.TensorType):
                data_shape  = topi.utils.get_const_tuple(lhs.args[0]._checked_type_.shape)
            const_shape = topi.utils.get_const_tuple(rhs._checked_type_.shape)

            if len(const_shape) == 1:
                if const_shape[0] == data_shape[3]: # NHWC
                    data_shape = (data_shape[0], data_shape[3], data_shape[1], data_shape[2])
                elif const_shape[0] == data_shape[1]: #NCHW
                    data_shape = data_shape
                else:
                    assert 0
                new_rhs_data = rhs.data.asnumpy()
                zeros = np.zeros(data_shape, dtype=str(new_rhs_data.dtype))
                new_rhs_data = new_rhs_data.reshape(1, data_shape[1], 1, 1)
                new_rhs_data = new_rhs_data + zeros
                rhs = relay.Constant(tvm.nd.array(new_rhs_data))

        out_dtype = ""
        if isinstance(lhs._checked_type_, tvm.ir.tensor_type.TensorType):
            out_dtype = lhs._checked_type_.dtype
        if isinstance(rhs._checked_type_, tvm.ir.tensor_type.TensorType):
            out_dtype = rhs._checked_type_.dtype
        assert "int8" in out_dtype

        xm_eltadd = xmnpu.relay.eltwise_add(
                        lhs,
                        rhs,
                        lhs_scale,
                        rhs_scale,
                        out_scale,
                        int(l_zp.data.asnumpy()),
                        int(r_zp.data.asnumpy()),
                        int(o_zp.data.asnumpy()),
                        "NCHW",
                        out_dtype)
        return xm_eltadd

class XMLutActivationRewrite(DFPatternCallback):
    def __init__(self):
        super(XMLutActivationRewrite, self).__init__()
        self.act_map = {
            "qnn.tanh": xmnpu.relay.tanh,
            "qnn.sigmoid": xmnpu.relay.sigmoid,
            "qnn.silu": xmnpu.relay.silu,
            "qnn.mish": xmnpu.relay.mish,
        }

        pattern_list = []
        for act_name in self.act_map.keys():
            args_list = [wildcard(), is_constant(), is_constant(), is_constant(), is_constant()]
            pattern = is_op(act_name)(*args_list)
            pattern_list.append(pattern)

        from functools import reduce
        self.pattern = reduce(lambda x, y: x | y, pattern_list)

    def callback(self, pre, post, node_map):
        act_name = post.op.name
        func = self.act_map[act_name]

        data, in_scale, in_zero_point, out_scale, out_zero_point = post.args
        if isinstance(in_zero_point, tvm.relay.Constant):
            in_zero_point = in_zero_point.data.numpy().item()
        if isinstance(out_zero_point, tvm.relay.Constant):
            out_zero_point = out_zero_point.data.numpy().item()

        out = func(data, in_scale, out_scale, in_zero_point, out_zero_point)
        return out

class XMScaleRelayRewrite(DFPatternCallback):
    def __init__(self):
        super(XMScaleRelayRewrite, self).__init__()
        pattern = is_op("qnn.mul")(
            wildcard(), wildcard(), is_constant(), is_constant(), \
                is_constant(), is_constant(), is_constant(), is_constant()
        )
        self.pattern = pattern

    def callback(self, pre, post, node_map):
        lhs, rhs, lhs_scale, l_zp, rhs_scale, r_zp, out_scale, o_zp = post.args

        dtype = ""
        if isinstance(lhs._checked_type_, tvm.ir.tensor_type.TensorType):
            dtype = lhs._checked_type_.dtype
        elif isinstance(rhs._checked_type_, tvm.ir.tensor_type.TensorType):
            dtype = rhs._checked_type_.dtype
        elif isinstance(rhs._checked_type_, relay.Constant):
            dtype = rhs._checked_type_.dtype
        assert dtype != ""
        bias = relay.Constant(tvm.nd.array(0)),

        if isinstance(lhs, tvm.relay.expr.Constant):
            lhs, l_zp = UpdateNewWeight(lhs, l_zp)
        else:
            rhs, r_zp = UpdateNewWeight(rhs, r_zp)
        xm_scale = xmnpu.relay.scale(
                        lhs,
                        rhs,
                        bias,
                        lhs_scale,
                        rhs_scale,
                        out_scale,
                        int(l_zp.data.asnumpy()),
                        int(r_zp.data.asnumpy()),
                        int(o_zp.data.asnumpy()),
                        0,
                        0,
                        "NCHW",
                        dtype)
        return xm_scale

class XMMaxPool2DRelayRewrite(DFPatternCallback):
    def __init__(self):
        super(XMMaxPool2DRelayRewrite, self).__init__()
        self.pattern = wildcard().has_attr({"Composite": "xmnpu-105.max_pool2d"})(wildcard())

    def callback(self, pre, post, node_map):
        pool_input = post.args
        if isinstance(pool_input, tvm.ir.container.Array):
            assert len(pool_input) == 1
            pool_input = pool_input[0]
        body = post.op.body
        assert isinstance(body, relay.expr.Call)
        pool_size = body.attrs.pool_size
        padding   = body.attrs.padding
        strides   = body.attrs.strides
        layout    = body.attrs.layout
        out_dtype = body.checked_type.dtype
        in_dtype  = body.args[0].type_annotation.dtype
        in_shape  = body.args[0].type_annotation.shape
        dilation  = body.attrs.dilation
        ceil_mode = body.attrs.ceil_mode
        assert np.prod(np.array(dilation)) == 1
        if ceil_mode:
            from tvm.relay.op.nn.utils import get_pad_tuple2d
            pad_h_t, pad_w_l, pad_h_b, pad_w_r = get_pad_tuple2d(padding)
            padding = [pad_h_t, pad_w_l, pad_h_b, pad_w_r]
            padding[2] += (strides[0] - 1)
            padding[3] += (strides[1] - 1)

        if (pool_size[0] == 1 and pool_size[1] == 1) or \
              (pool_size[0] == 2 and pool_size[1] == 2) or \
              (pool_size[0] == 3 and pool_size[1] == 3):
            xm_max_pool2d = xmnpu.relay.pool2d(
                             pool_input,
                             0,
                             0,
                             pool_size,
                             strides,
                             padding,
                             "NCHW",
                             0,           # max pool
                             out_dtype)
            return xm_max_pool2d
        else:
            raise ValueError("not support pool when input{} and pool size{}."\
                            .format(in_shape, pool_size))


class XMAvgPool2DRelayRewrite(DFPatternCallback):
    def __init__(self):
        super(XMAvgPool2DRelayRewrite, self).__init__()
        self.pattern = wildcard().has_attr({"Composite": "xmnpu-105.avg_pool2d"})(wildcard())

    def callback(self, pre, post, node_map):
        pool_input = post.args
        if isinstance(pool_input, tvm.ir.container.Array):
            assert len(pool_input) == 1
            pool_input = pool_input[0]

        body1 = post.op.body
        assert isinstance(body1, relay.expr.Call)
        if body1.op.name == "qnn.requantize":
            # cast + mean + qnn.requantize
            # assert len(body1.args) == 5
            body_mean = body1.args[0]
            i_zp      = body1.args[1]
            o_zp      = body1.args[2]
            out_dtype = body1.attrs.out_dtype
            out_shape = body_mean.checked_type.shape
            assert body_mean.op.name == "mean"
            axis = body_mean.attrs.axis
            body_cast = body_mean.args[0]
            # assert out_dtype
            in_shape  = body_cast.args[0].type_annotation.shape
            assert len(axis) == 2
            pool_size = list()
            pool_size.append(in_shape[int(axis[0])])
            pool_size.append(in_shape[int(axis[1])])

            xm_gap = xmnpu.relay.global_avg_pool2d(
                             pool_input,
                             int(i_zp.data.asnumpy()),
                             int(o_zp.data.asnumpy()),
                             pool_size,
                             "NCHW",
                             out_dtype)
            return xm_gap
        else:
            # cast + nn.avg_pool2d + cast
            assert body1.op.name == "cast"
            out_dtype = body1.attrs.dtype
            body_pool = body1.args[0]
            if body_pool.op.name == "nn.avg_pool2d":
                pool_size = body_pool.attrs.pool_size
                padding   = body_pool.attrs.padding
                strides   = body_pool.attrs.strides
                layout    = body_pool.attrs.layout
                dilation  = body_pool.attrs.dilation
                body_in_cast = body_pool.args[0]
                ceil_mode = body_pool.attrs.ceil_mode
                assert np.prod(np.array(dilation)) == 1
                if ceil_mode:
                    from tvm.relay.op.nn.utils import get_pad_tuple2d
                    pad_h_t, pad_w_l, pad_h_b, pad_w_r = get_pad_tuple2d(padding)
                    padding = [pad_h_t, pad_w_l, pad_h_b, pad_w_r]
                    padding[2] += (strides[0] - 1)
                    padding[3] += (strides[1] - 1)

                in_dtype  = body_in_cast.args[0].type_annotation.dtype
                in_shape  = body_in_cast.args[0].type_annotation.shape
                out_shape = body_pool.checked_type.shape
                assert out_dtype == in_dtype

                if (layout == "NCHW" and out_shape[2] == 1 and out_shape[3] == 1) or \
                    (layout == "NHWC" and out_shape[1] == 1 and out_shape[2] == 1) :
                    # TODO FIX pool_size != input size
                    xm_gap = xmnpu.relay.global_avg_pool2d(
                                    pool_input,
                                    0,
                                    0,
                                    pool_size,
                                    "NCHW",
                                    out_dtype)
                    return xm_gap
                elif pool_size[0] == 2 or pool_size[0] == 3:
                    xm_avg = xmnpu.relay.pool2d(
                                    pool_input,
                                    0,
                                    0,
                                    pool_size,
                                    strides,
                                    padding,
                                    "NCHW",
                                    1,  # avg pool
                                    out_dtype)
                    return xm_avg
                else:
                    raise ValueError("not support pool when input{} and pool size{}."\
                                    .format(in_shape, pool_size))
                    assert 0
            else:
                assert body_pool.op.name == "nn.global_avg_pool2d"
                assert isinstance(body_pool.args[0]._checked_type_, tvm.ir.tensor_type.TensorType)
                in_shape = body_pool.args[0]._checked_type_.shape
                layout   = body_pool.attrs.layout
                if layout == "NCHW":
                    pool_size = [int(in_shape[2]), int(in_shape[3])]
                else:
                    assert layout == "NHWC"
                    pool_size = [int(in_shape[1]), int(in_shape[2])]
                xm_gap = xmnpu.relay.global_avg_pool2d(
                                pool_input,
                                0,
                                0,
                                pool_size,
                                "NCHW",
                                out_dtype)
                return xm_gap
        return post

class XMConv2DPadRelayRewrite(DFPatternCallback):
    def __init__(self):
        super(XMConv2DPadRelayRewrite, self).__init__()
        self.pattern = wildcard().has_attr({"Composite": "xmnpu-105.conv2d_pad"})(wildcard(), wildcard())

    def callback(self, pre, post, node_map):
        #得到func + (call的args)的一个大call
        #print("\n\n-----pre-----")
        #print(pre)
        #print("-----post-----")
        #print(post)
        #print("-------------")
        xm_conv2d = ReWriteRelayConv2d(post)
        return xm_conv2d

class XMConv2DRelayRewrite(DFPatternCallback):
    def __init__(self):
        super(XMConv2DRelayRewrite, self).__init__()
        self.pattern = wildcard().has_attr({"Composite": "xmnpu-105.conv2d"})(wildcard())

    def callback(self, pre, post, node_map):
        #得到func + (call的args)的一个大call
        #print("\n\n-----pre-----")
        #print(pre)
        #print("-----post-----")

        xm_conv2d = ReWriteRelayConv2d(post)
        return xm_conv2d

class XMDenseRelayRewrite(DFPatternCallback):
    def __init__(self):
        super(XMDenseRelayRewrite, self).__init__()
        self.pattern = wildcard().has_attr({"Composite": "xmnpu-105.dense"})(wildcard())

    def callback(self, pre, post, node_map):

        #print(post)
        #print("-------------")

        dense_input     = post.args
        body_requantize = post.op.body
        body_bias_add, isc, i_zp, out_scale, o_zp = body_requantize.args
        using_bias = 0
        if body_bias_add.op.name == "nn.bias_add":
            using_bias = 1
            body_dense, bias              = body_bias_add.args
        else:
            body_dense = body_bias_add
            bias = relay.Constant(tvm.nd.array(0))
        dense_body, weight, i_zp, k_zp, input_scale, kernel_scale = body_dense.args
        if not isinstance(dense_body, relay.expr.Var):
            assert dense_body.op.name == "reshape" or dense_body.op.name == "nn.batch_flatten" \
                or dense_body.op.name == "squeeze"

        if isinstance(dense_input, tvm.ir.container.Array):
            dense_input = dense_input[0]

        weight, k_zp = UpdateNewWeight(weight, k_zp)
        if isinstance(body_dense._checked_type_, tvm.ir.tensor_type.TensorType):
            out_shape = body_dense._checked_type_.shape
            weight_shape = weight.data.asnumpy().shape
            assert body_dense.attrs.units == out_shape[-1]
            assert body_dense.attrs.units == weight_shape[0]

        # TODO input is 4D and h/w is not = 1,need reshape weight
        xm_dense = xmnpu.relay.dense(
                        dense_input,
                        weight,
                        bias,
                        input_scale,
                        kernel_scale,
                        out_scale,
                        int(i_zp.data.asnumpy()),
                        int(k_zp.data.asnumpy()),
                        int(o_zp.data.asnumpy()),
                        using_bias,
                        body_requantize.attrs.out_dtype,
                        )
        return xm_dense

class XMConcatScaleRewrite(DFPatternCallback):
    def __init__(self):
        super(XMConcatScaleRewrite, self).__init__()
        self.pattern = is_op("qnn.concatenate")(None)

    def callback(self, pre, post, node_map):
        ins, scales, zps, os, ozp = post.args

        def _get_new_requantize(expr, out_scale, out_zp):
            assert isinstance(expr, relay.Call)
            if expr.op.name == "qnn.requantize":
                assert int(ozp.data.asnumpy()) == 0
                assert int(expr.args[4].data.asnumpy()) == 0
                new_scale = float(out_scale.data.asnumpy())
                new_zp    = int(out_zp.data.asnumpy()) - int(expr.args[4].data.asnumpy())
                new_expr  =  relay.qnn.op.requantize(
                                expr.args[0],
                                expr.args[1],
                                expr.args[2],
                                relay.Constant(tvm.nd.array(np.array(new_scale, dtype="float32"))),  # out scale
                                relay.Constant(tvm.nd.array(np.array(new_zp, dtype="int32"))),  # out zp
                                expr.attrs.axis,
                                expr.attrs.rounding,
                                expr.attrs.compute_dtype,
                                expr.attrs.out_dtype)
            else:
                # TODO: scale
                #print(expr.op.name)
                #assert expr.op.name == "nn.max_pool2d" or expr.op.name == "nn.max_pool2d"
                new_expr = expr
            return new_expr

        def _rewrite_scale(expr):
            assert isinstance(expr, relay.Call)
            assert expr.op.name == "qnn.concatenate"
            new_expr = []
            for i in range(len(expr.args[0])):
                new_expr.append(
                    _get_new_requantize(expr.args[0][i], os, ozp)
                )
            expr_args0 = relay.Tuple([x for x in new_expr])
            expr_args1 = relay.Tuple([os for x in expr.args[1]])
            expr_args2 = relay.Tuple([ozp for x in expr.args[2]])
            return relay.qnn.op.concatenate(
                    expr_args0,
                    expr_args1,
                    expr_args2,
                    expr.args[3],
                    expr.args[4],
                    expr.attrs.axis)

        new_concat = _rewrite_scale(post)

        return new_concat

class XMConcatRelayRewrite(DFPatternCallback):
    def __init__(self):
        super(XMConcatRelayRewrite, self).__init__()
        self.pattern = is_op("qnn.concatenate")(None)

    def callback(self, pre, post, node_map):
        #得到func + (call的args)的一个大call
        #print("\n\n-----pre-----")
        #print(pre)
        #print("-----post-----")
        #print(post)
        #print("-------------")

        axis = post.attrs.axis
        if axis == 3:
            axis = 1

        # must same scale and zp
        for i in range(len(post.args[1])):
            correct = np.allclose(
                        post.args[1][0].data.asnumpy(),
                        post.args[1][i].data.asnumpy(),
                        rtol=1e-5, atol=1e-5)
            if not correct:
                print("Concat Need same scale, but %s != %s"%( \
                         post.args[1][0].data.asnumpy(), post.args[1][i].data.asnumpy()))
                assert 0
        for i in range(len(post.args[2])):
            if not correct:
                print("Concat Need same zp, but %s != %s"%( \
                         post.args[2][0].data.asnumpy(), post.args[2][i].data.asnumpy()))
                assert 0

        return relay.qnn.op.concatenate(
                        post.args[0],
                        post.args[1],
                        post.args[2],
                        post.args[3],
                        post.args[4],
                        axis=axis)

        xm_concat = xmnpu.relay.concat(
                        post.args[0],
                        axis=axis)
        return xm_concat


def ReWriteConcatScale(mod):
    rewrite_func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod
    rewrite_func = xmnpu.relay.pattern.XMConcatScaleRewrite().rewrite(rewrite_func)
    mod = relay.Function(relay.analysis.free_vars(rewrite_func.body), rewrite_func.body)
    mod = tvm.IRModule.from_expr(mod)

    return mod

def ReWriteRelayQNN2XMIR(mod):
    rewrite_func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod
    rewrite_func = xmnpu.relay.pattern.XMEltwiseaddRelayRewrite().rewrite(rewrite_func)
    rewrite_func = xmnpu.relay.pattern.XMScaleRelayRewrite().rewrite(rewrite_func)
    rewrite_func = xmnpu.relay.pattern.XMConv2DPadRelayRewrite().rewrite(rewrite_func)
    rewrite_func = xmnpu.relay.pattern.XMConv2DRelayRewrite().rewrite(rewrite_func)
    rewrite_func = xmnpu.relay.pattern.XMAvgPool2DRelayRewrite().rewrite(rewrite_func)
    rewrite_func = xmnpu.relay.pattern.XMMaxPool2DRelayRewrite().rewrite(rewrite_func)
    rewrite_func = xmnpu.relay.pattern.XMDenseRelayRewrite().rewrite(rewrite_func)
    rewrite_func = xmnpu.relay.pattern.XMConcatRelayRewrite().rewrite(rewrite_func)
    rewrite_func = xmnpu.relay.pattern.XMLutActivationRewrite().rewrite(rewrite_func)
    mod = relay.Function(relay.analysis.free_vars(rewrite_func.body), rewrite_func.body)
    mod = tvm.IRModule.from_expr(mod)

    return mod


def ReWriteXMConv2dLayout(post, current_layout, target_layout):
    if current_layout == "NCHW":
        if target_layout == "NCHW":
            return post
        else:
            var_input = [0, 2, 3, 1]  # input is NCHW  ->  NHWC
            # XMIR is always HWIO when depthwise
            kernel_layout = "HWIO"
            new_axes = [2, 3, 1, 0]
    else:
        assert current_layout == "NHWC"
        if target_layout == "NCHW":
            var_input = [0, 3, 1, 2]   # input is NHWC  ->  NCHW
            kernel_layout = "OIHW"
            new_axes = [3, 2, 0, 1]    # HWIO --> OIHW
        else:
            return post

    assert isinstance(post, relay.Call)
    weight   = post.args[1]
    new_weight_data = np.transpose(weight.data.asnumpy(), axes=new_axes)
    weight = relay.Constant(tvm.nd.array(new_weight_data))
    if len(post.args[2].data.shape) != 1 and post.attrs.using_bias:
        assert 0

    conv_input = post.args[0]
    if isinstance(conv_input, relay.Var):
        new_shape = (conv_input.type_annotation.shape[var_input[0]],
                    conv_input.type_annotation.shape[var_input[1]],
                    conv_input.type_annotation.shape[var_input[2]],
                    conv_input.type_annotation.shape[var_input[3]])
        conv_input = relay.var(
                        name_hint=conv_input.name_hint,
                        shape=new_shape,
                        dtype=conv_input.type_annotation.dtype)

    xm_conv2d = xmnpu.relay.conv2d(
                    conv_input,
                    weight,
                    post.args[2],
                    post.attrs.input_scale,
                    post.attrs.kernel_scale,
                    post.attrs.output_scale,
                    post.attrs.input_zero_point,
                    post.attrs.kernel_zero_point,
                    post.attrs.output_zero_point,
                    post.attrs.kernel_size,
                    post.attrs.strides,
                    post.attrs.padding,
                    post.attrs.dilation,
                    post.attrs.ins,
                    post.attrs.using_bias,
                    post.attrs.relu_type,
                    post.attrs.groups,
                    target_layout,    # data_layout,
                    kernel_layout,    # kernel_layout,
                    target_layout,    # out_layout,
                    post.attrs.out_dtype,
                    )
    return xm_conv2d

class XMScaleRelayNCHWLayout(DFPatternCallback):
    def __init__(self):
        super(XMScaleRelayNCHWLayout, self).__init__()
        self.pattern = is_op("xm.scale")(None)

    def callback(self, pre, post, node_map):
        return xmnpu.relay.scale(
                            post.args[0],
                            post.args[1],
                            post.args[2],
                            post.attrs.input_scale,
                            post.attrs.kernel_scale,
                            post.attrs.output_scale,
                            post.attrs.input_zero_point,
                            post.attrs.kernel_zero_point,
                            post.attrs.output_zero_point,
                            post.attrs.using_bias,
                            post.attrs.relu_type,
                            "NCHW",
                            post.attrs.out_dtype)

class XMConv2DRelayNCHWLayout(DFPatternCallback):
    def __init__(self):
        super(XMConv2DRelayNCHWLayout, self).__init__()
        self.pattern = is_op("xm.conv2d")(None)

    def callback(self, pre, post, node_map):
        return ReWriteXMConv2dLayout(post, post.attrs.data_layout, "NCHW")

class XMConcatRelayNCHWLayout(DFPatternCallback):
    def __init__(self):
        super(XMConcatRelayNCHWLayout, self).__init__()
        self.pattern = is_op("qnn.concatenate")(None) | is_op("concatenate")(None)

    def callback(self, pre, post, node_map):
        if post.op.name == "concatenate":
            return relay.op.concatenate(
                            post.args[0],
                            axis=1)
        else:
            return relay.qnn.op.concatenate(
                            post.args[0],
                            post.args[1],
                            post.args[2],
                            post.args[3],
                            post.args[4],
                            axis=1)

class XMEltwiseAddNCHWLayout(DFPatternCallback):
    def __init__(self):
        super(XMEltwiseAddNCHWLayout, self).__init__()
        self.pattern = is_op("xm.eltwise_add")(None)

    def callback(self, pre, post, node_map):
        lhs = post.args[0]
        rhs = post.args[1]
        if isinstance(rhs, relay.Constant):
            new_rhs_data = rhs.data.asnumpy()
            assert new_rhs_data.ndim == 4
            if post.attrs.layout == "NHWC":
                new_rhs_data = np.transpose(new_rhs_data, axes=[0, 3, 1, 2])
                rhs = relay.Constant(tvm.nd.array(new_rhs_data))

        xm_eltadd = xmnpu.relay.eltwise_add(
                        lhs,
                        rhs,
                        post.attrs.lhs_scale,
                        post.attrs.rhs_scale,
                        post.attrs.out_scale,
                        post.attrs.lhs_zero_point,
                        post.attrs.rhs_zero_point,
                        post.attrs.output_zero_point,
                        "NCHW",
                        post.attrs.out_dtype)
        return xm_eltadd

class XMPool2DRelayNCHWLayout(DFPatternCallback):
    def __init__(self):
        super(XMPool2DRelayNCHWLayout, self).__init__()
        self.pattern = is_op("xm.pool2d")(None)

    def callback(self, pre, post, node_map):
        return xmnpu.relay.pool2d(
                            post.args[0],
                            post.attrs.input_zero_point,
                            post.attrs.output_zero_point,
                            post.attrs.pool_size,
                            post.attrs.strides,
                            post.attrs.padding,
                            "NCHW",
                            post.attrs.pool_type,
                            post.attrs.out_dtype)

class XMGAPRelayNCHWLayout(DFPatternCallback):
    def __init__(self):
        super(XMGAPRelayNCHWLayout, self).__init__()
        self.pattern = is_op("xm.global_avg_pool2d")(None)

    def callback(self, pre, post, node_map):
        return xmnpu.relay.global_avg_pool2d(
                            post.args[0],
                            post.attrs.input_zero_point,
                            post.attrs.output_zero_point,
                            post.attrs.pool_size,
                            "NCHW",
                            post.attrs.out_dtype)

class XMScaleRelayNHWCLayout(DFPatternCallback):
    def __init__(self):
        super(XMScaleRelayNHWCLayout, self).__init__()
        self.pattern = is_op("xm.scale")(None)

    def callback(self, pre, post, node_map):
        return xmnpu.relay.scale(
                            post.args[0],
                            post.args[1],
                            post.args[2],
                            post.attrs.input_scale,
                            post.attrs.kernel_scale,
                            post.attrs.output_scale,
                            post.attrs.input_zero_point,
                            post.attrs.kernel_zero_point,
                            post.attrs.output_zero_point,
                            post.attrs.using_bias,
                            post.attrs.relu_type,
                            "NHWC",
                            post.attrs.out_dtype)

class XMConv2DRelayNHWCLayout(DFPatternCallback):
    def __init__(self):
        super(XMConv2DRelayNHWCLayout, self).__init__()
        self.pattern = is_op("xm.conv2d")(None)

    def callback(self, pre, post, node_map):
        return ReWriteXMConv2dLayout(post, post.attrs.data_layout, "NHWC")

class XMConcatRelayNHWCLayout(DFPatternCallback):
    def __init__(self):
        super(XMConcatRelayNHWCLayout, self).__init__()
        self.pattern = is_op("qnn.concatenate")(None) | is_op("concatenate")(None)

    def callback(self, pre, post, node_map):
        if post.op.name == "concatenate":
            return relay.op.concatenate(
                            post.args[0],
                            axis=3)
        else:
            return relay.qnn.op.concatenate(
                            post.args[0],
                            post.args[1],
                            post.args[2],
                            post.args[3],
                            post.args[4],
                            axis=3)

class XMEltwiseAddNHWCLayout(DFPatternCallback):
    def __init__(self):
        super(XMEltwiseAddNHWCLayout, self).__init__()
        self.pattern = is_op("xm.eltwise_add")(None)

    def callback(self, pre, post, node_map):
        lhs = post.args[0]
        rhs = post.args[1]
        if isinstance(rhs, relay.Constant):
            new_rhs_data = rhs.data.asnumpy()
            assert new_rhs_data.ndim == 4
            if post.attrs.layout == "NCHW":
                new_rhs_data = np.transpose(new_rhs_data, axes=[0, 2, 3, 1])
                rhs = relay.Constant(tvm.nd.array(new_rhs_data))

        xm_eltadd = xmnpu.relay.eltwise_add(
                        lhs,
                        rhs,
                        post.attrs.lhs_scale,
                        post.attrs.rhs_scale,
                        post.attrs.out_scale,
                        post.attrs.lhs_zero_point,
                        post.attrs.rhs_zero_point,
                        post.attrs.output_zero_point,
                        "NHWC",
                        post.attrs.out_dtype)
        return xm_eltadd

class XMPool2DRelayNHWCLayout(DFPatternCallback):
    def __init__(self):
        super(XMPool2DRelayNHWCLayout, self).__init__()
        self.pattern = is_op("xm.pool2d")(None)

    def callback(self, pre, post, node_map):
        return xmnpu.relay.pool2d(
                            post.args[0],
                            post.attrs.input_zero_point,
                            post.attrs.output_zero_point,
                            post.attrs.pool_size,
                            post.attrs.strides,
                            post.attrs.padding,
                            "NHWC",
                            post.attrs.pool_type,
                            post.attrs.out_dtype)

class XMGAPRelayNHWCLayout(DFPatternCallback):
    def __init__(self):
        super(XMGAPRelayNHWCLayout, self).__init__()
        self.pattern = is_op("xm.global_avg_pool2d")(None)

    def callback(self, pre, post, node_map):
        return xmnpu.relay.global_avg_pool2d(
                            post.args[0],
                            post.attrs.input_zero_point,
                            post.attrs.output_zero_point,
                            post.attrs.pool_size,
                            "NHWC",
                            post.attrs.out_dtype)

def ReWriteRelayLayout(mod, target_layout="NCHW"):
    rewrite_func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod
    assert isinstance(rewrite_func, relay.function.Function)
    #body = xmrelaylayout(func.body, target_layout)

    if target_layout == "NCHW":
        rewrite_func = xmnpu.relay.pattern.XMConv2DRelayNCHWLayout().rewrite(rewrite_func)
        rewrite_func = xmnpu.relay.pattern.XMScaleRelayNCHWLayout().rewrite(rewrite_func)
        rewrite_func = xmnpu.relay.pattern.XMPool2DRelayNCHWLayout().rewrite(rewrite_func)
        rewrite_func = xmnpu.relay.pattern.XMGAPRelayNCHWLayout().rewrite(rewrite_func)
        rewrite_func = xmnpu.relay.pattern.XMEltwiseAddNCHWLayout().rewrite(rewrite_func)
        rewrite_func = xmnpu.relay.pattern.XMConcatRelayNCHWLayout().rewrite(rewrite_func)
    else:
        rewrite_func = xmnpu.relay.pattern.XMConv2DRelayNHWCLayout().rewrite(rewrite_func)
        rewrite_func = xmnpu.relay.pattern.XMScaleRelayNHWCLayout().rewrite(rewrite_func)
        rewrite_func = xmnpu.relay.pattern.XMPool2DRelayNHWCLayout().rewrite(rewrite_func)
        rewrite_func = xmnpu.relay.pattern.XMGAPRelayNHWCLayout().rewrite(rewrite_func)
        rewrite_func = xmnpu.relay.pattern.XMEltwiseAddNHWCLayout().rewrite(rewrite_func)
        rewrite_func = xmnpu.relay.pattern.XMConcatRelayNHWCLayout().rewrite(rewrite_func)

    mod = relay.Function(relay.analysis.free_vars(rewrite_func.body), rewrite_func.body)
    mod = tvm.IRModule.from_expr(mod)

    return mod



class XMEltwiseadd2RelayNN(DFPatternCallback):
    def __init__(self):
        super(XMEltwiseadd2RelayNN, self).__init__()
        self.pattern = is_op("xm.eltwise_add")(None)

    def callback(self, pre, post, node_map):
        lhs = relay.cast(post.args[0], "int32")
        rhs = relay.cast(post.args[1], "int32")
        if post.attrs.lhs_zero_point != 0:
            lhs   = relay.op.subtract(
                            lhs,
                            relay.const(post.attrs.lhs_zero_point, "int32"))
        if post.attrs.rhs_zero_point != 0:
            if isinstance(post.args[1], relay.Constant):
                rhs = post.args[1].data.asnumpy()
                rhs = rhs.astype("int32") - post.attrs.rhs_zero_point
                rhs = relay.Constant(tvm.nd.array(rhs))
            else:
                rhs   = relay.op.subtract(
                            rhs,
                            relay.const(post.attrs.rhs_zero_point, "int32"))

        lhs_quant_coeff = post.attrs.lhs_scale.data.asnumpy()
        rhs_quant_coeff = post.attrs.rhs_scale.data.asnumpy()
        assert lhs_quant_coeff.ndim == 2
        assert rhs_quant_coeff.ndim == 2

        if lhs_quant_coeff.shape[1] == 1:
            assert isinstance(lhs_quant_coeff[0][0], (int, np.int32))
            lhs = relay.op.fixed_point_multiply(
                        lhs,
                        lhs_quant_coeff[0][0],
                        31 - lhs_quant_coeff[1][0])
        else:
            #per - channel for mul+shift
            assert 0

        if rhs_quant_coeff.shape[1] == 1:
            assert isinstance(rhs_quant_coeff[0][0], (int, np.int32))
            rhs = relay.op.fixed_point_multiply(
                        rhs,
                        rhs_quant_coeff[0][0],
                        31 - rhs_quant_coeff[1][0])
        else:
            #per - channel for mul+shift
            assert 0

        func = relay.add(lhs, rhs)

        if post.attrs.output_zero_point != 0:
            func = relay.add(func, relay.const(post.attrs.output_zero_point, "int32"))

        if post.attrs.out_dtype == "uint8":
            func = relay.clip(func, 0, 255)
        else:
            assert post.attrs.out_dtype == "int8"
            func = relay.clip(func, -128, 127)
        func = relay.cast(func, post.attrs.out_dtype)
        return func

class XMScale2RelayNN(DFPatternCallback):
    def __init__(self):
        super(XMScale2RelayNN, self).__init__()
        self.pattern = is_op("xm.scale")(None)

    def callback(self, pre, post, node_map):
        data   = relay.cast(post.args[0], "int32")

        weight = post.args[1].data.asnumpy()
        if post.attrs.data_layout.index("C") == 1: #NCHW
            new_weight_data = np.reshape(weight.astype("int32"), (1, weight.shape[0], 1, 1))
            weight = relay.Constant(tvm.nd.array(new_weight_data))

        weight_data = post.args[1].data.asnumpy()
        assert weight_data.ndim == 1

        if post.attrs.input_zero_point != 0:
            data   = relay.op.subtract(
                            data,
                            relay.const(post.attrs.input_zero_point, "int32"))
        if post.attrs.kernel_zero_point != 0:
            weight = weight.data.asnumpy()
            weight = weight.astype("int32") - post.attrs.kernel_zero_point
            weight = relay.Constant(tvm.nd.array(weight))
        elif post.attrs.data_layout.index("C") != 1:
            weight = relay.cast(post.args[1], "int32")

        func = relay.op.multiply(data, weight)

        if post.attrs.using_bias:
            axis_idx = post.attrs.data_layout.index("C")
            func = relay.op.nn.bias_add(func, post.args[2], axis=axis_idx)

        quant_coeff = post.attrs.output_scale.data.asnumpy()
        assert quant_coeff.ndim == 2
        # mul+shift quantization
        if quant_coeff.shape[1] == 1:
            assert isinstance(quant_coeff[0][0], (int, np.int32))
            func = relay.op.fixed_point_multiply(
                        func,
                        quant_coeff[0][0],
                        31 - quant_coeff[1][0])
        else:
            #per - channel for mul+shift
            assert 0

        if post.attrs.relu_type == 1:
            func = relay.op.nn.relu(func)
        elif post.attrs.relu_type >= 2:
            pos = relay.maximum(func, relay.const(0, "int32"))
            neg = relay.minimum(func, relay.const(0, "int32"))
            multiplier = 3 if (post.attrs.relu_type == 3) else 26 # 0.1 = 26/256  0.01 = 3/256
            shift = 8
            neg  = relay.op.fixed_point_multiply(neg, multiplier, 31 - shift)
            func = relay.add(pos, neg)

        if post.attrs.output_zero_point != 0:
            func = relay.add(func, relay.const(post.attrs.output_zero_point, "int32"))

        if post.attrs.out_dtype == "uint8":
            func = relay.clip(func, 0, 255)
        else:
            assert post.attrs.out_dtype == "int8"
            func = relay.clip(func, -128, 127)
        func = relay.cast(func, post.attrs.out_dtype)
        return func

class XMConv2D2RelayNN(DFPatternCallback):
    def __init__(self):
        super(XMConv2D2RelayNN, self).__init__()
        self.pattern = is_op("xm.conv2d")(None)

    def callback(self, pre, post, node_map):
        assert post.attrs.data_layout   == "NHWC" or post.attrs.data_layout   == "NCHW"
        assert post.attrs.kernel_layout == "HWIO" or post.attrs.kernel_layout == "OIHW"
        weight_shape   = post.args[1].data.asnumpy().shape
        channel_idx = post.attrs.kernel_layout.index("O")
        assert channel_idx >= 0

        data   = relay.cast(post.args[0], "int32")
        weight = post.args[1]
        if post.attrs.input_zero_point != 0:
            data   = relay.op.subtract(
                            data,
                            relay.const(post.attrs.input_zero_point, "int32"))

        kernel_layout = post.attrs.kernel_layout
        if post.attrs.groups != 1 and kernel_layout == "HWIO":
            kernel_layout = "HWOI"
            new_weight_data = np.transpose(weight.data.asnumpy(), axes=[0, 1, 3, 2])
            weight = relay.Constant(tvm.nd.array(new_weight_data))

        if post.attrs.kernel_zero_point != 0:
            weight = weight.data.asnumpy()
            weight = weight.astype("int32") - post.attrs.kernel_zero_point
            weight = relay.Constant(tvm.nd.array(weight))
        else:
            weight = relay.cast(weight, "int32")

        func = relay.op.nn.conv2d(
                          data,
                          weight,
                          post.attrs.strides,
                          post.attrs.padding,
                          post.attrs.dilation,
                          post.attrs.groups,
                          weight_shape[channel_idx],
                          post.attrs.kernel_size,
                          post.attrs.data_layout,
                          kernel_layout,
                          post.attrs.data_layout,
                          "int32")
        assert post.attrs.ins[0] == 0 and post.attrs.ins[1] == 0
        if post.attrs.using_bias:
            axis_idx = post.attrs.data_layout.index("C")
            func = relay.op.nn.bias_add(func, post.args[2], axis=axis_idx)

        quant_coeff = post.attrs.output_scale.data.asnumpy()
        if quant_coeff.ndim == 2:
            # mul+shift quantization
            if quant_coeff.shape[1] == 1:
                assert isinstance(quant_coeff[0][0], (int, np.int32))
                func = relay.op.fixed_point_multiply(
                            func,
                            quant_coeff[0][0],
                            31 - quant_coeff[1][0])
            else:
                #per - channel for mul+shift
                assert 0
        else:
            # m for shift quantization
            assert 0

        if post.attrs.relu_type == 1:
            func = relay.op.nn.relu(func)
        elif post.attrs.relu_type >= 2:
            pos = relay.maximum(func, relay.const(0, "int32"))
            neg = relay.minimum(func, relay.const(0, "int32"))
            multiplier = 3 if (post.attrs.relu_type == 3) else 26 # 0.1 = 26/256  0.01 = 3/256
            shift = 8
            neg  = relay.op.fixed_point_multiply(neg, multiplier, 31 - shift)
            func = relay.add(pos, neg)

        if post.attrs.output_zero_point != 0:
            func = relay.add(func, relay.const(post.attrs.output_zero_point, "int32"))

        if post.attrs.out_dtype == "uint8":
            func = relay.clip(func, 0, 255)
        else:
            assert post.attrs.out_dtype == "int8"
            func = relay.clip(func, -128, 127)
        func = relay.cast(func, post.attrs.out_dtype)
        return func

class XMPool2D2RelayNN(DFPatternCallback):
    def __init__(self):
        super(XMPool2D2RelayNN, self).__init__()
        self.pattern = is_op("xm.pool2d")(None)

    def callback(self, pre, post, node_map):
        assert post.attrs.layout == "NHWC" or post.attrs.layout == "NCHW"

        from tvm.relay.op.nn.utils import get_pad_tuple2d
        pad_h_t, pad_w_l, pad_h_b, pad_w_r = get_pad_tuple2d(post.attrs.padding)
        padding = [pad_h_t, pad_w_l, pad_h_b, pad_w_r]

        data   = relay.cast(post.args[0], "int32")
        if post.attrs.pool_type == 0:  # max
            pad_value = (-128) if post.attrs.out_dtype == "int8" else 0
            if post.attrs.layout == "NHWC":
                func = relay.op.nn.pad(
                            data,
                            ((0, 0),(pad_h_t, pad_h_b),(pad_w_l, pad_w_r),(0, 0)),
                            pad_value)
            else:
                func = relay.op.nn.pad(
                            data,
                            ((0, 0),(0, 0),(pad_h_t, pad_h_b),(pad_w_l, pad_w_r)),
                            pad_value)

            func = relay.op.nn.max_pool2d(
                            func,
                            post.attrs.pool_size,
                            post.attrs.strides,
                            layout=post.attrs.layout)
        else:                           #avg
            pad_value = post.attrs.input_zero_point
            if post.attrs.layout == "NHWC":
                func = relay.op.nn.pad(
                            data,
                            ((0, 0),(pad_h_t, pad_h_b),(pad_w_l, pad_w_r),(0, 0)),
                            pad_value)
            else:
                func = relay.op.nn.pad(
                            data,
                            ((0, 0),(0, 0),(pad_h_t, pad_h_b),(pad_w_l, pad_w_r)),
                            pad_value)

            if post.attrs.pool_size[0] == 3:
                func = relay.op.multiply(func, relay.const(9, "int32"))

            func = relay.op.nn.avg_pool2d(
                            func,
                            post.attrs.pool_size,
                            post.attrs.strides,
                            layout=post.attrs.layout)

            if post.attrs.pool_size[0] == 3:
                func = relay.op.multiply(func, relay.const(57, "int32"))
                func = relay.op.right_shift(func, relay.const(9, "int32"))

        if post.attrs.out_dtype == "uint8":
            func = relay.clip(func, 0, 255)
        else:
            assert post.attrs.out_dtype == "int8"
            func = relay.clip(func, -128, 127)
        func = relay.cast(func, post.attrs.out_dtype)
        return func

class XMGAP2RelayNN(DFPatternCallback):
    def __init__(self):
        super(XMGAP2RelayNN, self).__init__()
        self.pattern = is_op("xm.global_avg_pool2d")(None)

    def callback(self, pre, post, node_map):
        assert post.attrs.layout == "NHWC" or post.attrs.layout == "NCHW"

        data   = relay.cast(post.args[0], "int32")

        func = relay.op.nn.avg_pool2d(
                        data,
                        post.attrs.pool_size,
                        post.attrs.pool_size, # stride
                        layout=post.attrs.layout)

        if post.attrs.out_dtype == "uint8":
            func = relay.clip(func, 0, 255)
        else:
            assert post.attrs.out_dtype == "int8"
            func = relay.clip(func, -128, 127)
        func = relay.cast(func, post.attrs.out_dtype)
        return func

class XMDense2RelayNN(DFPatternCallback):
    def __init__(self):
        super(XMDense2RelayNN, self).__init__()
        self.pattern = is_op("xm.dense")(None)

    def callback(self, pre, post, node_map):
        data   = relay.cast(post.args[0], "int32")
        weight = relay.cast(post.args[1], "int32")

        if post.attrs.input_zero_point != 0:
            data   = relay.op.subtract(
                            data,
                            relay.const(post.attrs.input_zero_point, "int32"))

        func = relay.op.reshape(
                        data,
                        newshape=[1, -1])

        weight_shape   = post.args[1].data.asnumpy().shape
        if post.attrs.kernel_zero_point != 0:
            weight = post.args[1].data.asnumpy()
            weight = weight.astype("int32") - post.attrs.kernel_zero_point
            weight = relay.Constant(tvm.nd.array(weight))

        func = relay.op.nn.dense(
                        func,
                        weight,
                        weight_shape[0],
                        out_dtype="int32")
        if post.attrs.using_bias:
            func = relay.op.nn.bias_add(func, post.args[2], axis=1)

        quant_coeff = post.attrs.output_scale.data.asnumpy()
        if quant_coeff.ndim == 2:
            # mul+shift quantization
            if quant_coeff.shape[1] == 1:
                assert isinstance(quant_coeff[0][0], (int, np.int32))
                func = relay.op.fixed_point_multiply(
                            func,
                            quant_coeff[0][0],
                            31 - quant_coeff[1][0])
            else:
                #per - channel for mul+shift
                assert 0
        else:
            # m for shift quantization
            assert 0

        if post.attrs.output_zero_point != 0:
            func = relay.add(func, relay.const(post.attrs.output_zero_point, "int32"))

        if post.attrs.out_dtype == "uint8":
            func = relay.clip(func, 0, 255)
        else:
            assert post.attrs.out_dtype == "int8"
            func = relay.clip(func, -128, 127)
        func = relay.cast(func, post.attrs.out_dtype)

        return func

def ReWriteXMIR2RelayNN(mod, target_layout="NCHW"):
    mod = ReWriteRelayLayout(mod, target_layout)
    mod = relay.transform.InferType()(mod)

    rewrite_func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod
    assert isinstance(rewrite_func, relay.function.Function)

    rewrite_func = XMDense2RelayNN().rewrite(rewrite_func)
    rewrite_func = XMEltwiseadd2RelayNN().rewrite(rewrite_func)
    rewrite_func = XMScale2RelayNN().rewrite(rewrite_func)
    rewrite_func = XMConv2D2RelayNN().rewrite(rewrite_func)
    rewrite_func = XMPool2D2RelayNN().rewrite(rewrite_func)
    rewrite_func = XMGAP2RelayNN().rewrite(rewrite_func)

    mod = relay.Function(relay.analysis.free_vars(rewrite_func.body), rewrite_func.body)
    mod = tvm.IRModule.from_expr(mod)

    return mod

def RemoveSoftmaxEnd(mod):
    func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod
    assert isinstance(func, relay.function.Function)
    body = func.body

    def _remove(body):
        print(body.op.name)
        if body.op.name == "qnn.quantize" \
            or body.op.name == "nn.softmax" \
            or body.op.name == "qnn.dequantize":
            body = body.args[0]
        return body
    if isinstance(body, tvm.relay.Call) and body.op.name == "qnn.quantize" and \
       isinstance(body.args[0], tvm.relay.Call) and body.args[0].op.name == "nn.softmax" and \
       isinstance(body.args[0].args[0], tvm.relay.Call) and body.args[0].args[0].op.name == "qnn.dequantize":
        body = body.args[0].args[0].args[0]
    if isinstance(body, tvm.relay.Call) and body.op.name == "nn.softmax" and \
       isinstance(body.args[0], tvm.relay.Call) and body.args[0].op.name == "qnn.dequantize":
        body = body.args[0].args[0]
    if isinstance(body, tvm.relay.Call) and body.op.name == "reshape":
        body = body.args[0]

    func = relay.function.Function(relay.analysis.free_vars(body), body)
    mod = tvm.IRModule.from_expr(func)
    return mod


def RemoveAvgPoolTest(mod):
    func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod
    assert isinstance(func, relay.function.Function)
    body = func.body

    for i in range(6):
        if len(body.args) >= 2 and isinstance(body.args[1], relay.expr.Call):
            body = body.args[1]
        else:
            body = body.args[0]

    func = relay.function.Function(relay.analysis.free_vars(body), body)
    mod = tvm.IRModule.from_expr(func)

    #print(mod)
    #assert 0

    return mod


def RemoveTest2(mod):
    func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod
    assert isinstance(func, relay.function.Function)
    body = func.body

    #body = body.args[0]
    for i in range(161):
        if isinstance(body, relay.expr.Tuple):
            body = body[0]
        elif isinstance(body.args[0], relay.expr.Call):
            body = body.args[0]
        elif len(body.args) >= 2 and isinstance(body.args[1], relay.expr.Call):
            body = body.args[1]
        else:
            body = body.args[0]

    func = relay.function.Function(relay.analysis.free_vars(body), body)
    mod = tvm.IRModule.from_expr(func)

    return mod


def RemoveTest3(mod):
    func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod
    assert isinstance(func, relay.function.Function)
    body = func.body

    body = body.args[0].args[0]

    for i in range(0):
        if isinstance(body.args[0], relay.expr.Call):
            body = body.args[0]
        elif len(body.args) >= 2 and isinstance(body.args[1], relay.expr.Call):
            body = body.args[1]
        else:
            body = body.args[0]

    func = relay.function.Function(relay.analysis.free_vars(body), body)
    mod = tvm.IRModule.from_expr(func)

    return mod

def opt_model(mod):
    mod = relay.transform.InferType()(mod)
    mod = xmnpu.relay.pattern.RemoveSoftmaxEnd(mod)
    return mod

def create_xmir(mod, params):
    from tvm.relay.op.contrib import get_pattern_table
    with tvm.transform.PassContext(opt_level=3):
        f = relay.build_module.bind_params_by_name(mod["main"], params)
        mod = tvm.IRModule()
        mod["main"] = f

        pattern = get_pattern_table("xmnpu-105")
        mod = relay.transform.InferType()(mod)
        mod = relay.transform.MergeComposite(pattern)(mod)
        mod = xmnpu.relay.pattern.ReWriteRelayQNN2XMIR(mod)
        mod = relay.transform.InferType()(mod)
        mod = relay.qnn.transform.CanonicalizeOps()(mod)
        mod = relay.transform.InferType()(mod)
        mod = relay.transform.Legalize()(mod)
        mod = relay.qnn.transform.Legalize()(mod)
        mod = relay.transform.InferType()(mod)
        mod = relay.transform.InferType()(mod)
        mod = relay.transform.Legalize()(mod)
        return mod
