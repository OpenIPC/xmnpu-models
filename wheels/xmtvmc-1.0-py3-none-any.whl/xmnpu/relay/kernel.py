import tvm

@tvm._ffi.register_func("relay.backend.xmnpu_op_conv")
def xmnpu_op_conv(kernel, input, weight, bias, output, info):
    f = tvm.get_global_func("libxm7205v500.xmnpu_op_conv", True);

    if f:
        return f(kernel, input, weight, bias, output, info)

@tvm._ffi.register_func("relay.backend.xmnpu_op_pool")
def xmnpu_op_pool(kernel, input, output, info):
    f = tvm.get_global_func("libxm7205v500.xmnpu_op_pool", True);

    if f:
        return f(kernel, input, output, info)

@tvm._ffi.register_func("relay.backend.xmnpu_build_and_query_kernel")
def xmnpu_build_and_query_kernel(kernel):
    f = tvm.get_global_func("libxm7205v500.xmnpu_build_and_query_kernel", True);

    if f:
        return f(kernel)

@tvm._ffi.register_func("relay.backend.xmnpu_create_kernel")
def xmnpu_create_kernel(kernel_type):
    f = tvm.get_global_func("libxm7205v500.xmnpu_create_kernel", True);

    if f:
        return f(kernel_type)

@tvm._ffi.register_func("relay.backend.xmnpu_create_tensor")
def xmnpu_create_tensor(tensor_info):
    f = tvm.get_global_func("libxm7205v500.xmnpu_create_tensor", True);

    if f:
        return f(tensor_info)

@tvm._ffi.register_func("relay.backend.xmnpu_op_global_avg_pool")
def xmnpu_op_global_avg_pool(kernel, input, output):
    f = tvm.get_global_func("libxm7205v500.xmnpu_op_global_avg_pool", True);

    if f:
        return f(kernel, input, output)

@tvm._ffi.register_func("relay.backend.xmnpu_op_elmwise_add")
def xmnpu_op_global_elmwise_add(kernel, input1, input2, output):
    f = tvm.get_global_func("libxm7205v500.xmnpu_op_elmwise_add", True);

    if f:
        return f(kernel, input1, input2, output)

@tvm._ffi.register_func("relay.backend.xmnpu_op_depth_wise_conv")
def xmnpu_op_depth_wise_conv(kernel, input, weight, bias, output, info):
    f = tvm.get_global_func("libxm7205v500.xmnpu_op_depth_wise_conv", True);

    if f:
        return f(kernel, input, weight, bias, output, info)

@tvm._ffi.register_func("relay.backend.xmnpu_op_upsample")
def xmnpu_op_upsample(kernel, input, output, h_factor):
    f = tvm.get_global_func("libxm7205v500.xmnpu_op_upsample", True);

    if f:
        return f(kernel, input, output, h_factor)

@tvm._ffi.register_func("relay.backend.xmnpu_op_concat")
def xmnpu_op_concat(kernel):
    f = tvm.get_global_func("libxm7205v500.xmnpu_op_concat", True);

    if f:
        return f(kernel)

@tvm._ffi.register_func("relay.backend.xmnpu_op_split")
def xmnpu_op_split(kernel, input, outputs, split_part_num):
    f = tvm.get_global_func("libxm7205v500.xmnpu_op_split", True);

    if f:
        return f(kernel, input, outputs, split_part_num)

@tvm._ffi.register_func("relay.backend.xmnpu_op_deconv")
def xmnpu_op_deconv(kernel, input, weight, bias, output, deconv_ins_h, info):
    f = tvm.get_global_func("libxm7205v500.xmnpu_op_deconv", True);

    if f:
        return f(kernel, input, weight, bias, output, deconv_ins_h, info)

