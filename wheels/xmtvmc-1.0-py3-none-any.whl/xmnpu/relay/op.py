# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
# pylint: disable=invalid-name
"""QNN dialect operators."""

from __future__ import absolute_import as _abs
from tvm import relay
from tvm.relay.expr import Tuple, TupleWrapper
from tvm.relay.op.nn.utils import get_pad_tuple2d
from tvm.topi.utils import get_const_tuple, get_const_int
from tvm.topi.nn.qnn import SQNN_DTYPE_TO_CODE
from . import _make
import numpy as np
from tvm.ir import Attrs
import tvm._ffi

# concat     -> qnn.concatenate()
# upsample   -> image.resize()


def swish(data, beta, scale, output_scale, zero_point, output_zero_point, dtype):
    """XMIR swish.

    params:
        x : relay.Expr
            The quantized input tensor.

        scale: relay.Expr
            The scale of the quantized expr.
        
        output_scale: relay.Expr
            The scale of the output quantized expr.

        zero_point: int
            The zero point of quantized expr.

        output_zero_point: int
            The zero point of output quantized expr.

    return:
        result : relay.Expr
            The computed result.

    """
    scale = scale.data.numpy().item()
    output_scale = output_scale.data.numpy().item()

    table = create_lut_table(lambda x: x/(1+np.exp(-beta*x)), scale,
                             output_scale, zero_point, output_zero_point, dtype, "int32")
    table = tvm.relay.const(table)

    return _make.lut(data, table, dtype)


def gelu(data, scale, output_scale, zero_point, output_zero_point, dtype):
    """XMIR gelu.

    params:
        x : relay.Expr
            The quantized input tensor.

        scale: relay.Expr
            The scale of the quantized expr.
        
        output_scale: relay.Expr
            The scale of the output quantized expr.

        zero_point: int
            The zero point of quantized expr.

        output_zero_point: int
            The zero point of output quantized expr.

    return:
        result : relay.Expr
            The computed result.

    """
    def gelu_np(x):
        return 0.5*x*(1+np.tanh(np.sqrt(2/np.pi)*(x+0.044715*np.power(x, 3))))

    scale = scale.data.numpy().item()
    output_scale = output_scale.data.numpy().item()

    table = create_lut_table(gelu_np, scale, output_scale,
                             zero_point, output_zero_point, dtype, "int32")
    table = tvm.relay.const(table)

    return _make.lut(data, table, dtype)


def silu(data, scale, output_scale, zero_point, output_zero_point, dtype):
    """XMIR silu.

    params:
        x : relay.Expr
            The quantized input tensor.

        scale: relay.Expr
            The scale of the quantized expr.
        
        output_scale: relay.Expr
            The scale of the output quantized expr.

        zero_point: int
            The zero point of quantized expr.

        output_zero_point: int
            The zero point of output quantized expr.

    return:
        result : relay.Expr
            The computed result.

    """
    scale = scale.data.numpy().item()
    output_scale = output_scale.data.numpy().item()

    table = create_lut_table(lambda x: x/(1+np.exp(-x)), scale,
                             output_scale, zero_point, output_zero_point, dtype, "int32")
    table = tvm.relay.const(table)

    return _make.lut(data, table, dtype)


def mish(data, scale, output_scale, zero_point, output_zero_point, dtype):
    """XMIR mish.

    params:
        x : relay.Expr
            The quantized input tensor.

        scale: relay.Expr
            The scale of the quantized expr.
        
        output_scale: relay.Expr
            The scale of the output quantized expr.

        zero_point: int
            The zero point of quantized expr.

        output_zero_point: int
            The zero point of output quantized expr.

    return:
        result : relay.Expr
            The computed result.

    """
    scale = scale.data.numpy().item()
    output_scale = output_scale.data.numpy().item()

    table = create_lut_table(lambda x: x*np.tanh(np.log((1+np.exp(x)))), scale,
                             output_scale, zero_point, output_zero_point, dtype, "int32")
    table = tvm.relay.const(table)

    return _make.lut(data, table, dtype)


def relu(data, scale, output_scale, zero_point, output_zero_point, dtype):
    """XMIR relu.

    params:
        x : relay.Expr
            The quantized input tensor.

        scale: relay.Expr
            The scale of the quantized expr.
        
        output_scale: relay.Expr
            The scale of the output quantized expr.

        zero_point: int
            The zero point of quantized expr.

        output_zero_point: int
            The zero point of output quantized expr.

    return:
        result : relay.Expr
            The computed result.

    """
    scale = scale.data.numpy().item()
    output_scale = output_scale.data.numpy().item()

    table = create_lut_table(lambda x: np.maximum(
        0, x), scale, output_scale, zero_point, output_zero_point, dtype, "int32")
    table = tvm.relay.const(table)

    return _make.lut(data, table, dtype)


def leaky_relu(data, alpha, scale, output_scale, zero_point, output_zero_point, dtype):
    """XMIR leaky relu.

    params:
        x : relay.Expr
            The quantized input tensor.

        scale: relay.Expr
            The scale of the quantized expr.
        
        output_scale: relay.Expr
            The scale of the output quantized expr.

        zero_point: int
            The zero point of quantized expr.

        output_zero_point: int
            The zero point of output quantized expr.

    return:
        result : relay.Expr
            The computed result.

    """

    scale = scale.data.numpy().item()
    output_scale = output_scale.data.numpy().item()

    table = create_lut_table(lambda x:np.maximum(x*alpha,x), scale, output_scale,
                             zero_point, output_zero_point, dtype, "int32")
    table = tvm.relay.const(table)

    return _make.lut(data, table, dtype)

def relu6(data, scale, output_scale, zero_point, output_zero_point, dtype):
    scale = scale.data.numpy().item()
    output_scale = output_scale.data.numpy().item()

    table = create_lut_table(lambda x: np.minimum(np.maximum(0, x), 6), 
        scale, output_scale, zero_point, output_zero_point, dtype, "int32")
    table = tvm.relay.const(table)

    return _make.lut(data, table, dtype)

def mish(data, scale, output_scale, zero_point, output_zero_point, dtype):
    scale = scale.data.numpy().item()
    output_scale = output_scale.data.numpy().item()

    table = create_lut_table(lambda x: x*np.tanh(np.log(1+np.exp(x))), 
        scale, output_scale, zero_point, output_zero_point, dtype, "int32")
    table = tvm.relay.const(table)

    return _make.lut(data, table, dtype)

def tanh(data, scale, output_scale, zero_point, output_zero_point, dtype):
    """XMIR tanh.

    params:
        x : relay.Expr
            The quantized input tensor.

        scale: relay.Expr
            The scale of the quantized expr.
        
        output_scale: relay.Expr
            The scale of the output quantized expr.

        zero_point: int
            The zero point of quantized expr.

        output_zero_point: int
            The zero point of output quantized expr.

    return:
        result : relay.Expr
            The computed result.

    """
    scale = scale.data.numpy().item()
    output_scale = output_scale.data.numpy().item()

    table = create_lut_table(lambda x: np.tanh(
        x), scale, output_scale, zero_point, output_zero_point, dtype, "int32")
    table = tvm.relay.const(table)

    return _make.lut(data, table, dtype)


def sigmoid(data, scale, output_scale, zero_point, output_zero_point, dtype):
    """XMIR sigmoid.

    params:
        x : relay.Expr
            The quantized input tensor.

        scale: relay.Expr
            The scale of the quantized expr.
        
        output_scale: relay.Expr
            The scale of the output quantized expr.

        zero_point: int
            The zero point of quantized expr.

        output_zero_point: int
            The zero point of output quantized expr.

    return:
        result : relay.Expr
            The computed result.

    """
    scale = scale.data.numpy().item()
    output_scale = output_scale.data.numpy().item()
    table = create_lut_table(lambda x: 1/(1+np.exp(-x)), scale,
                             output_scale, zero_point, output_zero_point, dtype, "int32")
    table = tvm.relay.const(table)
    # return _make.sigmoid(data, scale, output_scale, zero_point, output_zero_point)

    return _make.lut(data, table, dtype)

def lut(data, table, dtype="uint8"):
    """Look-Up Table
    This operator takes the data as query to search the value in table
    and replace source value in data.

    .. math::
                data[i]=table[data[i]]

    params:
        data: tvm.relay.Expr
            The input data to the operator.
            The data value is the index of table, so data type must be int or uint.
        table: tvm.relay.Expr
            The table to the operator, shape must be 1-D tensor.
    return:
        tvm.relay.Expr
            The ouput data by Look-Up Table. 
            It has the same shape with data.
    """

    return _make.lut(data, table, dtype)


def yuv2rgb(
    Y,
    UV,
    yuv_format: str = "YUV_422SP",
    bt_format: str = "BT601",
    yuv_range: str = "FULL",
    input_wptch: int = 1,
    input_mtype: int = 1,
    dtype: float = "uint8",
):
    """convert YUV data to RGB image
    This operator takes the YUV data and convert to RGB image tensor.
    Because of Y and UV have different shape for differrent yuv format, so 
    the operator take input Y and UV split.
    If yuv format is YUV_422SP, must Y.shape==UV.shape.
    If yuv format is YUV_420SP, must Y.shape.h == UV.shape.h*2

    params:
        Y: tvm.relay.Expr
            The input Y of YUV data to the operator.
            It will be 2-Dim Matrix with shape (h,w).
        UV: tvm.relay.Expr
            The input UV of YUV data to the operator.
            It will be 2-Dim Matrix with shape (h,w).
        yuv_format: str
            The YUV data sample format, it can be ('YUV_422SP','YUV_420SP').
            It decided UV sample rate.
        bt_format: str
            The YUV data bits format, it can be ('BT601','BT709').
        yuv_range: str
            The YUV data value range type, it can be ('FULL'.'TV').
    return:
        tvm.relay.Expr
            The RGB image data covnerted by YUV.
            It will be 3-Dim Tensor with shape (3,h,w).
    """

    assert yuv_format in ("YUV_422SP", "YUV_420SP"),\
        f"YUV format must be one of ('YUV_422SP','YUV_420SP'),but input '{yuv_format}'"
    assert bt_format in ("BT601", "BT709"),\
        f"Bt format must be one of ('BT601','BT709'),but input '{bt_format}'"
    assert yuv_range in ("FULL", "TV"),\
        f"YUV range must be one of ('FULL','TV'),but input '{yuv_range}'"

    return _make.yuv2rgb(Y, UV, yuv_format, bt_format, yuv_range, dtype, input_wptch, input_mtype)

def eltwise_add(
    lhs,
    rhs,
    lhs_scale,
    rhs_scale,
    out_scale,
    lhs_zero_point,
    rhs_zero_point,
    output_zero_point,
    layout="NCHW",
    out_dtype="uint8"):
    assert out_dtype == "uint8" or out_dtype == "int8"

    return _make.eltwise_add(
        lhs,
        rhs,
        lhs_scale,
        rhs_scale,
        out_scale,
        lhs_zero_point,
        rhs_zero_point,
        output_zero_point,
        layout,
        out_dtype)


def scale(
    data,
    kernel,
    bias,
    input_scale,
    kernel_scale,
    output_scale,
    input_zero_point,
    kernel_zero_point,
    output_zero_point,
    using_bias=0,
    relu_type=0,     #0:no relu;1:relu;2/3:leaky_relu(0.1/0.01);
    layout="NCHW",
    out_dtype="uint8"):

    #assert layout    == "NCHW"
    assert out_dtype == "uint8" or out_dtype == "int8"

    if using_bias == 0:
        bias = tvm.relay.Constant(tvm.nd.array(0))

    return _make.scale(
        data,
        kernel,
        bias,
        input_scale,
        kernel_scale,
        output_scale,
        input_zero_point,
        kernel_zero_point,
        output_zero_point,
        using_bias,
        relu_type,
        layout,
        out_dtype)

def global_avg_pool2d(
    data,
    input_zero_point,
    output_zero_point,
    pool_size,
    layout,
    out_dtype="uint8"):
    assert out_dtype == "uint8" or out_dtype == "int8"

    return _make.global_avg_pool2d(
        data,
        input_zero_point,
        output_zero_point,
        pool_size,
        layout,
        out_dtype)


def pool2d(
    data,
    input_zero_point,
    output_zero_point,
    pool_size,
    strides,
    padding,
    layout,
    pool_type,  # 0:max, 1:avg
    out_dtype="uint8"):
    assert out_dtype == "uint8" or out_dtype == "int8"

    # user make sure out_dtype same as input dtype
    #pad_h_t, pad_w_l, pad_h_b, pad_w_r = get_pad_tuple2d(padding)
    #padding = (pad_h_t, pad_h_b, pad_w_l, pad_w_r)
    padding = get_pad_tuple2d(padding)
    return _make.pool2d(
        data,
        input_zero_point,
        output_zero_point,
        pool_size,
        strides,
        padding,
        layout,
        pool_type,
        out_dtype)



def dense(
    data,
    kernel,
    bias,
    input_scale,
    kernel_scale,
    output_scale,
    input_zero_point,
    kernel_zero_point,
    output_zero_point,
    using_bias,
    out_dtype="uint8"):

    if using_bias == 0:
        bias = tvm.relay.Constant(tvm.nd.array(0))

    return _make.dense(
        data,
        kernel,
        bias,
        input_scale,
        kernel_scale,
        output_scale,
        input_zero_point,
        kernel_zero_point,
        output_zero_point,
        using_bias,
        out_dtype)

def matmul(tensor_a, tensor_b, out_dtype="", transpose_a=False, transpose_b=True,
                o_shape=[1,1,1], i1_zp=0, i2_zp=0, o_zp=0, quant_mode=0, f_multiplier=0,
                multiplier=[0,0]):
    r"""
    Compute batch matrix multiplication of `tensor_a` and `tensor_b`.

    Both `tensor_a` and `tensor_b` can be transposed. For legacy reason, we use NT format
    (transpose_a=False, transpose_b=True) by default.

    .. math::

        \mbox{batch_matmul}(A, B)[i, :, :] = \mbox{matmul}(A[i, :, :], B[i, :, :])

    Parameters
    ----------
    tensor_a : tvm.relay.Expr
        The first input.

    tensor_b : tvm.relay.Expr
        The second input.

    out_dtype : Optional[str]
        Specifies the output data type for mixed precision batch matmul.

    transpose_a : Optional[bool] = False
        Whether the first tensor is in transposed format.

    transpose_b : Optional[bool] = True
        Whether the second tensor is in transposed format.

    Returns
    -------
    result: tvm.relay.Expr
        The computed result.
    """
    return _make.matmul(tensor_a, tensor_b, out_dtype, transpose_a, transpose_b, o_shape,
                                i1_zp, i2_zp, o_zp, quant_mode, f_multiplier, multiplier)

def channel_shuffle(data, group, axes):
    """Channel shuffle of the input data.

    Parameters
    ----------
    data : relay.Expr
        The input data to the operator.

    group : int
        The groups of the input data.

    axes : None or List[int]
        The target axes order, reverse order if not specified.

    Returns
    -------
    result : relay.Expr
        The computed result.
    """
    return _make.channel_shuffle(data, group, axes)

def conv2d(
    data,
    kernel,
    bias,
    input_scale,
    kernel_scale,
    output_scale,
    input_zero_point,
    kernel_zero_point,
    output_zero_point,
    kernel_size,
    strides=(1, 1),
    padding=(0, 0),
    dilation=(1, 1),
    ins=(0, 0),
    using_bias=1,
    relu_type=0,     #0:no relu;1:relu;2/3:leaky_relu(0.1/0.01);
    groups=1,
    data_layout="NCHW",
    kernel_layout="OIHW",
    out_layout="",
    out_dtype="uint8"):

    # mul_quant : quant_coeff is a float value or float tensor
    #     after FTVMLegalize, is a (2,1)/(2,oc)
    # shift_quant : is a int value(m) or int tensor
    #     after FTVMLegalize, do nothing
    #assert isinstance(input_zero_point, int)
    #assert isinstance(kernel_zero_point, int)
    #assert isinstance(output_zero_point, int)
    #assert isinstance(input_scale, float)
    #assert isinstance(kernel_scale, float)
    #assert isinstance(output_scale, float)

    #assert data_layout  == "NCHW"
    #assert kernel_layout == "OIHW"
    #assert out_layout    == "NCHW"
    assert out_dtype     == "uint8" or out_dtype == "int8"

    '''
    if isinstance(data, tvm.ir.container.Array):
        assert len(data) == 1
        data = data[0]
    kernel_params = kernel
    if isinstance(kernel, tvm.relay.expr.Call):
        kernel_params = kernel.args[0] 

    print((kernel_params._checked_type_.dtype))
    print(type(kernel_params._checked_type_))
    assert data.type_annotation.dtype == "uint8" \
                 or  data.type_annotation.dtype == "int8"
    assert kernel.type_annotation.dtype == "uint8" \
                 or  kernel.type_annotation.dtype == "int8"

    input_shape  = get_const_tuple(data.type_annotation.shape)
    kernel_shape = get_const_tuple(kernel.type_annotation.shape)
    assert len(input_shape)  == 4
    assert len(kernel_shape) == 4

    # bias is not Var mean's not use bias
    if using_bias:
        bias_shape   = get_const_tuple(bias.type_annotation.shape)
        if len(bias_shape) != 1:
            assert len(bias_shape) == 4
            assert bias_shape[0] == 1
            assert bias_shape[2] == 1
            assert bias_shape[3] == 1
        assert np.prod(bias_shape) == kernel_shape[0]

    if groups != 1 or input_shape[1] != kernel_shape[1]:
        assert groups == input_shape[1]
        assert groups == kernel_shape[0]
    assert kernel_size[0] == kernel_shape[2]
    assert kernel_size[1] == kernel_shape[3]
    '''

    if using_bias == 0:
        bias = tvm.relay.Constant(tvm.nd.array(0))
    # TODO same check as cmodel atmoic

    # TODO enforce 4-way padding in topi/nn/conv2d after #4644 merged
    # convert 2-way padding to 4-way padding
    #pad_h_t, pad_w_l, pad_h_b, pad_w_r = get_pad_tuple2d(padding)
    #padding = (pad_h_t, pad_h_b, pad_w_l, pad_w_r)
    padding = get_pad_tuple2d(padding)
    return _make.conv2d(
        data,
        kernel,
        bias,
        input_scale,
        kernel_scale,
        output_scale,
        input_zero_point,
        kernel_zero_point,
        output_zero_point,
        kernel_size,
        strides,
        padding,
        dilation,
        ins,
        using_bias,
        relu_type,
        groups,
        data_layout,
        kernel_layout,
        out_layout,
        out_dtype)

@tvm._ffi.register_object("relay.attrs.XMYUV2RGBAttrs")
class XMYUV2RGBAttrs(Attrs):
    """Attributes for nn.conv2d"""

@tvm._ffi.register_object("relay.attrs.XMConv2DAttrs")
class XMConv2DAttrs(Attrs):
    """Attributes for nn.conv2d"""

@tvm._ffi.register_object("relay.attrs.XMDenseAttrs")
class XMDenseAttrs(Attrs):
    """Attributes for nn.conv2d"""

@tvm._ffi.register_object("relay.attrs.XMPool2DAttrs")
class XMPool2DAttrs(Attrs):
    """Attributes for nn.conv2d"""

@tvm._ffi.register_object("relay.attrs.XMGlobalPool2DAttrs")
class XMGlobalPool2DAttrs(Attrs):
    """Attributes for nn.conv2d"""

@tvm._ffi.register_object("relay.attrs.XMEltwiseADDAttrs")
class XMEltwiseADDAttrs(Attrs):
    """Attributes for nn.conv2d"""

def create_lut_table(np_func, in_scale, out_scale, in_zero_point, out_zero_point, in_dtype="uint8", out_dtype="uint8"):
    if not np.issubdtype(np.dtype(in_dtype), np.integer) or not np.issubdtype(np.dtype(out_dtype), np.integer):
        raise ValueError(
            f"Only integer dtypes allowed got {in_dtype} and {out_dtype} for in and out dtypes.")

    num_bits = np.iinfo(in_dtype).bits
    table = np.arange(0, 2**num_bits).astype(np.float32)

    table = (table-in_zero_point)*in_scale
    table = np_func(table)
    table = np.round(table/out_scale)+out_zero_point
    table = table.astype(out_dtype)
    if in_dtype == "int8":
        table = np.clip(table, -128, 127)
    elif in_dtype == "uint8":
        table = np.clip(table, 0, 255)

    return table
