# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
# pylint: disable=unused-argument
"""The register functions for the QNN dialect."""
import tvm.ir
from tvm import topi
from tvm.relay.op import op as reg
from tvm.relay.op import OpPattern
from tvm.topi.nn.utils import get_pad_tuple
from tvm.target import generic_func, override_native_generic_func


def register_xm_qnn_legalize(op_name, legal_op=None, level=10):
    """Register legal transformation function for a QNN op

    Parameters
    ----------
    op_name : str
        The name of the operator

    legal_op: function (attrs: Attrs, inputs: List[Expr]) -> new_expr: Expr
        The function for transforming an expr to another expr.

    level : int
        The priority level
    """
    return tvm.ir.register_op_attr(op_name, "FTVMQnnLegalize", legal_op, level)

@override_native_generic_func("xm_transpose_strategy")
def xm_transpose_strategy(attrs,inputs,out_type,target):
    """transpose generic strategy"""
    raise ValueError("xm_transpose_strategy not resgister.")

    return None


@override_native_generic_func("xm_lut_strategy")
def xm_lut_strategy(attrs, inputs, out_type, target):
    """lut generic strategy"""
    raise ValueError("xm_lut_startegy not resgister.")

    return None

@override_native_generic_func("xm_conv2d_strategy")
def xm_conv2d_strategy(attrs, inputs, out_type, target):
    """conv2d generic strategy"""
    raise ValueError("xm_conv2d_strategy not resgister.")

    return None

@override_native_generic_func("xm_concat_strategy")
def xm_concat_strategy(attrs, inputs, out_type, target):
    """concat generic strategy"""
    raise ValueError("xm_concat_strategy not resgister.")

    return None

@override_native_generic_func("xm_neg_strategy")
def xm_neg_strategy(attrs, inputs, out_type, target):
    """neg generic strategy"""
    raise ValueError("xm_neg_strategy not resgister.")

    return None

@override_native_generic_func("xm_eltwiseadd_strategy")
def xm_eltwiseadd_strategy(attrs, inputs, out_type, target):
    """eltwiseadd generic strategy"""
    raise ValueError("xm_eltwiseadd_strategy not resgister.")

    return None

@override_native_generic_func("xm_scale_strategy")
def xm_scale_strategy(attrs, inputs, out_type, target):
    """conv2d generic strategy"""
    raise ValueError("xm_scale_strategy not resgister.")

    return None

@override_native_generic_func("xm_pool2d_strategy")
def xm_pool2d_strategy(attrs, inputs, out_type, target):
    """pool2d generic strategy"""
    raise ValueError("xm_pool2d_strategy not resgister.")

    return None

@override_native_generic_func("xm_dense_strategy")
def xm_dense_strategy(attrs, inputs, out_type, target):
    """dense generic strategy"""
    raise ValueError("xm_dense_strategy not resgister.")

    return None

@override_native_generic_func("xm_global_avg_pool2d_strategy")
def xm_global_avg_pool2d_strategy(attrs, inputs, out_type, target):
    """pool2d generic strategy"""
    raise ValueError("xm_global_avg_pool2d_strategy not resgister.")

    return None

@override_native_generic_func("xm_tile_strategy")
def xm_tile_strategy(attrs, inputs, out_type, target):
    """tile generic strategy"""
    raise ValueError("xm_tile_strategy not resgister.")

    return None

@override_native_generic_func("xm_yuv2rgb_strategy")
def xm_yuv2rgb_strategy(attrs, inputs, out_type, target):
    """yuv2rgb generic strategy"""
    raise ValueError("xm_yuv2rgb_strategy not resgister.")

    return None

@override_native_generic_func("xm_upsample_strategy")
def xm_upsample_strategy(attrs,inputs,out_type,target):
    """upsample generic strategy"""
    raise ValueError("xm_upsample_strategy not resgister.")

    return None

@override_native_generic_func("xm_space_to_depth_strategy")
def xm_space_to_depth_strategy(attrs, inputs, out_type, target):
    """space_to_depth generic strategy"""
    raise ValueError("xm_space_to_depth_strategy not resgister.")

    return None

@override_native_generic_func("xm_depth_to_space_strategy")
def xm_depth_to_space_strategy(attrs, inputs, out_type, target):
    """depth_to_space generic strategy"""
    raise ValueError("xm_depth_to_space_strategy not resgister.")

    return None

@override_native_generic_func("xm_strided_slice_strategy")
def xm_strided_slice_strategy(attrs, inputs, out_type, target):
    """strided_slice generic strategy"""
    raise ValueError("xm_strided_slice_strategy not resgister.")

    return None

@override_native_generic_func("xm_batch_to_space_nd_strategy")
def xm_batch_to_space_nd_strategy(attrs, inputs, out_type, target):
    """batch_to_space generic strategy"""
    raise ValueError("xm_batch_to_space_nd_strategy not resgister.")

    return None

@override_native_generic_func("xm_space_to_batch_nd_strategy")
def xm_space_to_batch_nd_strategy(attrs, inputs, out_type, target):
    """space_to_batch generic strategy"""
    raise ValueError("xm_space_to_batch_nd_strategy not resgister.")

    return None

@override_native_generic_func("xm_channel_shuffle_strategy")
def xm_channel_shuffle_strategy(attrs, inputs, out_type, target):
    """channel_shuffle generic strategy"""
    raise ValueError("xm_channel_shuffle_strategy not resgister.")

    return None

@override_native_generic_func("xm_clip_strategy")
def xm_clip_strategy(attrs, inputs, out_type, target):
    """clip generic strategy"""
    raise ValueError("xm_clip_strategy not resgister.")

    return None

@override_native_generic_func("xm_split_strategy")
def xm_split_strategy(attrs, inputs, out_type, target):
    """split generic strategy"""
    raise ValueError("xm_split_strategy not resgister.")

    return None

@override_native_generic_func("xm_matmul_strategy")
def xm_matmul_strategy(attrs, inputs, out_type, target):
    """matmul generic strategy"""
    raise ValueError("xm_matmul_strategy not resgister.")

    return None

@override_native_generic_func("xm_reduce_mean_strategy")
def xm_reduce_mean_strategy(attrs, inputs, out_type, target):
    """reduce_mean generic strategy"""
    raise ValueError("xm_reduce_mean_strategy not resgister.")

    return None

'''
reg.register_strategy("xxx.conv2d", strategy.conv2d_strategy)
reg.register_pattern("xxx.conv2d", OpPattern.OUT_ELEMWISE_FUSABLE)
reg.register_shape_func("xxx.conv2d", False, conv_shape_func)
@reg.register_legalize("xxx.conv2d")
@reg.register_alter_op_layout("xxx.conv2d")
@reg.register_convert_op_layout("xxx.conv2d")
@register_annotate_function("xxx.conv2d")
@register_partition_function("xxx.conv2d")
@register_gradient("xxx.conv2d")
'''
reg.register_strategy("xm.lut", xm_lut_strategy)

reg.register_strategy("xm.yuv2rgb", xm_yuv2rgb_strategy)

# conv2d
reg.register_strategy("xm.conv2d", xm_conv2d_strategy)
reg.register_pattern("xm.conv2d", OpPattern.OUT_ELEMWISE_FUSABLE)
reg.register_strategy("xm.conv2d_nobias", xm_conv2d_strategy)
reg.register_pattern("xm.conv2d_nobias", OpPattern.OUT_ELEMWISE_FUSABLE)

reg.register_strategy("xm.dense", xm_dense_strategy)
reg.register_pattern("xm.dense", OpPattern.OUT_ELEMWISE_FUSABLE)
reg.register_strategy("xm.dense_nobias", xm_dense_strategy)
reg.register_pattern("xm.dense_nobias", OpPattern.OUT_ELEMWISE_FUSABLE)


reg.register_strategy("xm.pool2d", xm_pool2d_strategy)
reg.register_pattern("xm.pool2d", OpPattern.OUT_ELEMWISE_FUSABLE)

reg.register_strategy("xm.eltwise_add", xm_eltwiseadd_strategy)
reg.register_pattern("xm.eltwise_add", OpPattern.OUT_ELEMWISE_FUSABLE)

reg.register_strategy("xm.scale", xm_scale_strategy)
reg.register_pattern("xm.scale", OpPattern.OUT_ELEMWISE_FUSABLE)

reg.register_strategy("xm.global_avg_pool2d", xm_global_avg_pool2d_strategy)
reg.register_pattern("xm.global_avg_pool2d", OpPattern.OUT_ELEMWISE_FUSABLE)

reg.register_strategy("xm.channel_shuffle", xm_channel_shuffle_strategy)
reg.register_pattern("xm.channel_shuffle", OpPattern.OUT_ELEMWISE_FUSABLE)

reg.register_strategy("xm.matmul", xm_matmul_strategy)
reg.register_pattern("xm.matmul", OpPattern.OUT_ELEMWISE_FUSABLE)

reg.get("concatenate").get_attr("FTVMStrategy").register(xm_concat_strategy, "xmnpu")
reg.get("tile").get_attr("FTVMStrategy").register(xm_tile_strategy, "xmnpu")
reg.get("negative").get_attr("FTVMStrategy").register(xm_neg_strategy, "xmnpu")
reg.get("nn.upsampling").get_attr("FTVMStrategy").register(xm_upsample_strategy, "xmnpu")
reg.get("nn.space_to_depth").get_attr("FTVMStrategy").register(xm_space_to_depth_strategy, "xmnpu")
reg.get("nn.depth_to_space").get_attr("FTVMStrategy").register(xm_depth_to_space_strategy, "xmnpu")
reg.get("transpose").get_attr("FTVMStrategy").register(xm_transpose_strategy, "xmnpu")
reg.get("strided_slice").get_attr("FTVMStrategy").register(xm_strided_slice_strategy, "xmnpu")
reg.get("nn.batch_to_space_nd").get_attr("FTVMStrategy").register(xm_batch_to_space_nd_strategy, "xmnpu")
reg.get("nn.space_to_batch_nd").get_attr("FTVMStrategy").register(xm_space_to_batch_nd_strategy, "xmnpu")
reg.get("split").get_attr("FTVMStrategy").register(xm_split_strategy, "xmnpu")
reg.get("clip").get_attr("FTVMStrategy").register(xm_clip_strategy, "xmnpu")
reg.get("mean").get_attr("FTVMStrategy").register(xm_reduce_mean_strategy, "xmnpu")

# Registering XM Conv2D legalization function.
@register_xm_qnn_legalize("xm.conv2d")
def legalize_xm_qnn_conv2d(attrs, inputs, types):
    return xm_qnn_conv2d_legalize(attrs, inputs, types)

@reg.register_legalize("xm.conv2d")
def legalize_xm_conv2d(attrs, inputs, types):
    #assert 0
    """Legalize conv2d op.

    Parameters
    ----------
    attrs : tvm.ir.Attrs
        Attributes of current convolution
    inputs : list of tvm.relay.Expr
        The args of the Relay expr to be legalized
    types : list of types
        List of input and output types

    Returns
    -------
    result : tvm.relay.Expr
        The legalized expr
    """
    return xm_conv2d_legalize(attrs, inputs, types)

@reg.register_alter_op_layout("xm.conv2d")
def alter_op_layout_conv2d(attrs, inputs, tinfos, out_type):
    """Alternate the layout of conv2d"""
    #assert 0
    #return topi.nn.conv2d_alter_layout(attrs, inputs, tinfos, out_type)
    return None

@reg.register_alter_op_layout("xm.pool2d")
def alter_op_layout_pool2d(attrs, inputs, tinfos, out_type):
    """Alternate the layout of pool2d"""

    return None

@reg.register_convert_op_layout("xm.conv2d")
def convert_conv2d(attrs, inputs, tinfos, desired_layouts):
    assert 0
    # pylint: disable=import-outside-toplevel
    from tvm import relay

    data, weight = inputs

    # First check if there is a LayoutConfig scope, and if so, whether
    # it indicates we should ignore this layer or not.
    layout_config = LayoutConfig.current
    if layout_config is not None:
        skip_layer = layout_config.check_skip()
        if skip_layer:
            return relay.nn.conv2d(data, weight, **attrs)

    # Prepare new layout.
    new_attrs = dict(attrs)
    assert len(desired_layouts) == 2, "A desired layout is expected for both of nn.conv2d's inputs"
    desired_data_layout, desired_kernel_layout = map(str, desired_layouts)
    assert desired_data_layout != "default", "Data layout cannot be default"
    new_attrs["data_layout"] = desired_data_layout

    if desired_kernel_layout != "default":
        new_attrs["kernel_layout"] = desired_kernel_layout
        return relay.nn.conv2d(data, weight, **new_attrs)

    # Handle default kernel layouts
    if desired_data_layout == "NCHW":
        new_attrs["kernel_layout"] = "OIHW"
        return relay.nn.conv2d(data, weight, **new_attrs)
    elif desired_data_layout == "NHWC":
        # Check for depthwise convolution.
        data_info, weight_info = tinfos
        if is_depthwise_conv2d(
            data_info.shape,
            attrs["data_layout"],
            weight_info.shape,
            attrs["kernel_layout"],
            attrs["groups"],
        ):
            new_attrs["kernel_layout"] = "HWOI"
        else:
            new_attrs["kernel_layout"] = "HWIO"
        return relay.nn.conv2d(data, weight, **new_attrs)
    elif desired_data_layout == "HWNC":
        new_attrs["kernel_layout"] = "HWOI"
        return relay.nn.conv2d(data, weight, **new_attrs)

    raise ValueError("Layout %s is not yet supported." % desired_data_layout)


@tvm.target.generic_func
def xm_qnn_conv2d_legalize(attrs, inputs, types):
    # not to change by default
    data, kernel, bias = inputs
    return None

@tvm.target.generic_func
def xm_conv2d_legalize(attrs, inputs, types):

    assert (attrs.output_scale.data.dtype != "float32")
    return None

@tvm.target.generic_func
def xm_pool2d_legalize(attrs, inputs, types):

    return None

'''
register_partition_function
@register_annotate_function("xm.conv2d")
def conv2d_rewrite(ref_call, new_args, ctx):
    assert 0

    return None
'''
