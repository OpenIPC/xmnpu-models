import tvm
import tvm.relay as relay
import mxnet.ndarray as nd
import mxnet as mx
import json
from copy import deepcopy
import os

def save_xmir_params(wb_params,params_list,params_path):
    """save params as a mxnet params type"""
    new_params = {}
    for i in range(len(wb_params)):
        tmp = wb_params[i]
        arr = arrtarnas(tmp)
        key = params_list[i]
        new_params[key] = arr

    mx.nd.save(params_path, new_params)

def save_quantize_params(new_params, quantize_params_dict, params_path):
    """save params as a mxnet params type"""
    quantize_params = {}
    keys = quantize_params_dict.keys()
    for key in keys:
        name = quantize_params_dict[key]
        data = new_params[key]
        arr = arrtarnas(data)
        quantize_params[name] = arr
    mx.nd.save(params_path, quantize_params)

def save_params(new_params, params_dict, params_path):
    """save params as a mxnet params type"""
    relayir_params = {}
    keys = params_dict.keys()
    for key in keys:
        if(len(new_params[key].shape)):
            name = params_dict[key]
            data = new_params[key]
            arr = arrtarnas(data)
            relayir_params[name] = arr
        else:
            name = params_dict[key]
            n_data = (new_params[key].numpy())
            n_data = nd.array(n_data.reshape(1))
            relayir_params[name] = n_data
    mx.nd.save(params_path, relayir_params)
    
def arrtarnas(tvmarr):
    """change params data tpye to mxnet data type"""
    nparr = tvmarr.numpy()
    arr = nd.array(nparr)
    return arr

def _set_params(mod):
    """help function to handle every dfs order node"""
    wb_params = []
    scale_params = []
    def visit_func(expr):
        if isinstance(expr, tvm.relay.expr.Call):
            if(str(expr.op) == 'nn.pad'):
                scale_params.pop()
        if isinstance(expr, tvm.relay.expr.Constant):
            name = str(expr)
            data_type = expr.data.dtype
            if(name.startswith('meta')):
                data = expr.data
                wb_params.append(data)
            elif(data_type == 'float32'):
                data = str(expr.data)
                scale_params.append(data)

    main_func = mod["main"]
    tvm.relay.analysis.post_order_visit(main_func, visit_func)
    return wb_params, scale_params

def create_params(mod, params):
    """create xmir's weight bias params and scale params"""
    with tvm.transform.PassContext(opt_level=3):
        f = relay.build_module.bind_params_by_name(mod["main"], params)
        mod = tvm.IRModule()
        mod["main"] = f

        wb_params, scale_params = _set_params(mod)
        return wb_params, scale_params

class xmir_node_fun():
    """
    the class to convert every xmir to a json node.
    """
    
    def xm_conv2d(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,params_list,scale_params,scale_index):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('xm.conv2d')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('*/')[-2].split('/*')[0].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()
        weight_name = output_name + '_' + 'weight'
        params_list.append(weight_name)
        bias_name = output_name + '_' + 'bias'
        params_list.append(bias_name)
        
        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])
            index[0]+=1

        nodes_name[weight_name] = deepcopy(index)
        index[0]+=1
        nodes_name[bias_name] = deepcopy(index)
        index[0]+=1
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[weight_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[bias_name]))
        
        tmp_dic['name'] = weight_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[weight_name][0])

        tmp_dic['name'] = bias_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[bias_name][0])
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'Convolution'

        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        tmp_dic_output['param']['input_scale'] = scale_params[scale_index[0] + 0]
        tmp_dic_output['param']['kernel_scale'] = scale_params[scale_index[0] + 1]
        tmp_dic_output['param']['output_scale'] = scale_params[scale_index[0] + 3]
        if(len(scale_params) > 4):
            scale_index[0]+=4

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()
        
        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def xm_eltwise_add(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,params_list,scale_params,scale_index):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
            
        input_str = node.split('xm.eltwise_add')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('/*')[0].split(')')[0]
        
        inputl_name = input_str.split('%')[1].split(',')[0].strip()
        inputr_name = input_str.split('%')[2].split(',')[0].strip()
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputl_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'eltwise_add'

        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value
        tmp_dic_output['param']['lhs_scale'] = scale_params[scale_index[0] + 0]
        tmp_dic_output['param']['rhs_scale'] = scale_params[scale_index[0] + 1]
        tmp_dic_output['param']['out_scale'] = scale_params[scale_index[0] + 2]
        if(len(scale_params) > 3):
            scale_index[0]+=3

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()
        
        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def xm_pool2d(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,params_list,scale_params,scale_index):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
            
        input_str = node.split('xm.pool2d')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('/*')[0].split(')')[0]

        input_name = input_str.split('%')[1].split(',')[0].strip()

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'Pooling'

        params_num = params_str.count('=')
        params_str_list = params_str.split('=')

        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()
        
        new_json["nodes"].append(deepcopy(tmp_dic_output))

class quantize_node_fun():
    """
    the class to convert every uint8 relayir to a json node.
    """
    
    def qnn_conv2d(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('qnn.conv2d')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str1_list = input_str.split('%')[-1].split(',')[1:5]
        params_str2 = input_str.split('*/')[-2].split('/*')[0].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()
        weight_name_key = input_str.split('%')[2].split(',')[0].strip()
        weight_name = output_name + '_' + weight_name_key
        quantize_params_dict[weight_name_key] = weight_name
        
        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[weight_name] = deepcopy(index)
        index[0]+=1
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[weight_name]))
        
        tmp_dic['name'] = weight_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[weight_name][0])

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'Convolution'

        tmp_dic_output['param']['input_zero_point'] = params_str1_list[0].split('/*')[0].strip()
        tmp_dic_output['param']['kernel_zero_point'] = params_str1_list[1].split('/*')[0].strip()
        tmp_dic_output['param']['input_scale'] = params_str1_list[2].split('/*')[0].strip()
        tmp_dic_output['param']['kernel_scale'] = params_str1_list[3].split('/*')[0].strip()
        
        params_num = params_str2.count('=')
        params_str2_list = params_str2.split('=')
        
        for k in range(params_num):
            key = params_str2_list[k].split(',')[-1].strip()
            if(params_str2_list[k+1].startswith('[')):
                value = '[' + params_str2_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str2_list[k+1].startswith('\"')):
                value = eval(params_str2_list[k+1].split(',')[0])
            else:
                value = (params_str2_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def qnn_conv2d_bias_add(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('qnn.conv2d_bias_add')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str1_list = input_str.split('%')[-1].split(',')[1:5]
        params_str2 = input_str.split('*/')[-2].split('/*')[0].split(')')[0]

        input_name = input_str.split('%')[1].split(',')[0].strip()
        weight_name_key = input_str.split('%')[2].split(',')[0].strip()
        weight_name = output_name + '_' + weight_name_key
        quantize_params_dict[weight_name_key] = weight_name

        bias_name_key = input_str.split('%')[3].split(',')[0].strip()
        bias_name = output_name + '_' + bias_name_key
        quantize_params_dict[bias_name_key] = bias_name
        
        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[weight_name] = deepcopy(index)
        index[0]+=1
        nodes_name[bias_name] = deepcopy(index)
        index[0]+=1
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[weight_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[bias_name]))
        
        tmp_dic['name'] = weight_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[weight_name][0])

        tmp_dic['name'] = bias_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[bias_name][0])

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'Convolution'

        tmp_dic_output['param']['input_zero_point'] = params_str1_list[0].split('/*')[0].strip()
        tmp_dic_output['param']['kernel_zero_point'] = params_str1_list[1].split('/*')[0].strip()
        tmp_dic_output['param']['input_scale'] = params_str1_list[2].split('/*')[0].strip()
        tmp_dic_output['param']['kernel_scale'] = params_str1_list[3].split('/*')[0].strip()
        
        params_num = params_str2.count('=')
        params_str2_list = params_str2.split('=')
        
        for k in range(params_num):
            key = params_str2_list[k].split(',')[-1].strip()
            if(params_str2_list[k+1].startswith('[')):
                value = '[' + params_str2_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str2_list[k+1].startswith('\"')):
                value = eval(params_str2_list[k+1].split(',')[0])
            else:
                value = (params_str2_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def qnn_dense(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('qnn.dense')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str1_list = input_str.split('%')[-1].split(',')[1:5]
        params_str2 = input_str.split('*/')[-2].split('/*')[0].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()
        weight_name_key = input_str.split('%')[2].split(',')[0].strip()
        weight_name = output_name + '_' + weight_name_key
        
        quantize_params_dict[weight_name_key] = weight_name
        
        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[weight_name] = deepcopy(index)
        index[0]+=1
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[weight_name]))
        
        tmp_dic['name'] = weight_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[weight_name][0])

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'dense'

        tmp_dic_output['param']['input_zero_point'] = params_str1_list[0].split('/*')[0].strip()
        tmp_dic_output['param']['kernel_zero_point'] = params_str1_list[1].split('/*')[0].strip()
        tmp_dic_output['param']['input_scale'] = params_str1_list[2].split('/*')[0].strip()
        tmp_dic_output['param']['kernel_scale'] = params_str1_list[3].split('/*')[0].strip()
        
        params_num = params_str2.count('=')
        params_str2_list = params_str2.split('=')
        
        for k in range(params_num):
            key = params_str2_list[k].split(',')[-1].strip()
            if(params_str2_list[k+1].startswith('[')):
                value = '[' + params_str2_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str2_list[k+1].startswith('\"')):
                value = eval(params_str2_list[k+1].split(',')[0])
            else:
                value = (params_str2_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def qnn_mul(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('qnn.mul')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str_list = input_str.split('%')[-1].split(')')[0].split(',')[1:7]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()
        weight_name_key = input_str.split('%')[2].split(',')[0].strip()
        weight_name = output_name + '_' + weight_name_key
        quantize_params_dict[weight_name_key] = weight_name
        
        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[weight_name] = deepcopy(index)
        index[0]+=1
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[weight_name]))
        
        tmp_dic['name'] = weight_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[weight_name][0])

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'mul'
    
        tmp_dic_output['param']['lhs_scale'] = params_str_list[0].split('/*')[0].strip()
        tmp_dic_output['param']['lhs_zero_point'] = params_str_list[1].split('/*')[0].strip()
        tmp_dic_output['param']['rhs_scale'] = params_str_list[2].split('/*')[0].strip()
        tmp_dic_output['param']['rhs_zero_point'] = params_str_list[3].split('/*')[0].strip()
        tmp_dic_output['param']['output_scale'] = params_str_list[4].split('/*')[0].strip()
        tmp_dic_output['param']['output_zero_point'] = params_str_list[5].split('/*')[0].strip()
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def nn_bias_add(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.bias_add')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]

        input_name = input_str.split('%')[1].split(',')[0].strip()
        bias_name_key = input_str.split('%')[2].split(')')[0].split(',')[0].strip()
        bias_name = output_name + '_' + bias_name_key
        quantize_params_dict[bias_name_key] = bias_name

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'bias_add'

        nodes_name[bias_name] = deepcopy(index)
        index[0]+=1
        
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[bias_name]))
        
        tmp_dic['name'] = bias_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[bias_name][0])
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        if('=' in params_str):
            key = params_str.split('=')[0].split(',')[-1].strip()
            value = params_str.split('=')[-1].strip()
            tmp_dic_output['param'][key] = value
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def cast(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('cast')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'cast'

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def reshape(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('reshape')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'reshape'

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        key = params_str.split('=')[0].split(',')[-1].strip()
        value = params_str.split('=')[-1].strip()
        tmp_dic_output['param'][key] = value
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
    
    def nn_softmax(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.softmax')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].split(')')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'softmax'
        
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def qnn_requantize(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('qnn.requantize')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str1_list = input_str.split('%')[-1].split(',')[1:5]
        params_str2 = input_str.split('*/')[-2].split('/*')[0].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'requantize'

        tmp_dic_output['param']['input_scale'] = params_str1_list[0].split('/*')[0].strip()
        tmp_dic_output['param']['input_zero_point'] = params_str1_list[1].split('/*')[0].strip()
        tmp_dic_output['param']['output_scale'] = params_str1_list[2].split('/*')[0].strip()
        tmp_dic_output['param']['output_zero_point'] = params_str1_list[3].split('/*')[0].strip()
        
        params_num = params_str2.count('=')
        params_str2_list = params_str2.split('=')
        
        for k in range(params_num):
            key = params_str2_list[k].split(',')[-1].strip()
            if(params_str2_list[k+1].startswith('[')):
                value = '[' + params_str2_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str2_list[k+1].startswith('\"')):
                value = eval(params_str2_list[k+1].split(',')[0])
            else:
                value = (params_str2_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def qnn_dequantize(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('qnn.dequantize')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'dequantize'

        tmp_dic_output['param']['input_scale'] = params_str.split(',')[1].split('/*')[0].strip()
        tmp_dic_output['param']['input_zero_point'] = params_str.split(',')[2].split('/*')[0].strip()
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def qnn_add(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('qnn.add')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str_list = input_str.split('%')[-1].split(')')[0].split(',')[1:]
        
        inputl_name = input_str.split('%')[1].split(',')[0].strip()
        inputr_name = input_str.split('%')[2].split(',')[0].strip()

        if inputl_name not in nodes_name:
            nodes_name[inputl_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = inputl_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[inputl_name][0])

        if inputr_name not in nodes_name:
            inputr_name_key = inputr_name
            inputr_name = output_name + '_' + inputr_name_key
            quantize_params_dict[inputr_name_key] = inputr_name

            nodes_name[inputr_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = inputr_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[inputr_name][0])

            tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))
        else:
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputl_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'add'

        tmp_dic_output['param']['lhs_scale'] = params_str_list[0].split('/*')[0].strip()
        tmp_dic_output['param']['lhs_zero_point'] = params_str_list[1].split('/*')[0].strip()
        tmp_dic_output['param']['rhs_scale'] = params_str_list[2].split('/*')[0].strip()
        tmp_dic_output['param']['rhs_zero_point'] = params_str_list[3].split('/*')[0].strip()
        tmp_dic_output['param']['output_scale'] = params_str_list[4].split('/*')[0].strip()
        tmp_dic_output['param']['output_zero_point'] = params_str_list[5].split('/*')[0].strip()
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def qnn_quantize(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('qnn.quantize')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'quantize'

        tmp_dic_output['param']['output_scale'] = params_str.split(',')[1].split('/*')[0].strip()
        tmp_dic_output['param']['output_zero_point'] = params_str.split(',')[2].split('/*')[0].strip()
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def nn_avg_pool2d(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.avg_pool2d')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'Pooling'
        tmp_dic_output['param']['pool_type'] = 'avg'
        
        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
    
    def nn_max_pool2d(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.max_pool2d')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'Pooling'
        tmp_dic_output['param']['pool_type'] = 'max'
        
        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def mean(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('mean')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'mean'
        
        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def nn_pad(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.pad')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str1 = input_str.split('%')[-1].split('*/')[0]
        params_str2 = input_str.split('*/')[-2].split('/*')[0].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'pad'

        tmp_dic_output['param']['pad_val'] = params_str1.split(',')[-1].split('/*')[0].strip()
        tmp_dic_output['param']['pad_width'] = params_str2.split('=')[-1].strip()
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def concat(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('(')[-1].split(')')[0]

        if ('ty=float32' in input_str):
            input_str_list = input_str.split(',')
            for i in range(len(input_str_list)):
                scale_name = 'scale_' + str(i+1)
                scale_val = input_str_list[i].split('/*')[0].strip()
                tmp_dic_output['param'][scale_name] = scale_val
            tmp_dic_output['op'] = 'concat_scale'
        elif('ty=int32' in input_str):
            input_str_list = input_str.split(',')
            for i in range(len(input_str_list)):
                zp_name = 'zp_' + str(i+1)
                zp_val = input_str_list[i].split('/*')[0].strip()
                tmp_dic_output['param'][zp_name] = zp_val
            tmp_dic_output['op'] = 'concat_zp'
        else:
            input_num = input_str.count('%')
            input_str_list = input_str.split('%')[1:]
            
            for k in range(input_num):
                input_name = input_str_list[k].split(',')[0].strip()
                tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
            tmp_dic_output['op'] = 'concat'
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        tmp_dic_output['name'] = output_name
        
        new_json["nodes"].append(deepcopy(tmp_dic_output))
    
    def qnn_concatenate(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('qnn.concatenate')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str1_list = input_str.split('%')[-1].split(',')[1:3]
        params_str2 = input_str.split('*/')[-2].split('/*')[0].split(')')[0]
        
        input_num = input_str.count('%')
        input_str_list = input_str.split('%')[1:]
        
        for k in range(input_num):
            input_name = input_str_list[k].split(',')[0].strip()
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'concatenate'

        tmp_dic_output['param']['output_scale'] = params_str1_list[0].split('/*')[0].strip()
        tmp_dic_output['param']['output_zero_point'] = params_str1_list[1].split('/*')[0].strip()
        
        params_num = params_str2.count('=')
        params_str2_list = params_str2.split('=')
        
        for k in range(params_num):
            key = params_str2_list[k].split(',')[-1].strip()
            if(params_str2_list[k+1].startswith('[')):
                value = '[' + params_str2_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str2_list[k+1].startswith('\"')):
                value = eval(params_str2_list[k+1].split(',')[0])
            else:
                value = (params_str2_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def concat_supernode(self, node,index,new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('concat_supernode')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str1_list = input_str.split('%')[-1].split(',')[1:3]
        params_str2 = input_str.split('*/')[-2].split('/*')[0].split(')')[0]
        
        input_num = input_str.count('%')
        input_str_list = input_str.split('%')[1:]
        
        for k in range(input_num):
            input_name = input_str_list[k].split(',')[0].strip()
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'concat'

        tmp_dic_output['param']['output_scale'] = params_str1_list[0].split('/*')[0].strip()
        tmp_dic_output['param']['output_zero_point'] = params_str1_list[1].split('/*')[0].strip()
        
        params_num = params_str2.count('=')
        params_str2_list = params_str2.split('=')
        
        for k in range(params_num):
            key = params_str2_list[k].split(',')[-1].strip()
            if(params_str2_list[k+1].startswith('[')):
                value = '[' + params_str2_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str2_list[k+1].startswith('\"')):
                value = eval(params_str2_list[k+1].split(',')[0])
            else:
                value = (params_str2_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

class node_fun():

    def nn_conv2d(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.conv2d')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()
        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
            
        weight_name_key = input_str.split('%')[2].split(',')[0].strip()
        if(weight_name_key in nodes_name):
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[weight_name_key]))
        else:
            weight_name = output_name + '_' + weight_name_key
            params_dict[weight_name_key] = weight_name
            nodes_name[weight_name] = deepcopy(index)
            index[0]+=1

            tmp_dic['name'] = weight_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[weight_name][0])
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[weight_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'Convolution'
        
        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def nn_conv2d_bias_add(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.conv2d_bias_add')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]

        input_name = input_str.split('%')[1].split(',')[0].strip()
        
        weight_name_key = input_str.split('%')[2].split(',')[0].strip()
        weight_name = output_name + '_' + weight_name_key
        params_dict[weight_name_key] = weight_name

        bias_name_key = input_str.split('%')[3].split(',')[0].strip()
        bias_name = output_name + '_' + bias_name_key
        params_dict[bias_name_key] = bias_name
        
        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[weight_name] = deepcopy(index)
        index[0]+=1
        nodes_name[bias_name] = deepcopy(index)
        index[0]+=1
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[weight_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[bias_name]))
        
        tmp_dic['name'] = weight_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[weight_name][0])

        tmp_dic['name'] = bias_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[bias_name][0])

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'Convolution'
        
        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def nn_batch_norm(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.batch_norm')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()
        
        gamma_name_key = input_str.split('%')[2].split(',')[0].strip()
        gamma_name = output_name + '_' + gamma_name_key
        params_dict[gamma_name_key] = gamma_name

        beta_name_key = input_str.split('%')[3].split(',')[0].strip()
        beta_name = output_name + '_' + beta_name_key
        params_dict[beta_name_key] = beta_name

        mean_name_key = input_str.split('%')[4].split(',')[0].strip()
        mean_name = output_name + '_' + mean_name_key
        params_dict[mean_name_key] = mean_name

        variance_name_key = input_str.split('%')[5].split(')')[0].split(',')[0].strip()
        variance_name = output_name + '_' + variance_name_key
        params_dict[variance_name_key] = variance_name
        
        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[gamma_name] = deepcopy(index)
        index[0]+=1
        nodes_name[beta_name] = deepcopy(index)
        index[0]+=1
        nodes_name[mean_name] = deepcopy(index)
        index[0]+=1
        nodes_name[variance_name] = deepcopy(index)
        index[0]+=1
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[beta_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[gamma_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[mean_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[variance_name]))
        
        tmp_dic['name'] = gamma_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[gamma_name][0])

        tmp_dic['name'] = beta_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[beta_name][0])

        tmp_dic['name'] = mean_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[mean_name][0])
        
        tmp_dic['name'] = variance_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[variance_name][0])

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'batch_norm'
        
        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[1].split('Tensor')[0].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def nn_dense(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.dense')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split('/*')[0].split(')')[0]
        input_name = input_str.split('%')[1].split(',')[0].strip()
        inputr_name = input_str.split('%')[2].split(',')[0].strip()
       
        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        if inputr_name not in nodes_name:
            inputr_name_key = inputr_name
            inputr_name = output_name + '_' + inputr_name_key
            params_dict[inputr_name_key] = inputr_name

            nodes_name[inputr_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = inputr_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[inputr_name][0])

            tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))
        else:
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'dense'

        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def dyn_reshape(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('dyn.reshape')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split('/*')[0].split(')')[0]
        input_name = input_str.split('%')[1].split(',')[0].strip()
        inputr_name = input_str.split('%')[2].split(',')[0].strip()
       
        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        if inputr_name not in nodes_name:
            inputr_name_key = inputr_name
            inputr_name = output_name + '_' + inputr_name_key
            params_dict[inputr_name_key] = inputr_name

            nodes_name[inputr_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = inputr_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[inputr_name][0])

            tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))
        else:
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'dyn_reshape'

        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def nn_bias_add(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.bias_add')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        input_name = input_str.split('%')[1].split(',')[0].strip()

        bias_name_key = input_str.split('%')[2].split(')')[0].split(',')[0].strip()
        bias_name = output_name + '_' + bias_name_key

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'bias_add'

        params_dict[bias_name_key] = bias_name

        nodes_name[bias_name] = deepcopy(index)
        index[0]+=1
        
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[bias_name]))
        
        tmp_dic['name'] = bias_name
        new_json["nodes"].append(deepcopy(tmp_dic))
        new_json['arg_nodes'].append(nodes_name[bias_name][0])
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        if('=' in params_str):
            key = params_str.split('=')[0].split(',')[-1].strip()
            value = params_str.split('=')[-1].strip()
            tmp_dic_output['param'][key] = value
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def divide(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('divide')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        inputl_name = input_str.split('%')[1].split(',')[0].strip()
        inputr_name = input_str.split('%')[2].split(')')[0].split(',')[0].strip()

        if inputr_name not in nodes_name:
            inputr_name_key = inputr_name
            inputr_name = output_name + '_' + inputr_name_key
            params_dict[inputr_name_key] = inputr_name

            nodes_name[inputr_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = inputr_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[inputr_name][0])
            
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))
            
        else:
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'divide'
        
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputl_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        if('=' in params_str):
            key = params_str.split('=')[0].split(',')[-1].strip()
            value = params_str.split('=')[-1].strip()
            tmp_dic_output['param'][key] = value
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def nn_relu(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.relu')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        input_name = input_str.split('%')[1].split(',')[0].split(')')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'relu'
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def exp(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('exp')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        input_name = input_str.split('%')[1].split(',')[0].split(')')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'exp'
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def nn_batch_flatten(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.batch_flatten')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        input_name = input_str.split('%')[1].split(',')[0].split(')')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'batch_flatten'
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def nn_leaky_relu(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.relu')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        input_name = input_str.split('%')[1].split(',')[0].split(')')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'leaky_relu'
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def sigmoid(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('sigmoid')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        input_name = input_str.split('%')[1].split(',')[0].split(')')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'sigmoid'
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def nn_dropout(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.dropout')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        input_name = input_str.split('%')[1].split(',')[0].split(')')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'dropout'
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        output_shape_str = output_shape_str.split('[')[1].split('Tensor')[0].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def nn_global_avg_pool2d(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.global_avg_pool2d')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        input_name = input_str.split('%')[1].split(',')[0].split(')')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'Pooling'
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        tmp_dic_output['param']['pool_type'] = 'global_avg_pool2d'
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def node_0(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'

        input_name = node.split('%')[-1].split('.')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'node_0'
        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def reshape(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('reshape')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()
        
        if input_name not in nodes_name:
            input_name_key = input_name
            input_name = output_name + '_' + input_name_key
            params_dict[input_name_key] = input_name

            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])
            
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        else:
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'reshape'
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        key = params_str.split('=')[0].split(',')[-1].strip()
        value = params_str.split('=')[-1].strip()
        tmp_dic_output['param'][key] = value
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def nn_lrn(self, node,index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.lrn')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'lrn'

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        key = params_str.split('=')[0].split(',')[-1].strip()
        value = params_str.split('=')[-1].strip()
        tmp_dic_output['param'][key] = value
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def strided_slice(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('strided_slice')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            input_name_key = input_name
            input_name = output_name + '_' + input_name_key
            params_dict[input_name_key] = input_name

            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

            tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        else:
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
            
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'strided_slice'

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def squeeze(self, node,index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('squeeze')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].split(')')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'squeeze'

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        if '=' in params_str:
            key = params_str.split('=')[0].split(',')[-1].strip()
            value = params_str.split('=')[-1].strip()
            tmp_dic_output['param'][key] = value
        
            output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
            tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
            tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def split(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('split')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].split(')')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'split'

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        if '=' in params_str:
            key = params_str.split('=')[0].split(',')[-1].strip()
            value = params_str.split('=')[-1].strip()
            tmp_dic_output['param'][key] = value
        
            output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
            tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
            tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def clip(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('clip')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'clip'

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def nn_upsampling(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.upsampling')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'upsampling'

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def nn_leaky_relu(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.leaky_relu')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'leaky_relu'

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def max(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('max')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'max'

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def sum(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('sum')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'sum'

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def nn_avg_pool2d(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.avg_pool2d')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'Pooling'

        tmp_dic_output['param']['pool_type'] = 'avg'
        
        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def nn_adaptive_avg_pool2d(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.adaptive_avg_pool2d')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'Pooling'

        tmp_dic_output['param']['pool_type'] = 'adaptive_avg'
        
        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def nn_max_pool2d(self, node,index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.max_pool2d')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'Pooling'
        
        tmp_dic_output['param']['pool_type'] = 'max'
        
        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def concat(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
            
        if ('meta[relay.Constant]' in node):
            input_str = node.split('%')[-1].split(')')[0].strip()
            input_name_key = input_str
            input_name = output_name + '_' + input_name_key
            params_dict[input_name_key] = input_name

            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])
            
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        else:
            input_str = node.split('(')[-1].split(')')[0]

            if ('ty=float32' in input_str):
                input_str_list = input_str.split(',')
                for i in range(len(input_str_list)):
                    scale_name = 'scale_' + str(i+1)
                    scale_val = input_str_list[i].split('/*')[0].strip()
                    tmp_dic_output['param'][scale_name] = scale_val
                tmp_dic_output['op'] = 'concat_scale'
            elif('ty=int32' in input_str):
                input_str_list = input_str.split(',')
                for i in range(len(input_str_list)):
                    zp_name = 'zp_' + str(i+1)
                    zp_val = input_str_list[i].split('/*')[0].strip()
                    tmp_dic_output['param'][zp_name] = zp_val
                tmp_dic_output['op'] = 'concat_zp'
            else:
                input_num = input_str.count('%')
                input_str_list = input_str.split('%')[1:]

                for k in range(input_num):
                    input_name = input_str_list[k].split(',')[0].strip()
                    if input_name not in nodes_name:
                        input_name_key = input_name
                        input_name = output_name + '_' + input_name_key
                        params_dict[input_name_key] = input_name

                        nodes_name[input_name] = deepcopy(index)
                        index[0]+=1
                        tmp_dic['name'] = input_name
                        new_json["nodes"].append(deepcopy(tmp_dic))
                        new_json['arg_nodes'].append(nodes_name[input_name][0])
                        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
                    else:
                        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))

                tmp_dic_output['op'] = 'concat'
            
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        tmp_dic_output['name'] = output_name
        
        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def concatenate(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('concatenate')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split('/*')[0].split(')')[0]
        
        input_num = input_str.count('%')
        input_str_list = input_str.split('%')[1:]
        
        for k in range(input_num):
            input_name = input_str_list[k].split(')')[0].split(',')[0].strip()
            
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'concatenate'
        
        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def concat_supernode(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('concat_supernode')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split('/*')[0].split(')')[0]
        
        input_num = input_str.count('%')
        input_str_list = input_str.split('%')[1:]
        
        for k in range(input_num):
            input_name = input_str_list[k].split(',')[0].strip()
            
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'concat'
        
        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def nn_softmax(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.softmax')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        input_name = input_str.split('%')[1].split(')')[0].split(',')[0].strip()

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'softmax'

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        if('=' in params_str):
            key = params_str.split('=')[0].split(',')[-1].strip()
            value = params_str.split('=')[-1].strip()
            tmp_dic_output['param'][key] = value
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def add(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('add(')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        
        inputl_name = input_str.split('%')[1].split(',')[0].strip()
        inputr_name = input_str.split('%')[2].split(',')[0].split(')')[0].strip()

        if inputl_name not in nodes_name:
            nodes_name[inputl_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = inputl_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[inputl_name][0])

        if inputr_name not in nodes_name:
            inputr_name_key = inputr_name
            
            inputr_name_key = inputr_name
            inputr_name = output_name + '_' + inputr_name_key
            params_dict[inputr_name_key] = inputr_name

            nodes_name[inputr_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = inputr_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[inputr_name][0])
            

            tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))
            
        else:
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputl_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'add'
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def multiply(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('multiply')[-1].split(')')[0].split('(')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        
        inputl_name = input_str.split(',')[0].split('/*')[0].strip()
        inputr_name = input_str.split(',')[-1].split('/*')[0].strip()

        if (inputl_name.startswith('%')):
            inputl_name = inputl_name.split('%')[-1]
            if inputl_name in nodes_name:
                tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputl_name]))
            else:
                inputl_name_key = inputl_name
                inputl_name = output_name + '_' + inputl_name_key
                params_dict[inputl_name_key] = inputl_name

                nodes_name[inputl_name] = deepcopy(index)
                index[0]+=1
                tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputl_name]))
                
                tmp_dic['name'] = inputl_name
                new_json["nodes"].append(deepcopy(tmp_dic))
                
                new_json['arg_nodes'].append(nodes_name[inputl_name][0])
        else:
            tmp_dic_output['param']['mul_lval'] = inputl_name

        if (inputr_name.startswith('%')):
            inputr_name = inputr_name.split('%')[-1]
            if inputr_name in nodes_name:
                tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))
            else:
                inputr_name_key = inputr_name
                inputr_name = output_name + '_' + inputr_name_key
                params_dict[inputr_name_key] = inputr_name

                nodes_name[inputr_name] = deepcopy(index)
                index[0]+=1
                tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))
                
                tmp_dic['name'] = inputr_name
                new_json["nodes"].append(deepcopy(tmp_dic))
                
                new_json['arg_nodes'].append(nodes_name[inputr_name][0])
        else:
            tmp_dic_output['param']['mul_val'] = inputr_name

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'multiply'
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def power(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('power')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        inputl_name = input_str.split('%')[1].split(',')[0].strip()
        inputr_name = input_str.split('/*')[0].split(')')[0].split(',')[-1].strip()
        
        if inputl_name not in nodes_name:
            nodes_name[inputl_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = inputl_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[inputl_name][0])

        if (inputr_name.startswith('%')):
            inputr_name = inputr_name.split('%')[-1]
            if inputr_name in nodes_name:
                tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))
        else:
            tmp_dic_output['param']['power_val'] = inputr_name

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputl_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'power'
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def subtract(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('subtract')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        inputl_name = input_str.split('%')[1].split(',')[0].strip()
        inputr_name = input_str.split('/*')[0].split(')')[0].split(',')[-1].strip()

        if inputl_name not in nodes_name:
            nodes_name[inputl_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = inputl_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[inputl_name][0])

        if (inputr_name.startswith('%')):
            inputr_name = inputr_name.split('%')[-1]
            if inputr_name in nodes_name:
                tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))
            else:
                inputr_name_key = inputr_name
                inputr_name = output_name + '_' + inputr_name_key
                params_dict[inputr_name_key] = inputr_name

                nodes_name[inputr_name] = deepcopy(index)
                index[0]+=1
                tmp_dic['name'] = inputr_name
                new_json["nodes"].append(deepcopy(tmp_dic))
                new_json['arg_nodes'].append(nodes_name[inputr_name][0])
            
                tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputr_name]))
            
        else:
            tmp_dic_output['param']['subtract_val'] = inputr_name

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[inputl_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'subtract'
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def nn_pad(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('nn.pad')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str1 = input_str.split('%')[-1].split('*/')[0]
        params_str2 = input_str.split('*/')[1].split('/*')[0].split(')')[0]

        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'pad'

        tmp_dic_output['param']['pad_val'] = params_str1.split(',')[-1].split('/*')[0].strip()
        tmp_dic_output['param']['pad_width'] = params_str2.split('=')[-1].strip()
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def mean(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('mean')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        
        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'mean'
        
        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))

    def image_resize2d(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('image.resize2d')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'image.resize2d'
        
        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value

        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
    def transpose(self, node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict):
        if (node.startswith('%')):
            output_name = node.split('=')[0].split('%')[-1].strip()
        else:
            output_name = 'output'
        input_str = node.split('transpose(')[-1]
        output_shape_str = input_str.split('/*')[-1].split('*/')[0]
        params_str = input_str.split('%')[-1].split(')')[0]
        input_name = input_str.split('%')[1].split(',')[0].strip()

        if input_name not in nodes_name:
            input_name_key = input_name
            input_name = output_name + '_' + input_name_key
            params_dict[input_name_key] = input_name

            nodes_name[input_name] = deepcopy(index)
            index[0]+=1
            tmp_dic['name'] = input_name
            new_json["nodes"].append(deepcopy(tmp_dic))
            new_json['arg_nodes'].append(nodes_name[input_name][0])

            tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
        else:
            tmp_dic_output['inputs'].append(deepcopy(nodes_name[input_name]))
            
        tmp_dic_output['name'] = output_name
        tmp_dic_output['op'] = 'transpose'

        nodes_name[output_name] = deepcopy(index)
        index[0]+=1

        params_num = params_str.count('=')
        params_str_list = params_str.split('=')
        
        for k in range(params_num):
            key = params_str_list[k].split(',')[-1].strip()
            if(params_str_list[k+1].startswith('[')):
                value = '[' + params_str_list[k+1].split('[')[-1].split(']')[0] + ']'
            elif(params_str_list[k+1].startswith('\"')):
                value = eval(params_str_list[k+1].split(',')[0])
            else:
                value = (params_str_list[k+1].split(',')[0])
            tmp_dic_output['param'][key] = value
        
        output_shape_str = output_shape_str.split('[')[-1].split(']')[0]
        tmp_dic_output['param']['output_shape'] = output_shape_str.split('(')[-1].split(')')[0].strip()
        tmp_dic_output['param']['output_dtype'] = output_shape_str.split(',')[-1].strip()

        new_json["nodes"].append(deepcopy(tmp_dic_output))
        
def xmir_getnode(node, index, new_json,nodes_name,params_list,scale_params,scale_index):
    if(node.startswith('%')):
        index_num = node.find('=')+2
        node_name = node[index_num:]
        if(node_name.startswith('%')):
            node_name = 'node_0'
        elif(node_name.startswith('nn')):
            node_name = node_name.split('(')[0].split('.')[-1].strip()
        elif(node_name.startswith('(')):
            node_name = 'concat'
        else:
            node_name = node_name.split('(')[0].strip()
    else:
        node_name = node.split('(')[0].strip()
    node_name = node_name.replace('.','_')
    tmp_dic = {"op": "params","param": {}, "name": "X", "inputs": []}
    tmp_dic_output = {"op": "null", "param": {}, "name": "X", "inputs": []}

    nf = xmir_node_fun()
    op = getattr(nf, node_name, None)
    op(node, index, new_json,tmp_dic,tmp_dic_output,nodes_name,params_list,scale_params,scale_index)

def quantize_getnode(node, index, new_json,nodes_name,quantize_params_dict):
    if(node.startswith('%')):
        index_num = node.find('=')+2
        node_name = node[index_num:]
        if(node_name.startswith('%')):
            node_name = 'node_0'
        elif(node_name.startswith('(')):
            node_name = 'concat'
        else:
            node_name = node_name.split('(')[0].strip()
    else:
        node_name = node.split('(')[0].strip()

    node_name = node_name.replace('.','_')
    tmp_dic = {"op": "params","param": {}, "name": "X", "inputs": []}
    tmp_dic_output = {"op": "null", "param": {}, "name": "X", "inputs": []}

    nf = quantize_node_fun()
    op = getattr(nf, node_name, None)
    op(node, index, new_json,tmp_dic,tmp_dic_output,nodes_name,quantize_params_dict)

def getnode(node, index, new_json, nodes_name, params_dict):
    if(node.startswith('%')):
        index_num = node.find('=')+2
        node_name = node[index_num:]
        
        if(node_name.startswith('%')):
            node_name = 'node_0'
        elif(node_name.startswith('(')):
            node_name = 'concat'
        else:
            node_name = node_name.split('(')[0].strip()
    else:
        if(node.startswith('(')):
            node_name = 'concat'
        else:
            node_name = node.split('(')[0].strip()

    node_name = node_name.replace('.','_')
    tmp_dic = {"op": "params","param": {}, "name": "X", "inputs": []}
    tmp_dic_output = {"op": "null", "param": {}, "name": "X", "inputs": []}

    nf = node_fun()
    op = getattr(nf, node_name, None)
    op(node, index, new_json, tmp_dic, tmp_dic_output, nodes_name, params_dict)
    
def xmir_mod2json(scale_params,mod, json_path):
    str_mod = str(mod)
    new_json = {"nodes":[],"arg_nodes":[],"heads":[]}
    nodes = str_mod.split('{')[-1].split('}')[0].split(';')

    nodes_name = {}
    index = [0,0]
    scale_index = [0]
    params_list = []
    for i in range(len(nodes)):
        nodes[i] = nodes[i].replace('\n','').strip()
        xmir_getnode(nodes[i], index, new_json,nodes_name,params_list,scale_params,scale_index)

    """add input shape to first layer"""
    all_vars = str(tvm.relay.analysis.all_vars(mod['main']))
    input_shape_str = all_vars.split('TensorType')[-1]
    input_shape_val = input_shape_str.split('[')[-1].split(']')[0]
    input_dtype_val = input_shape_str.split(',')[-1].split(')')[0].strip()
    for i in range(len(new_json["nodes"])):
        if(new_json["nodes"][i]['op'] != 'params'):
            new_json["nodes"][i]['param']['input_shape'] = input_shape_val
            new_json["nodes"][i]['param']['input_dtype'] = input_dtype_val
            break
        
    format_json = json.dumps(new_json,sort_keys=False, indent=2,separators=(',',':'))
    with open(json_path, 'w') as file_obj:
        file_obj.write(format_json)
    return params_list

def quantize_mod2json(mod, json_path):
    quantize_str_mod = str(mod)
    new_json = {"nodes":[],"arg_nodes":[],"heads":[]}
    nodes = quantize_str_mod.split('{')[-1].split('}')[0].split(';')
    nodes_name = {}
    index = [0,0]
    quantize_params_dict = {}
    
    for i in range(len(nodes)):
        nodes[i] = nodes[i].replace('\n','').strip()
        quantize_getnode(nodes[i], index, new_json,nodes_name,quantize_params_dict)
        
    """add input shape to first layer"""
    all_vars = str(tvm.relay.analysis.all_vars(mod['main'])[0])
    input_shape_str = all_vars.split('Tensor')[-1]
    input_shape_val = input_shape_str.split('(')[-1].split(')')[0]
    input_dtype_val = input_shape_str.split(',')[-1].split(']')[0].strip()
    for i in range(len(new_json["nodes"])):
        if(new_json["nodes"][i]['op'] != 'params'):
            new_json["nodes"][i]['param']['input_shape'] = input_shape_val
            new_json["nodes"][i]['param']['input_dtype'] = input_dtype_val
            break

    format_json = json.dumps(new_json,sort_keys=False, indent=2,separators=(',',':'))
    with open(json_path, 'w') as file_obj:
        file_obj.write(format_json)
    return quantize_params_dict

def mod2json(mod, json_path):
    str_mod = str(mod['main'])
    new_json = {"nodes":[],"arg_nodes":[],"heads":[]}
    nodes = str_mod.split('{')[-1].split('}')[0].split(';')
    nodes_name = {}
    index = [0,0]
    params_dict = {}
    
    for i in range(len(nodes)):
        nodes[i] = nodes[i].replace('\n','').strip()
        getnode(nodes[i], index, new_json,nodes_name,params_dict)

    """add input shape to first layer"""
    all_vars = str(tvm.relay.analysis.all_vars(mod['main'])[0])
    input_shape_str = all_vars.split('Tensor')[-1]
    input_shape_val = input_shape_str.split('(')[-1].split(')')[0]
    input_dtype_val = input_shape_str.split(',')[-1].split(']')[0].strip()
    for i in range(len(new_json["nodes"])):
        if(new_json["nodes"][i]['op'] != 'params'):
            new_json["nodes"][i]['param']['input_shape'] = input_shape_val
            new_json["nodes"][i]['param']['input_dtype'] = input_dtype_val
            break

    """add macs number to last layer"""
    total_mac_num = relay.analysis.get_total_mac_number(mod['main'])
    new_json["nodes"][-1]['param']['mac_num'] = total_mac_num

    format_json = json.dumps(new_json,sort_keys=False, indent=2,separators=(',',':'))
    with open(json_path, 'w') as file_obj:
        file_obj.write(format_json)
    return params_dict
    
def rebuild_quantize_relay(mod,quantize_json_path):
    """
    function to help to rebuild relay ir
    convert detail relay ir to brief relay ir
    delete the not care ops as clip, pad...
    combine conv2d adn bias_add to a op conv2d_bias_add
    combine the concat ops to a concat_supernode
    """
    
    quantize_str_mod = str(mod)
    nodes = quantize_str_mod.split('{')[-1].split('}')[0].split(';')
    res_relay = []
    repeat_dict = {}
    
    for i in range(len(nodes)):
        nodes[i] = nodes[i].replace('\n','').strip()
        node_name = nodes[i].split('(')[0].split('=')[-1].strip()
        node_name = node_name.replace('.','_')
        if (node_name == 'cast' or node_name == 'clip' or node_name == 'shift' or node_name == 'nn_pad'
            or node_name == 'mean'):
            key = '%' + nodes[i].split('=')[0].split('%')[-1].strip()
            value = '%' + nodes[i].split('%')[-1].split(',')[0].strip()
            repeat_dict[key] = value
            continue
        res_relay.append(nodes[i])
        
    res_relay_supernode = []
    count = 0
    while (count < len(res_relay)):
        row = res_relay[count]
        node_name = row.split('(')[0].split('=')[-1].strip().split('.')[-1]
        
        if(node_name == 'conv2d'):
            if((count+1) < len(res_relay)):
                bias_name = res_relay[count+1].split('(')[0].split('=')[-1].strip().split('.')[-1]
                if(bias_name == 'bias_add'):
                    bias_params_name = ', %' + res_relay[count+1].split('%')[-1].split(')')[0].split(',')[0].strip()
                    rp_key = '%' + res_relay[count+1].split('=')[0].split('%')[-1].strip()
                    rp_value = '%' + res_relay[count+1].split('%')[2].split(',')[0].strip()
                    repeat_dict[rp_key] = rp_value

                    insert_index_tmp = row.rfind('%')
                    insert_index = row.find(',',insert_index_tmp)
                    supernode_row_list = list(row)
                    supernode_row_list.insert(insert_index, bias_params_name)
                    supernode_row = ''.join(supernode_row_list)
                    supernode_row = supernode_row.replace('conv2d','conv2d_bias_add')
                    res_relay_supernode.append(supernode_row)
                    count = count + 2
                    continue

        if(node_name == ''):
            if((count+3) < len(res_relay)):
                scale_name = res_relay[count+1].split('(')[0].split('=')[-1].strip().split('.')[-1]
                zp_name = res_relay[count+2].split('(')[0].split('=')[-1].strip().split('.')[-1]
                concat_name = res_relay[count+3].split('(')[0].split('=')[-1].strip().split('.')[-1]
                if(scale_name == '' and zp_name == '' and concat_name == 'concatenate'):
                    input_str = res_relay[count].split('(')[-1].split(')')[0]
                    supernode_row_left = res_relay[count+3].split('(')[0] + '('
                    supernode_row_right = res_relay[count+3].split('%')[-1]
                    insert_index = supernode_row_right.find(',')
                    supernode_row_right = (supernode_row_right)[insert_index:]

                    supernode_concat = supernode_row_left + input_str + supernode_row_right
                    supernode_concat = supernode_concat.replace('qnn.concatenate','concat_supernode')
                    res_relay_supernode.append(supernode_concat)
                    count = count + 4
                    continue
                elif(scale_name == '' and zp_name == '' and concat_name != 'concatenate'):
                    input_str = res_relay[count].split('(')[-1].split(')')[0]
                    input_str1 = res_relay[count].split('=')[0].strip()
                    input_str2 = res_relay[count+1].split('=')[0].strip()
                    input_str3 = res_relay[count+2].split('=')[0].strip()
                    tmp_count = count + 4
                    while(tmp_count < len(res_relay)):
                        concat_name = res_relay[tmp_count].split('(')[0].split('=')[-1].strip().split('.')[-1]
                        if(concat_name == 'concatenate'):
                            if(input_str1 in res_relay[tmp_count] and input_str2 in res_relay[tmp_count] and input_str3 in res_relay[tmp_count]):
                                supernode_row_left = res_relay[tmp_count].split('(')[0] + '('
                                supernode_row_right = res_relay[tmp_count].split('%')[-1]
                                insert_index = supernode_row_right.find(',')
                                supernode_row_right = (supernode_row_right)[insert_index:]

                                supernode_concat = supernode_row_left + input_str + supernode_row_right
                                supernode_concat = supernode_concat.replace('qnn.concatenate','concat_supernode')
                                res_relay[tmp_count] = supernode_concat
                                count = count + 3
                                break
                        tmp_count = tmp_count + 1
                    continue

        res_relay_supernode.append(row)
        count = count + 1
    """use repeat_dict's keys to replace origin keys"""
    for i in range(len(res_relay_supernode)):
        row = res_relay_supernode[i]
        name_list = row.split('%')[2:]
        for key in name_list:
            key_name = key.split(')')[0].split(',')[0].strip()
            if(key_name.isdigit()):
                key_name = '%' + key_name
                while(key_name in repeat_dict):
                    res_relay_supernode[i] = res_relay_supernode[i].replace(key_name,repeat_dict[key_name])
                    key_name = repeat_dict[key_name]

    new_json = {"nodes":[],"arg_nodes":[],"heads":[]}
    nodes_name = {}
    index = [0,0]
    quantize_params_dict = {}
    for i in range(len(res_relay_supernode)):
        quantize_getnode(res_relay_supernode[i], index, new_json,nodes_name,quantize_params_dict)

    """add input shape to first layer"""
    all_vars = str(tvm.relay.analysis.all_vars(mod['main'])[0])
    input_shape_str = all_vars.split('Tensor')[-1]
    input_shape_val = input_shape_str.split('(')[-1].split(')')[0]
    input_dtype_val = input_shape_str.split(',')[-1].split(']')[0].strip()
    for i in range(len(new_json["nodes"])):
        if(new_json["nodes"][i]['op'] != 'params'):
            new_json["nodes"][i]['param']['input_shape'] = input_shape_val
            new_json["nodes"][i]['param']['input_dtype'] = input_dtype_val
            break

    format_json = json.dumps(new_json,sort_keys=False, indent=2,separators=(',',':'))
    with open(quantize_json_path, 'w') as file_obj:
        file_obj.write(format_json)
    return quantize_params_dict

def rebuild_relay(mod, json_path):
    """
    function to help to rebuild relay ir
    convert detail relay ir to brief relay ir
    delete the not care ops as clip, pad...
    combine conv2d adn bias_add to a op conv2d_bias_add
    combine the concat ops to a concat_supernode
    """
    str_mod = str(mod['main'])
    nodes = str_mod.split('{')[-1].split('}')[0].split(';')
    res_relay = []
    repeat_dict = {}
    for i in range(len(nodes)):
        nodes[i] = nodes[i].replace('\n','').strip()
        node = nodes[i]
        if(node.startswith('%')):
            index_num = node.find('=')+2
            node_name = node[index_num:]
            
            if(node_name.startswith('%')):
                node_name = 'node_0'
            elif(node_name.startswith('(')):
                node_name = 'concat'
            else:
                node_name = node_name.split('(')[0].strip()
        else:
            node_name = node.split('(')[0].strip()
        node_name = node_name.replace('.','_')

        """delete the not care ops"""
        if (node_name == 'cast' or node_name == 'clip' or node_name == 'nn_pad' or node_name == 'squeeze'
            or node_name == 'mean' or node_name == 'nn_relu' or node_name == 'nn_dropout' or node_name == 'nn_lrn' 
            or node_name == 'power' or node_name == 'sigmoid' or node_name == 'exp' or node_name == 'max' or node_name == 'sum'
            or node_name == 'nn_batch_flatten' or node_name == 'nn_leaky_relu' or node_name == 'split'):
            key = '%' + nodes[i].split('=')[0].split('%')[-1].strip()
            value = '%' + nodes[i].split('%')[-1].split(')')[0].split(',')[0].strip()
            repeat_dict[key] = value
            continue

        if (node_name == 'node_0'):
            key = '%' + nodes[i].split('=')[0].split('%')[-1].strip()
            value = '%' + nodes[i].split('%')[-1].split('.')[0].strip()
            repeat_dict[key] = value
            continue

        res_relay.append(nodes[i])

    res_relay_supernode = []

    #super node build 
    count = 0
    """ build the conv supernode and concat supernode """
    while (count < len(res_relay)):
        row = res_relay[count]
        node_name = row.split('(')[0].split('=')[-1].strip().split('.')[-1]

        if(node_name == 'conv2d'):
            if((count+1) < len(res_relay)):
                bias_name = res_relay[count+1].split('(')[0].split('=')[-1].strip().split('.')[-1]
                is_bias_add = False
                if(bias_name == 'bias_add'):
                    is_bias_add = True
                elif(bias_name == 'add'):
                    weight_name = res_relay[count+1].split('add(')[-1].split('%')[2].split(')')[0].split(',')[0].strip()
                    if(not weight_name.isdigit()):
                        is_bias_add = True

                if(is_bias_add):
                    bias_params_name = ', %' + res_relay[count+1].split('%')[-1].split(')')[0].split(',')[0].strip()
                    rp_key = '%' + res_relay[count+1].split('=')[0].split('%')[-1].strip()
                    rp_value = '%' + res_relay[count+1].split('%')[2].split(',')[0].strip()
                    repeat_dict[rp_key] = rp_value

                    insert_index_tmp = row.rfind('%')
                    insert_index = row.find(',',insert_index_tmp)
                    supernode_row_list = list(row)
                    supernode_row_list.insert(insert_index, bias_params_name)
                    supernode_row = ''.join(supernode_row_list)
                    supernode_row = supernode_row.replace('conv2d(','conv2d_bias_add(')
                    res_relay_supernode.append(supernode_row)
                    count = count + 2
                    continue

        if(node_name == ''):
            if((count+1) < len(res_relay)):
                concat_name = res_relay[count+1].split('(')[0].split('=')[-1].strip().split('.')[-1]
                if(concat_name == 'concatenate'):
                    input_str = res_relay[count].split('(')[-1].split(')')[0]
                    supernode_row_left = res_relay[count+1].split('(')[0] + '('
                    supernode_row_right = res_relay[count+1].split('%')[-1]
                    insert_index = supernode_row_right.find(',')
                    supernode_row_right = (supernode_row_right)[insert_index:]

                    supernode_concat = supernode_row_left + input_str + supernode_row_right
                    supernode_concat = supernode_concat.replace('concatenate','concat_supernode')
                    res_relay_supernode.append(supernode_concat)
                    count = count + 2
                    continue
                else:
                    output_str = res_relay[count].split('=')[0].strip()
                    input_str = res_relay[count].split('(')[-1].split(')')[0].strip()
                    tmp_count = count + 1
                    while(tmp_count < len(res_relay)):
                        concat_name = res_relay[tmp_count].split('(')[0].split('=')[-1].strip().split('.')[-1]
                        if(concat_name == 'concatenate'):
                            if(output_str in res_relay[tmp_count]):
                                supernode_row_left = res_relay[tmp_count].split('(')[0] + '('
                                supernode_row_right = res_relay[tmp_count].split('%')[-1]
                                insert_index = supernode_row_right.find(',')
                                supernode_row_right = (supernode_row_right)[insert_index:]

                                supernode_concat = supernode_row_left + input_str + supernode_row_right
                                supernode_concat = supernode_concat.replace('concatenate','concat_supernode')
                                res_relay[tmp_count] = supernode_concat
                                count = count + 1
                                break
                        tmp_count = tmp_count + 1
                    continue
                
        res_relay_supernode.append(row)
        count = count + 1

    for i in range(len(res_relay_supernode)):
        row = res_relay_supernode[i]
        if (row.startswith('%')):
            name_list = row.split('%')[2:]
        else:
            name_list = row.split('%')[1:]

        for key in name_list:
            key_name = key.split(')')[0].split(',')[0].strip()
            if(key_name.isdigit()):
                key_name = '%' + key_name
                while(key_name in repeat_dict):
                    res_relay_supernode[i] = res_relay_supernode[i].replace(key_name,repeat_dict[key_name])
                    key_name = repeat_dict[key_name]
                    
    new_json = {"nodes":[],"arg_nodes":[],"heads":[]}
    nodes_name = {}
    index = [0,0]
    params_dict = {}
    for i in range(len(res_relay_supernode)):
        getnode(res_relay_supernode[i], index, new_json,nodes_name, params_dict)

    all_vars = str(tvm.relay.analysis.all_vars(mod['main'])[0])
    input_shape_str = all_vars.split('Tensor')[-1]
    input_shape_val = input_shape_str.split('(')[-1].split(')')[0]
    input_dtype_val = input_shape_str.split(',')[-1].split(']')[0].strip()
    for i in range(len(new_json["nodes"])):
        if(new_json["nodes"][i]['op'] != 'params'):
            new_json["nodes"][i]['param']['input_shape'] = input_shape_val
            new_json["nodes"][i]['param']['input_dtype'] = input_dtype_val
            break

    total_mac_num = relay.analysis.get_total_mac_number(mod['main'])
    new_json["nodes"][-1]['param']['mac_num'] = total_mac_num

    format_json = json.dumps(new_json,sort_keys=False, indent=2,separators=(',',':'))
    with open(json_path, 'w') as file_obj:
        file_obj.write(format_json)
    return params_dict
    
def dump_xmir_json_params(mod,xm_mod, params, modelname = "model", output_path=os.getcwd()):
    json_path = output_path + '/' + modelname + '-symbol.json'
    params_path = output_path + '/' + modelname + '-0000.params'

    try:
        wb_params, scale_params = create_params(mod, params)
        params_list = xmir_mod2json(scale_params,xm_mod,json_path)
        save_xmir_params(wb_params,params_list,params_path)
        print('Visualization done!')
    except:
        raise Exception('The visualization do not support the model.')

def dump_quantize_json_params(mod, params, model_type, modelname = "model", output_path=os.getcwd(),brief_display=False):
    json_path = output_path + '/' + modelname + '-symbol.json'
    params_path = output_path + '/' + modelname + '-0000.params'

    mod = relay.transform.InferType()(mod)
    new_params = {}
    if(model_type == 'tflite'):
        keys = params.keys()
        for key in keys:
            new_key = 'v' + key
            new_params[new_key] = params[key]
    try:
        if(brief_display):
            json_path = output_path + '/' + modelname + '-bd-symbol.json'
            params_path = output_path + '/' + modelname + '-bd-0000.params'
            quantize_params_dict = rebuild_quantize_relay(mod,json_path)
        else:
            quantize_params_dict = quantize_mod2json(mod, json_path)
            
        save_quantize_params(new_params, quantize_params_dict, params_path)
        print('Visualization done!')
    except:
        raise Exception('The visualization do not support the model.')

def dump_relayir_json_params(mod, params, model_type, modelname = "model", output_path=os.getcwd(),brief_display=False):
    json_path = output_path + '/' + modelname + '-symbol.json'
    params_path = output_path + '/' + modelname + '-0000.params'
    mod = relay.transform.InferType()(mod)

    new_params = {}
    if(model_type == 'tflite' or model_type == 'caffe'):
        keys = params.keys()
        for key in keys:
            new_key = 'v' + key
            new_params[new_key] = params[key]
    elif(model_type == 'onnx'):
        keys = params.keys()
        for key in keys:
            if(key.isdigit()):
                new_key = 'v' + key
                new_params[new_key] = params[key]
            else:
                new_params[key] = params[key]
    else:
        new_params = params

    try:
        if(brief_display):
            json_path = output_path + '/' + modelname + '-bd-symbol.json'
            params_path = output_path + '/' + modelname + '-bd-0000.params'
            params_dict = rebuild_relay(mod, json_path)
        else:
            params_dict = mod2json(mod, json_path)
        
        save_params(new_params, params_dict, params_path)
        print('Visualization done!')
    except:
        raise Exception('The visualization do not support the model.')

