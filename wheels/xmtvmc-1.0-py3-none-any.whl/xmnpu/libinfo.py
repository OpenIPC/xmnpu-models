# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""Library information."""
from __future__ import absolute_import
import sys
import os
import ctypes
import json
import warnings

import tvm
from .environment import get_env
from .environment import get_xmnpu_hw_path


def _get_lib_name(lib_name):
    """Get lib name with extension

    Returns
    -------
    lib_name_ext : str
        Name of XMNPU shared library with extension

    Parameters
    ------------
    lib_name : str
        Name of XMNPU shared library
    """
    if sys.platform.startswith("win32"):
        return lib_name + ".dll"
    if sys.platform.startswith("darwin"):
        return lib_name + ".dylib"
    return lib_name + ".so"


def find_libxmnpu(lib_xmnpu, optional=False):
    """Find XMNPU Chisel-based library

    Returns
    -------
    lib_found : str
        Library path

    Parameters
    ------------
    lib_xmnpu : str
        Name of XMNPU shared library

    optional : bool
        Enable error check
    """
    curr_path = os.path.dirname(os.path.abspath(os.path.expanduser(__file__)))
    lib_search = [
        os.path.join(
            curr_path,
            "..",
            "..",
            "..",
            "build",
        )
    ]
    lib_search += [os.path.join(get_xmnpu_hw_path(), "build")]
    lib_name = _get_lib_name(lib_xmnpu)
    lib_path = [os.path.join(x, lib_name) for x in lib_search]
    lib_found = [x for x in lib_path if os.path.exists(x)]
    if not lib_found and not optional:
        raise RuntimeError(
            "Cannot find the files.\n" + "List of candidates:\n" + str("\n".join(lib_path))
        )
    return lib_found

def xminit():
    """Check if simulator is enabled."""
    f = tvm.get_global_func("xm7205v500.init", True)

    if f:
        f()   # init
    return f is not None

def _load_sw():
    """Load hardware library for simulator."""

    env = get_env()
    lib_driver_name = "libxm7205v500" if env.TARGET == "cmodel" else "libxm7205v500"
    require_sim = env.TARGET in ("cmodel", "libxm7205v500")
    libs = []

    # Load driver library
    lib_driver = find_libxmnpu(lib_driver_name, optional=(not require_sim))

    if not lib_driver:
        return []


    try:
        libs = [ctypes.CDLL(lib_driver[0], ctypes.RTLD_GLOBAL)]
    except OSError as err:
        if require_sim:
            raise err
        warnings.warn("Error when loading XMNPU driver {}: {}".format(lib_driver[0], err))
        return []

    # init
    if not xminit():
        warnings.warn("Error when init {}".format(lib_driver_name))

    return libs

LIBS = _load_sw()
