# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""Additional Transformation Passes. for XMNPU"""
# pylint: disable=len-as-condition, no-else-return, unused-argument, invalid-name
import tvm
from tvm import te
#from tvm.topi import utils
import numpy as np

from tvm.te import tensor

from .environment import get_env
from . import topi
from operator import floordiv
from tvm.tir.transform import _ffi_api

# def InjectNPUIntrin():
#     return _ffi_api.InjectNPUIntrin()

def MergeReduceIntrin():
    return _ffi_api.MergeReduceIntrin()

class OP():
    TVM_XMOP_CONV2D   = 1
    TVM_XMOP_DWCONV   = 2
    TVM_XMOP_DECONV   = 3
    TVM_XMOP_DILCONV  = 4
    TVM_XMOP_SCALE    = 5
    TVM_XMOP_DENSE    = 6
    TVM_XMOP_ELTADD   = 7
    TVM_XMOP_POOL2D   = 8
    TVM_XMOP_GAP      = 9
    TVM_XMOP_UPSAMPLE = 10
    TVM_XMOP_YUV2RGB  = 11
    TVM_XMOP_CONCAT   = 12
    TVM_XMOP_ARITH    = 13
    TVM_XMOP_TILE     = 14
    TVM_XMOP_LUT      = 15
    TVM_XMOP_NEG      = 16
    TVM_XMOP_SPACE_TO_DEPTH    = 17
    TVM_XMOP_DEPTH_TO_SPACE    = 18
    TVM_XMOP_BATCH_TO_SPACE_ND = 19
    TVM_XMOP_SPACE_TO_BATCH_ND = 20
    TVM_XMOP_STRIDED_SLICE     = 21
    TVM_XMOP_TRANSPOSE         = 22
    TVM_XMOP_TEST_DMA          = 23
    TVM_XMOP_CLIP              = 24
    TVM_XMOP_MATMUL            = 25
    TVM_XMOP_REDUCE_MEAN       = 26
    TVM_XMOP_SPLIT             = 27
    TVM_XMOP_CHANNEL_SHUFFLE   = 28

def _match_pragma(stmt, key):
    """Internal helper to match stmt to pragma stmt.

    Parameters
    ----------
    stmt : Stmt
        The AttrStmt

    key : str
        The pragma key
    """
    return (stmt.attr_key == "pragma_" + key) or (
        stmt.attr_key == "pragma_scope" and stmt.value.value == key
    )

def _is_binary_op(op):
    if isinstance(op, tvm.tir.Add):
        return True
    if isinstance(op, tvm.tir.Sub):
        return True
    if isinstance(op, tvm.tir.Mul):
        return True
    if isinstance(op, tvm.tir.Div):
        return True
    if isinstance(op, tvm.tir.Max):
        return True
    if isinstance(op, tvm.tir.Min):
        return True
    if isinstance(op, tvm.tir.Mod):
        return True
    if isinstance(op, tvm.tir.FloorMod):
        return True
    if isinstance(op, tvm.tir.FloorDiv):
        return True
    if isinstance(op, tvm.tir.And):
        return True
    if isinstance(op, tvm.tir.EQ):
        return True
    if isinstance(op, tvm.tir.NE):
        return True
    if isinstance(op, tvm.tir.LT):
        return True
    if isinstance(op, tvm.tir.LE):
        return True
    if isinstance(op, tvm.tir.GT):
        return True
    if isinstance(op, tvm.tir.GE):
        return True
    if isinstance(op, tvm.tir.Or):
        return True
    else:
        return False

def _get_binary_op(op):
    if isinstance(op, tvm.tir.Add):
        return tvm.tir.Add
    if isinstance(op, tvm.tir.Sub):
        return tvm.tir.Sub
    if isinstance(op, tvm.tir.Mul):
        return tvm.tir.Mul
    if isinstance(op, tvm.tir.Div):
        return tvm.tir.Div
    if isinstance(op, tvm.tir.Max):
        return tvm.tir.Max
    if isinstance(op, tvm.tir.Min):
        return tvm.tir.Min
    if isinstance(op, tvm.tir.Mod):
        return tvm.tir.Mod
    if isinstance(op, tvm.tir.FloorMod):
        return tvm.tir.FloorMod
    if isinstance(op, tvm.tir.FloorDiv):
        return tvm.tir.FloorDiv
    if isinstance(op, tvm.tir.And):
        return tvm.tir.And
    if isinstance(op, tvm.tir.EQ):
        return tvm.tir.EQ
    if isinstance(op, tvm.tir.NE):
        return tvm.tir.NE
    if isinstance(op, tvm.tir.LT):
        return tvm.tir.LT
    if isinstance(op, tvm.tir.LE):
        return tvm.tir.LE
    if isinstance(op, tvm.tir.GT):
        return tvm.tir.GT
    if isinstance(op, tvm.tir.GE):
        return tvm.tir.GE
    if isinstance(op, tvm.tir.Or):
        return tvm.tir.Or
    assert 0
    return 0


def InjectNPUCoProcSync():
    """Pass inject coproc sync

    Returns
    -------
    fpass : tvm.transform.Pass
        The pass
    """

    def _ftransform(f, *_):
        success = [False]
        #print(f)

        def _do_fold(stmt):
            if _match_pragma(stmt, "coproc_sync"):
                success[0] = True
                sync = tvm.tir.Call("int32", "xmnpu.coproc_sync", [])
                return tvm.tir.SeqStmt([stmt.body, tvm.tir.Evaluate(sync)])
            if _match_pragma(stmt, "trim_loop"):
                op = stmt.body
                assert isinstance(op, tvm.tir.For)
                return tvm.tir.For(
                    op.loop_var, op.min, 2, op.kind, op.body, op.thread_binding, op.annotations
                )
            return None

        return f.with_body(
            tvm.tir.stmt_functor.ir_transform(f.body, None, _do_fold, ["tir.AttrStmt"])
        )

    return tvm.transform.Sequential(
        [
            tvm.tir.transform.prim_func_pass(_ftransform, 0, "tir.xmnpu.InjectNPUCoProcSync"),
            tvm.tir.transform.CoProcSync(),
        ],
        opt_level=0,
        name="tir.xmnpu.InjectNPUCoProcSync",
    )


# graph    = {"op_num": 0, "op_kind": 0, "op_lists": [], "output":[], "unique_id": 0, "opt_config": 0, "reserved": []}
# operator = {"op_type":-1, "in_tensors":[], "out_tensors":[], "params":{}, "output":[], "reserved": []}
def ConvertJson2Json(graph_json):
    #print(graph_json)
    op_params = graph_json["op_lists"][0]["params"]

    # remove buffer/buffer.data
    for i in range(graph_json["op_num"]):
        del graph_json["op_lists"][i]["in_tensors"]
        del graph_json["op_lists"][i]["out_tensors"]
        op_params = graph_json["op_lists"][i]["params"]
        for key, value in op_params.items():
            if "addr" in key:
                op_params[key] = 0

    def _rewrite_dict_value(old_dict):
        for key, value in old_dict.items():
            if isinstance(value, int):
                old_dict[key] = ['Int', value]
            elif isinstance(value, str):
                old_dict[key] = ["Str", value]
            elif isinstance(value, list):
                if len(value) == 0:
                    old_dict[key] = ['StrVector', value]
                elif isinstance(value[0], int):
                    old_dict[key] = ['IntVector', value]
                elif isinstance(value[0], list):   # list in list
                    total_len        = 0
                    first_value_type = 0           # 0:null,1:int,2:str
                    for i in range(len(value)):
                        total_len += len(value[i])
                        for j in range(len(value[i])):
                            # all type in list must same
                            if isinstance(value[i][j], int):
                                assert first_value_type == 1 or first_value_type == 0
                                first_value_type = 1
                            elif isinstance(value[i][j], str):
                                first_value_type = 2
                            else:
                                assert 0
                    if total_len == 0:
                        old_dict[key] = ['IntVector', value]
                    elif first_value_type == 1:
                        old_dict[key] = ['Int2DVector', value]
                    elif first_value_type == 2:
                        assert 0
                    else:
                        assert 0
                elif isinstance(value[0], dict):
                    old_dict[key] = ['StrVector', [json.dumps(x) for x in value]]
                elif isinstance(value[0], str):
                    old_dict[key] = ['StrVector', value]
                else:
                    print(type(value), key, value)
                    assert 0
            elif isinstance(value, dict):
                old_dict[key] = ['Str', json.dumps(value)]
            else:
                print(type(value), key, value)
                assert 0
        return old_dict

    import json
    for i in range(graph_json["op_num"]):
        operator  = graph_json["op_lists"][i]
        op_params = graph_json["op_lists"][i]["params"]
        if operator["op_type"] == OP.TVM_XMOP_CONCAT:
            assert "concat_offset" in op_params
            value = op_params["concat_offset"]
            op_params["concat_offset"] = {"concat_offset" : ['IntVector', value]}
        _rewrite_dict_value(op_params)
        _rewrite_dict_value(operator)

    _rewrite_dict_value(graph_json)

    return json.dumps(graph_json)

def SubmitGeneralOPIntrin(graph_json):
    if graph_json["op_num"] == 1:
        operator = graph_json["op_lists"][0]
        total_tensor = len(operator["in_tensors"]) + len(operator["out_tensors"])
        graph_output_idx  = graph_json["output"][0][0]
        graph_output_addr = graph_json["op_lists"][graph_output_idx]["params"]["output_addr"]
        if total_tensor <= 4:
            param = graph_json["op_lists"][0]["params"]
            input_addr  = graph_output_addr
            kernel_addr = graph_output_addr
            bias_addr   = graph_output_addr
            output_addr = graph_output_addr

            if graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D or \
                graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_DENSE or \
                graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_SCALE:

                input_addr  = param["input_addr"]
                kernel_addr = param["kernel_addr"]
                if param["using_bias"]:
                    bias_addr   = param["bias_addr"]
                output_addr = param["output_addr"]
            elif graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_POOL2D or \
                graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_GAP:

                input_addr  = param["input_addr"]
                output_addr = param["output_addr"]
            elif graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_ELTADD:
                input_addr  = param["input1_addr"]
                kernel_addr = param["input2_addr"]
                output_addr = param["output_addr"]
            elif graph_json["op_lists"][0]["op_type"] in [OP.TVM_XMOP_UPSAMPLE, OP.TVM_XMOP_SPACE_TO_DEPTH,
                OP.TVM_XMOP_DEPTH_TO_SPACE, OP.TVM_XMOP_BATCH_TO_SPACE_ND, OP.TVM_XMOP_SPACE_TO_BATCH_ND,
                OP.TVM_XMOP_REDUCE_MEAN] :
                input_addr  = param["input_addr"]
                output_addr = param["output_addr"]
            elif graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONCAT:
                input_addrs = [graph_output_addr for x in range(3)]
                for i in range(len(param["input_addr"])):
                    input_addrs[i] = param["input_addr"][i]
                input_addr  = input_addrs[0]
                kernel_addr = input_addrs[1]
                bias_addr   = input_addrs[2]
                output_addr = param["output_addr"]
            elif graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_NEG or \
                graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_STRIDED_SLICE or \
                graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CLIP or \
                graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_TRANSPOSE or \
                graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CHANNEL_SHUFFLE :
                input_addr  = param["input_addr"]
                if "bias_addr" in param:
                    bias_addr = param["bias_addr"]
                if "kernel_addr" in param:
                    kernel_addr = param["kernel_addr"]
                output_addr = param["output_addr"]
            elif graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_LUT:
                input_addr  = param["input_addr"]
                output_addr = param["output_addr"]
                kernel_addr = param["table_addr"]
            elif graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_TILE:
                input_addr  = param["input_addr"][0]
                output_addr = param["output_addr"]
            elif graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_YUV2RGB:
                input_addr  = param["input_addr"][0]
                kernel_addr = param["input_addr"][1]
                output_addr = param["output_addr"]
            elif graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_TEST_DMA:
                input_addr  = param["input_addr"]
            elif graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_MATMUL:
                input_addr  = param["input1_addr"]
                kernel_addr = param["input2_addr"]
                if param["using_bias"]:
                    bias_addr = param["bias_addr"]
                output_addr = param["output_addr"]
            else:
                assert 0

            str_json   = ConvertJson2Json(graph_json)
            irb = tvm.tir.ir_builder.create()
            irb.emit(
                tvm.tir.call_extern(
                    "int32", "XMNPUGeneralOp",
                    input_addr, kernel_addr, bias_addr, output_addr,
                    str_json, len(str_json),
                )
            )
            stmt = irb.get()
            return stmt
        elif graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONCAT:
            param = graph_json["op_lists"][0]["params"]
            tensor_addrs = [graph_output_addr for x in range(12)]
            if len(param["input_addr"]) >= 12:
                print("Error: Concat not support num of input addrs >= 12 yet.")
                assert 0
            for i in range(len(param["input_addr"])):
                tensor_addrs[i] = param["input_addr"][i]

            str_json   = ConvertJson2Json(graph_json)
            irb = tvm.tir.ir_builder.create()
            irb.emit(
                tvm.tir.call_extern(
                    "int32", "XMNPUGeneral12MOp",
                    tensor_addrs[0], tensor_addrs[1], tensor_addrs[2], tensor_addrs[3],
                    tensor_addrs[4], tensor_addrs[5], tensor_addrs[6], tensor_addrs[7],
                    tensor_addrs[8], tensor_addrs[9], tensor_addrs[10], tensor_addrs[11],
                    str_json, len(str_json),
                )
            )
            stmt = irb.get()
            return stmt

        else:
            assert 0
    else:
        assert 0

def SubmitMultiOPIntrin(graph_json):
    output_addr3 = 0
    for i in range(len(graph_json["op_lists"])):
        operator = graph_json["op_lists"][i]
        total_tensor = len(operator["in_tensors"]) + len(operator["out_tensors"])
        if total_tensor <= 4:
            param = graph_json["op_lists"][i]["params"]

            if graph_json["op_lists"][i]["op_type"] == OP.TVM_XMOP_SPLIT:
                input_addr  = param["input_addr"]
                if (i == 0):
                    output_addr1 = param["output_addr"]
                elif(i == 1):
                    output_addr2 = param["output_addr"]
                elif(i == 2):
                    output_addr3 = param["output_addr"]
                else:
                    # now only support split_num <= 3
                    assert 0
            else:
                assert 0
        else:
            assert 0
    str_json = ConvertJson2Json(graph_json)
    irb = tvm.tir.ir_builder.create()
    irb.emit(
        tvm.tir.call_extern(
            "int32", "XMNPUSpecialOp",
            input_addr, output_addr1, output_addr2, output_addr3,
            str_json, len(str_json),
        )
    )
    stmt = irb.get()
    return stmt

def SubmitTilingOneConv2dIntrin(graph_json):
    operator = graph_json["op_lists"][0]
    graph_output_idx  = graph_json["output"][-1][0]
    graph_output_addr = graph_json["op_lists"][graph_output_idx]["params"]["output_addr"]
    tensor_addrs = [graph_output_addr for x in range(5)]

    if graph_json["op_num"] == 1:
        # CONV
        assert graph_json["op_lists"][0]["output"] == [[0, -1]] # check connect
        c = graph_json["op_lists"][0]["params"]
        tensor_addrs[0]  = c["input_addr"]
        tensor_addrs[1]  = c["kernel_addr"]
        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c["bias_addr"]
    elif graph_json["op_num"] == 2 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D  and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_POOL2D and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, -1]]:
        # CONV + Pool
        c = graph_json["op_lists"][0]["params"]
        p = graph_json["op_lists"][1]["params"]
        tensor_addrs[0]  = c["input_addr"]
        tensor_addrs[1]  = c["kernel_addr"]
        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c["bias_addr"]
    elif graph_json["op_num"] == 2 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D  and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_POOL2D and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0], [0, -1]] and \
          graph_json["op_lists"][1]["output"] == [[0, -1]]:
        # CONV + Pool and conv out
        c = graph_json["op_lists"][0]["params"]
        p = graph_json["op_lists"][1]["params"]
        tensor_addrs[0]  = c["input_addr"]
        tensor_addrs[1]  = c["kernel_addr"]
        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c["bias_addr"]
        tensor_addrs[3]  = c["output_addr"]
    elif graph_json["op_num"] == 2 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D  and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_UPSAMPLE and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, -1]]:
        # CONV + Pool
        c = graph_json["op_lists"][0]["params"]
        p = graph_json["op_lists"][1]["params"]
        tensor_addrs[0]  = c["input_addr"]
        tensor_addrs[1]  = c["kernel_addr"]
        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c["bias_addr"]
    else:
        print("op num ", graph_json["op_num"])
        assert 0

    str_json   = ConvertJson2Json(graph_json)
    irb = tvm.tir.ir_builder.create()
    irb.emit(
        tvm.tir.call_extern(
            "int32", "XMNPUTilingOneConv2dOP",
            tensor_addrs[0], tensor_addrs[1], tensor_addrs[2], tensor_addrs[3],
            tensor_addrs[4],
            str_json, len(str_json),
        )
    )
    stmt = irb.get()
    return stmt

def SubmitTilingTwoConv2dIntrin(graph_json):
    operator = graph_json["op_lists"][0]
    graph_output_idx  = graph_json["output"][0][0]
    graph_output_addr = graph_json["op_lists"][graph_output_idx]["params"]["output_addr"]
    tensor_addrs = [graph_output_addr for x in range(10)]

    if graph_json["op_num"] == 2:
        # CONV + CONV
        assert graph_json["op_lists"][0]["output"] == [[0, 1, 0]] # check inner connect
        assert graph_json["op_lists"][1]["output"] == [[0, -1]] # check connect
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c2["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
    elif graph_json["op_num"] == 3 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D  and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_POOL2D and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
          graph_json["op_lists"][2]["output"] == [[0, -1]]:
        ## conv + conv + pool
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        p = graph_json["op_lists"][2]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  =  p["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
    elif graph_json["op_num"] == 3 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_GAP    and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
          graph_json["op_lists"][2]["output"] == [[0, -1]]:
        ## conv + conv + global_avg_pool
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        p = graph_json["op_lists"][2]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  =  p["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
    elif graph_json["op_num"] == 3 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D  and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_UPSAMPLE and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
          graph_json["op_lists"][2]["output"] == [[0, -1]]:
        ## conv + conv + upsp
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        p = graph_json["op_lists"][2]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  =  p["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
    elif graph_json["op_num"] == 3 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D  and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_ELTADD and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 1]] and \
          graph_json["op_lists"][2]["output"] == [[0, -1]]:
        ## conv + conv + eltadd
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        ea = graph_json["op_lists"][2]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = ea["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
    elif graph_json["op_num"] == 4 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D  and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_ELTADD and \
          graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_POOL2D and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 1]] and \
          graph_json["op_lists"][2]["output"] == [[0, 3, 0]] and \
          graph_json["op_lists"][3]["output"] == [[0, -1]]:
        ## conv + conv + eltadd + pool
        
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        ea = graph_json["op_lists"][2]["params"]
        p = graph_json["op_lists"][3]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  =  p["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
    else:
        print("op num ", graph_json["op_num"])
        assert 0

    str_json   = ConvertJson2Json(graph_json)
    irb = tvm.tir.ir_builder.create()
    irb.emit(
        tvm.tir.call_extern(
            "int32", "XMNPUTilingTwoConv2dOP",
            tensor_addrs[0], tensor_addrs[1], tensor_addrs[2], tensor_addrs[3],
            tensor_addrs[4], tensor_addrs[5], tensor_addrs[6], tensor_addrs[7],
            tensor_addrs[8], tensor_addrs[9],
            str_json, len(str_json),
        )
    )
    stmt = irb.get()
    return stmt

def SubmitTilingThreeConv2dIntrin(graph_json):
    operator = graph_json["op_lists"][0]
    graph_output_idx  = graph_json["output"][0][0]
    graph_output_addr = graph_json["op_lists"][graph_output_idx]["params"]["output_addr"]
    tensor_addrs = [graph_output_addr for x in range(14)]

    if graph_json["op_num"] == 3:
        # CONV + CONV
        assert graph_json["op_lists"][0]["output"] == [[0, 1, 0]] # check inner connect
        assert graph_json["op_lists"][1]["output"] == [[0, 2, 0]] # check inner connect
        assert graph_json["op_lists"][2]["output"] == [[0, -1]] # check connect
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        c3 = graph_json["op_lists"][2]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        tensor_addrs[7]  = c3["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
    elif graph_json["op_num"] == 4 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_ELTADD and \
          graph_json["op_lists"][0]["output"] == [[0, 3, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
          graph_json["op_lists"][2]["output"] == [[0, 3, 1]] and \
          graph_json["op_lists"][3]["output"] == [[0, -1]]:
        #      /----> conv2 conv3----\
        # input                    add--->
        #      \----> conv1 ---/
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        c3 = graph_json["op_lists"][2]["params"]
        ea = graph_json["op_lists"][3]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        tensor_addrs[7]  = ea["output_addr"]
        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
    elif graph_json["op_num"] == 5 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_ELTADD and \
          graph_json["op_lists"][4]["op_type"] == OP.TVM_XMOP_POOL2D and \
          graph_json["op_lists"][0]["output"] == [[0, 3, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
          graph_json["op_lists"][2]["output"] == [[0, 3, 1]] and \
          graph_json["op_lists"][3]["output"] == [[0, 4, 0]] and \
          graph_json["op_lists"][4]["output"] == [[0, -1]]:
        #      /----> conv2 conv3----\
        # input                    add---> pool
        #      \----> conv1 ---/
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        c3 = graph_json["op_lists"][2]["params"]
        ea = graph_json["op_lists"][3]["params"]
        p = graph_json["op_lists"][4]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        tensor_addrs[7]  = p["output_addr"]
        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
    elif graph_json["op_num"] == 4 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_CONCAT and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0], [0, 2, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 3, 1]] and \
          graph_json["op_lists"][2]["output"] == [[0, 3, 0]] and \
          graph_json["op_lists"][3]["output"] == [[0, -1]]:
        #      /----> conv----\
        # conv                 concat--->
        #      \----> conv ---/
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        c3 = graph_json["op_lists"][2]["params"]
        cc = graph_json["op_lists"][3]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        tensor_addrs[7]  = cc["output_addr"]
        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]

    elif graph_json["op_num"] == 5 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_CONCAT and \
          graph_json["op_lists"][4]["op_type"] == OP.TVM_XMOP_POOL2D and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0], [0, 2, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 3, 1]] and \
          graph_json["op_lists"][2]["output"] == [[0, 3, 0]] and \
          graph_json["op_lists"][3]["output"] == [[0, 4, 0]] and \
          graph_json["op_lists"][4]["output"] == [[0, -1]]:
        #      /----> conv----\
        # conv                 concat---> pool -->
        #      \----> conv ---/
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        c3 = graph_json["op_lists"][2]["params"]
        p = graph_json["op_lists"][4]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        tensor_addrs[7]  = p["output_addr"]
        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
    elif graph_json["op_num"] == 4 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D  and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_POOL2D and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
          graph_json["op_lists"][2]["output"] == [[0, 3, 0]] and \
          graph_json["op_lists"][3]["output"] == [[0, -1]]:
        ## conv + conv + pool
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        c3 = graph_json["op_lists"][2]["params"]
        p = graph_json["op_lists"][3]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        tensor_addrs[7]  =  p["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
    elif (graph_json["op_num"] == 4 or graph_json["op_num"] == 5) and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_ELTADD and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
          graph_json["op_lists"][2]["output"] == [[0, 3, 1]]:
          ## input->conv->conv->conv-eltadd->[pool/global_avg_pool]
          #       \_________________/
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        c3 = graph_json["op_lists"][2]["params"]
        eltadd = graph_json["op_lists"][3]["params"]
        if graph_json["op_num"] == 5:
            pool = graph_json["op_lists"][4]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        if graph_json["op_num"] == 4:
            tensor_addrs[7]  = eltadd["output_addr"]
        else:
            tensor_addrs[7]  = pool["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]

    elif graph_json["op_num"] == 4 and \
        graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
        graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
        graph_json["op_lists"][2]["output"] == [[0, 3, 0]] and \
        graph_json["op_lists"][3]["output"] == [[0, -1]] and \
        graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D  and \
        graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_POOL2D and \
        graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
        graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_CONV2D:
        # graph structure: CONV-->POOL-->CONV-->CONV
        # print("------------------------------")
        c0 = graph_json["op_lists"][0]["params"]
        p = graph_json["op_lists"][1]["params"]
        c1 = graph_json["op_lists"][2]["params"]
        c2 = graph_json["op_lists"][3]["params"]
        tensor_addrs[0]  = c0["input_addr"]
        tensor_addrs[1]  = c0["kernel_addr"]
        tensor_addrs[3]  = c1["kernel_addr"]
        tensor_addrs[5]  = c2["kernel_addr"]
        tensor_addrs[7]  = c2["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c0["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[4] = c1["bias_addr"]
        if graph_json["op_lists"][3]["params"]["using_bias"]:
            tensor_addrs[6] = c2["bias_addr"]
    elif (graph_json["op_num"] == 5 or graph_json["op_num"] == 6) and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_POOL2D and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][4]["op_type"] == OP.TVM_XMOP_ELTADD and \
          graph_json["op_lists"][0]["output"] == [[0, 4, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
          graph_json["op_lists"][2]["output"] == [[0, 3, 0]] and \
          graph_json["op_lists"][3]["output"] == [[0, 4, 1]]:
          ## input->conv->conv->conv-eltadd->[pool/global_avg_pool]
          #       \_______pool________/
        p1 = graph_json["op_lists"][0]["params"] 
        c1 = graph_json["op_lists"][1]["params"]
        c2 = graph_json["op_lists"][2]["params"]
        c3 = graph_json["op_lists"][3]["params"]
        eltadd = graph_json["op_lists"][4]["params"]
        if graph_json["op_num"] == 6:
            p2 = graph_json["op_lists"][5]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        if graph_json["op_num"] == 5:
            tensor_addrs[7]  = eltadd["output_addr"]
        else:
            tensor_addrs[7]  = p2["output_addr"]

        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][3]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
    elif graph_json["op_num"] == 4 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_CONCAT and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
          graph_json["op_lists"][2]["output"] == [[0, 3, 1]]:
          ## input->dwconv->conv->conv-concat->output
          #       \_________________/
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        c3 = graph_json["op_lists"][2]["params"]
        eltadd = graph_json["op_lists"][3]["params"]
        if graph_json["op_num"] == 5:
            pool = graph_json["op_lists"][4]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        if graph_json["op_num"] == 4:
            tensor_addrs[7]  = eltadd["output_addr"]
        else:
            tensor_addrs[7]  = pool["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
    elif graph_json["op_num"] == 4 and \
         graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_DECONV and \
         graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
         graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
         graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_ELTADD and \
         graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
         graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
         graph_json["op_lists"][2]["output"] == [[0, 3, 1]] and \
         graph_json["op_lists"][3]["output"] == [[0, -1]]:
         ## input->dwconv->conv->conv->conv-eltadd
         #       \_________________________/
        graph_json["op_lists"][0]["op_type"] = OP.TVM_XMOP_CONV2D
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        c3 = graph_json["op_lists"][2]["params"]
        eltadd = graph_json["op_lists"][3]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        tensor_addrs[7]  = eltadd["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
    elif graph_json["op_num"] == 5 and \
         graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_DECONV and \
         graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
         graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
         graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_ELTADD and \
         graph_json["op_lists"][4]["op_type"] == OP.TVM_XMOP_POOL2D and \
         graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
         graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
         graph_json["op_lists"][2]["output"] == [[0, 3, 1]] and \
         graph_json["op_lists"][3]["output"] == [[0, 4, 0]] and \
         graph_json["op_lists"][4]["output"] == [[0, -1]]:
         ## input->dwconv->conv->conv->conv-eltadd->pool
        graph_json["op_lists"][0]["op_type"] = OP.TVM_XMOP_CONV2D
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        c3 = graph_json["op_lists"][2]["params"]
        p = graph_json["op_lists"][4]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        tensor_addrs[7]  = p["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
    elif graph_json["op_num"] == 6 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_SPLIT  and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][4]["op_type"] == OP.TVM_XMOP_SPLIT  and \
          graph_json["op_lists"][5]["op_type"] == OP.TVM_XMOP_CONCAT and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
          graph_json["op_lists"][2]["output"] == [[0, 3, 0]] and \
          graph_json["op_lists"][3]["output"] == [[0, 5, 1]] and \
          graph_json["op_lists"][4]["output"] == [[0, 5, 0]] and \
          graph_json["op_lists"][5]["output"] == [[0, -1]]:
          ## input->split->conv->dwconv->conv-concat->output
          #            \_______________________/
        spt0 = graph_json["op_lists"][0]["params"]
        c1 = graph_json["op_lists"][1]["params"]
        c2 = graph_json["op_lists"][2]["params"]
        c3 = graph_json["op_lists"][3]["params"]
        spt1 = graph_json["op_lists"][4]["params"]
        concat = graph_json["op_lists"][5]["params"]
        tensor_addrs[0]  = spt0["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        tensor_addrs[7]  = concat["output_addr"]

        if c1["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if c2["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if c3["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
    else:
        print("op num ", graph_json["op_num"])
        assert 0

    str_json   = ConvertJson2Json(graph_json)

    irb = tvm.tir.ir_builder.create()
    irb.emit(
        tvm.tir.call_extern(
            "int32", "XMNPUTilingThreeConv2dOP",
            tensor_addrs[0], tensor_addrs[1], tensor_addrs[2], tensor_addrs[3],
            tensor_addrs[4], tensor_addrs[5], tensor_addrs[6], tensor_addrs[7],
            tensor_addrs[8], tensor_addrs[9], tensor_addrs[10], tensor_addrs[11],
            tensor_addrs[12], tensor_addrs[13],
            str_json, len(str_json),
        )
    )
    stmt = irb.get()
    return stmt

def SubmitTilingFourConv2dIntrin(graph_json):
    operator = graph_json["op_lists"][0]
    graph_output_idx  = graph_json["output"][0][0]
    graph_output_addr = graph_json["op_lists"][graph_output_idx]["params"]["output_addr"]
    tensor_addrs = [graph_output_addr for x in range(18)]
    if (graph_json["op_num"]  == 4 or (graph_json["op_num"]  == 5 and \
        graph_json["op_lists"][4]["op_type"] == OP.TVM_XMOP_POOL2D)):
        # CONV + CONV
        assert graph_json["op_lists"][0]["output"] == [[0, 1, 0]] # check inner connect
        assert graph_json["op_lists"][1]["output"] == [[0, 2, 0]] # check inner connect
        assert graph_json["op_lists"][2]["output"] == [[0, 3, 0]] # check inner connect
        # assert graph_json["op_lists"][3]["output"] == [[0, 4, 0]] # check inner connect
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        c3 = graph_json["op_lists"][2]["params"]
        c4 = graph_json["op_lists"][3]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        tensor_addrs[7]  = c4["kernel_addr"]
        if graph_json["op_num"] == 4:
            tensor_addrs[9]  = c4["output_addr"]
        else:
            p = graph_json["op_lists"][4]["params"]
            tensor_addrs[9] = p["output_addr"]


        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
        if graph_json["op_lists"][3]["params"]["using_bias"]:
            tensor_addrs[8] = c4["bias_addr"]
    elif graph_json["op_num"] == 5 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D  and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][4]["op_type"] == OP.TVM_XMOP_CONCAT and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 0], [0, 3, 0]] and \
          graph_json["op_lists"][2]["output"] == [[0, 4, 1]] and \
          graph_json["op_lists"][3]["output"] == [[0, 4, 0]] and \
          graph_json["op_lists"][4]["output"] == [[0, -1]]:
        # 4CONV + concat
        # swap op[2] op[3]
        tmp_op = graph_json["op_lists"][2]
        graph_json["op_lists"][2] = graph_json["op_lists"][3]
        graph_json["op_lists"][3] = tmp_op

        c0 = graph_json["op_lists"][0]["params"]
        c1 = graph_json["op_lists"][1]["params"]
        c2 = graph_json["op_lists"][2]["params"]
        c3 = graph_json["op_lists"][3]["params"]
        cc = graph_json["op_lists"][4]["params"]

        tensor_addrs[0]  = c0["input_addr"]
        tensor_addrs[1]  = c0["kernel_addr"]
        tensor_addrs[3]  = c1["kernel_addr"]
        tensor_addrs[5]  = c2["kernel_addr"]
        tensor_addrs[7]  = c3["kernel_addr"]
        tensor_addrs[9]  = cc["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c0["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c1["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[6] = c2["bias_addr"]
        if graph_json["op_lists"][3]["params"]["using_bias"]:
            tensor_addrs[8] = c3["bias_addr"]

    elif graph_json["op_num"] == 5 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D  and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_CONV2D and \
          graph_json["op_lists"][4]["op_type"] == OP.TVM_XMOP_ELTADD and \
          graph_json["op_lists"][0]["output"] == [[0, 4, 0]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
          graph_json["op_lists"][2]["output"] == [[0, 3, 0]] and \
          graph_json["op_lists"][3]["output"] == [[0, 4, 1]] and \
          graph_json["op_lists"][4]["output"] == [[0, -1]]:
          
        # 4CONV + eltadd
        assert graph_json["op_lists"][0]["output"] == [[0, 4, 0]] # check inner connect
        assert graph_json["op_lists"][1]["output"] == [[0, 2, 0]] # check inner connect
        assert graph_json["op_lists"][2]["output"] == [[0, 3, 0]] # check inner connect
        assert graph_json["op_lists"][3]["output"] == [[0, 4, 1]] # check inner connect
        assert graph_json["op_lists"][4]["output"] == [[0, -1]] # check connect
        c1 = graph_json["op_lists"][1]["params"]
        c2 = graph_json["op_lists"][2]["params"]
        c3 = graph_json["op_lists"][3]["params"]
        c4 = graph_json["op_lists"][0]["params"]
        ea = graph_json["op_lists"][4]["params"]

        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        tensor_addrs[7]  = c4["kernel_addr"]
        tensor_addrs[9]  = ea["output_addr"]

        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][3]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[8] = c4["bias_addr"]
    elif graph_json["op_num"] == 6 and \
        graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D  and \
        graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
        graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
        graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_CONV2D and \
        graph_json["op_lists"][4]["op_type"] == OP.TVM_XMOP_ELTADD and \
        graph_json["op_lists"][5]["op_type"] == OP.TVM_XMOP_POOL2D and \
        graph_json["op_lists"][0]["output"] == [[0, 4, 0]] and \
        graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
        graph_json["op_lists"][2]["output"] == [[0, 3, 0]] and \
        graph_json["op_lists"][3]["output"] == [[0, 4, 1]] and \
        graph_json["op_lists"][4]["output"] == [[0, 5, 0]] and \
        graph_json["op_lists"][5]["output"] == [[0, -1]]:
        # 4CONV + eltadd + pool

        c1 = graph_json["op_lists"][1]["params"]
        c2 = graph_json["op_lists"][2]["params"]
        c3 = graph_json["op_lists"][3]["params"]
        c4 = graph_json["op_lists"][0]["params"]
        ea = graph_json["op_lists"][4]["params"]
        p = graph_json["op_lists"][5]["params"]

        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        tensor_addrs[7]  = c4["kernel_addr"]
        tensor_addrs[9]  = p["output_addr"]
  
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][3]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[8] = c4["bias_addr"]
    elif graph_json["op_num"] == 6 and \
        graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_POOL2D and \
        graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
        graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
        graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_CONV2D and \
        graph_json["op_lists"][4]["op_type"] == OP.TVM_XMOP_CONV2D and \
        graph_json["op_lists"][5]["op_type"] == OP.TVM_XMOP_CONCAT and \
        graph_json["op_lists"][0]["output"] == [[0, 5, 2]] and \
        graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
        graph_json["op_lists"][2]["output"] == [[0, 3, 0]] and \
        graph_json["op_lists"][3]["output"] == [[0, 5, 1]] and \
        graph_json["op_lists"][4]["output"] == [[0, 5, 0]] and \
        graph_json["op_lists"][5]["output"] == [[0, -1]]:
        # conv2d --------------------------\
        # conv2d --> conv2d --> conv2d -----> concat 
        # pool2d --------------------------/
            c1 = graph_json["op_lists"][1]["params"]
            c2 = graph_json["op_lists"][2]["params"]
            c3 = graph_json["op_lists"][3]["params"]
            c4 = graph_json["op_lists"][4]["params"]
            cc = graph_json["op_lists"][5]["params"]

            tensor_addrs[0]  = c1["input_addr"]
            tensor_addrs[1]  = c1["kernel_addr"]
            tensor_addrs[3]  = c2["kernel_addr"]
            tensor_addrs[5]  = c3["kernel_addr"]
            tensor_addrs[7]  = c4["kernel_addr"]
            tensor_addrs[9]  = cc["output_addr"]
    
            if graph_json["op_lists"][1]["params"]["using_bias"]:
                tensor_addrs[2] = c1["bias_addr"]
            if graph_json["op_lists"][2]["params"]["using_bias"]:
                tensor_addrs[4] = c2["bias_addr"]
            if graph_json["op_lists"][3]["params"]["using_bias"]:
                tensor_addrs[6] = c3["bias_addr"]
            if graph_json["op_lists"][4]["params"]["using_bias"]:
                tensor_addrs[8] = c4["bias_addr"]
    elif (graph_json["op_num"] == 5 or graph_json["op_num"] == 6) and \
         graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D and \
         graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
         graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
         graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_CONV2D and \
         graph_json["op_lists"][4]["op_type"] == OP.TVM_XMOP_ELTADD and \
         graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
         graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
         graph_json["op_lists"][2]["output"] == [[0, 3, 0]] and \
         graph_json["op_lists"][3]["output"] == [[0, 4, 1]]:
         ## input->dwconv->conv->conv->conv-eltadd->[pool/global_avg_pool]
         #       \_________________________/
        c1 = graph_json["op_lists"][0]["params"]
        c2 = graph_json["op_lists"][1]["params"]
        c3 = graph_json["op_lists"][2]["params"]
        c4 = graph_json["op_lists"][3]["params"]
        eltadd = graph_json["op_lists"][4]["params"]
        if graph_json["op_num"] == 6:
            pool = graph_json["op_lists"][5]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        tensor_addrs[7]  = c4["kernel_addr"]
        if graph_json["op_num"] == 5:
            tensor_addrs[9]  = eltadd["output_addr"]
        else:
            tensor_addrs[9]  = pool["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
        if graph_json["op_lists"][3]["params"]["using_bias"]:
            tensor_addrs[8] = c4["bias_addr"]
    elif (graph_json["op_num"] == 6 or graph_json["op_num"] == 7) and \
         graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_POOL2D and \
         graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
         graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
         graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_CONV2D and \
         graph_json["op_lists"][4]["op_type"] == OP.TVM_XMOP_CONV2D and \
         graph_json["op_lists"][5]["op_type"] == OP.TVM_XMOP_ELTADD and \
         graph_json["op_lists"][0]["output"] == [[0, 5, 0]] and \
         graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
         graph_json["op_lists"][2]["output"] == [[0, 3, 0]] and \
         graph_json["op_lists"][3]["output"] == [[0, 4, 0]] and \
         graph_json["op_lists"][4]["output"] == [[0, 5, 1]]:
         ## input->dwconv->conv->conv->conv-eltadd->[max/avg_pool]
         #       \___________pool___________/
        p1 = graph_json["op_lists"][0]["params"]
        c1 = graph_json["op_lists"][1]["params"]
        c2 = graph_json["op_lists"][2]["params"]
        c3 = graph_json["op_lists"][3]["params"]
        c4 = graph_json["op_lists"][4]["params"]
        eltadd = graph_json["op_lists"][5]["params"]
        if graph_json["op_num"] == 7:
            p2 = graph_json["op_lists"][6]["params"]
        tensor_addrs[0]  = c1["input_addr"]
        tensor_addrs[1]  = c1["kernel_addr"]
        tensor_addrs[3]  = c2["kernel_addr"]
        tensor_addrs[5]  = c3["kernel_addr"]
        tensor_addrs[7]  = c4["kernel_addr"]
        if graph_json["op_num"] == 6:
            tensor_addrs[9]  = eltadd["output_addr"]
        else:
            tensor_addrs[9]  = p2["output_addr"]

        if c1["using_bias"]:
            tensor_addrs[2] = c1["bias_addr"]
        if c2["using_bias"]:
            tensor_addrs[4] = c2["bias_addr"]
        if c3["using_bias"]:
            tensor_addrs[6] = c3["bias_addr"]
        if c4["using_bias"]:
            tensor_addrs[8] = c4["bias_addr"]
    else:
        print("op num ", graph_json["op_num"])
        for i in range(graph_json["op_num"]):
            print(graph_json["op_lists"][i]["op_type"], "  ", graph_json["op_lists"][i]["output"])
        assert 0

    str_json   = ConvertJson2Json(graph_json)
    irb = tvm.tir.ir_builder.create()
    irb.emit(
        tvm.tir.call_extern(
            "int32", "XMNPUTilingFourConv2dOP",
            tensor_addrs[0], tensor_addrs[1], tensor_addrs[2], tensor_addrs[3],
            tensor_addrs[4], tensor_addrs[5], tensor_addrs[6], tensor_addrs[7],
            tensor_addrs[8], tensor_addrs[9], tensor_addrs[10], tensor_addrs[11],
            tensor_addrs[12], tensor_addrs[13],tensor_addrs[14], tensor_addrs[15],
            tensor_addrs[16], tensor_addrs[17],
            str_json, len(str_json),
        )
    )
    stmt = irb.get()
    return stmt

def SubmitTilingFiveConv2dIntrin(graph_json):
    operator = graph_json["op_lists"][0]
    graph_output_idx  = graph_json["output"][0][0]
    graph_output_addr = graph_json["op_lists"][graph_output_idx]["params"]["output_addr"]
    tensor_addrs = [graph_output_addr for x in range(22)]

    if graph_json["op_num"] == 6 and \
            graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_CONV2D and \
            graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_CONV2D and \
            graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_CONV2D and \
            graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_CONV2D and \
            graph_json["op_lists"][4]["op_type"] == OP.TVM_XMOP_CONV2D and \
            graph_json["op_lists"][5]["op_type"] == OP.TVM_XMOP_CONCAT and \
            graph_json["op_lists"][0]["output"] == [[0, 1, 0]] and \
            graph_json["op_lists"][1]["output"] == [[0, 2, 0]] and \
            graph_json["op_lists"][2]["output"] == [[0, 5, 1]] and \
            graph_json["op_lists"][3]["output"] == [[0, 4, 0]] and \
            graph_json["op_lists"][4]["output"] == [[0, 5, 0]] and \
            graph_json["op_lists"][5]["output"] == [[0, -1]]:
        # ---> conv2d(dw) ----------> conv2d --------|
        # |--> conv2d --> conv2d(dw) --> conv2d -----> concat 
        c0 = graph_json["op_lists"][0]["params"]
        c1 = graph_json["op_lists"][1]["params"]
        c2 = graph_json["op_lists"][2]["params"]
        c3 = graph_json["op_lists"][3]["params"]
        c4 = graph_json["op_lists"][4]["params"]
        cc = graph_json["op_lists"][5]["params"]

        tensor_addrs[0] = c0["input_addr"]
        tensor_addrs[1] = c0["kernel_addr"]
        tensor_addrs[3] = c1["kernel_addr"]
        tensor_addrs[5] = c2["kernel_addr"]
        tensor_addrs[7] = c3["kernel_addr"]
        tensor_addrs[9] = c4["kernel_addr"]
        tensor_addrs[11] = cc["output_addr"]

        if graph_json["op_lists"][0]["params"]["using_bias"]:
            tensor_addrs[2] = c0["bias_addr"]
        if graph_json["op_lists"][1]["params"]["using_bias"]:
            tensor_addrs[4] = c1["bias_addr"]
        if graph_json["op_lists"][2]["params"]["using_bias"]:
            tensor_addrs[6] = c2["bias_addr"]
        if graph_json["op_lists"][3]["params"]["using_bias"]:
            tensor_addrs[8] = c3["bias_addr"]
        if graph_json["op_lists"][4]["params"]["using_bias"]:
            tensor_addrs[10] = c4["bias_addr"]
    else:
        print("op num ", graph_json["op_num"])
        for i in range(graph_json["op_num"]):
            print(graph_json["op_lists"][i]["op_type"], "  ", graph_json["op_lists"][i]["output"])
        assert 0

    str_json   = ConvertJson2Json(graph_json)
    irb = tvm.tir.ir_builder.create()
    irb.emit(
        tvm.tir.call_extern(
            "int32", "XMNPUTilingFiveConv2dOP",
            tensor_addrs[0], tensor_addrs[1], tensor_addrs[2], tensor_addrs[3],
            tensor_addrs[4], tensor_addrs[5], tensor_addrs[6], tensor_addrs[7],
            tensor_addrs[8], tensor_addrs[9], tensor_addrs[10], tensor_addrs[11],
            tensor_addrs[12], tensor_addrs[13],tensor_addrs[14], tensor_addrs[15],
            tensor_addrs[16], tensor_addrs[17],tensor_addrs[18], tensor_addrs[19],
            tensor_addrs[20], tensor_addrs[21],
            str_json, len(str_json),
        )
    )
    stmt = irb.get()
    return stmt

def SubmitTilingThreePool2dIntrin(graph_json):
    operator = graph_json["op_lists"][0]
    graph_output_idx  = graph_json["output"][-1][0]
    graph_output_addr = graph_json["op_lists"][graph_output_idx]["params"]["output_addr"]
    tensor_addrs = [graph_output_addr for x in range(5)]

    if graph_json["op_num"] == 3:
        # pool1+pool2+pool3
        assert 0
    elif graph_json["op_num"] == 4 and \
          graph_json["op_lists"][0]["op_type"] == OP.TVM_XMOP_POOL2D  and \
          graph_json["op_lists"][1]["op_type"] == OP.TVM_XMOP_POOL2D and \
          graph_json["op_lists"][2]["op_type"] == OP.TVM_XMOP_POOL2D and \
          graph_json["op_lists"][3]["op_type"] == OP.TVM_XMOP_CONCAT and \
          graph_json["op_lists"][0]["output"] == [[0, 1, 0], [0, 3, 1]] and \
          graph_json["op_lists"][1]["output"] == [[0, 2, 0], [0, 3, 2]] and \
          graph_json["op_lists"][2]["output"] == [[0, 3, 3]] and \
          graph_json["op_lists"][3]["output"] == [[0, -1]]:
        # pool1+pool2+pool3+concat
        p1 = graph_json["op_lists"][0]["params"]
        p2 = graph_json["op_lists"][1]["params"]
        p3 = graph_json["op_lists"][2]["params"]
        ct = graph_json["op_lists"][3]["params"]
        tensor_addrs[0]  = p1["input_addr"]
        tensor_addrs[1]  = ct["output_addr"]
    else:
        print("op num ", graph_json["op_num"])
        assert 0

    str_json   = ConvertJson2Json(graph_json)
    irb = tvm.tir.ir_builder.create()
    irb.emit(
        tvm.tir.call_extern(
            "int32", "XMNPUTilingThreePool2dOP",
            tensor_addrs[0], tensor_addrs[1], tensor_addrs[2], tensor_addrs[3],
            tensor_addrs[4],
            str_json, len(str_json),
        )
    )
    stmt = irb.get()
    return stmt

def GenerateNPUStmt(graph):
    num_conv2d = 0
    num_pool2d = 0
    for i in range(graph["op_num"]):
        num_conv2d += (1 if(graph["op_lists"][i]["op_type"] == OP.TVM_XMOP_CONV2D) else 0)
    for i in range(graph["op_num"]):
        num_pool2d += (1 if(graph["op_lists"][i]["op_type"] == OP.TVM_XMOP_POOL2D) else 0)
        
    if num_conv2d == 0:
        if graph["op_num"] == 1:
            # normal single op
            return SubmitGeneralOPIntrin(graph)
        elif num_pool2d == 3:
            return SubmitTilingThreePool2dIntrin(graph)
        else:
            # normal multi op
            return SubmitMultiOPIntrin(graph)
    elif num_conv2d == 1:
        if graph["op_num"] == 1:  # single CONV
            return SubmitGeneralOPIntrin(graph)
        else:
            # tiling conv + xxx
            return SubmitTilingOneConv2dIntrin(graph)
    elif num_conv2d == 2:
        return SubmitTilingTwoConv2dIntrin(graph)
    elif num_conv2d == 3:
        return SubmitTilingThreeConv2dIntrin(graph)
    elif num_conv2d == 4:
        return SubmitTilingFourConv2dIntrin(graph)
    elif num_conv2d == 5:
        return SubmitTilingFiveConv2dIntrin(graph)
    else:
        assert 0

def ParsingNPUSpecialStmt2Dict(body, buffer_map):
    operator = {"op_type":-1, "in_tensors":[], "out_tensors":[], "params":{}, "reserved": [], "output":[]}
    while isinstance(body, tvm.tir.For):
        body = body.body
    while isinstance(body, tvm.tir.IfThenElse):
        body = body.then_case
    assert isinstance(body, tvm.tir.BufferStore)

    if isinstance(body.value, topi.tir.XMConv2d):
        operator["op_type"] = OP.TVM_XMOP_CONV2D
        operator["out_tensors"].append(body.buffer)
        conv2d_body = body.value
        operator["in_tensors"].append(conv2d_body.data.buffer)
        operator["in_tensors"].append(conv2d_body.kernel.buffer)

        conv2d_params = dict()
        if conv2d_body.data.buffer in buffer_map:
            conv2d_params["input_addr"]  = conv2d_body.data.buffer.data
        else:
            conv2d_params["input_addr"]  = 0
        if conv2d_body.kernel.buffer in buffer_map:
            conv2d_params["kernel_addr"]  = conv2d_body.kernel.buffer.data
        else:
            conv2d_params["kernel_addr"]  = 0
        if body.buffer in buffer_map:
            conv2d_params["output_addr"]  = body.buffer.data
        else:
            conv2d_params["output_addr"]  = 0
        if conv2d_body.using_bias:
            operator["in_tensors"].append(conv2d_body.bias.buffer)
            if conv2d_body.bias.buffer in buffer_map:
                conv2d_params["bias_addr"]  = conv2d_body.bias.buffer.data
        else:
            conv2d_params["bias_addr"]  = 0

        conv2d_params["i_dtype"]  = get_env().convert_npu_dtype(conv2d_body.data.dtype)
        conv2d_params["k_dtype"]  = get_env().convert_npu_dtype(conv2d_body.kernel.dtype)
        conv2d_params["b_dtype"]  = get_env().convert_npu_dtype(conv2d_body.bias.dtype)
        conv2d_params["o_dtype"]  = get_env().convert_npu_dtype(body.value.dtype)

        conv2d_params["multiplier"]  = conv2d_body.multiplier
        conv2d_params["right_shift"] = conv2d_body.right_shift
        conv2d_params["quant_mode"]  = conv2d_body.quant_mode
        conv2d_params["i_zp"] = conv2d_body.i_zp
        conv2d_params["k_zp"] = conv2d_body.k_zp
        conv2d_params["o_zp"] = conv2d_body.o_zp
        conv2d_params["kh"] = conv2d_body.kh
        conv2d_params["kw"] = conv2d_body.kw
        conv2d_params["kh_stride"] = conv2d_body.kh_stride
        conv2d_params["kw_stride"] = conv2d_body.kw_stride
        conv2d_params["pad_h_t"] = conv2d_body.pad_h_t
        conv2d_params["pad_h_b"] = conv2d_body.pad_h_b
        conv2d_params["pad_w_l"] = conv2d_body.pad_w_l
        conv2d_params["pad_w_r"] = conv2d_body.pad_w_r
        conv2d_params["dilation_h"] = conv2d_body.dilation_h
        conv2d_params["dilation_w"] = conv2d_body.dilation_w
        conv2d_params["ins_h"] = conv2d_body.ins_h
        conv2d_params["ins_w"] = conv2d_body.ins_w
        conv2d_params["using_bias"] = conv2d_body.using_bias
        conv2d_params["relu_type"]  = conv2d_body.relu_type
        conv2d_params["groups"]     = conv2d_body.groups
        conv2d_params["in_n"]  = conv2d_body.in_shape[0].value
        conv2d_params["in_c"]  = conv2d_body.in_shape[1].value
        conv2d_params["in_h"]  = conv2d_body.in_shape[2].value
        conv2d_params["in_w"]  = conv2d_body.in_shape[3].value
        conv2d_params["out_c"] = conv2d_body.out_shape[1].value
        conv2d_params["out_h"] = conv2d_body.out_shape[2].value
        conv2d_params["out_w"] = conv2d_body.out_shape[3].value
        assert body.value.dtype == conv2d_body.out_dtype
        operator["params"] = conv2d_params
    elif isinstance(body.value, topi.tir.XMScale):
        operator["op_type"] = OP.TVM_XMOP_SCALE
        operator["out_tensors"].append(body.buffer)
        scale_body = body.value
        operator["in_tensors"].append(scale_body.data.buffer)
        operator["in_tensors"].append(scale_body.kernel.buffer)

        scale_params = dict()
        if scale_body.data.buffer in buffer_map:
            scale_params["input_addr"]  = scale_body.data.buffer.data
        else:
            scale_params["input_addr"]  = 0
        if scale_body.kernel.buffer in buffer_map:
            scale_params["kernel_addr"]  = scale_body.kernel.buffer.data
        else:
            scale_params["kernel_addr"]  = 0
        if body.buffer in buffer_map:
            scale_params["output_addr"]  = body.buffer.data
        else:
            scale_params["output_addr"]  = 0
        if scale_body.using_bias:
            operator["in_tensors"].append(scale_body.bias.buffer)
            if scale_body.bias.buffer in buffer_map:
                scale_params["bias_addr"]  = scale_body.bias.buffer.data
        else:
            scale_params["bias_addr"]  = 0
        scale_params["i_dtype"]  = get_env().convert_npu_dtype(scale_body.data.dtype)
        scale_params["k_dtype"]  = get_env().convert_npu_dtype(scale_body.kernel.dtype)
        scale_params["b_dtype"]  = get_env().convert_npu_dtype(scale_body.bias.dtype)
        scale_params["o_dtype"]  = get_env().convert_npu_dtype(body.value.dtype)
        scale_params["multiplier"]  = scale_body.multiplier
        scale_params["right_shift"] = scale_body.right_shift
        scale_params["quant_mode"]  = scale_body.quant_mode
        scale_params["i_zp"] = scale_body.i_zp
        scale_params["k_zp"] = scale_body.k_zp
        scale_params["o_zp"] = scale_body.o_zp
        scale_params["n"] = scale_body.in_shape[0].value
        scale_params["c"] = scale_body.in_shape[1].value
        scale_params["h"] = scale_body.in_shape[2].value
        scale_params["w"] = scale_body.in_shape[3].value
        scale_params["using_bias"] = scale_body.using_bias
        scale_params["relu_type"]  = scale_body.relu_type
        assert body.value.dtype == scale_body.out_dtype
        operator["params"] = scale_params
    elif isinstance(body.value, topi.tir.XMDense):
        operator["op_type"] = OP.TVM_XMOP_DENSE
        operator["out_tensors"].append(body.buffer)
        dense_body = body.value
        operator["in_tensors"].append(dense_body.data.buffer)
        operator["in_tensors"].append(dense_body.kernel.buffer)

        dense_params = dict()
        if dense_body.data.buffer in buffer_map:
            dense_params["input_addr"]  = dense_body.data.buffer.data
        else:
            dense_params["input_addr"]  = 0
        if dense_body.kernel.buffer in buffer_map:
            dense_params["kernel_addr"]  = dense_body.kernel.buffer.data
        else:
            dense_params["kernel_addr"]  = 0
        if body.buffer in buffer_map:
            dense_params["output_addr"]  = body.buffer.data
        else:
            dense_params["output_addr"]  = 0
        if dense_body.using_bias:
            operator["in_tensors"].append(dense_body.bias.buffer)
            if dense_body.bias.buffer in buffer_map:
                dense_params["bias_addr"]  = dense_body.bias.buffer.data
        else:
            dense_params["bias_addr"]  = 0

        dense_params["i_dtype"]  = get_env().convert_npu_dtype(dense_body.data.dtype)
        dense_params["k_dtype"]  = get_env().convert_npu_dtype(dense_body.kernel.dtype)
        dense_params["b_dtype"]  = get_env().convert_npu_dtype(dense_body.bias.dtype)
        dense_params["o_dtype"]  = get_env().convert_npu_dtype(body.value.dtype)

        dense_params["multiplier"]  = dense_body.multiplier
        dense_params["right_shift"] = dense_body.right_shift
        dense_params["quant_mode"]  = dense_body.quant_mode
        dense_params["i_zp"] = dense_body.i_zp
        dense_params["k_zp"] = dense_body.k_zp
        dense_params["o_zp"] = dense_body.o_zp
        dense_params["using_bias"] = dense_body.using_bias
        dense_params["in_h"] = dense_body.data.buffer.shape[0].value
        dense_params["in_w"] = np.prod(dense_body.data.buffer.shape[1:]).value
        dense_params["out_w"] = body.buffer.shape[1].value
        assert body.value.dtype == dense_body.out_dtype
        operator["params"] = dense_params
    elif isinstance(body.value, topi.tir.XMEltwiseAdd):
        operator["op_type"] = OP.TVM_XMOP_ELTADD
        operator["out_tensors"].append(body.buffer)
        eltadd_body = body.value
        operator["in_tensors"].append(eltadd_body.lhs.buffer)
        operator["in_tensors"].append(eltadd_body.rhs.buffer)

        eltadd_params = dict()
        if eltadd_body.lhs.buffer in buffer_map:
            eltadd_params["input1_addr"]  = eltadd_body.lhs.buffer.data
        else:
            eltadd_params["input1_addr"]  = 0
        if eltadd_body.rhs.buffer in buffer_map:
            eltadd_params["input2_addr"]  = eltadd_body.rhs.buffer.data
        else:
            eltadd_params["input2_addr"]  = 0
        if body.buffer in buffer_map:
            eltadd_params["output_addr"]  = body.buffer.data
        else:
            eltadd_params["output_addr"]  = 0

        eltadd_params["i1_dtype"] = get_env().convert_npu_dtype(eltadd_body.lhs.dtype)
        eltadd_params["i2_dtype"] = get_env().convert_npu_dtype(eltadd_body.rhs.dtype)
        eltadd_params["o_dtype"]  = get_env().convert_npu_dtype(body.value.dtype)
        eltadd_params["n"] = eltadd_body.lhs.buffer.shape[0].value
        eltadd_params["c"] = eltadd_body.lhs.buffer.shape[1].value
        eltadd_params["h"] = eltadd_body.lhs.buffer.shape[2].value
        eltadd_params["w"] = eltadd_body.lhs.buffer.shape[3].value
        eltadd_params["multiplier_1"] = eltadd_body.lhs_mul
        eltadd_params["multiplier_2"] = eltadd_body.rhs_mul
        eltadd_params["r_shift_m1"]   = eltadd_body.lhs_shift
        eltadd_params["r_shift_m2"]   = eltadd_body.rhs_shift
        eltadd_params["i1_zp"]   = eltadd_body.lhs_zp
        eltadd_params["i2_zp"]   = eltadd_body.rhs_zp
        eltadd_params["o_zp"]    = eltadd_body.out_zp
        operator["params"] = eltadd_params
    elif isinstance(body.value, topi.tir.XMPool2d):
        operator["op_type"] = OP.TVM_XMOP_POOL2D
        operator["out_tensors"].append(body.buffer)
        pool2d_body = body.value
        operator["in_tensors"].append(pool2d_body.data.buffer)

        pool2d_params = dict()
        if pool2d_body.data.buffer in buffer_map:
            pool2d_params["input_addr"]  = pool2d_body.data.buffer.data
        else:
            pool2d_params["input_addr"]  = 0
        if body.buffer in buffer_map:
            pool2d_params["output_addr"]  = body.buffer.data
        else:
            pool2d_params["output_addr"]  = 0

        pool2d_params["i_dtype"]  = get_env().convert_npu_dtype(pool2d_body.data.dtype)
        pool2d_params["o_dtype"]  = get_env().convert_npu_dtype(body.value.dtype)
        pool2d_params["zp"] = pool2d_body.zero_point
        pool2d_params["kh"] = pool2d_body.kh
        pool2d_params["kw"] = pool2d_body.kw
        pool2d_params["kh_stride"] = pool2d_body.kh_stride
        pool2d_params["kw_stride"] = pool2d_body.kw_stride
        pool2d_params["pad_h_t"]   = pool2d_body.pad_h_t
        pool2d_params["pad_h_b"]   = pool2d_body.pad_h_b
        pool2d_params["pad_w_l"]   = pool2d_body.pad_w_l
        pool2d_params["pad_w_r"]   = pool2d_body.pad_w_r
        pool2d_params["pool_type"] = pool2d_body.pool_type
        pool2d_params["in_n"]  = pool2d_body.in_shape[0].value
        pool2d_params["in_c"]  = pool2d_body.in_shape[1].value
        pool2d_params["in_h"]  = pool2d_body.in_shape[2].value
        pool2d_params["in_w"]  = pool2d_body.in_shape[3].value
        pool2d_params["out_c"] = pool2d_body.out_shape[1].value
        pool2d_params["out_h"] = pool2d_body.out_shape[2].value
        pool2d_params["out_w"] = pool2d_body.out_shape[3].value
        assert pool2d_body.data.dtype == body.value.dtype
        operator["params"] = pool2d_params
    elif isinstance(body.value, topi.tir.XMGlobalAvgPool2d):
        operator["op_type"] = OP.TVM_XMOP_GAP
        operator["out_tensors"].append(body.buffer)
        gap_body = body.value
        operator["in_tensors"].append(gap_body.data.buffer)

        gap_params = dict()
        if gap_body.data.buffer in buffer_map:
            gap_params["input_addr"]  = gap_body.data.buffer.data
        else:
            gap_params["input_addr"]  = 0
        if body.buffer in buffer_map:
            gap_params["output_addr"]  = body.buffer.data
        else:
            gap_params["output_addr"]  = 0

        gap_params["i_dtype"]  = get_env().convert_npu_dtype(gap_body.data.dtype)
        gap_params["o_dtype"]  = get_env().convert_npu_dtype(body.value.dtype)
        gap_params["zp"]    = gap_body.zero_point
        gap_params["kh"]    = gap_body.kh
        gap_params["kw"]    = gap_body.kw
        gap_params["in_n"]  = gap_body.data.buffer.shape[0].value
        gap_params["in_c"]  = gap_body.data.buffer.shape[1].value
        gap_params["in_h"]  = gap_body.data.buffer.shape[2].value
        gap_params["in_w"]  = gap_body.data.buffer.shape[3].value
        gap_params["out_c"] = body.buffer.shape[1].value
        gap_params["out_h"] = body.buffer.shape[2].value
        gap_params["out_w"] = body.buffer.shape[3].value
        assert gap_body.data.dtype == body.value.dtype
        operator["params"] = gap_params
    elif isinstance(body.value, topi.tir.XMUpsample):
        operator["op_type"] = OP.TVM_XMOP_UPSAMPLE
        operator["out_tensors"].append(body.buffer)
        gap_body = body.value
        operator["in_tensors"].append(gap_body.data.buffer)

        upsp_params = dict()
        if gap_body.data.buffer in buffer_map:
            upsp_params["input_addr"]  = gap_body.data.buffer.data
        else:
            upsp_params["input_addr"]  = 0
        if body.buffer in buffer_map:
            upsp_params["output_addr"] = body.buffer.data
        else:
            upsp_params["output_addr"] = 0
        upsp_params["dtype"]  = get_env().convert_npu_dtype(body.value.dtype)
        assert body.value.scale_h == body.value.scale_w
        upsp_params["factor"] = body.value.scale_h
        upsp_params["in_n"]  = gap_body.data.buffer.shape[0].value
        upsp_params["in_c"]  = gap_body.data.buffer.shape[1].value
        upsp_params["in_h"]  = gap_body.data.buffer.shape[2].value
        upsp_params["in_w"]  = gap_body.data.buffer.shape[3].value
        upsp_params["out_c"] = body.buffer.shape[1].value
        upsp_params["out_h"] = body.buffer.shape[2].value
        upsp_params["out_w"] = body.buffer.shape[3].value
        assert gap_body.data.dtype == body.value.dtype
        operator["params"] = upsp_params
    else:
        assert 0

    return 1, [operator]

def ParsingNPUConcatStmt2Dict(body, buffer_map):
    operator = {"op_type":-1, "in_tensors":[], "out_tensors":[], "params":{}, "reserved": [], "output":[]}
    tmp_body = body

    while isinstance(tmp_body, tvm.tir.For):
        tmp_body = tmp_body.body
    concat_body = tmp_body
    if isinstance(concat_body, tvm.tir.stmt.IfThenElse):
        concat_body = tmp_body.then_case

    def _get_concat_axis(concat_body):
        concat_condition = concat_body.value.args[0]
        concat_condition = tvm.arith.Analyzer().simplify(concat_condition)
        concat_var = concat_condition.a if isinstance(concat_condition.a, tvm.tir.Var) else concat_condition.b
        out_shape_indices = concat_body.indices

        concat_axis = 0
        for x in out_shape_indices:
            if type(x) == type(concat_var) and  x == concat_var:
                break
            concat_axis += 1
        return concat_axis

    def _get_concat_params(condition, lhs, rhs, c_operator):
        condition = tvm.arith.Analyzer().simplify(condition)
        #print(condition, type(condition))
        assert isinstance(lhs, tvm.tir.BufferLoad)
        assert _is_binary_op(condition)
        concat_num = condition.a if isinstance(condition.a, tvm.tir.IntImm) else condition.b
        concat_num = concat_num.value
        concat_axis = c_operator["params"]["axis"]

        if isinstance(rhs, tvm.tir.BufferLoad):
            c_operator["params"]["in1_n"] = rhs.buffer.shape[0].value
            c_operator["params"]["in1_c"] = rhs.buffer.shape[1].value
            c_operator["params"]["in1_h"] = rhs.buffer.shape[2].value
            c_operator["params"]["in1_w"] = rhs.buffer.shape[3].value
            c_operator["params"]["concat_offset"] = [concat_num]
            c_operator["in_tensors"].append(rhs.buffer)
        c_operator["in_tensors"].append(lhs.buffer)
        c_operator["params"]["concat_offset"].append(lhs.buffer.shape[concat_axis].value)

    def _find_concat_params(body, c_operator):
        assert isinstance(body, tvm.tir.Call)
        assert len(body.args) == 3
        concat_condition = body.args[0]
        lhs_input        = body.args[1]
        rhs_input        = body.args[2]
        params = []
        if isinstance(rhs_input, tvm.tir.Call):
            _find_concat_params(rhs_input, c_operator)

        _get_concat_params(concat_condition, lhs_input, rhs_input, c_operator)

    def _update_concat_addr(c_operator, buffer_map):
        concat_params = c_operator["params"]
        concat_params["input_addr"]  = [] #c_operator["in_tensors"][0].data
        for i in range(len(c_operator["in_tensors"])):
            if c_operator["in_tensors"][i] in buffer_map:
                buf_addr = c_operator["in_tensors"][i].data
            else:
                buf_addr = 0
            concat_params["input_addr"].append(buf_addr)

        assert len(c_operator["out_tensors"]) == 1
        if c_operator["out_tensors"][0] in buffer_map:
            concat_params["output_addr"]  = c_operator["out_tensors"][0].data
        else:
            concat_params["output_addr"]  = 0

        return c_operator

    concat_axis = _get_concat_axis(concat_body)
    operator["op_type"] = OP.TVM_XMOP_CONCAT
    concat_params = dict()
    concat_params["dtype"]  = get_env().convert_npu_dtype(concat_body.buffer.dtype)
    concat_params["axis"]   = concat_axis
    operator["params"]      = concat_params
    operator["out_tensors"].append(concat_body.buffer)

    _find_concat_params(concat_body.value, operator)
    operator = _update_concat_addr(operator, buffer_map)

    return 1, [operator]

def ParsingNPUSplitStmt2Dict(parsing_body, buffer_map):
    operator = {"op_type":-1, "in_tensors":[], "out_tensors":[], "params":{}, "reserved": [], "output":[]}
    tmp_body = parsing_body.body

    while isinstance(tmp_body, tvm.tir.For):
        tmp_body = tmp_body.body

    if _match_pragma(parsing_body, get_env().split(1)):
        split_body = tmp_body
        operator["op_type"] = OP.TVM_XMOP_SPLIT
        split_params = dict()
        split_params["dtype"] = get_env().convert_npu_dtype(split_body.buffer.dtype)

        operator["params"] = split_params
        split_body1 = split_body.value
        operator["params"]["array_len"] = split_body1.a.b.value
        operator["out_tensors"].append(split_body.buffer)
        in_n, in_c, in_h, in_w = [int(x) for x in split_body.buffer.shape]

        operator["params"]["input_n"] = in_n
        operator["params"]["input_c"] = in_c
        operator["params"]["input_h"] = in_h
        operator["params"]["input_w"] = in_w
        operator["params"]["axis"] = 1
        operator["params"]["split_idx"] = in_c

        split_body_input = split_body1.a.a
        operator["in_tensors"].append(split_body_input.buffer)
        split_params = operator["params"]
        split_params["input_addr"] = operator["in_tensors"][0].data

        if operator["out_tensors"][0] in buffer_map:
            split_params["output_addr"] = operator["out_tensors"][0].data
        else:
            split_params["output_addr"] = 0

    return 1, [operator]

def ParsingNPUGeneralStmt2Dict(parsing_body, buffer_map):
    operator = {"op_type":-1, "in_tensors":[], "out_tensors":[], "params":{}, "reserved": [], "output":[]}
    tmp_body = parsing_body.body

    while isinstance(tmp_body, tvm.tir.For):
        tmp_body = tmp_body.body

    if _match_pragma(parsing_body, get_env().neg(1)):
        neg_body = tmp_body
        operator["op_type"] = OP.TVM_XMOP_NEG
        neg_params = dict()
        neg_params["o_dtype"] = get_env().convert_npu_dtype(neg_body.buffer.dtype)
        operator["params"]    = neg_params
        operator["out_tensors"].append(neg_body.buffer)

        operator["params"]["in_n"] = neg_body.shape[0].value
        operator["params"]["in_c"] = neg_body.shape[1].value
        operator["params"]["in_h"] = neg_body.shape[2].value
        operator["params"]["in_w"] = neg_body.shape[3].value
        body = neg_body.value
        while not isinstance(body, tvm.tir.BufferLoad):
            if isinstance(body, tvm.tir.Mul):
                body = body.a
            elif isinstance(body, tvm.tir.Cast):
                body = body.value
            else:
                assert 0, "unknown tir node to process!!!"
        operator["params"]["i_dtype"] = get_env().convert_npu_dtype(body.dtype)
        operator["in_tensors"].append(body.buffer)

        neg_params = operator["params"]
        if operator["in_tensors"][0] in buffer_map:
            neg_params["input_addr"] = operator["in_tensors"][0].data
        else:
            neg_params["input_addr"] = 0
        assert len(operator["out_tensors"]) == 1
        if operator["out_tensors"][0] in buffer_map:
            neg_params["output_addr"]  = operator["out_tensors"][0].data
        else:
            neg_params["output_addr"]  = 0
    elif _match_pragma(parsing_body, get_env().lut(1)):
        input, table, output = buffer_map
        operator["op_type"] = OP.TVM_XMOP_LUT
        operator["in_tensors"].append(input)
        operator["out_tensors"].append(output)
        operator["in_tensors"].append(table)
        operator["params"]["input_addr"] = input.data
        operator["params"]["table_addr"] = table.data
        operator["params"]["output_addr"] = output.data
        operator["params"]["input_w"] = int(np.prod(input.shape))
        operator["params"]["table_num"] = 256
        operator["params"]["table_index"] = 0
        operator["params"]["i_dtype"] = get_env().convert_npu_dtype(input.dtype)
        operator["params"]["o_dtype"] = get_env().convert_npu_dtype(output.dtype)
    elif _match_pragma(parsing_body, get_env().clip(1)):
        clip_body = tmp_body
        operator["op_type"] = OP.TVM_XMOP_CLIP
        clip_params = dict()
        input, output = buffer_map
        operator["in_tensors"].append(input)
        clip_params["i_dtype"] = get_env().convert_npu_dtype(input.dtype)
        clip_params["o_dtype"] = get_env().convert_npu_dtype(clip_body.buffer.dtype)

        operator["params"] = clip_params
        operator["out_tensors"].append(clip_body.buffer)
        operator["params"]["in_n"] = clip_body.shape[0].value
        operator["params"]["in_c"] = clip_body.shape[1].value
        operator["params"]["in_h"] = clip_body.shape[2].value
        operator["params"]["in_w"] = clip_body.shape[3].value

        body = clip_body.value
        operator["params"]["min_threshold"] = body.b.value
        operator["params"]["max_threshold"] = body.a.b.value
        operator["params"]["input_addr"]  = operator["in_tensors"][0].data
        operator["params"]["output_addr"] = operator["out_tensors"][0].data
    elif _match_pragma(parsing_body, get_env().tile(1)):
        tile_body = tmp_body
        operator["op_type"] = OP.TVM_XMOP_TILE
        tile_params = dict()
        tile_params["dtype"]  = get_env().convert_npu_dtype(tile_body.buffer.dtype)
        operator["params"]      = tile_params
        operator["out_tensors"].append(tile_body.buffer)
        
        assert isinstance(tile_body, tvm.tir.stmt.BufferStore)
        mul_n, mul_c, mul_h, mul_w = [int(x) for x in tile_body.shape]

        tile_body_input = tile_body.value
        assert isinstance(tile_body_input, tvm.tir.expr.BufferLoad)
        in_n, in_c, in_h, in_w = [int(y) for y in tile_body_input.buffer.shape]

        mul_n = int(mul_n / in_n)
        mul_c = int(mul_c / in_c)
        mul_h = int(mul_h / in_h)
        mul_w = int(mul_w / in_w)

        operator["params"]["in_n"] = in_n
        operator["params"]["in_c"] = in_c
        operator["params"]["in_h"] = in_h
        operator["params"]["in_w"] = in_w
        operator["params"]["mul_n"] = mul_n
        operator["params"]["mul_c"] = mul_c
        operator["params"]["mul_h"] = mul_h
        operator["params"]["mul_w"] = mul_w
        operator["in_tensors"].append(tile_body_input.buffer)
        
        tile_params = operator["params"]
        tile_params["input_addr"]  = []
        for i in range(len(operator["in_tensors"])):
            if operator["in_tensors"][i] in buffer_map:
                buf_addr = operator["in_tensors"][i].data
            else:
                buf_addr = 0
            tile_params["input_addr"].append(buf_addr)

        assert len(operator["out_tensors"]) == 1
        if operator["out_tensors"][0] in buffer_map:
            tile_params["output_addr"]  = operator["out_tensors"][0].data
        else:
            tile_params["output_addr"]  = 0
    elif _match_pragma(parsing_body, get_env().yuv2rgb(1)):
        yuv2rgb_body = tmp_body
        operator["op_type"] = OP.TVM_XMOP_YUV2RGB
        yuv2rgb_params = dict()
        yuv2rgb_params["dtype"] = get_env().convert_npu_dtype(yuv2rgb_body.buffer.dtype)
        operator["params"] = yuv2rgb_params
        operator["out_tensors"].append(yuv2rgb_body.buffer)

        assert isinstance(yuv2rgb_body, tvm.tir.stmt.BufferStore)
        _, _, input_h, input_w = [int(x) for x in yuv2rgb_body.shape]
        operator["params"]["input_h"] = input_h
        operator["params"]["input_w"] = input_w
        operator["params"]["input_wptch"] = input_w
        yuv2rgb_body_input = yuv2rgb_body.value
        operator["params"]["range_e"] = yuv2rgb_body_input.b.value
        yuv2rgb_body_input_a = yuv2rgb_body_input.a
        operator["params"]["input_mtype"] = yuv2rgb_body_input_a.b.value - 1
        yuv2rgb_body_input_a2 = yuv2rgb_body_input_a.a
        operator["params"]["btfmt_e"] = yuv2rgb_body_input_a2.b.value
        yuv2rgb_body_input_a3 = yuv2rgb_body_input_a2.a
        operator["params"]["pic_format_e"] = yuv2rgb_body_input_a3.b.value - 1
        yuv2rgb_body_input_a4 = yuv2rgb_body_input_a3.a
        operator["in_tensors"].append(yuv2rgb_body_input_a4.a.buffer)
        operator["in_tensors"].append(yuv2rgb_body_input_a4.b.buffer)

        yuv2rgb_params = operator["params"]
        yuv2rgb_params["input_addr"]  = []
        for i in range(len(operator["in_tensors"])):
            if operator["in_tensors"][i] in buffer_map:
                buf_addr = operator["in_tensors"][i].data
            else:
                buf_addr = 0
            yuv2rgb_params["input_addr"].append(buf_addr)

        assert len(operator["out_tensors"]) == 1
        if operator["out_tensors"][0] in buffer_map:
            yuv2rgb_params["output_addr"]  = operator["out_tensors"][0].data
        else:
            yuv2rgb_params["output_addr"]  = 0
    elif _match_pragma(parsing_body, get_env().space_to_depth(1)):
        s2d_body = tmp_body
        _input = s2d_body.value.buffer
        _transfer = s2d_body.value.buffer
        _output = s2d_body.buffer
        dtype = s2d_body.value.buffer.dtype
        n, ic, ih, iw = s2d_body.value.buffer.shape
        on, oc, oh, ow = s2d_body.buffer.shape
        block_size = int(int(iw) / int(ow))
        operator["op_type"] = OP.TVM_XMOP_SPACE_TO_DEPTH
        operator["in_tensors"].append(_input)
        operator["in_tensors"].append(_transfer)
        operator["out_tensors"].append(_output)
        operator["params"]["input_addr"] = _input.data
        operator["params"]["transfer_addr"] = _transfer.data
        operator["params"]["output_addr"] = _output.data
        operator["params"]["factor"] = block_size
        operator["params"]["input_n"] = int(n)
        operator["params"]["input_c"] = int(ic)
        operator["params"]["input_h"] = int(ih)
        operator["params"]["input_w"] = int(iw)
        operator["params"]["output_n"] = int(on)
        operator["params"]["output_c"] = int(oc)
        operator["params"]["output_h"] = int(oh)
        operator["params"]["output_w"] = int(ow)
        operator["params"]["dtype"] = get_env().convert_npu_dtype(dtype)
    elif _match_pragma(parsing_body, get_env().depth_to_space(1)):
        d2s_body = tmp_body
        _input  = d2s_body.value.buffer
        _transfer = d2s_body.value.buffer
        _output = d2s_body.buffer
        dtype   = d2s_body.value.buffer.dtype
        n, ic, ih, iw  = d2s_body.value.buffer.shape
        on, oc, oh, ow = d2s_body.buffer.shape
        block_size = int(int(ow) / int(iw))
        operator["op_type"] = OP.TVM_XMOP_DEPTH_TO_SPACE
        operator["in_tensors"].append(_input)
        operator["in_tensors"].append(_transfer)
        operator["out_tensors"].append(_output)
        operator["params"]["input_addr"] = _input.data
        operator["params"]["transfer_addr"] = _transfer.data
        operator["params"]["output_addr"] = _output.data
        operator["params"]["factor"] = block_size
        operator["params"]["input_n"] = int(n)
        operator["params"]["input_c"] = int(ic)
        operator["params"]["input_h"] = int(ih)
        operator["params"]["input_w"] = int(iw)
        operator["params"]["output_n"] = int(on)
        operator["params"]["output_c"] = int(oc)
        operator["params"]["output_h"] = int(oh)
        operator["params"]["output_w"] = int(ow)
        operator["params"]["dtype"] = get_env().convert_npu_dtype(dtype)
    elif _match_pragma(parsing_body, get_env().strided_slice(1)):
        def get_start_index(val):
            assert isinstance(val, tvm.tir.BufferLoad)
            in_dices = val.indices
            start_index = [0, 0, 0, 0]
            strides = [1, 1, 1, 1]
            for i in range(len(in_dices)):
                if isinstance(in_dices[i], tvm.tir.IntImm) and \
                    in_dices[i].value == 0:
                    start_index[i] = 0
                elif isinstance(in_dices[i], tvm.tir.Var):
                    start_index[i] = 0
                elif isinstance(in_dices[i], tvm.tir.Add):
                    start_index[i] += in_dices[i].b.value
                    if isinstance(in_dices[i].a, tvm.tir.Mul):
                        strides[i] = in_dices[i].a.b.value
                elif isinstance(in_dices[i], tvm.tir.Mul):
                    start_index[i] = 0
                    strides[i] = in_dices[i].b.value
            return start_index, strides

        def get_end_index(out_infos, in_shape, start_idx, in_strides):
            end_index = [-1, -1, -1, -1]
            axes_str = ["ax0", "ax1", "ax2", "ax3"]
            for inx, axe in enumerate(axes_str):
                if axe in out_infos:
                    range_l = out_infos[axe]
                    end_index_val = start_idx[inx] + in_strides[inx] * range_l[1]
                    if isinstance(end_index_val, tvm.tir.IntImm):
                        end_index_val = end_index_val.value
                    if end_index_val > in_shape[inx]:
                        end_index_val = in_shape[inx]
                    end_index[inx] = end_index_val
                else:
                    end_index[inx] = start_idx[inx] + 1
            return end_index

        # output info
        output_infos = {}
        loop_body = parsing_body.body
        while isinstance(loop_body, tvm.tir.For):
            var_name = str(loop_body.loop_var.name)
            loop_start_v = loop_body.min
            loop_end_v = loop_body.extent
            output_infos[var_name] = [loop_start_v, loop_end_v]
            loop_body = loop_body.body
        strided_slice_body = loop_body
        operator["op_type"] = OP.TVM_XMOP_STRIDED_SLICE
        ss_params = dict()
        dtype = get_env().convert_npu_dtype(strided_slice_body.value.dtype)
        ss_params["dtype"] = dtype
        operator["params"] = ss_params
        operator["out_tensors"].append(strided_slice_body.buffer)
        body = strided_slice_body

        if isinstance(body, tvm.tir.BufferStore):
            output_data  = body.buffer.data
            output_shape = [int(x) for x in body.shape]
            body         = body.value
        assert isinstance(body, tvm.tir.BufferLoad)
        operator["in_tensors"].append(body.buffer)
        input_shape = [int(x) for x in body.buffer.shape]
        n, c, h, w = input_shape
        operator["params"]["in_n"] = n
        operator["params"]["in_c"] = c
        operator["params"]["in_h"] = h
        operator["params"]["in_w"] = w
        input_data = body.buffer.data
        expr_indices = strided_slice_body.value.indices[0]
        #needed params
        start_index = [0, 0, 0, 0]
        end_index = [-1, -1, -1, -1]
        strides = [1, 1, 1, 1]
        start_index, strides = get_start_index(strided_slice_body.value)
        end_index = get_end_index(output_infos, input_shape, start_index, strides)
        operator["params"]["start_idx0"] = start_index[0]
        operator["params"]["start_idx1"] = start_index[1]  
        operator["params"]["start_idx2"] = start_index[2] 
        operator["params"]["start_idx3"] = start_index[3] 
        operator["params"]["end_idx0"] = end_index[0]
        operator["params"]["end_idx1"] = end_index[1]  
        operator["params"]["end_idx2"] = end_index[2] 
        operator["params"]["end_idx3"] = end_index[3] 
        operator["params"]["strides_idx0"] = strides[0]
        operator["params"]["strides_idx1"] = strides[1]  
        operator["params"]["strides_idx2"] = strides[2] 
        operator["params"]["strides_idx3"] = strides[3] 
        ss_params = operator["params"]
        if operator["in_tensors"][0] in buffer_map:
            ss_params["input_addr"] = operator["in_tensors"][0].data
        else:
            ss_params["input_addr"] = 0
        assert len(operator["out_tensors"]) == 1
        if operator["out_tensors"][0] in buffer_map:
            ss_params["output_addr"]  = operator["out_tensors"][0].data
        else:
            ss_params["output_addr"]  = 0
    elif _match_pragma(parsing_body, get_env().transpose(1)):
        trans_body = tmp_body
        operator["op_type"] = OP.TVM_XMOP_TRANSPOSE
        trans_params = dict()
        trans_params["dtype"] = get_env().convert_npu_dtype(trans_body.buffer.dtype)
        operator["params"]    = trans_params
        operator["out_tensors"].append(trans_body.buffer)

        operator["params"]["out_n"] = trans_body.shape[0].value
        operator["params"]["out_c"] = trans_body.shape[1].value
        operator["params"]["out_h"] = trans_body.shape[2].value
        operator["params"]["out_w"] = trans_body.shape[3].value
        body = trans_body.value
        assert isinstance(body, tvm.tir.BufferLoad)
        input_shape = [int(x) for x in body.buffer.shape]
        n, c, h, w = input_shape
        operator["params"]["in_n"] = n
        operator["params"]["in_c"] = c
        operator["params"]["in_h"] = h
        operator["params"]["in_w"] = w
        operator["in_tensors"].append(body.buffer)

        def get_permute_swap_axes(in_body):
            axes_str = ["ax0", "ax1", "ax2", "ax3"]
            axes_l = in_body.indices
            order_l = [0,0,0,0]
            for inx, axe in enumerate(axes_str):
                for iny, v in enumerate(axes_l):
                    if isinstance(v, tvm.tir.Var):
                        if axe == v.name:
                            order_l[inx] = iny
            #calc c_map/h_map/w_map via order_l
            c_map=2
            h_map=1
            w_map=0
            if order_l[1] == 3:
                w_map = 2
            elif order_l[1] == 2:
                h_map = 2
            elif order_l[1] == 1:
                c_map = 2

            if order_l[2] == 3:
                w_map = 1
            elif order_l[2] == 2:
                h_map = 1
            elif order_l[2] == 1:
                c_map = 1

            if order_l[3] == 3:
                w_map = 0 
            elif order_l[3] == 2:
                h_map = 0
            elif order_l[3] == 1:
                c_map = 0

            return c_map, h_map, w_map

        cmap, hmap, wmap = get_permute_swap_axes(body)
        operator["params"]["c_map"] = cmap
        operator["params"]["h_map"] = hmap
        operator["params"]["w_map"] = wmap
        trans_params = operator["params"]
        if operator["in_tensors"][0] in buffer_map:
            trans_params["input_addr"] = operator["in_tensors"][0].data
        else:
            trans_params["input_addr"] = 0
        assert len(operator["out_tensors"]) == 1
        if operator["out_tensors"][0] in buffer_map:
            trans_params["output_addr"]  = operator["out_tensors"][0].data
        else:
            trans_params["output_addr"]  = 0
    elif _match_pragma(parsing_body, get_env().channel_shuffle(1)):
        shuffle_body = tmp_body
        operator["op_type"] = OP.TVM_XMOP_CHANNEL_SHUFFLE
        shuffle_params = dict()
        shuffle_params["dtype"] = get_env().convert_npu_dtype(shuffle_body.buffer.dtype)
        operator["params"] = shuffle_params
        operator["out_tensors"].append(shuffle_body.buffer)

        operator["params"]["out_n"] = shuffle_body.shape[0].value
        operator["params"]["out_c"] = shuffle_body.shape[1].value
        operator["params"]["out_h"] = shuffle_body.shape[2].value
        operator["params"]["out_w"] = shuffle_body.shape[3].value
        body = shuffle_body.value
        assert isinstance(body, tvm.tir.BufferLoad)
        input_shape = [int(x) for x in body.buffer.shape]

        n, c, h, w = input_shape
        operator["params"]["in_n"] = n
        operator["params"]["in_c"] = c
        operator["params"]["in_h"] = h
        operator["params"]["in_w"] = w
        operator["in_tensors"].append(body.buffer)
        group = int(shuffle_body.buffer.name.split("_")[-1])
        operator["params"]["group"] = group
        shuffle_params = operator["params"]
        if operator["in_tensors"][0] in buffer_map:
            shuffle_params["input_addr"] = operator["in_tensors"][0].data
        else:
            shuffle_params["input_addr"] = 0
        assert len(operator["out_tensors"]) == 1
        if operator["out_tensors"][0] in buffer_map:
            shuffle_params["output_addr"]  = operator["out_tensors"][0].data
        else:
            shuffle_params["output_addr"]  = 0
    elif _match_pragma(parsing_body, get_env().test_load(1)) or \
         _match_pragma(parsing_body, get_env().test_store(1)):
        test_body = tmp_body
        operator["op_type"] = OP.TVM_XMOP_TEST_DMA
        test_params = dict()
        test_params["dtype"] = get_env().convert_npu_dtype(test_body.buffer.dtype)
        operator["out_tensors"].append(test_body.buffer)
        operator["in_tensors"].append(test_body.value.buffer)

        test_dma_params = dict()
        if test_body.buffer in buffer_map:
            test_dma_params["input_addr"]  = test_body.value.buffer.data
        else:
            test_dma_params["input_addr"]  = 0
        if test_body.buffer in buffer_map:
            test_dma_params["output_addr"]  = test_body.buffer.data
        else:
            test_dma_params["output_addr"]  = 0
        if _match_pragma(parsing_body, get_env().test_load(1)):
            test_dma_params["direction"] = 0  # load
        else:
            test_dma_params["direction"] = 1  # store
        if len(test_body.value.buffer.shape) == 4:
            test_dma_params["n"]  = test_body.value.buffer.shape[0].value
            test_dma_params["c"]  = test_body.value.buffer.shape[1].value
            test_dma_params["h"]  = test_body.value.buffer.shape[2].value
            test_dma_params["w"]  = test_body.value.buffer.shape[3].value
        else:
            test_dma_params["n"]  = test_body.value.buffer.shape[0].value
            test_dma_params["c"]  = 1
            test_dma_params["h"]  = 1
            test_dma_params["w"]  = test_body.value.buffer.shape[1].value
        test_dma_params["dtype"]  = get_env().convert_npu_dtype(test_body.value.dtype)
        operator["params"] = test_dma_params
    elif _match_pragma(parsing_body, get_env().batch_to_space_nd(1)):
        b2s_body = tmp_body
        operator["op_type"] = OP.TVM_XMOP_BATCH_TO_SPACE_ND
        _input    = b2s_body.value.buffer
        _transfer = b2s_body.value.buffer
        _output   = b2s_body.buffer
        dtype     = b2s_body.value.buffer.dtype
        n, ic, ih, iw  = b2s_body.value.buffer.shape
        on, oc, oh, ow = b2s_body.buffer.shape
        crop = [int(i) for i in b2s_body.buffer.name.split("_")[-4:]]
        block_shape = [floordiv((oh + crop[0] + crop[2]), ih), floordiv((ow + crop[1] + crop[3]), iw)]
        operator["op_type"] = OP.TVM_XMOP_BATCH_TO_SPACE_ND
        operator["in_tensors"].append(_input)
        operator["in_tensors"].append(_transfer)
        operator["out_tensors"].append(_output)
        operator["params"]["input_addr"]    = _input.data
        operator["params"]["transfer_addr"] = _transfer.data
        operator["params"]["output_addr"]   = _output.data
        operator["params"]["block_shape_0"] = int(block_shape[0])
        operator["params"]["block_shape_1"] = int(block_shape[1])
        operator["params"]["crop_t"] = crop[0]
        operator["params"]["crop_b"] = crop[2]
        operator["params"]["crop_l"] = crop[1]
        operator["params"]["crop_r"] = crop[3]
        operator["params"]["n"]  = int(n)
        operator["params"]["ic"] = int(ic)
        operator["params"]["ih"] = int(ih)
        operator["params"]["iw"] = int(iw)
        operator["params"]["on"] = int(on)
        operator["params"]["oc"] = int(oc)
        operator["params"]["oh"] = int(oh)
        operator["params"]["ow"] = int(ow)
        operator["params"]["dtype"] = get_env().convert_npu_dtype(dtype)
    elif _match_pragma(parsing_body, get_env().space_to_batch_nd(1)):
        s2b_body = tmp_body
        operator["op_type"] = OP.TVM_XMOP_SPACE_TO_BATCH_ND
        _input    = s2b_body.value.buffer
        _transfer = s2b_body.value.buffer
        _output   = s2b_body.buffer
        dtype     = s2b_body.value.buffer.dtype
        n, ic, ih, iw  = s2b_body.value.buffer.shape
        on, oc, oh, ow = s2b_body.buffer.shape
        pad = [int(i) for i in s2b_body.buffer.name.split("_")[-4:]]
        block_shape = [floordiv((ih + pad[0] + pad[2]), oh), floordiv((iw + pad[1] + pad[3]), ow)]
        operator["op_type"] = OP.TVM_XMOP_SPACE_TO_BATCH_ND
        operator["in_tensors"].append(_input)
        operator["in_tensors"].append(_transfer)
        operator["out_tensors"].append(_output)
        operator["params"]["input_addr"]    = _input.data
        operator["params"]["transfer_addr"] = _transfer.data
        operator["params"]["output_addr"]   = _output.data
        operator["params"]["block_shape_0"] = int(block_shape[0])
        operator["params"]["block_shape_1"] = int(block_shape[1])
        operator["params"]["pad_t"] = pad[0]
        operator["params"]["pad_b"] = pad[2]
        operator["params"]["pad_l"] = pad[1]
        operator["params"]["pad_r"] = pad[3]
        operator["params"]["n"]  = int(n)
        operator["params"]["ic"] = int(ic)
        operator["params"]["ih"] = int(ih)
        operator["params"]["iw"] = int(iw)
        operator["params"]["on"] = int(on)
        operator["params"]["oc"] = int(oc)
        operator["params"]["oh"] = int(oh)
        operator["params"]["ow"] = int(ow)
        operator["params"]["dtype"] = get_env().convert_npu_dtype(dtype)
    elif _match_pragma(parsing_body, get_env().matmul(1)):
        mul_body = tmp_body
        oc, oh, ow = mul_body.seq[1].value.a.buffer.shape
        transpose_a, transpose_b, i1_zp, i2_zp, o_zp, quant_mode, f_multiplier, multiplier, r_shift_m =\
            mul_body.seq[1].buffer.name.split("_")[-9:]
        
        o_dtype = mul_body.seq[1].value.a.dtype
        output  = mul_body.seq[1].value.a.buffer
        input1_body = mul_body.seq[1].value.b.a
        input2_body = mul_body.seq[1].value.b.b
        if isinstance(input1_body, tvm.tir.expr.Cast):
            i1_dtype = input1_body.value.buffer.dtype
            input_1 = input1_body.value.buffer
            i1_c, i1_h, i1_w = input1_body.value.buffer.shape
        else:
            i1_dtype = (input1_body.buffer.dtype)
            input_1 = input1_body.buffer
            i1_c, i1_h, i1_w = input1_body.buffer.shape
        if isinstance(input2_body, tvm.tir.expr.Cast):
            i2_dtype = input2_body.value.buffer.dtype
            input_2 = input2_body.value.buffer
            i2_c, i2_h, i2_w = input2_body.value.buffer.shape
        else:
            i2_dtype = input2_body.buffer.dtype
            input_2 = input2_body.buffer
            i2_c, i2_h, i2_w = input2_body.buffer.shape
        operator["op_type"] = OP.TVM_XMOP_MATMUL
        operator["in_tensors"].append(input_1)
        operator["in_tensors"].append(input_2)
        operator["out_tensors"].append(output)
        operator["params"]["input1_addr"] = input_1.data
        operator["params"]["input2_addr"] = input_2.data
        operator["params"]["output_addr"] = output.data
        operator["params"]["input1_n"] = 1
        operator["params"]["input1_c"] = int(i1_c)
        operator["params"]["input1_h"] = int(i1_h)
        operator["params"]["input1_w"] = int(i1_w)
        operator["params"]["input2_n"] = 1
        operator["params"]["input2_c"] = int(i2_c)
        operator["params"]["input2_h"] = int(i2_h)
        operator["params"]["input2_w"] = int(i2_w)
        operator["params"]["output_n"] = 1
        operator["params"]["output_c"] = int(oc)
        operator["params"]["output_h"] = int(oh)
        operator["params"]["output_w"] = int(ow)
        operator["params"]["using_bias"] = 0
        operator["params"]["i1_zp"] = int(i1_zp)
        operator["params"]["i2_zp"] = int(i2_zp)
        operator["params"]["o_zp"]  = int(o_zp)
        operator["params"]["quant_mode"]   = int(quant_mode)
        #operator["params"]["f_multiplier"] = float(f_multiplier)
        operator["params"]["multiplier"]   = int(multiplier)
        operator["params"]["r_shift_m"]    = int(r_shift_m)
        operator["params"]["i1_dtype"] = get_env().convert_npu_dtype(i1_dtype)
        operator["params"]["i2_dtype"] = get_env().convert_npu_dtype(i2_dtype)
        operator["params"]["o_dtype"]  = get_env().convert_npu_dtype(o_dtype)
    elif _match_pragma(parsing_body, get_env().reduce_mean(1)):
        reduce_body = tmp_body
        operator["op_type"] = OP.TVM_XMOP_REDUCE_MEAN
        _output = reduce_body.seq[0].buffer
        o_dtype = reduce_body.seq[0].buffer.dtype
        on, oc, oh, ow  = reduce_body.seq[0].shape
        _input = buffer_map[0]
        n, ic, ih, iw  = buffer_map[0].shape
        i_dtype = buffer_map[0].dtype
        o_dtype = i_dtype
        input_num_dims = 4
        output_num_dims = 2 if oh == 1 else 3
        axis_0 = 3
        axis_1 = 2 if oh == 1 else 0
        operator["in_tensors"].append(_input)
        operator["out_tensors"].append(_output)
        operator["params"]["input_addr"]  = _input.data
        operator["params"]["output_addr"] = _output.data
        operator["params"]["input_n"]  = int(n)
        operator["params"]["input_c"]  = int(ic)
        operator["params"]["input_h"]  = int(ih)
        operator["params"]["input_w"]  = int(iw)
        operator["params"]["output_c"] = int(oc)
        operator["params"]["output_h"] = int(oh)
        operator["params"]["output_w"] = int(ow)
        operator["params"]["input_num_dims"]  = input_num_dims
        operator["params"]["output_num_dims"] = output_num_dims
        operator["params"]["axis_0"]  = axis_0
        operator["params"]["axis_1"]  = axis_1
        operator["params"]["i_dtype"] = get_env().convert_npu_dtype(i_dtype)
        operator["params"]["o_dtype"] = get_env().convert_npu_dtype(o_dtype)
    else:
        assert 0, "Should NOT go here."

    return 1, [operator]

def InjectNPUIntrin():
    def _ftransform(func, mod, ctx):
        env = get_env()
        idxm = tvm.tir.indexmod
        analyzer = tvm.arith.Analyzer()
        graph_json = {"op_num": 0, "op_kind": 0, "op_lists": [], "output":[], "unique_id": 9, "opt_config": 0, "reserved": []}
        # "output":[[1,0],[2,0],[2,1]],
        #           [1,0] 表示idx=1(第二个)OP的第0个out_tensor是整个graph的output
        #           [2,0] 表示idx=2(第三个)OP的第0个out_tensor是整个graph的output
        #           [2,1] 表示idx=2(第三个)OP的第1个out_tensor是整个graph的output
        # operator里面也有output，[[0,1，0],[1,2,0], [1,4,1], [2, -1]]
        #                         [0,1,0] 表示本OP的第0个out tensor, 连接到idx=1(第二个)OP的第0个in tenor
        #                         [1,2,0] 表示本OP的第1个out tensor, 连接到idx=2(第三个)OP的第0个in tenor
        #                         [1,4,1] 表示本OP的第1个out tensor, 连接到idx=4(第五个)OP的第1个in tenor
        #                         [2,-1]  表示本OP的第2个out tensor, 连接到graph的output，和外面的json对应[op_idx, 2]

        #print(func)
        def _get_tiling_config(body):
            unique_id    = 0
            opt_config   = 0
            realize_body = body
            if isinstance(realize_body, tvm.tir.AttrStmt):
                attr_id_config = realize_body.value
                realize_body   = realize_body.body
                unique_id  = attr_id_config.args[1].value
                opt_config = attr_id_config.args[2].value
            elif isinstance(realize_body, tvm.tir.BufferRealize):
                #process split cut two parts
                if isinstance(realize_body.body, tvm.tir.SeqStmt) and len(realize_body.body) == 2:
                    pending_body = realize_body.body[1]
                    if isinstance(pending_body, tvm.tir.AttrStmt):
                        attr_id_config = pending_body.value
                        #realize_body   = pending_body.body
                        unique_id  = attr_id_config.args[1].value
                        opt_config = attr_id_config.args[2].value
                #else:
                #    assert 0, "add your process code!!!"
            # else:
            #     assert 0, "wrong npu_id_config."
            return unique_id, opt_config, realize_body
        def _prim_body_recursive(body, buffer_map, graph_dict):
            assert isinstance(body, tvm.tir.BufferRealize)
            if isinstance(body.body, tvm.tir.SeqStmt):
                parsing_body = body.body[0]
                pending_body = body.body[1]
            else:
                parsing_body = body.body
                pending_body = None

            #print(hash(body.buffer), body.bounds, body.condition)
            #test_body = parsing_body
            #print(type(test_body), "\n", test_body)
            #print(type(test_body.value), test_body.value.in_shape, test_body.value.out_shape)

            assert isinstance(parsing_body, tvm.tir.AttrStmt)
            loop_body = parsing_body.body

            op_num = 0
            if _match_pragma(parsing_body, env.conv2d(1)) or \
                _match_pragma(parsing_body, env.scale(1)) or \
                _match_pragma(parsing_body, env.dense(1)) or \
                _match_pragma(parsing_body, env.eltwiseadd(1)) or \
                _match_pragma(parsing_body, env.pool2d(1)) or \
                _match_pragma(parsing_body, env.upsample(1)) or \
                _match_pragma(parsing_body, env.gap(1)):

                op_num, operator = ParsingNPUSpecialStmt2Dict(loop_body, buffer_map)
            elif _match_pragma(parsing_body, env.concat(1)):
                op_num, operator = ParsingNPUConcatStmt2Dict(loop_body, buffer_map)
            elif _match_pragma(parsing_body, env.split(1)):
                op_num, operator = ParsingNPUSplitStmt2Dict(parsing_body, buffer_map)
            elif _match_pragma(parsing_body, env.neg(1)) or \
                 _match_pragma(parsing_body, env.transpose(1)) or \
                 _match_pragma(parsing_body, env.tile(1)) or \
                 _match_pragma(parsing_body, env.space_to_depth(1)) or \
                 _match_pragma(parsing_body, env.depth_to_space(1)) or \
                 _match_pragma(parsing_body, env.lut(1)) or \
                 _match_pragma(parsing_body, env.clip(1)) or \
                 _match_pragma(parsing_body, env.yuv2rgb(1)) or \
                 _match_pragma(parsing_body, env.strided_slice(1)) or \
                 _match_pragma(parsing_body, env.channel_shuffle(1)) or \
                 _match_pragma(parsing_body, env.test_load(1)) or \
                 _match_pragma(parsing_body, env.test_store(1)) or \
                 _match_pragma(parsing_body, env.batch_to_space_nd(1)) or \
                 _match_pragma(parsing_body, env.space_to_batch_nd(1)) or \
                 _match_pragma(parsing_body, env.matmul(1)) or \
                 _match_pragma(parsing_body, env.reduce_mean(1)):
                op_num, operator = ParsingNPUGeneralStmt2Dict(parsing_body, buffer_map)

            graph_dict["op_num"] += op_num
            for i in range(op_num):
                graph_dict["op_lists"].append(operator[i])

            if pending_body is not None:
                if isinstance(pending_body, tvm.tir.AttrStmt):
                    pending_body = pending_body.body
                _prim_body_recursive(pending_body, buffer_map, graph_dict)
        def _update_graph_connection(graph_json, buffer_map):
            assert graph_json["op_num"] > 0
            for i in range(graph_json["op_num"]):
                operator = graph_json["op_lists"][i]

                # find graph_output
                output_list = []
                for j in range(len(operator["out_tensors"])):
                    out_tensor = operator["out_tensors"][j]
                    if out_tensor in buffer_map:
                        graph_json["output"].append([i, j])

                # get inner connection
                for j in range(len(operator["out_tensors"])):
                    out_tensor = operator["out_tensors"][j]
                    for k in range(graph_json["op_num"]):
                        in_tensors = graph_json["op_lists"][k]["in_tensors"]
                        for m in range(len(in_tensors)):
                            if out_tensor == in_tensors[m]:
                                operator["output"].append([j, k, m])
                    if out_tensor in buffer_map:
                        operator["output"].append([j, -1])

            # remove in/out tensor
            #for i in range(graph_json["op_num"]):
            #    del graph_json["op_lists"][i]["in_tensors"]
            #    del graph_json["op_lists"][i]["out_tensors"]

            # update op type kind num
            type_dict = dict()
            for i in range(graph_json["op_num"]):
                op_type = graph_json["op_lists"][i]["op_type"]
                type_dict[op_type] = 0
            graph_json["op_kind"] = len(type_dict)
            return graph_json

        # import pdb; pdb.set_trace()
        extern_buffer_map = list()
        for key, value in func.buffer_map.items():
            extern_buffer_map.append(value)

        unique_id, opt_config, realize_body = _get_tiling_config(func.body)
        _prim_body_recursive(realize_body, extern_buffer_map, graph_json)
        graph_json = _update_graph_connection(graph_json, extern_buffer_map)
        graph_json["unique_id"]  = unique_id
        graph_json["opt_config"] = opt_config

        new_stmt = GenerateNPUStmt(graph_json)

        irb = tvm.tir.ir_builder.create()
        irb.scope_attr(
            env.dev.xmnpu_axis, "coproc_scope", env.dev.get_task_qid(0)
        )
        #irb.scope_attr(
        #    env.dev.xmnpu_axis, "coproc_uop_scope", env.dev.xmnpu_verify_op
        #)
        irb.emit(new_stmt)
        new_stmt = irb.get()

        new_prim_func = tvm.tir.PrimFunc(
            func.params,
            new_stmt,
            func.ret_type,
            func.buffer_map,
            func.preflattened_buffer_map,
            func.attrs,
            func.span
        )
        #print(new_prim_func)
        return new_prim_func
    return tvm.tir.transform.prim_func_pass(
        _ftransform, opt_level=0, name="tir.xmnpu.InjectNPUIntrin"
    )


