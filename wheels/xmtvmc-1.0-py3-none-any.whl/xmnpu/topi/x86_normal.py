# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
# pylint: disable=unused-argument
"""The register functions for the QNN dialect."""

import numpy as np

import tvm.ir
from tvm import topi
from ..relay.register import *
from tvm.relay.op import op as _op
from tvm.relay.op import OpPattern
from tvm.topi.nn.utils import get_pad_tuple
from tvm.relay.op.nn.utils import get_pad_tuple2d
from tvm.topi.utils import get_const_tuple
from tvm.target import generic_func, override_native_generic_func
from tvm.relay.op.strategy.generic import *

from xmnpu.environment import get_env
env = get_env()


################################################
#Single OP
################################################
def xm_schedule(outs):
    """Create schedule for tensors"""
    outs = [outs] if isinstance(outs, te.tensor.Tensor) else outs
    s = te.create_schedule([x.op for x in outs])
    return s

def xm_lut_compute(input, table, o_dtype):
    ret = te.compute(input.shape, lambda *idx: table[input[idx]])
    return topi.cast(ret, o_dtype)

def xm_relu_compute(data):
    return topi.nn.relu(data)

def xm_conv2d_compute(data, kernel, bias, quant_coeff, quant_mode, zero_point,
            strides, padding, dilation, ins, using_bias, relu_type, groups,
            out_dtype, unique_id=0, opt_config=0):
    i_zp, k_zp, o_zp = zero_point
    data_original   = topi.subtract(data, i_zp)
    kernel_original = topi.subtract(kernel, k_zp)

    s_n,  s_ic, s_ih, s_iw = get_const_tuple(data.shape)
    s_oc, s_kc, s_kh, s_kw = get_const_tuple(kernel.shape)
    pad_t, pad_l, pad_b, pad_r = get_pad_tuple2d(padding)
    assert ins[0] == 0 and ins[1] == 0
    dilation_h, dilation_w = (
        dilation if isinstance(dilation, (tuple, list)) else (dilation, dilation)
    )
    stride_h, stride_w = strides if isinstance(strides, (tuple, list)) else (strides, strides)
    dilated_kernel_h = (s_kh - 1) * dilation_h + 1
    dilated_kernel_w = (s_kw - 1) * dilation_w + 1
    s_oh = (s_ih + pad_t + pad_b - dilated_kernel_h) // stride_h + 1
    s_ow = (s_iw + pad_l + pad_r - dilated_kernel_w) // stride_w + 1
    oshape = (s_n, s_oc, s_oh, s_ow)

    pad_data = topi.nn.pad(data_original, [0, 0, pad_t, pad_l], [0, 0, pad_b, pad_r], name="pad_data")
    kh = te.reduce_axis((0, s_kh), name="kh")
    kw = te.reduce_axis((0, s_kw), name="kw")

    if groups == s_oc and s_oc == s_ic:      # depthwise
        res = te.compute(
            oshape,
            lambda n_o, c_o, h_o, w_o: te.sum(
                pad_data[n_o, c_o, h_o * stride_h + kh, w_o * stride_w + kw].astype("int32")
                * kernel_original[c_o, 0, kh, kw].astype("int32"),
                axis=[kh, kw],
            ),
            name="depthwise",
            tag="depthwise",
        )
    elif groups != 1:
        ic_group = s_ic // groups
        oc_group = s_oc // groups

        data_shape = (groups, s_n, s_kc, s_ih + pad_t + pad_b, 1, s_iw + pad_l + pad_r)
        data_vec = te.compute(
            data_shape,
            lambda g, n, C, h, c, w: pad_data[n, C + c + s_kc * g, h, w],
            name="data_vec",
        )

        # pack kernel
        kernel_shape = (groups, oc_group, s_kc, s_kh, s_kw, 1, 1)
        kernel_vec = te.compute(
            kernel_shape,
            lambda g, out_channel, in_channel, h, w, ci, co: kernel_original[
                (out_channel + co + g * oc_group), in_channel + ci, h, w],
            name="kernel_vec",
        )

        g_oshape = (groups, s_n, oc_group, s_oh, s_ow, 1)
        ic = te.reduce_axis((0, s_kc), name="kernel_depth")
        idxmod = tvm.tir.indexmod
        idxdiv = tvm.tir.indexdiv
        conv = te.compute(
            g_oshape,
            lambda g, n, oc_chunk, oh, ow, oc_block: te.sum(
                data_vec[g, n, ic, oh * stride_h + kh * dilation_h, 0, ow * stride_w + kw * dilation_w].astype("int32")
                * kernel_vec[g, oc_chunk, ic, kh, kw, 0, oc_block].astype("int32"),
                axis=[ic, kh, kw],
            ),
            name="group_conv2d",
        )

        res = te.compute(
            oshape,
            lambda n, c, h, w: conv[
                idxdiv(c, oc_group),
                n,
                idxmod(c, oc_group),
                h,
                w,
                0,
            ].astype("int32"),
            name="output_unpack",
            tag="group_conv2d_nchw",
        )
    else:
        assert s_ic == s_kc
        ic = te.reduce_axis((0, s_ic), name="ic")
        res = te.compute(
            oshape,
            lambda n_o, c_o, h_o, w_o: te.sum(
                pad_data[n_o, ic, h_o * stride_h + kh, w_o * stride_w + kw].astype("int32")
                * kernel_original[c_o, ic, kh, kw].astype("int32"),
                axis=[ic, kh, kw],
            ),
            name="conv2d",
            tag="conv2d",
        ) 
    #res = topi.x86.conv2d_nchw(data, kernel, strides, padding, dilation, out_dtype)

    if using_bias:
        assert len(bias.shape) == 1
        real_bias = bias
        if quant_mode == 2:
            # get real bias
            real_bias = topi.right_shift(bias, 6)
        real_bias = topi.reshape(real_bias, (1, bias.shape[0], 1, 1))
        res       = topi.add(res, real_bias)

    if isinstance(quant_coeff, (tuple, list)):
        quant_coeff = np.array(quant_coeff)

    if quant_mode == 0:
        # mul + shift quantization
        assert quant_coeff.ndim     == 2
        assert quant_coeff.shape[1] == 1
        res = topi.fixed_point_quantize(
                        res,
                        quant_coeff[0][0],
                        quant_coeff[1][0])
    elif quant_mode == 1:
        # m for shift quantization
        res = topi.fixed_point_quantize(res, 1, quant_coeff[0])
    elif quant_mode == 2:
        # per - channel for shift
        rshift    = topi.bitwise_and(bias, 0x3F)

        mask      = topi.left_shift(1, rshift) - 1
        mask      = topi.reshape(mask, (1, bias.shape[0], 1, 1))
        remainder = topi.bitwise_and(res, mask)
        threshold = te.compute(
            oshape,
            lambda n_o, c_o, h_o, w_o:
                tvm.tir.Select(
                        res[n_o, c_o, h_o, w_o] > 0,
                        0, 1)
        )
        threshold = threshold + topi.right_shift(mask, 1)
        rounding_value = te.compute(
            oshape,
            lambda n_o, c_o, h_o, w_o:
                tvm.tir.Select(
                    remainder[n_o, c_o, h_o, w_o] > threshold[n_o, c_o, h_o, w_o],
                    1, 0)
        )

        res = te.compute(
            oshape,
            lambda n_o, c_o, h_o, w_o:
                res[n_o, c_o, h_o, w_o] >> rshift[c_o],
        )
        res = res + rounding_value
    else:
        # unsupport
        assert 0

    # relu
    if relu_type == 1:
        res = topi.nn.relu(res)
    elif relu_type == 2:
        res = topi.nn.npu_leaky_relu(res, 26)   # 0.1 = 26/256
    elif relu_type == 3:
        res = topi.nn.npu_leaky_relu(res, 3)    # 0.01 = 3/256

    res = topi.add(res, o_zp)
    if out_dtype == "int8":
        res = topi.maximum(res, -128)
        res = topi.minimum(res, 127)
    else:
        res = topi.maximum(res, 0)
        res = topi.minimum(res, 255)
    res = topi.cast(res, out_dtype)

    return res

def xm_pool2d_compute(data, zero_point, pool_size, strides, padding, pool_type,
            unique_id=0, opt_config=0):
    compute_as_npu = True  # compute way same as npu(True) or qnn(False)
    i_zp, o_zp = zero_point
    i_dtype = data.dtype
    s_n, s_ic, s_ih, s_iw = get_const_tuple(data.shape)
    pad_t, pad_l, pad_b, pad_r = get_pad_tuple2d(padding)
    s_kh, s_kw = (
        pool_size if isinstance(pool_size, (tuple, list)) else (pool_size, pool_size))
    stride_h, stride_w = strides if isinstance(strides, (tuple, list)) else (strides, strides)
    s_oh = (s_ih + pad_t + pad_b - s_kh) // stride_h + 1
    s_ow = (s_iw + pad_l + pad_r - s_kw) // stride_w + 1
    oshape = (s_n, s_ic, s_oh, s_ow)
    kh = te.reduce_axis((0, s_kh), name="kh")
    kw = te.reduce_axis((0, s_kw), name="kw")

    if compute_as_npu:
        data = topi.subtract(data, i_zp)
        if pool_type == 0: # max
            pad_value = (-128 - i_zp) if i_dtype == "int8" else (0 - i_zp)
            data = topi.nn.pad(data,
                    [0, 0, pad_t, pad_l],
                    [0, 0, pad_b, pad_r],
                    pad_value=pad_value,
                    name="pad_data")
            res = te.compute(
                oshape,
                lambda n_o, c_o, h_o, w_o: te.max(
                    data[n_o, c_o, h_o * stride_h + kh, w_o * stride_w + kw].astype("int32"),
                    axis=[kh, kw],
                ),
                name="pool2d",
                tag="pool2d",
            )
        elif pool_type == 1:  # avg
            data = topi.nn.pad(data,
                    [0, 0, pad_t, pad_l],
                    [0, 0, pad_b, pad_r],
                    pad_value=0,
                    name="pad_data")
            res = te.compute(
                oshape,
                lambda n_o, c_o, h_o, w_o: te.sum(
                    data[n_o, c_o, h_o * stride_h + kh, w_o * stride_w + kw].astype("int32"),
                    axis=[kh, kw],
                ),
                name="pool2d_sum",
                tag="pool2d_sum",
            )
            divide_factor  = s_kh * s_kw
            if divide_factor == 4:
                res = topi.fixed_point_quantize(res, 1, 2)
            elif divide_factor == 9:  #57/2^9
                res = topi.multiply(res, 57)
                res = topi.right_shift(res, 9)
            elif divide_factor > 1:
                print(pool_size, strides, pool_type)
                assert 0
        else:
            assert 0
        res = topi.add(res, o_zp)
    else:
        data = topi.subtract(data, i_zp)
        if pool_type == 0: # max
            pad_value = (-128 - i_zp) if i_dtype == "int8" else (0 - i_zp)
            data = topi.nn.pad(data,
                    [0, 0, pad_t, pad_l],
                    [0, 0, pad_b, pad_r],
                    pad_value=pad_value,
                    name="pad_data")
            res = te.compute(
                oshape,
                lambda n_o, c_o, h_o, w_o: te.max(
                    data[n_o, c_o, h_o * stride_h + kh, w_o * stride_w + kw].astype("int32"),
                    axis=[kh, kw],
                ),
                name="pool2d",
                tag="pool2d",
            )
        elif pool_type == 1:  # avg
            pad_value = 0
            data = topi.nn.pad(data,
                    [0, 0, pad_t, pad_l],
                    [0, 0, pad_b, pad_r],
                    pad_value=pad_value,
                    name="pad_data")
            res = te.compute(
                oshape,
                lambda n_o, c_o, h_o, w_o: te.sum(
                    data[n_o, c_o, h_o * stride_h + kh, w_o * stride_w + kw].astype("int32"),
                    axis=[kh, kw],
                ),
                name="pool2d_sum",
                tag="pool2d_sum",
            )
            divide_factor  = s_kh * s_kw
            rounding_value = divide_factor >> 1
            res = te.compute(
                oshape,
                lambda n_o, c_o, h_o, w_o: te.div(
                    te.if_then_else(res[n_o, c_o, h_o, w_o] > 0,
                                res[n_o, c_o, h_o, w_o] + rounding_value,
                                res[n_o, c_o, h_o, w_o] - rounding_value),
                    divide_factor,
                ),
                name="pool_div",
                tag="pool_div",
            )
        else:
            pad_value = 0 - i_zp
            assert 0
        res = topi.add(res, o_zp)

    out_dtype = i_dtype
    if out_dtype == "int8":
        res = topi.maximum(res, -128)
        res = topi.minimum(res, 127)
    else:
        res = topi.maximum(res, 0)
        res = topi.minimum(res, 255)
    res = topi.cast(res, out_dtype)

    return res

def xm_eltwiseadd_compute(lhs, rhs, lhs_quant_coeff, rhs_quant_coeff,
                      lhs_zp, rhs_zp, o_zp, unique_id=0, opt_config=0):

    lhs_original = topi.subtract(lhs, lhs_zp)
    rhs_original = topi.subtract(rhs, rhs_zp)
    if isinstance(lhs_quant_coeff, (tuple, list)):
        lhs_quant_coeff = np.array(lhs_quant_coeff)
    if isinstance(rhs_quant_coeff, (tuple, list)):
        rhs_quant_coeff = np.array(rhs_quant_coeff)
    assert len(lhs_quant_coeff) == 2
    assert len(rhs_quant_coeff) == 2
    if len(lhs_quant_coeff[0]) == 1:
        lhs_mul = topi.fixed_point_quantize(
                        lhs_original,
                        lhs_quant_coeff[0][0],
                        lhs_quant_coeff[1][0])
    else:
        #per - channel for mul+shift
        assert 0
    if len(rhs_quant_coeff[0]) == 1:
        rhs_mul = topi.fixed_point_quantize(
                        rhs_original,
                        rhs_quant_coeff[0][0],
                        rhs_quant_coeff[1][0])
    else:
        #per - channel for mul+shift
        assert 0
    if len(lhs_mul.shape) == 1:
        lhs_mul = topi.reshape(lhs_mul, (1, lhs_mul.shape[0], 1, 1))
    if len(rhs_mul.shape) == 1:
        rhs_mul = topi.reshape(rhs_mul, (1, rhs_mul.shape[0], 1, 1))
    res = topi.add(lhs_mul, rhs_mul)
    res = topi.add(res, o_zp)
    assert lhs.dtype == rhs.dtype
    out_dtype = lhs.dtype
    if out_dtype == "int8":
        res = topi.maximum(res, -128)
        res = topi.minimum(res, 127)
    else:
        res = topi.maximum(res, 0)
        res = topi.minimum(res, 255)
    res = topi.cast(res, out_dtype)

    return res

def coef_expand(coef):
    if (coef & (1 << 12)):
        return  -1 * ((1 << 13) - coef)
    return coef

def xm_yuv2rgb_compute(y_data, uv_data, input_h, input_w, input_wptch, pic_format_e,
        btfmt_e, range_e, out_dtype, input_mtype, unique_id=0, opt_config=0):
    if pic_format_e == 1:
        uv_data = topi.tile(uv_data, (2, ))
        uv_data = topi.reshape(uv_data, (input_h, input_w))

    fmtcv_coef = [
    [1024, 1437, 1812, 731, 351, 0],  # bt601 full range
    [1024, 1613, 1901, 479, 191, 0],  # bt709 full range
    [1192, 1635, 2063, 833, 399, 19], # bt601 tv range
    [1192, 1836, 2164, 546, 218, 19]  # bt709 tv range
    ]
    coef_index = range_e * 2 + btfmt_e
    cy = fmtcv_coef[coef_index][0]
    cr = fmtcv_coef[coef_index][1]
    cb = fmtcv_coef[coef_index][2]
    cg0 = fmtcv_coef[coef_index][3]
    cg1 = fmtcv_coef[coef_index][4]
    d = fmtcv_coef[coef_index][5]
    DIV_FACTOR = 1 << 10
    cy = coef_expand(cy)
    cr = coef_expand(cr)
    cb = coef_expand(cb)
    cg0 = coef_expand(cg0)
    cg1 = coef_expand(cg1)
    d = coef_expand(d)

    y = te.compute((input_h, input_w),
            lambda iw, ih: (y_data[iw, ih]), name="y")
    u = te.compute((input_h, input_w),
            lambda iw, ih: (uv_data[(2 * (iw * (input_w // 2) + (ih // 2)) + 1) // input_w,
            (2 * (iw * (input_w // 2) + (ih // 2)) + 1) % input_w]), name="u")
    v = te.compute((input_h, input_w),
            lambda iw, ih: (uv_data[(2 * (iw * (input_w // 2) + (ih // 2))) // input_w,
            (2 * (iw * (input_w // 2) + (ih // 2))) % input_w]), name="v")

    r = cy * y + cr * (v - 128)
    r += topi.sign(r) * (DIV_FACTOR >> 1)
    r = topi.subtract(topi.divide(r, DIV_FACTOR), d)

    g = cy * y - cg1 * (u - 128) - cg0 * (v - 128)
    g += topi.sign(g) * (DIV_FACTOR >> 1)
    g = topi.subtract(topi.divide(g, DIV_FACTOR), d)

    b = cy * y + cb * (u - 128)
    b += topi.sign(b) * (DIV_FACTOR >> 1)
    b = topi.subtract(topi.divide(b, DIV_FACTOR), d)

    r = topi.reshape(r, (1, input_h, input_w))
    g = topi.reshape(g, (1, input_h, input_w))
    b = topi.reshape(b, (1, input_h, input_w))

    res = topi.concatenate((r, g, b), axis=0)
    res = topi.expand_dims(res,0)
    res = topi.minimum(topi.maximum(res, 0), 255)
    res = topi.cast(res, out_dtype)

    return res

def xm_scale_compute(data, kernel, bias, quant_coeff, quant_mode, zero_point,
            using_bias, relu_type, out_dtype, unique_id=0, opt_config=0):
    i_zp, k_zp, o_zp = zero_point
    data_original   = topi.subtract(data, i_zp)
    kernel_original = topi.subtract(kernel, k_zp)

    kernel_original = topi.reshape(kernel_original, (1, kernel_original.shape[0], 1, 1))
    res = topi.multiply(data_original, kernel_original)

    if using_bias:
        assert len(bias.shape) == 1
        bias = topi.reshape(bias, (1, bias.shape[0], 1, 1))
        res = topi.add(res, bias)

    if isinstance(quant_coeff, (tuple, list)):
        quant_coeff = np.array(quant_coeff)
    if len(quant_coeff) == 2:
        # mul+shift quantization
        if len(quant_coeff[0]) == 1 and quant_mode == 0:
            res = topi.fixed_point_quantize(
                          res,
                          quant_coeff[0][0],
                          quant_coeff[1][0])
        else:
            #per - channel for mul+shift
            assert 0
    else:
        # m for shift quantization
        assert 0
        res = topi.fixed_point_quantize(res, 1, quant_coeff[0])

    # relu
    if relu_type == 1:
        res = topi.nn.relu(res)
    elif relu_type == 2:
        res = topi.nn.npu_leaky_relu(res, 26)   # 0.1 = 26/256
    elif relu_type == 3:
        res = topi.nn.npu_leaky_relu(res, 3)    # 0.01 = 3/256

    res = topi.add(res, o_zp)
    if out_dtype == "int8":
        res = topi.maximum(res, -128)
        res = topi.minimum(res, 127)
    else:
        res = topi.maximum(res, 0)
        res = topi.minimum(res, 255)
    res = topi.cast(res, out_dtype)
    return res

def xm_dense_compute(data, kernel, bias, quant_coeff, quant_mode, zero_point,
            using_bias, out_dtype, unique_id=0, opt_config=0):
    i_zp, k_zp, o_zp = zero_point
    if len(data.shape) == 4:
        s_n,  s_ic, s_ih, s_iw = get_const_tuple(data.shape)
    else:
        s_n,  s_ic = get_const_tuple(data.shape)
        s_ih = s_iw = 1
    s_oc, s_kc = get_const_tuple(kernel.shape)
    oshape = (s_n, s_oc)
    data_original   = topi.subtract(data, i_zp)
    kernel_original = topi.subtract(kernel, k_zp)


    assert s_ic * s_ih * s_iw == s_kc
    if len(data.shape) == 4:
        ic = te.reduce_axis((0, s_ic), name="ic")
        ih = te.reduce_axis((0, s_ih), name="ih")
        iw = te.reduce_axis((0, s_iw), name="iw")
        res = te.compute(
            oshape,
            lambda n_o, c_o: te.sum(
                data_original[n_o, ic, ih, iw].astype("int32")
                * kernel_original[c_o, ic * s_ih * s_iw + ih * s_iw + iw].astype("int32"),
                axis=[ic, ih, iw],
            ),
            name="dense",
            tag="dense",
        )
    else:
        ic = te.reduce_axis((0, s_ic), name="ic")
        res = te.compute(
            oshape,
            lambda n_o, c_o: te.sum(
                data_original[n_o, ic].astype("int32")
                * kernel_original[c_o, ic].astype("int32"),
                axis=[ic],
            ),
            name="dense",
            tag="dense",
        )

    #res = topi.x86.conv2d_nchw(data, kernel, strides, padding, dilation, out_dtype)

    if using_bias:
        assert len(bias.shape) == 1
        bias = topi.reshape(bias, (1, bias.shape[0]))
        res = topi.add(res, bias)

    if len(quant_coeff) == 2:
        # mul+shift quantization
        if len(quant_coeff[0]) == 1 and quant_mode == 0:
            res = topi.fixed_point_quantize(
                          res,
                          quant_coeff[0][0],
                          quant_coeff[1][0])
        else:
            #per - channel for mul+shift
            assert 0
    else:
        # m for shift quantization
        assert 0
        res = topi.fixed_point_quantize(res, 1, quant_coeff[0])

    res = topi.add(res, o_zp)
    if out_dtype == "int8":
        res = topi.maximum(res, -128)
        res = topi.minimum(res, 127)
    else:
        res = topi.maximum(res, 0)
        res = topi.minimum(res, 255)
    res = topi.cast(res, out_dtype)

    return res

def xm_global_avg_pool2d_compute(data, zero_point, pool_size, unique_id=0, opt_config=0):
    i_zp, o_zp = zero_point
    s_n, s_ic, s_ih, s_iw = get_const_tuple(data.shape)
    s_kh, s_kw = (
        pool_size if isinstance(pool_size, (tuple, list)) else (pool_size, pool_size))
    assert s_kh <= s_ih and s_kw <= s_iw
    oshape = (s_n, s_ic, 1, 1)

    # pool size may < data.shape size
    kh = te.reduce_axis((0, s_kh), name="kh")
    kw = te.reduce_axis((0, s_kw), name="kw")

    data_original = topi.subtract(data, i_zp)
    res = te.compute(
        oshape,
        lambda n_o, c_o, h_o, w_o: te.sum(
            data_original[n_o, c_o, kh, kw].astype("int32"),
            axis=[kh, kw],
        ),
        name="pool_sum",
        tag="pool_sum",
    )
    divide_factor  = s_kh * s_kw
    rounding_value = divide_factor >> 1
    res = te.compute(
        oshape,
        lambda n_o, c_o, h_o, w_o: te.div(
            te.if_then_else(res[n_o, c_o, h_o, w_o] > 0,
                           res[n_o, c_o, h_o, w_o] + rounding_value,
                           res[n_o, c_o, h_o, w_o] - rounding_value),
            divide_factor,
        ),
        name="pool_div",
        tag="pool_div",
    )

    res = topi.add(res, o_zp)
    out_dtype = data.dtype
    if out_dtype == "int8":
        res = topi.maximum(res, -128)
        res = topi.minimum(res, 127)
    else:
        res = topi.maximum(res, 0)
        res = topi.minimum(res, 255)
    res = topi.cast(res, out_dtype)

    return res

def xm_concat_compute(inputs, axis):
    assert len(inputs)  >= 2
    assert len(inputs[0].shape)  == 4

    res = topi.concatenate(inputs, axis)
    return res

def xm_tile_compute(inputs, reps):

    res = topi.tile(inputs, reps)
    return res

def xm_upsample_compute(input, scale_h, scale_w, unique_id=0, opt_config=0):
    res = topi.nn.upsampling(input, scale_h, scale_w)
    return res

def xm_neg_compute(inputs, o_dtype="int8"):
    inputs_i32 = topi.cast(inputs, "int32")
    res = topi.negative(inputs_i32)
    res = topi.cast(res, o_dtype)
    return res

def xm_transpose_compute(data, axes):
    assert len(data.shape) == 4
    #each element in axes [0,4)
    for v in axes:
        assert (int(v) >= 0 and int(v) < len(data.shape))
    #axes all elements must be not equal
    assert len(list(set(axes))) == len(axes)
    res = topi.transpose(data, axes)
    return res

def xm_strided_slice_compute(data, start_index, end_index, strides):
    assert len(data.shape) == 4
    assert (len(start_index) == len(end_index) == len(strides))
    for i in range(len(start_index)):
        assert start_index[i] < end_index[i]
        assert (start_index[i] >= 0 and start_index[i] < data.shape[i])
        assert (end_index[i] > 0 and end_index[i] <= data.shape[i])
        assert strides[i] > 0
    res = topi.strided_slice(data, start_index, end_index, strides)
    return res

def xm_crop_compute(data, out_shape, axis, offset):
    assert len(data.shape) == len(out_shape)
    assert isinstance(offset, (int, list, tuple))
    assert (axis >= 0 and axis < len(data.shape))
    slice_start = [0] * len(data.shape)
    import copy
    slice_end = copy.deepcopy(out_shape)
    for i in range(len(data.shape)):
        if i >= axis:
            if isinstance(offset, int):
                slice_start[i] = offset
            elif isinstance(offset, (list, tuple)):
                slice_start[i] = offset[i - axis]
            slice_end[i] = slice_start[i] + out_shape[i]
    res = topi.strided_slice(data, slice_start, slice_end)
    return res

def xm_channel_shuffle_compute(data, group, axes):
    assert len(data.shape) == 4
    assert group >= 2
    c_per_group = data.shape[1] // group
    new_data = topi.reshape(data, [data.shape[0], group, c_per_group, \
        data.shape[2], data.shape[3]])
    new_data = topi.transpose(new_data, axes)
    res = topi.reshape(new_data, data.shape)
    return res

def xm_space_to_depth_compute(data, block_size, layout):
    res = topi.nn.space_to_depth(data, block_size, layout)
    return res

def xm_depth_to_space_compute(data, block_size, layout, mode):
    res = topi.nn.depth_to_space(data, block_size, layout, mode)
    return res

def xm_batch_to_space_nd_compute(data, block_shape, crop_begin_list, crop_end_list):
    res = topi.nn.batch_to_space_nd(data, block_shape, crop_begin_list, crop_end_list)
    return res

def xm_space_to_batch_nd_compute(data, block_shape, pad_before, pad_after):
    res = topi.nn.space_to_batch_nd(data, block_shape, pad_before, pad_after)
    return res

def xm_split_compute(data, array_len, split_idx, axis):
    res = topi.split(data, split_idx, axis)
    return res

def xm_clip_compute(data, a_min, a_max):
    res = topi.clip(data, a_min, a_max)
    return res

def xm_matmul_compute(input_1, input_2, oshape, out_dtype, trans_a, trans_b, 
                        i1_zp, i2_zp, o_zp, quant_mode, f_multiplier, quant_coeff):
    input_1 = topi.subtract(input_1, i1_zp)
    input_2 = topi.subtract(input_2, i2_zp) 
    res = topi.nn.batch_matmul(input_1, input_2, oshape, "int32", trans_a, trans_b)
    if len(quant_coeff) == 2:
        if len(quant_coeff[0]) == 1 and quant_mode == 0:
            res = topi.fixed_point_quantize(
                          res,
                          quant_coeff[0][0],
                          quant_coeff[1][0])
        else:
            assert 0
    else:
        assert 0
        res = topi.fixed_point_quantize(res, 1, quant_coeff[0])
    res = topi.add(res, o_zp)
    if out_dtype == "int8":
        res = topi.maximum(res, -128)
        res = topi.minimum(res, 127)
    else:
        res = topi.maximum(res, 0)
        res = topi.minimum(res, 255)
    res = topi.cast(res, out_dtype)
    return res

def xm_reduce_mean_compute(data, axis):
    n, c, h, w = get_const_tuple(data.shape)
    if axis[1] == 0:
        res = topi.sum(data.astype("int32"), axis, keepdims=True)
        res = topi.divide(res, w)
    else:
        res = topi.sum(data.astype("int32"), axis, keepdims=True)
        res = topi.divide(res, h * w)
    return res

def xm_leaky_relu_compute(data, alpha):
    return topi.nn.leaky_relu(data, alpha)

def xm_relu6_compute(data):
    res = topi.nn.relu(data)
    return topi.minimum(res, 6)

def xm_swish_compute(data, alpha):
    res = topi.divide(data, (1 + topi.exp(-alpha * data)))
    return res

def xm_mish_compute(data):
    res = data * topi.tanh(topi.log(1 + topi.exp(data)))
    return res