# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

# pylint: disable=redefined-builtin, wildcard-import
"""TVM Operator Inventory.

TOPI is the operator collection library for TVM, to provide sugars
for constructing compute declaration as well as optimized schedules.

Some of the schedule function may have been specially optimized for a
specific workload.
"""
from tvm._ffi.libinfo import __version__

# Ensure C++ schedules get registered first, so python schedules can
# override them.
#from tvm.topi import cpp


from . import x86_strategy
from . import x86_normal
from . import x86_tiling
from . import xmnpu_strategy
from . import tir
from .topi import *
from .xmnpu_normalop import compute_conv2d, schedule_conv2d
from .xmnpu_normalop import compute_pool2d, schedule_pool2d
from .xmnpu_normalop import compute_gap, schedule_gap
from .xmnpu_normalop import compute_dense, schedule_dense
from .xmnpu_normalop import compute_upsample, schedule_upsample
from .xmnpu_normalop import compute_eltwiseadd, schedule_eltwiseadd
from .xmnpu_normalop import compute_yuv2rgb, schedule_yuv2rgb
from .xmnpu_normalop import compute_concat, schedule_concat
from .xmnpu_normalop import compute_scale, schedule_scale
from .xmnpu_normalop import compute_lut, schedule_lut
from .xmnpu_normalop import compute_tile, schedule_tile
from .xmnpu_normalop import compute_space_to_depth, schedule_space_to_depth
from .xmnpu_normalop import compute_depth_to_space, schedule_depth_to_space
from .xmnpu_normalop import compute_batch_to_space_nd, schedule_batch_to_space_nd
from .xmnpu_normalop import compute_space_to_batch_nd, schedule_space_to_batch_nd
from .xmnpu_normalop import compute_neg, schedule_neg
from .xmnpu_normalop import compute_transpose, schedule_transpose
from .xmnpu_normalop import compute_strided_slice, schedule_strided_slice
from .xmnpu_normalop import compute_crop, schedule_crop
from .xmnpu_normalop import compute_clip, schedule_clip
from .xmnpu_normalop import compute_split, schedule_split
from .xmnpu_normalop import compute_channel_shuffle, schedule_channel_shuffle
from .xmnpu_normalop import compute_matmul, schedule_matmul
from .xmnpu_normalop import compute_reduce_mean, schedule_reduce_mean

from .xmnpu_tilingop import compute_1conv2d, schedule_1conv2d
from .xmnpu_tilingop import compute_conv2dupsp, schedule_conv2dupsp
from .xmnpu_tilingop import compute_2conv2d, schedule_2conv2d
from .xmnpu_tilingop import compute_2conv2dupsp, schedule_2conv2dupsp
from .xmnpu_tilingop import compute_3conv2d, schedule_3conv2d
from .xmnpu_tilingop import compute_3conv2d_concat, schedule_3conv2d_concat
from .xmnpu_tilingop import compute_4conv2d_concat, schedule_4conv2d_concat
from .xmnpu_tilingop import compute_4conv2d, schedule_4conv2d
from .xmnpu_tilingop import compute_conv2d_pool2d_2conv2d, schedule_conv2d_pool2d_2conv2d
from .xmnpu_tilingop import compute_conv2d_dw_conv2d_add, schedule_conv2d_dw_conv2d_add
from .xmnpu_tilingop import compute_conv2d_dw_conv2d, schedule_conv2d_dw_conv2d
from .xmnpu_tilingop import compute_3conv2d_add, schedule_3conv2d_add
from .xmnpu_tilingop import compute_4conv2d_eltadd, schedule_4conv2d_eltadd
from .xmnpu_tilingop import compute_3pool_concat, schedule_3pool_concat
from .xmnpu_tilingop import compute_3conv2d_pool_add, schedule_3conv2d_pool_add
from .xmnpu_tilingop import compute_dw_2conv2d_dw_conv2d_concat, schedule_dw_2conv2d_dw_conv2d_concat
from .xmnpu_tilingop import compute_4conv2d_pool_concat, schedule_4conv2d_pool_concat
from .xmnpu_tilingop import compute_dwconv2d, schedule_dwconv2d
from .xmnpu_tilingop import compute_3dwconvconv_concat, schedule_3dwconvconv_concat
from .xmnpu_tilingop import compute_2conv2d_add, schedule_2conv2d_add
from .xmnpu_tilingop import compute_4dwtripleconv2d_add, schedule_4dwtripleconv2d_add
from .xmnpu_tilingop import compute_3conv2d_eltadd_type2, schedule_3conv2d_eltadd_type2
from .xmnpu_tilingop import compute_4dwtripleconv2d_lpool_add, schedule_4dwtripleconv2d_lpool_add
from .xmnpu_tilingop import compute_3dwdoubleconv2d_add, schedule_3dwdoubleconv2d_add
from .xmnpu_tilingop import compute_3spconvdwconv_concat, schedule_3spconvdwconv_concat

# not import testing by default
# because testing can have extra deps that are not necessary
# we can import them from test cases explicitly
# from . import testing
