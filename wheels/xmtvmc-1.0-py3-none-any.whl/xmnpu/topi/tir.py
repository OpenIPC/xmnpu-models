# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
# pylint: disable=redefined-builtin
"""TIR expression nodes.

Each expression node have subfields that can be visited from python side.
For example, you can use addexp.a to get the left operand of an Add node.

.. code-block:: python

  x = tvm.tir.Var("n", "int32")
  y = x + 2
  assert(isinstance(y, tvm.tir.Add))
  assert(y.a == x)
"""
import tvm._ffi

import tvm.ir._ffi_api
from . import _ffi_api
from tvm.tir import generic as _generic
from tvm.ir import PrimExpr, Op

class ExprOp(object):
    def __nonzero__(self):
        raise ValueError(
            "Cannot use "
        )

    def __bool__(self):
        return self.__nonzero__()

    def equal(self, other, span=None):
        """Build an equal check expression with other expr.

        Parameters
        ----------
        other : PrimExpr
            The other expression

        span : Optional[Span]
            The location of the cast in the source.

        Returns
        -------
        ret : PrimExpr
            The equality expression.
        """
        return _ffi_api._OpEQ(self, other, span)

    def astype(self, dtype, span=None):
        """Cast the expression to other type.

        Parameters
        ----------
        dtype : str
            The type of new expression

        span : Optional[Span]
            The location of the cast in the source.

        Returns
        -------
        expr : PrimExpr
            Expression with new type
        """
        return _generic.cast(self, dtype, span)


class PrimExprWithOp(ExprOp, PrimExpr):
    """Helper base class to inherit from PrimExpr."""

    # In Python3, We have to explicitly tell interpreter to retain __hash__ if we overide __eq__
    # https://docs.python.org/3.1/reference/datamodel.html#object.__hash__
    __hash__ = PrimExpr.__hash__

@tvm._ffi.register_object("tir.XMEltwiseAdd")
class XMEltwiseAdd(PrimExprWithOp):
    """Add node.

    Parameters
    ----------
    a : PrimExpr
        The left hand operand.

    b : PrimExpr
        The right hand operand.

    span : Optional[Span]
        The location of this itervar in the source code.
    """

    def __init__(self,
                lhs,
                rhs,
                lhs_mul,
                lhs_shift,
                rhs_mul,
                rhs_shift,
                lhs_zp,
                rhs_zp,
                out_zp,
                span=None):
        self.__init_handle_by_constructor__(
                        _ffi_api.XMEltwiseAdd,
                        lhs,
                        rhs,
                        lhs_mul,
                        lhs_shift,
                        rhs_mul,
                        rhs_shift,
                        lhs_zp,
                        rhs_zp,
                        out_zp,
                        span)


@tvm._ffi.register_object("tir.XMConv2d")
class XMConv2d(PrimExprWithOp):
    def __init__(self,
                data,
                kernel,
                bias,
                multiplier,
                right_shift,
                quant_mode,
                i_zp,
                k_zp,
                o_zp,
                kh,
                kw,
                kh_stride,
                kw_stride,
                pad_h_t,
                pad_h_b,
                pad_w_l,
                pad_w_r,
                dilation_h,
                dilation_w,
                ins_h,
                ins_w,
                using_bias,
                relu_type,
                groups,
                in_shape=None,
                out_shape=None,
                out_dtype=None,
                span=None):
        self.__init_handle_by_constructor__(
                        _ffi_api.XMConv2d,
                        data,
                        kernel,
                        bias,
                        multiplier,
                        right_shift,
                        quant_mode,
                        i_zp,
                        k_zp,
                        o_zp,
                        kh,
                        kw,
                        kh_stride,
                        kw_stride,
                        pad_h_t,
                        pad_h_b,
                        pad_w_l,
                        pad_w_r,
                        dilation_h,
                        dilation_w,
                        ins_h,
                        ins_w,
                        using_bias,
                        relu_type,
                        groups,
                        in_shape,
                        out_shape,
                        out_dtype,
                        span)



@tvm._ffi.register_object("tir.XMScale")
class XMScale(PrimExprWithOp):
    def __init__(self,
                data,
                kernel,
                bias,
                multiplier,
                right_shift,
                quant_mode,
                i_zp,
                k_zp,
                o_zp,
                using_bias,
                relu_type,
                shape=None,
                out_dtype=None,
                span=None):
        self.__init_handle_by_constructor__(
                        _ffi_api.XMScale,
                        data,
                        kernel,
                        bias,
                        multiplier,
                        right_shift,
                        quant_mode,
                        i_zp,
                        k_zp,
                        o_zp,
                        using_bias,
                        relu_type,
                        shape,
                        out_dtype,
                        span)


@tvm._ffi.register_object("tir.XMDense")
class XMDense(PrimExprWithOp):
    def __init__(self,
                data,
                kernel,
                bias,
                multiplier,
                right_shift,
                quant_mode,
                i_zp,
                k_zp,
                o_zp,
                using_bias,
                out_dtype,
                span=None):
        self.__init_handle_by_constructor__(
                        _ffi_api.XMDense,
                        data,
                        kernel,
                        bias,
                        multiplier,
                        right_shift,
                        quant_mode,
                        i_zp,
                        k_zp,
                        o_zp,
                        using_bias,
                        out_dtype,
                        span)

@tvm._ffi.register_object("tir.XMPool2d")
class XMPool2d(PrimExprWithOp):
    def __init__(self,
                data,
                zero_point,
                kh,
                kw,
                kh_stride,
                kw_stride,
                pad_h_t,
                pad_h_b,
                pad_w_l,
                pad_w_r,
                pool_type,
                in_shape=None,
                out_shape=None,
                span=None):
        self.__init_handle_by_constructor__(
                        _ffi_api.XMPool2d,
                        data,
                        zero_point,
                        kh,
                        kw,
                        kh_stride,
                        kw_stride,
                        pad_h_t,
                        pad_h_b,
                        pad_w_l,
                        pad_w_r,
                        pool_type,
                        in_shape,
                        out_shape,
                        span)

@tvm._ffi.register_object("tir.XMGlobalAvgPool2d")
class XMGlobalAvgPool2d(PrimExprWithOp):
    def __init__(self,
                data,
                zero_point,
                kh,
                kw,
                span=None):
        self.__init_handle_by_constructor__(
                        _ffi_api.XMGlobalAvgPool2d,
                        data,
                        zero_point,
                        kh,
                        kw,
                        span)

@tvm._ffi.register_object("tir.XMConcat")
class XMConcat(PrimExprWithOp):
    def __init__(self,
                a_tuple,
                axis,
                span=None):
        self.__init_handle_by_constructor__(
                        _ffi_api.XMConcat,
                        a_tuple,
                        axis,
                        span)

@tvm._ffi.register_object("tir.XMUpsample")
class XMUpsample(PrimExprWithOp):
    def __init__(self,
                data,
                scale_h,
                scale_w,
                span=None):
        self.__init_handle_by_constructor__(
                        _ffi_api.XMUpsample,
                        data,
                        scale_h,
                        scale_w,
                        span)



