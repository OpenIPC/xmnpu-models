# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

import numpy as np

import tvm
from tvm import te
from tvm import autotvm
from tvm import topi
from tvm.relay.op.nn.utils import get_pad_tuple2d

from .utils import is_packed_layout
from ..environment import get_env
import xmnpu

#from . import topi
#from . import tir

env = get_env()

def combine_new_op(op, unique_id=-1, opt_config=0):
    dtype = "int32"
    try:
        type_info = np.iinfo(dtype)
    except ValueError:
        type_info = np.finfo(dtype)
    #if (unique_id > type_info.max) or (unique_id < type_info.min):
    #    print("unique_id is overflow")
    #unique_id = np.clip(unique_id, type_info.min, type_info.max)

    unique_id = int(np.array(unique_id).astype("int32"))
    new_attrs = dict()
    new_attrs["unique_id"]  = unique_id
    new_attrs["opt_config"] = opt_config
    new_op  = tvm.te._ffi_api.ComputeOp(op.name, op.tag, new_attrs, op.axis, op.body)
    return new_op

def compute_load(input, unique_id=-1, opt_config=0):
    res = topi.cast(input, input.dtype)

    new_op = combine_new_op(res.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    res = outputs[0] if num == 1 else outputs
    return res

def schedule_load(outs):
    output = outs[0]

    s = te.create_schedule(output.op)

    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value
    s[output].npu_id_config(output.op.axis[0], unique_id, opt_config) # input

    s[output].pragma(output.op.axis[0], env.test_load(1))
    return s


def compute_store(input, unique_id=-1, opt_config=0):
    res = topi.cast(input, input.dtype)

    new_op = combine_new_op(res.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    res = outputs[0] if num == 1 else outputs
    return res


def schedule_store(outs):
    output = outs[0]

    s = te.create_schedule(output.op)

    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value
    s[output].npu_id_config(output.op.axis[0], unique_id, opt_config) # input

    s[output].pragma(output.op.axis[0], env.test_store(1))
    return s

def compute_conv2d(input, kernel, bias, quant_coeff, quant_mode = 0,
                zero_point=(0,0,0), strides=(1,1),
                padding=(0,0,0,0), dilation=(1,1), ins=(0,0),
                using_bias=1, relu_type=0, groups=1, out_dtype="uint8",
                unique_id=0, opt_config=0):

    assert len(zero_point)   == 3
    assert len(padding)      == 4
    assert len(input.shape)  == 4
    assert len(kernel.shape) == 4

    assert ins[0] == 0 and ins[1] == 0
    assert dilation[0] == 1 and dilation[1] == 1
    if using_bias:
        assert len(bias.shape)   == 1
    mul    = 1
    rshift = 0
    if quant_mode == 0:
        assert len(quant_coeff)  == 2
        mul    = quant_coeff[0][0]
        rshift = quant_coeff[1][0]
    elif quant_mode == 1:
        rshift = quant_coeff[0]
    else:
        assert quant_mode == 2

    ishape = topi.utils.get_const_tuple(input.shape)
    kshape = topi.utils.get_const_tuple(kernel.shape)
    pad_t, pad_l, pad_b, pad_r = get_pad_tuple2d(padding)
    oh = 1 + (ishape[2] + pad_t + pad_b - kshape[2]) // strides[0]
    ow = 1 + (ishape[3] + pad_l + pad_r - kshape[3]) // strides[1]
    oshape = (input.shape[0], kernel.shape[0], oh, ow)

    res = xmnpu.topi.conv2d(input, kernel, bias, mul, rshift,
            quant_mode, zero_point[0], zero_point[1], zero_point[2],
            kshape[2], kshape[3], strides[0], strides[1],
            pad_t, pad_b, pad_l, pad_r,
            dilation[0], dilation[1], ins[0], ins[1],
            using_bias, relu_type, groups,
            input.shape, oshape, out_dtype)

    new_op = combine_new_op(res.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    res = outputs[0] if num == 1 else outputs
    return res

def schedule_conv2d(outs):
    """Schedule packed conv2d"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []

    def _traverse(op):
        if op.tag == "conv2d_sum":
            reduce_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)

    conv2d_reduce = reduce_ops[0].output(0) if len(reduce_ops) else output
    conv2d_tensor = conv2d_ops[0].output(0)
    assert conv2d_tensor == output

    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value
    s[output].npu_id_config(output.op.axis[0], unique_id, opt_config) # input

    s[conv2d_reduce].compute_at(s[output], output.op.axis[3])
    s[output].pragma(output.op.axis[0], env.conv2d(1))
    return s

def compute_dense(input, kernel, bias, quant_coeff, quant_mode = 0,
                zero_point=(0,0,0), using_bias=1, out_dtype="uint8",
                unique_id=0, opt_config=0):

    assert len(zero_point)   == 3
    assert len(input.shape)  == 2 or len(input.shape) == 4
    assert len(kernel.shape) == 2
    assert len(quant_coeff)  == 2
    if using_bias:
        assert len(bias.shape)    == 1

    ishape = topi.utils.get_const_tuple(input.shape)
    kshape = topi.utils.get_const_tuple(kernel.shape)
    oshape = (input.shape[0], kernel.shape[0])

    res = xmnpu.topi.dense(input, kernel, bias,
            quant_coeff[0][0], quant_coeff[1][0], quant_mode,
            zero_point[0], zero_point[1], zero_point[2],
            using_bias, out_dtype)

    new_op = combine_new_op(res.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    res = outputs[0] if num == 1 else outputs
    return res

def schedule_dense(outs):
    """Schedule packed dense"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs = []
    reduce_ops   = []
    dense_ops    = []

    def _traverse(op):
        if op.tag == "dense_sum":
            reduce_ops.append(op)
        else:
            dense_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    dense_reduce = reduce_ops[0].output(0) if len(reduce_ops) else output
    dense_tensor = dense_ops[0].output(0)
    assert dense_tensor == output

    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value
    s[output].npu_id_config(output.op.axis[0], unique_id, opt_config) # input

    s[dense_reduce].compute_at(s[output], output.op.axis[1])
    s[output].pragma(output.op.axis[0], env.dense(1))
    return s

def compute_scale(input, kernel, bias, quant_coeff, quant_mode = 0,
                zero_point=(0,0,0), using_bias=1,
                relu_type=0, out_dtype="uint8", unique_id=0, opt_config=0):

    assert len(zero_point)   == 3
    assert len(input.shape)  == 4
    assert len(kernel.shape) == 1
    assert len(quant_coeff)  == 2
    if using_bias:
        assert len(bias.shape)   == 1

    ishape = topi.utils.get_const_tuple(input.shape)

    res = xmnpu.topi.scale(input, kernel, bias,
            quant_coeff[0][0], quant_coeff[1][0], quant_mode,
            zero_point[0], zero_point[1], zero_point[2],
            using_bias, relu_type,
            input.shape, out_dtype)

    new_op = combine_new_op(res.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    res = outputs[0] if num == 1 else outputs
    return res

def schedule_scale(outs):
    """Schedule packed scale"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs = []
    reduce_ops   = []
    scale_ops = []

    def _traverse(op):
        if "scale_sum" in op.tag:
            reduce_ops.append(op)
        else:
            scale_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value
    s[output].npu_id_config(output.op.axis[0], unique_id, opt_config) # input

    scale_reduce = reduce_ops[0].output(0) if len(reduce_ops) else output
    scale_tensor = scale_ops[0].output(0)
    assert scale_tensor == output

    s[output].pragma(output.op.axis[0], env.scale(1))
    return s

def compute_pool2d(input, zero_point=(0,0),
                pool_size=(3,3), strides=(1,1),
                padding=(0,0,0,0), pool_type=0,
                unique_id=0, opt_config=0):
    assert len(zero_point)   == 2
    assert len(padding)      == 4
    assert len(input.shape)  == 4
    assert zero_point[0] == zero_point[1]
    ishape = topi.utils.get_const_tuple(input.shape)
    pad_t, pad_l, pad_b, pad_r = get_pad_tuple2d(padding)
    oh = 1 + (ishape[2] + pad_t + pad_b - pool_size[0]) // strides[0]
    ow = 1 + (ishape[3] + pad_l + pad_r - pool_size[1]) // strides[1]
    oshape = (input.shape[0], input.shape[1], oh, ow)
    s_kh, s_kw = (
        pool_size if isinstance(pool_size, (tuple, list)) else (pool_size, pool_size))

    res = xmnpu.topi.pool2d(input,
            zero_point[0],
            s_kh, s_kw, strides[0], strides[1],
            pad_t, pad_b, pad_l, pad_r,
            pool_type, input.shape, oshape)

    new_op = combine_new_op(res.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    res = outputs[0] if num == 1 else outputs
    return res

def schedule_pool2d(outs):
    """Schedule packed pool2d"""
    assert len(outs) == 1
    output = outs[0]
    #assert "int8" in output.op.input_tensors[0].dtype
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    pool2d_ops    = []

    def _traverse(op):
        if "pool2d_sum" in op.tag:
            reduce_ops.append(op)
        else:
            pool2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    pool2d_reduce = reduce_ops[0].output(0) if len(reduce_ops) else output
    pool2d_tensor = pool2d_ops[0].output(0)
    assert pool2d_tensor == output

    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value
    s[output].npu_id_config(output.op.axis[0], unique_id, opt_config) # input

    s[pool2d_reduce].compute_at(s[output], output.op.axis[3])
    s[output].pragma(output.op.axis[0], env.pool2d(1))
    return s

def compute_gap(input, zero_point=(0,0),
                pool_size=(3,3), unique_id=0, opt_config=0):
    assert len(zero_point)   == 2
    assert len(input.shape)  == 4
    assert zero_point[0] == zero_point[1]
    s_kh, s_kw = (
        pool_size if isinstance(pool_size, (tuple, list)) else (pool_size, pool_size))

    res = xmnpu.topi.global_avg_pool2d(input, zero_point[0], s_kh, s_kw)
    new_op = combine_new_op(res.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    res = outputs[0] if num == 1 else outputs

    return res

def schedule_gap(outs):
    """Schedule packed gap"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs = []
    reduce_ops   = []
    gap_ops      = []

    def _traverse(op):
        if "gap_sum" in op.tag:
            reduce_ops.append(op)
        else:
            gap_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)

    gap_reduce = reduce_ops[0].output(0) if len(reduce_ops) else output
    gap_tensor = gap_ops[0].output(0)
    assert gap_tensor == output

    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value
    s[output].npu_id_config(output.op.axis[0], unique_id, opt_config) # input

    s[gap_reduce].compute_at(s[output], output.op.axis[1])
    s[output].pragma(output.op.axis[0], env.gap(1))
    return s

def compute_eltwiseadd(lhs, rhs, lhs_quant_coeff, rhs_quant_coeff,
                      lhs_zp, rhs_zp, o_zp, unique_id=0, opt_config=0):
    assert len(lhs.shape)  == 4
    assert len(rhs.shape)  == 4
    assert topi.utils.get_const_tuple(lhs.shape) == topi.utils.get_const_tuple(rhs.shape)
    assert len(lhs_quant_coeff)  == 2
    assert len(rhs_quant_coeff)  == 2
    
    res = xmnpu.topi.eltwiseadd(lhs, rhs,
            lhs_quant_coeff[0][0], lhs_quant_coeff[1][0],
            rhs_quant_coeff[0][0], rhs_quant_coeff[1][0],
            lhs_zp, rhs_zp, o_zp)

    new_op = combine_new_op(res.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    res = outputs[0] if num == 1 else outputs
    return res

def schedule_eltwiseadd(outs):
    """Schedule packed eltwiseadd"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs   = []
    reduce_ops     = []
    eltwiseadd_ops = []

    def _traverse(op):
        if "eltwiseadd_sum" in op.tag:
            reduce_ops.append(op)
        else:
            eltwiseadd_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)

    eltwiseadd_reduce = reduce_ops[0].output(0) if len(reduce_ops) else output
    eltwiseadd_tensor = eltwiseadd_ops[0].output(0)
    assert eltwiseadd_tensor == output

    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value
    s[output].npu_id_config(output.op.axis[0], unique_id, opt_config)
    s[output].pragma(output.op.axis[0], env.eltwiseadd(1))
    return s

def compute_upsample(input, scale_h, scale_w, unique_id=0, opt_config=0):
    assert len(input.shape)  == 4

    res = xmnpu.topi.upsample(input, scale_h, scale_w)
    new_op = combine_new_op(res.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    res = outputs[0] if num == 1 else outputs
    return res

def schedule_upsample(outs):
    """Schedule packed upsample"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs = []
    reduce_ops   = []
    upsample_ops = []

    def _traverse(op):
        if "upsample_sum" in op.tag:
            reduce_ops.append(op)
        else:
            upsample_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)

    upsample_reduce = reduce_ops[0].output(0) if len(reduce_ops) else output
    upsample_tensor = upsample_ops[0].output(0)
    assert upsample_tensor == output

    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value
    s[output].npu_id_config(output.op.axis[0], unique_id, opt_config)
    s[output].pragma(output.op.axis[0], env.upsample(1))
    return s

def compute_concat(inputs, axis):
    assert len(inputs)  >= 2
    assert len(inputs[0].shape)  == 4

    input_lhs = inputs[0]
    lhs_shape = topi.utils.get_const_tuple(input_lhs.shape)
    oshape = list(lhs_shape)
    for i in range(len(inputs)-1):
        input_rhs = inputs[i+1]
        rhs_shape = topi.utils.get_const_tuple(input_rhs.shape)
        oshape[axis] = oshape[axis] + rhs_shape[axis]
        assert input_lhs.dtype == input_rhs.dtype
        for i in range(len(oshape)):
            if i != axis:
                assert lhs_shape[i] == rhs_shape[i]

    res = topi.concatenate(inputs, axis)
    #res = topi.cast(res, input_lhs.dtype)

    return res

def schedule_concat(outs):
    """Schedule packed concat"""
    assert len(outs) == 1
    output = outs[0]
    assert "int" in output.op.input_tensors[0].dtype

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)


    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.concat(1))
    return s


def compute_lut(input, table, o_dtype):
    assert len(input.shape) == 4, "expected input shape size = 4, but got {}".format(len(input.shape))
    assert len(table.shape) == 1, "expected table shape size = 1, but got {}".format(len(table.shape))

    res = te.compute(input.shape, lambda i,j,k,l:table[input[i,j,k,l]])
    return topi.cast(res, o_dtype)

def schedule_lut(outs):
    """Schedule packed concat"""
    assert len(outs) == 1
    output = outs[0]
    assert "int" in output.op.input_tensors[0].dtype

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.lut(1))
    return s

def compute_space_to_depth(inputs, block_size, layout):
    assert layout == "NCHW", "GOKE NPU only supported NCHW layout now!"
    res = topi.nn.space_to_depth(inputs, block_size, "NCHW")
    return res

def schedule_space_to_depth(outs):
    """Schedule space_to_depth"""
    assert len(outs) == 1
    output = outs[0]

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)

    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.space_to_depth(1))
    return s


def compute_depth_to_space(inputs, block_size, layout, mode):
    assert layout == "NCHW", "GOKE NPU only supported NCHW layout now!"
    assert len(inputs.shape)  == 4
    #! We rewrite topi.nn.depth_to_space since parameter 'mode' can NOT be passed to cmodel by tvm.topi.nn.depth_to_space.
    # return topi.nn.depth_to_space(inputs, block_size, layout, mode)

    """Perform depth to space transformation on the data

    Parameters
    ----------
    data : tvm.te.Tensor
        4-D tensor in either NCHW or NHWC layout.

    block_size : int
        Size of blocks to compose from channel dimension.

    layout : string
        Either NCHW or NHWC, indicating data layout.

    mode : string
        Either DCR or CDR, indicates how channels should be accessed.
        In DCR, channels are interwoven in the Tensorflow style while
        in CDR channels are accessed sequentially as in Pytorch.

    Returns
    -------
    output : tvm.te.Tensor
        Output of shape [N, C / block_size**2, H * block_size, W * block_size]
    """
    if layout == "NCHW":
        in_n, in_c, in_h, in_w = inputs.shape
        channel_factor = tvm.tir.truncdiv(in_c, (block_size * block_size))
        output_shape = [in_n, channel_factor, in_h * block_size, in_w * block_size]
    elif layout == "NHWC":
        in_n, in_h, in_w, in_c = inputs.shape
        channel_factor = tvm.tir.truncdiv(in_c, (block_size * block_size))
        output_shape = [in_n, in_h * block_size, in_w * block_size, channel_factor]
    else:
        raise ValueError("Only NCHW and NHWC layouts are currently supported.")

    def _get_indices(*indices):
        if layout == "NCHW":
            n, c, y, x = indices
        elif layout == "NHWC":
            n, y, x, c = indices
        return n, c, y, x

    def _get_pixel(n, c, y, x):
        block_x = tvm.tir.truncdiv(x, block_size)
        block_y = tvm.tir.truncdiv(y, block_size)
        idx_x = tvm.tir.truncmod(x, block_size)
        idx_y = tvm.tir.truncmod(y, block_size)
        
        if mode == "DCR":
            channel_idx = channel_factor * ((block_size * idx_y) + idx_x) + c
        else:
            channel_idx = (c * block_size * block_size) + ((block_size * idx_y) + idx_x)

        if layout == "NCHW":
            output = inputs(n, channel_idx, block_y, block_x)
        else:
            output = inputs(n, block_y, block_x, channel_idx)
        return output

    def _compute(*indices):
        n, c, y, x = _get_indices(*indices)
        return _get_pixel(n, c, y, x)

    return te.compute(output_shape, _compute, name="depth_to_space", varargs_names=[mode+"i0", "i1", "i2", "i3"],  tag=topi.tag.INJECTIVE)


def schedule_depth_to_space(outs):
    """Schedule depth_to_space"""
    assert len(outs) == 1
    output = outs[0]

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)

    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.depth_to_space(1))
    return s

def compute_batch_to_space_nd(data, block_shape, crop_begin_list, crop_end_list):
    assert len(data.shape) == 4, "expected 4-D tensor"
    assert len(crop_begin_list) == len(crop_end_list) == 2, "expected the len of crop list is 2."

    suffix = "_" + str(crop_begin_list[0]) + "_" + str(crop_begin_list[1]) +\
             "_" + str(crop_end_list[0]) + "_" + str(crop_end_list[1])
    from operator import floordiv
    on = floordiv(data.shape[0],(block_shape[0] * block_shape[1]))
    oc = data.shape[1]
    oh = data.shape[2] * block_shape[0] - crop_begin_list[0] - crop_end_list[0]
    ow = data.shape[3] * block_shape[1] - crop_begin_list[1] - crop_end_list[1]
    shape = [on, oc, oh, ow]
    res = te.compute(shape, lambda *indices: data[indices], name = "batch_to_space_nd" + suffix)

    return res

def schedule_batch_to_space_nd(outs):
    """Schedule batch_to_space_nd"""
    assert len(outs) == 1
    output = outs[0]

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.batch_to_space_nd(1))
    return s

def compute_space_to_batch_nd(data, block_shape, pad_before, pad_after):
    assert len(data.shape) == 4, "expected 4-D tensor"
    assert len(pad_before) == len(pad_after) == 2, "expected the len of pad list is 2."

    from operator import floordiv
    on = data.shape[0] * (block_shape[0] * block_shape[1])
    oc = data.shape[1]
    oh = floordiv(data.shape[2] + pad_before[0] + pad_after[0], block_shape[0])
    ow = floordiv(data.shape[3] + pad_before[1] + pad_after[1], block_shape[1])
    shape = [on, oc, oh, ow]
    suffix = "_" + str(pad_before[0]) + "_" + str(pad_before[1]) + "_" + str(pad_after[0]) + "_" + str(pad_after[1])
    res = te.compute(shape, lambda *indices: data[indices], name="space_to_batch_nd" + suffix)

    return res

def schedule_space_to_batch_nd(outs):
    """Schedule space_to_batch_nd"""
    assert len(outs) == 1
    output = outs[0]

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.space_to_batch_nd(1))
    return s

def compute_tile(inputs, multiples=(1,1,1,1)):
    assert len(inputs.shape)  == 4
    assert len(multiples)  == 4

    res = topi.tile(inputs, multiples)

    return res

def schedule_tile(outs):
    """Schedule packed tile"""
    assert len(outs) == 1
    output = outs[0]
    assert "int" in output.op.input_tensors[0].dtype

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)

    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.tile(1))

    return s

def compute_split(inputs, array_len, split_idx, axis):
    res1 = topi.clip(inputs, 0, array_len)
    res  = topi.split(res1, split_idx, axis)

    return res

def schedule_split(outs):
    """Schedule packed split"""
    output = outs

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output[i].op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    for i in range(len(output)):
        _traverse(output[i].op)

    s = te.create_schedule([x.op for x in output])
    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    for i in range(len(output)):
        s[output[i]].pragma(output[i].op.axis[0], env.split(1))

    return s

def compute_clip(inputs, a_min, a_max):
    assert a_min <= a_max
    res  = topi.clip(inputs, a_min, a_max)

    return res

def schedule_clip(outs):
    """Schedule packed clip"""
    assert len(outs) == 1
    output = outs[0]

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.clip(1))

    return s

def compute_matmul(input1, input2, oshape, out_dtype, transpose_a, transpose_b,
                    i1_zp, i2_zp, o_zp, quant_mode, f_multiplier, quant_coeff):
    res = topi.nn.batch_matmul(input1, input2, oshape, out_dtype, transpose_a, transpose_b)
    suffix = "_" + str(transpose_a) + "_" + str(transpose_b) +\
             "_" + str(i1_zp) + "_" + str(i2_zp) + "_" + str(o_zp) + "_" + str(quant_mode) +\
             "_" + str(f_multiplier) + "_" + str(quant_coeff[0][0]) + "_" + str(quant_coeff[1][0])
    res = te.compute(oshape, lambda *indices: res[indices], name = "matmul" + suffix)

    return res

def schedule_matmul(outs):
    """Schedule matmul"""
    assert len(outs) == 1
    output = outs[0]
    assert "int" in output.op.input_tensors[0].dtype

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.matmul(1))
    return s

def compute_reduce_mean(data, axis):
    n, c, h, w = data.shape
    if axis[1] == 0:
        oshape = [n, c, h, 1]
        kw = te.reduce_axis((0, w), name="kh")
        res = te.compute(oshape, lambda on, oc, oh, ow : te.div(data[on, oc, oh, ow], w),
                        name="reduce_div", tag="reduce_div")
        res = te.compute(oshape, lambda on, oc, oh, ow : te.sum(res[on, oc, oh, kw].astype(data.dtype), 
                        axis=kw), name="reduce_sum", tag="reduce_sum")
    else:
        oshape = [n, c, 1, 1]
        kh = te.reduce_axis((0, h), name="kh")
        kw = te.reduce_axis((0, w), name="kw")
        res = te.compute(oshape, lambda on, oc, oh, ow : te.div(data[on, oc, oh, ow], h * w),
                        name="reduce_div", tag="reduce_div")
        res = te.compute(oshape, lambda on, oc, oh, ow : te.sum(res[on, oc, kh, kw].astype(data.dtype), 
                        axis=[kh, kw]), name="reduce_sum", tag="reduce_sum")
    return res

def schedule_reduce_mean(outs):
    """Schedule packed reduce_mean"""
    assert len(outs) == 1
    output = outs[0]

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.reduce_mean(1))

    return s

def compute_neg(inputs, o_dtype="int8"):
    #dtype_l = ["int8", "uint8", "int32"]
    dtype_l = ["int8", "uint8", "int32"]
    assert inputs.dtype in dtype_l
    assert o_dtype in ["int8", "int32"]

    #inputs_i32 = topi.cast(inputs, "int32")
    res = topi.negative(inputs)
    #res = topi.cast(res, o_dtype)

    return res

def schedule_neg(outs):
    """Schedule packed neg"""
    assert len(outs) == 1
    output = outs[0]

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.neg(1))
    return s

def compute_transpose(data, axes):
    assert len(data.shape) == 4
    #each element in axes [0,4)
    for v in axes:
        assert (int(v) >= 0 and int(v) < len(data.shape))
    #axes all elements must be not equal
    assert len(list(set(axes))) == len(axes)
    res = topi.transpose(data, axes)

    return res

def schedule_transpose(outs):
    """Schedule packed transpose"""
    assert len(outs) == 1
    output = outs[0]

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)

    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.transpose(1))

    return s

def compute_strided_slice(data, start_index, end_index, strides):
    assert len(data.shape) == 4
    assert (len(start_index) == len(end_index) == len(strides))
    for i in range(len(start_index)):
        assert start_index[i] < end_index[i]
        assert (start_index[i] >= 0 and start_index[i] < data.shape[i])
        assert (end_index[i] > 0 and end_index[i] <= data.shape[i])
        assert strides[i] > 0
    res = topi.strided_slice(data, start_index, end_index, strides)

    return res

def schedule_strided_slice(outs):
    """Schedule packed strided_slice"""
    assert len(outs) == 1
    output = outs[0]

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)

    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.strided_slice(1))

    return s

def compute_crop(data, out_shape, axis, offset):
    assert len(data.shape) == len(out_shape) 
    assert isinstance(offset, (int, list, tuple))
    if isinstance(offset, (list, tuple)):
        assert len(data.shape) == axis + len(offset)
    for inx, v in enumerate(out_shape):
        assert (v > 0 and v <= data.shape[inx])
        if inx >= axis:
            if isinstance(offset, int):
                assert (offset + out_shape[inx] <= data.shape[inx])
            elif isinstance(offset, (list, tuple)):
                assert (offset[inx - axis] + out_shape[inx] <= data.shape[inx])
    import copy
    slice_start = [0] * len(data.shape)
    slice_end = copy.deepcopy(out_shape)
    for i in range(len(data.shape)):
        if i >= axis:
            if isinstance(offset, int):
                slice_start[i] = offset
            elif isinstance(offset, (list, tuple)):
                slice_start[i] = offset[i - axis]
            slice_end[i] = slice_start[i] + out_shape[i]
    res = topi.strided_slice(data, slice_start, slice_end)

    return res

def schedule_crop(outs):
    """Schedule packed crop"""
    assert len(outs) == 1
    output = outs[0]

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)
    s = te.create_schedule(output.op)

    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.strided_slice(1))

    return s

def compute_channel_shuffle(data, group, axes):
    assert len(data.shape) == 4
    assert len(list(set(axes))) == len(axes)
    assert group >= 2
    c_per_group = data.shape[1] // group
    new_data = topi.reshape(data, [data.shape[0], group, c_per_group, \
        data.shape[2], data.shape[3]])
    new_data = topi.transpose(new_data, axes)
    res = topi.reshape(new_data, data.shape)
    res = te.compute(res.shape, lambda *indices: res[indices], \
        name = "channel_shuffle_" + str(group))

    return res

def schedule_channel_shuffle(outs):
    """Schedule packed channel_shuffle"""
    assert len(outs) == 1
    output = outs[0]

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)

    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.channel_shuffle(1))

    return s

def compute_yuv2rgb(y_data, uv_data, input_h, input_w, input_wptch, pic_format_e,
        btfmt_e, range_e, output_dtype="uint8", input_mtype=1, unique_id=0, opt_config=0):
    if(pic_format_e):
        res_tmp1 = topi.tile(uv_data, (2, 1))
        res_tmp = topi.maximum(y_data, res_tmp1)
    else:
        res_tmp = topi.maximum(y_data, uv_data)
    res_clip = topi.clip(res_tmp, btfmt_e, pic_format_e + 1)
    res_clip2 = topi.clip(res_clip, range_e, input_mtype + 1)
    res = topi.tile(res_clip2, (1, 3, 1, 1))

    new_op = combine_new_op(res.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    res = outputs[0] if num == 1 else outputs

    return res

def schedule_yuv2rgb(outs):
    """Schedule packed yuv2rgb"""
    assert len(outs) == 1
    output = outs[0]
    #assert "int" in output.op.input_tensors[0].dtype

    const_ops    = []
    ewise_inputs = []
    ewise_ops    = []
    concat_res   = []

    def _traverse(op):
        if not op.same_as(output.op):
            if not op.axis:
                const_ops.append(op)
            else:
                ewise_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)

    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value
    s[output].npu_id_config(output.op.axis[0], unique_id, opt_config) # input

    for op in ewise_ops:
        s[op].compute_inline()
    for op in const_ops:
        s[op].compute_inline()
    s[output].pragma(output.op.axis[0], env.yuv2rgb(1))

    return s

