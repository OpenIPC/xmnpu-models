# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
# pylint: disable=unused-argument
"""The register functions for the QNN dialect."""

import numpy as np

import tvm.ir
from tvm import topi
from ..relay.register import *
from tvm.relay.op import op as _op
from tvm.relay.op import OpPattern
from tvm.topi.nn.utils import get_pad_tuple
from tvm.relay.op.nn.utils import get_pad_tuple2d
from tvm.topi.utils import get_const_tuple
from tvm.target import generic_func, override_native_generic_func
from tvm.relay.op.strategy.generic import *
from .x86_strategy import wrap_compute_xm_xconv2d, wrap_compute_xm_xconv2dadd, wrap_compute_xm_4conv2dadd, \
                    wrap_compute_xm_3convpooladd, wrap_compute_xm_mobinet, wrap_compute_xm_triplepoolconcat, \
                    wrap_compute_xm_3conv2dconcat, wrap_compute_xm_xconv2d_upsample, wrap_compute_xm_convpooldoubleconv, \
                    wrap_compute_xm_dwdoubleconvconcat, wrap_compute_xm_dw2convdwconvconcat, wrap_compute_xm_3conv2daddtype2, \
                    wrap_compute_xm_quadconvpoolconcat, wrap_compute_xm_dw3convlpooladd, wrap_compute_xm_spconvdwconvconcat, wrap_compute_xm_conv2d, \
                    wrap_compute_xm_pool2d, wrap_compute_xm_eltwiseadd, wrap_compute_xm_dense, wrap_compute_xm_scale, \
                    wrap_compute_xm_global_avg_pool2d, wrap_compute_xm_concat, \
                    wrap_compute_xm_tile, wrap_compute_xm_neg, wrap_compute_xm_yuv2rgb, \
                    wrap_compute_xm_lut, wrap_compute_xm_upsample, wrap_compute_xm_transpose, \
                    wrap_compute_xm_space_to_depth, wrap_compute_xm_depth_to_space, \
                    wrap_compute_xm_strided_slice, wrap_compute_xm_clip, \
                    wrap_compute_xm_batch_to_space_nd, wrap_compute_xm_space_to_batch_nd, \
                    wrap_compute_xm_channel_shuffle, wrap_compute_xm_split, \
                    wrap_compute_xm_matmul, wrap_compute_xm_reduce_mean

from .xmnpu_normalop import *
from .xmnpu_tilingop import *

from xmnpu.environment import get_env
env = get_env()

@xm_transpose_strategy.register('xmnpu')
def xm_transpose_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_transpose(compute_transpose),
        wrap_topi_schedule(schedule_transpose),
        name="xm_transpose_nchw.xmnpu",
    )
    return strategy

@xm_lut_strategy.register("xmnpu")
def xm_lut_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_lut(compute_lut),
        wrap_topi_schedule(schedule_lut),
        name="xm_lut_nchw.xmnpu",
    )
    return strategy

@xm_conv2d_strategy.register("xmnpu")
def xm_conv2d_strategy_xmnpu(attrs, inputs, out_type, target):
    """conv2d npu strategy"""
    #from .. import op as _op
    strategy = _op.OpStrategy()
    group_pattern = ""
    if isinstance(attrs, tvm.ir.DictAttrs):
        group_pattern = attrs["GroupPattern"]
    else:
        assert len(inputs) == 3
        data, kernel, bias = inputs
        stride_h, stride_w = get_const_tuple(attrs.strides)
        dilation_h, dilation_w = get_const_tuple(attrs.dilation)
        groups = attrs.groups
        layout = attrs.data_layout
        kernel_layout = attrs.kernel_layout
        if dilation_h < 1 or dilation_w < 1:
            raise ValueError("dilation should be positive value")

    if group_pattern == "conv2d_pool2d":
            strategy.add_implementation(
                wrap_compute_xm_xconv2d(compute_1conv2d),
                wrap_topi_schedule(schedule_1conv2d),
                name="xm_conv2d_pool2d_nchw.xmnpu",
            )
    elif group_pattern == "2conv2d":
            strategy.add_implementation(
                wrap_compute_xm_xconv2d(compute_2conv2d),
                wrap_topi_schedule(schedule_2conv2d),
                name="xm_2conv2d_nchw.xmnpu",
            )
    elif group_pattern == "convdw":
            strategy.add_implementation(
                wrap_compute_xm_mobinet(compute_2conv2d), #TODO
                wrap_topi_schedule(schedule_2conv2d),
                name="xm_conv2d_dw_nchw.xmnpu",
            )
    elif group_pattern == "dwconv":
            strategy.add_implementation(
                wrap_compute_xm_xconv2d(compute_dwconv2d),
                wrap_topi_schedule(schedule_dwconv2d),
                name="xm_dw_conv2d_nchw.xmnpu",
            )
    elif group_pattern == "3conv2d":
            strategy.add_implementation(
                wrap_compute_xm_xconv2d(compute_3conv2d),
                wrap_topi_schedule(schedule_3conv2d),
                name="xm_3conv2d_nchw.xmnpu",
            )
    elif group_pattern == "convdwconv":
            strategy.add_implementation(
                wrap_compute_xm_mobinet(compute_conv2d_dw_conv2d),
                wrap_topi_schedule(schedule_conv2d_dw_conv2d),
                name="xm_conv2d_dw_conv2d_nchw.xmnpu",
            )
    elif group_pattern == "4conv2d":
            strategy.add_implementation(
                wrap_compute_xm_xconv2d(compute_4conv2d),
                wrap_topi_schedule(schedule_4conv2d),
                name="xm_4conv2d_nchw.xmnpu",
            )
    elif group_pattern == "3conv2d_add":
            strategy.add_implementation(
                wrap_compute_xm_xconv2dadd(compute_3conv2d_add),
                wrap_topi_schedule(schedule_3conv2d_add),
                name="xm_3conv2d_add_nchw.xmnpu",
            )
    elif group_pattern == "convdwconv_add":
            strategy.add_implementation(
                wrap_compute_xm_mobinet(compute_conv2d_dw_conv2d_add),
                wrap_topi_schedule(schedule_conv2d_dw_conv2d_add),
                name="xm_conv2d_dw_conv2d_add_nchw.xmnpu",
            )
    elif group_pattern == "dwdoubleconvadd":
            strategy.add_implementation(
                wrap_compute_xm_xconv2dadd(compute_3dwdoubleconv2d_add),
                wrap_topi_schedule(schedule_3dwdoubleconv2d_add),
                name="xm_3dwdoubleconv2d_add_nchw.xmnpu",
            )
    elif group_pattern == "dwtripleconvadd":
            strategy.add_implementation(
                wrap_compute_xm_xconv2dadd(compute_4dwtripleconv2d_add),
                wrap_topi_schedule(schedule_4dwtripleconv2d_add),
                name="xm_dw_triple_conv2d_add_nchw.xmnpu",
            )
    elif group_pattern == "doubleconvrightadd":
            strategy.add_implementation(
                wrap_compute_xm_xconv2dadd(compute_2conv2d_add),
                wrap_topi_schedule(schedule_2conv2d_add),
                name="xm_2conv2d_add_nchw.xmnpu",
            )
    elif group_pattern == "4conv2d_add":
            strategy.add_implementation(
                wrap_compute_xm_4conv2dadd(compute_4conv2d_eltadd),
                wrap_topi_schedule(schedule_4conv2d_eltadd),
                name="xm_4conv2d_add_nchw.xmnpu",
            )
    elif group_pattern == "convupsample":
            strategy.add_implementation(
                wrap_compute_xm_xconv2d_upsample(compute_conv2dupsp),
                wrap_topi_schedule(schedule_conv2dupsp),
                name="xm_convupsample_nchw.xmnpu",
           )
    elif group_pattern == "doubleconvupsample":
            strategy.add_implementation(
                wrap_compute_xm_xconv2d_upsample(compute_2conv2dupsp),
                wrap_topi_schedule(schedule_2conv2dupsp),
                name="xm_doubleconvupsample_nchw.xmnpu",
           )
    elif group_pattern == "convpooldoubleconv":
            strategy.add_implementation(
                wrap_compute_xm_convpooldoubleconv(compute_conv2d_pool2d_2conv2d),
                wrap_topi_schedule(schedule_conv2d_pool2d_2conv2d),
                name="xm_convpooldoubleconv_nchw.xmnpu",
           )
    elif group_pattern == "tripleconvconcat":
            strategy.add_implementation(
                wrap_compute_xm_3conv2dconcat(compute_3conv2d_concat),
                wrap_topi_schedule(schedule_3conv2d_concat),
                name="xm_tripleconvconcat_nchw.xmnpu",
            )
    elif group_pattern == "dwdoubleconvconcat":
            strategy.add_implementation(
                wrap_compute_xm_dwdoubleconvconcat(compute_3dwconvconv_concat),
                wrap_topi_schedule(schedule_3dwconvconv_concat),
                name="xm_dwdoubleconvconcat_nchw.xmnpu",
            )
    elif group_pattern == "dw2convdwconvconcat":
            strategy.add_implementation(
                wrap_compute_xm_dw2convdwconvconcat(compute_dw_2conv2d_dw_conv2d_concat),
                wrap_topi_schedule(schedule_dw_2conv2d_dw_conv2d_concat),
                name="xm_dw2convdwconvconcat_nchw.xmnpu",
            )
    elif group_pattern == "tripleconvaddtype2":
            strategy.add_implementation(
                wrap_compute_xm_3conv2daddtype2(compute_3conv2d_eltadd_type2),
                wrap_topi_schedule(schedule_3conv2d_eltadd_type2),
                name="xm_tripleconvaddtype2_nchw.xmnpu",
            )
    elif group_pattern == "quadconvpoolconcat":
            strategy.add_implementation(
                wrap_compute_xm_quadconvpoolconcat(compute_4conv2d_pool_concat),
                wrap_topi_schedule(schedule_4conv2d_pool_concat),
                name="xm_quadconvpoolconcat_nchw.xmnpu",
            )
    elif groups == 1:
        if layout == "NCHW":
            assert kernel_layout == "OIHW"
            strategy.add_implementation(
                wrap_compute_xm_conv2d(compute_conv2d),
                wrap_topi_schedule(schedule_conv2d),
                name="xm_conv2d_nchw.xmnpu",
            )
        else:
            raise RuntimeError("Unsupported conv2d layout {} for xmnpu".format(layout))
    elif is_depthwise_conv2d(data.shape, layout, kernel.shape, kernel_layout, groups):
        if layout == "NCHW":
            assert kernel_layout == "OIHW"
            strategy.add_implementation(
                wrap_compute_xm_conv2d(compute_conv2d),
                wrap_topi_schedule(schedule_conv2d),
                name="xm_depthwise_conv2d_nchw.xmnpu",
            )
        else:
            raise RuntimeError("Unsupported depthwise_conv2d layout {}".format(layout))
    else:  # group_conv2d
        assert 0
    return strategy

@xm_scale_strategy.register("xmnpu")
def xm_scale_strategy_xmnpu(attrs, inputs, out_type, target):
    """scale npu strategy"""
    #from .. import op as _op
    strategy = _op.OpStrategy()
    assert len(inputs) == 3
    data, kernel, bias = inputs
    layout = attrs.data_layout
    kernel_layout = attrs.kernel_layout

    if layout == "NCHW":
        assert kernel_layout == "C"
        strategy.add_implementation(
            wrap_compute_xm_scale(compute_scale),
            wrap_topi_schedule(schedule_scale),
            name="xm_scale_nchw.xmnpu",
        )
    else:
        raise RuntimeError("Unsupported scale layout {} for xmnpu".format(layout))
    return strategy

@xm_pool2d_strategy.register("xmnpu")
def xm_pool2d_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()
    group_pattern = ""
    if isinstance(attrs, tvm.ir.DictAttrs):
        group_pattern = attrs["GroupPattern"]
    else:
        layout = attrs.layout

    if group_pattern == "triplepoolconcat":
        strategy.add_implementation(
            wrap_compute_xm_triplepoolconcat(compute_3pool_concat),
            wrap_topi_schedule(schedule_3pool_concat),
            name="xm_triplepoolconcat_nchw.xmnpu",
        )
    elif group_pattern == "3convpool_add":
        strategy.add_implementation(
            wrap_compute_xm_3convpooladd(compute_3conv2d_pool_add),
            wrap_topi_schedule(schedule_3conv2d_pool_add),
            name="xm_3conv2d_pool_add_nchw.xmnpu",
        )
    elif group_pattern == "dwtripleconvlpooladd":
        strategy.add_implementation(
            wrap_compute_xm_dw3convlpooladd(compute_4dwtripleconv2d_lpool_add),
            wrap_topi_schedule(schedule_4dwtripleconv2d_lpool_add),
            name="xm_dwtripleconvlpooladd_nchw.xmnpu",
        )
    else:
        assert layout == "NCHW"
        strategy.add_implementation(
            wrap_compute_xm_pool2d(compute_pool2d),
            wrap_topi_schedule(schedule_pool2d),
            name="xm_pool2d_nchw.xmnpu",
        )
    return strategy

@xm_eltwiseadd_strategy.register("xmnpu")
def xm_eltwiseadd_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_eltwiseadd(compute_eltwiseadd),
        wrap_topi_schedule(schedule_eltwiseadd),
        name="xm_eltwiseadd_nchw.xmnpu",
    )
    return strategy

@xm_upsample_strategy.register("xmnpu")
def xm_upsample_strategy_xmnpu(attrs,inputs,out_type,target):
    strategy=_op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_upsample(compute_upsample),
        wrap_topi_schedule(schedule_upsample),
        name="xm_upsample.xmnpu"
    )
    return strategy

@xm_space_to_depth_strategy.register("xmnpu")
def xm_space_to_depth_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy=_op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_space_to_depth(compute_space_to_depth),
        wrap_topi_schedule(schedule_space_to_depth),
        name="xm_space_to_depth.xmnpu"
    )
    return strategy

@xm_depth_to_space_strategy.register("xmnpu")
def xm_depth_to_space_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy=_op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_depth_to_space(compute_depth_to_space),
        wrap_topi_schedule(schedule_depth_to_space),
        name="xm_depth_to_space.xmnpu"
    )
    return strategy

@xm_yuv2rgb_strategy.register("xmnpu")
def xm_yuv2rgb_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_yuv2rgb(compute_yuv2rgb),
        wrap_topi_schedule(schedule_yuv2rgb),
        name="xm_yuv2rgb_nchw.xmnpu",
    )
    return strategy

@xm_dense_strategy.register("xmnpu")
def xm_dense_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_dense(compute_dense),
        wrap_topi_schedule(schedule_dense),
        name="xm_dense_nchw.xmnpu",
    )
    return strategy

@xm_global_avg_pool2d_strategy.register("xmnpu")
def xm_global_avg_pool2d_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_global_avg_pool2d(compute_gap),
        wrap_topi_schedule(schedule_gap),
        name="xm_global_avg_pool2d_nchw.xmnpu",
    )
    return strategy


@xm_concat_strategy.register("xmnpu")
def xm_concat_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_concat(compute_concat),
        wrap_topi_schedule(schedule_concat),
        name="xm_concat_nchw.xmnpu",
    )
    return strategy

@xm_strided_slice_strategy.register("xmnpu")
def xm_strided_slice_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_strided_slice(compute_strided_slice),
        wrap_topi_schedule(schedule_strided_slice),
        name="xm_strided_slice_nchw.xmnpu",
    )
    return strategy

@xm_tile_strategy.register("xmnpu")
def xm_tile_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_tile(compute_tile),
        wrap_topi_schedule(schedule_tile),
        name="xm_tile_nchw.xmnpu",
    )
    return strategy

@xm_neg_strategy.register("xmnpu")
def xm_neg_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_neg(compute_neg),
        wrap_topi_schedule(schedule_neg),
        name="xm_neg_nchw.xmnpu",
    )
    return strategy

@xm_batch_to_space_nd_strategy.register("xmnpu")
def xm_batch_to_space_nd_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy=_op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_batch_to_space_nd(compute_batch_to_space_nd),
        wrap_topi_schedule(schedule_batch_to_space_nd),
        name="xm_batch_to_space_nd_nhwc.xmnpu"
    )
    return strategy

@xm_reduce_mean_strategy.register("xmnpu")
def xm_reduce_mean_strategy_xmnpu(attr, inputs, out_type, target):
    strategy=_op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_reduce_mean(compute_reduce_mean),
        wrap_topi_schedule(schedule_reduce_mean),
        name="xm_reduce_mean_nchw.xmnpu"
    )
    return strategy


@xm_space_to_batch_nd_strategy.register("xmnpu")
def xm_space_to_batch_nd_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy=_op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_space_to_batch_nd(compute_space_to_batch_nd),
        wrap_topi_schedule(schedule_space_to_batch_nd),
        name="xm_space_to_batch_nd_nhwc.xmnpu"
    )
    return strategy

@xm_channel_shuffle_strategy.register("xmnpu")
def xm_channel_shuffle_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_channel_shuffle(compute_channel_shuffle),
        wrap_topi_schedule(schedule_channel_shuffle),
        name="xm_channel_shuffle_nchw.xmnpu",
    )
    return strategy

@xm_clip_strategy.register("xmnpu")
def xm_clip_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_clip(compute_clip),
        wrap_topi_schedule(schedule_clip),
        name="xm_clip_nchw.xmnpu",
    )
    return strategy

@xm_split_strategy.register("xmnpu")
def xm_split_strategy_xmnpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()
    group_pattern = ""
    if isinstance(attrs, tvm.ir.DictAttrs):
        group_pattern = attrs["GroupPattern"]
    else:
        layout = "NCHW"
    
    if group_pattern == "spconvdwconvconcat":
        strategy.add_implementation(
            wrap_compute_xm_spconvdwconvconcat(compute_3spconvdwconv_concat),
            wrap_topi_schedule(schedule_3spconvdwconv_concat),
            name="xm_spconvdwconvconcat_nchw.xmnpu",
        )
    else:
        assert layout == "NCHW"
        strategy.add_implementation(
            wrap_compute_xm_split(compute_split),
            wrap_topi_schedule(schedule_split),
            name="xm_split_nchw.xmnpu",
        )
    return strategy

@xm_matmul_strategy.register("xmnpu")
def xm_matmul_strategy_xmnpu(attr, inputs, out_type, target):
    strategy=_op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_matmul(compute_matmul),
        wrap_topi_schedule(schedule_matmul),
        name="xm_matmul_nchw.xmnpu"
    )
    return strategy

@xm_reduce_mean_strategy.register("xmnpu")
def xm_reduce_mean_strategy_xmnpu(attr, inputs, out_type, target):
    strategy=_op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_reduce_mean(compute_reduce_mean),
        wrap_topi_schedule(schedule_reduce_mean),
        name="xm_reduce_mean_nchw.xmnpu"
    )
    return strategy

