# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
# pylint: disable=unused-argument
"""The register functions for the QNN dialect."""

import numpy as np

import tvm.ir
from tvm import topi
from ..relay.register import *
from tvm.relay.op import op as _op
from tvm.relay.op import OpPattern
from tvm.topi.nn.utils import get_pad_tuple
from tvm.relay.op.nn.utils import get_pad_tuple2d
from tvm.topi.utils import get_const_tuple
from tvm.target import generic_func, override_native_generic_func
from tvm.relay.op.strategy.generic import *
from .x86_tiling import *

from xmnpu.environment import get_env
env = get_env()


def wrap_compute_xm_transpose(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap transpose topi compute"""
    def _compute_transpose(attrs, inputs, out_type):
        args=list()
        args.append(inputs[0])
        args.append(attrs.axes)
        if need_auto_scheduler_layout:
            args.append(get_auto_scheduler_rewritten_layout(attrs))

        return [topi_compute(*args)]
    
    return _compute_transpose

def wrap_compute_xm_channel_shuffle(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap channel_shuffle topi compute"""

    def _compute_channel_shuffle(attrs, inputs, out_type):
        args = list()
        args.append(inputs[0])
        args.append(attrs.group)
        args.append(attrs.axes)
        if need_auto_scheduler_layout:
            args.append(get_auto_scheduler_rewritten_layout(attrs))

        return [topi_compute(*args)]

    return _compute_channel_shuffle

def wrap_compute_xm_lut(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap lut topi compute"""
    def _compute_lut(attrs, inputs, out_type):
        args=list()
        args.append(inputs[0])
        args.append(inputs[1])
        args.append(attrs.dtype)
        if need_auto_scheduler_layout:
            args.append(get_auto_scheduler_rewritten_layout(attrs))

        return [topi_compute(*args)]
    
    return _compute_lut

def wrap_compute_xm_conv2d(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap conv2d topi compute"""
    def _compute_conv2d(attrs, inputs, out_type):
        padding = get_const_tuple(attrs.padding)
        strides = get_const_tuple(attrs.strides)
        dilation = get_const_tuple(attrs.dilation)
        ins = get_const_tuple(attrs.ins)
        data_layout = attrs.get_str("data_layout")
        out_layout = attrs.get_str("out_layout")
        out_dtype = attrs.out_dtype
        out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
        args = [x for x in inputs]
        if attrs.using_bias == 0:
            args[2] = None
        if len(inputs[1].shape) == 1:     # scale
            args.append(attrs.output_scale.data.asnumpy().tolist())
            args.append(0)               # TODO quantmode for perchanel
            args.append((attrs.input_zero_point, attrs.kernel_zero_point, attrs.output_zero_point))
            args.append(attrs.using_bias)
            args.append(attrs.relu_type)
            args.append(out_dtype)
        else:
            args.append(attrs.output_scale.data.asnumpy().tolist())
            args.append(0)              # TODO quantmode for perchanel
            args.append((attrs.input_zero_point, attrs.kernel_zero_point, attrs.output_zero_point))
            args.append(strides)
            args.append(padding)
            args.append(dilation)
            args.append(ins)
            args.append(attrs.using_bias)
            args.append(attrs.relu_type)
            args.append(attrs.groups) 
            args.append(out_dtype)

        if need_data_layout:
            assert 0
            args.append(data_layout)
        if need_out_layout:
            assert 0
            args.append(out_layout)
        if need_auto_scheduler_layout:
            assert 0
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_conv2d

def wrap_compute_xm_dense(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap dense topi compute"""
    def _compute_dense(attrs, inputs, out_type):
        out_dtype = attrs.out_dtype
        out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
        args = [x for x in inputs]
        if attrs.using_bias == 0:
            args[2] = None
        args.append(attrs.output_scale.data.asnumpy().tolist())
        args.append(0)              # TODO quantmode for perchanel
        args.append((attrs.input_zero_point, attrs.kernel_zero_point, attrs.output_zero_point))
        args.append(attrs.using_bias)
        args.append(out_dtype)

        if need_auto_scheduler_layout:
            assert 0
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_dense

def wrap_compute_xm_upsample(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap upsample topi compute"""

    def _compute_upsample(attrs, inputs, output_dtype):
        scale_h = int(attrs.scale_h)
        scale_w = int(attrs.scale_w)
        # layout = attrs.layout
        # method = attrs.method
        # align_corners = attrs.align_corners
        args=[inputs[0],scale_h,scale_w]
        if need_auto_scheduler_layout:
            assert 0
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]
    
    return _compute_upsample

def wrap_compute_xm_space_to_depth(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap space_to_depth topi compute"""

    def _compute_space_to_depth(attrs, inputs, output_dtype):
        block_size = int(attrs.block_size)
        layout = attrs.layout

        args=[inputs[0], block_size, layout]
        if need_auto_scheduler_layout:
            assert 0
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_space_to_depth

def wrap_compute_xm_depth_to_space(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap depth_to_space topi compute"""

    def _compute_depth_to_space(attrs, inputs, output_dtype):
        block_size = int(attrs.block_size)
        layout = attrs.layout
        mode = attrs.mode

        args=[inputs[0], block_size, layout, mode]
        if need_auto_scheduler_layout:
            assert 0
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_depth_to_space

def wrap_compute_xm_batch_to_space_nd(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap batch_to_space_nd topi compute"""

    def _compute_batch_to_space_nd(attrs, inputs, output_dtype):
        block_shape = attrs.block_shape
        crops = attrs.crops
        crop_begin_list = [crops[0][0], crops[1][0]]
        crop_end_list = [crops[0][1], crops[1][1]]
        args=[inputs[0], block_shape, crop_begin_list, crop_end_list]
        if need_auto_scheduler_layout:
            assert 0
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]
    
    return _compute_batch_to_space_nd

def wrap_compute_xm_space_to_batch_nd(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap space_to_batch_nd topi compute"""

    def _compute_space_to_batch_nd(attrs, inputs, output_dtype):
        block_shape = attrs.block_shape
        pad = attrs.paddings
        pad_before = [pad[0][0], pad[1][0]]
        pad_after = [pad[0][1], pad[1][1]]
        args=[inputs[0], block_shape, pad_before, pad_after]
        if need_auto_scheduler_layout:
            assert 0
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]
    
    return _compute_space_to_batch_nd

def wrap_compute_xm_yuv2rgb(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap yuv2rgb topi compute"""
    def _compute_yuv2rgb(attrs, inputs, output_dtype):
        output_dtype = attrs.dtype
        pic_format_e = attrs.yuv_format
        btfmt_e = attrs.bt_format
        range_e = attrs.yuv_range
        input_mtype = attrs.input_mtype
        input_wptch = attrs.input_wptch

        if isinstance(pic_format_e,str):
            pic_format_e={"YUV_422SP":0,"YUV_420SP":1}[pic_format_e]
        if isinstance(btfmt_e,str):
            btfmt_e={"BT601":0,"BT709":1}[btfmt_e]
        if isinstance(range_e,str):
            range_e={"FULL":0, "TV":1}[range_e]

        args = [x for x in inputs]
        args.append(inputs[0].shape[0])
        args.append(inputs[0].shape[1])
        args.append(input_wptch)
        args.append(pic_format_e)
        args.append(btfmt_e)
        args.append(range_e)
        args.append(output_dtype)
        args.append(input_mtype)

        if need_auto_scheduler_layout:
            assert 0
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_yuv2rgb

def wrap_compute_xm_pool2d(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap pool2d topi compute"""
    def _compute_pool2d(attrs, inputs, out_type):
        data_layout = attrs.get_str("layout")
        pool_size = get_const_tuple(attrs.pool_size)
        strides = get_const_tuple(attrs.strides)
        padding = get_const_tuple(attrs.padding)
        args = [x for x in inputs]
        args.append((attrs.input_zero_point, attrs.output_zero_point))
        args.append(pool_size)
        args.append(strides)
        args.append(padding)
        args.append(attrs.pool_type)
        if need_data_layout:
            assert 0
            args.append(data_layout)
        if need_auto_scheduler_layout:
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_pool2d

def wrap_compute_xm_global_avg_pool2d(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap global_avg_pool2d topi compute"""
    def _compute_global_avg_pool2d(attrs, inputs, out_type):
        data_layout = attrs.get_str("layout")
        args = [x for x in inputs]
        args.append((attrs.input_zero_point, attrs.output_zero_point))
        pool_size = get_const_tuple(attrs.pool_size)
        args.append(pool_size)
        if need_data_layout:
            assert 0
            args.append(data_layout)
        if need_auto_scheduler_layout:
            assert 0
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_global_avg_pool2d

def wrap_compute_xm_eltwiseadd(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap eltwiseadd topi compute"""
    def _compute_elt(attrs, inputs, out_type):
        args = [x for x in inputs]
        args.append(attrs.lhs_scale.data.asnumpy().tolist())
        args.append(attrs.rhs_scale.data.asnumpy().tolist())
        args.append(attrs.lhs_zero_point)
        args.append(attrs.rhs_zero_point)
        args.append(attrs.output_zero_point)
        if need_auto_scheduler_layout:
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_elt

def wrap_compute_xm_concat(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap concat topi compute"""
    def _compute_concat(attrs, inputs, out_type):
        args = list()
        args.append([x for x in inputs])
        args.append(attrs.axis)
        if need_auto_scheduler_layout:
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_concat

def wrap_compute_xm_strided_slice(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap strided_slice topi compute"""

    def _compute_strided_slice(attrs, inputs, out_type):
        start_index = attrs.begin
        end_index = attrs.end
        strides = attrs.strides
        args = [inputs[0], start_index, end_index, strides]
        if need_auto_scheduler_layout:
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_strided_slice

def wrap_compute_xm_tile(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap tile topi compute"""
    def _compute_tile(attrs, inputs, out_type):
        args = list()
        args.append(inputs[0])
        args.append(attrs.reps)
        if need_auto_scheduler_layout:
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_tile

def wrap_compute_xm_neg(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap neg topi compute"""
    def _compute_neg(attrs, inputs, out_type):
        assert len(inputs) == 1, "neg op inputs len must equals 1"
        args = list()
        args.append(inputs[0])
        args.append(out_type.dtype)
        if need_auto_scheduler_layout:
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_neg

def wrap_compute_xm_split(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap split topi compute"""

    def _compute_split(attrs, inputs, out_type):
        split_idx = attrs.indices_or_sections
        array_len = len(split_idx)
        axis = attrs.axis
        args = [inputs[0], array_len, split_idx, axis]
        if need_auto_scheduler_layout:
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return list(topi_compute(*args))

    return _compute_split

def wrap_compute_xm_clip(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap clip topi compute"""

    def _compute_clip(attrs, inputs, out_type):
        a_min = attrs.a_min
        a_max = attrs.a_max
        args = [inputs[0], a_min, a_max]
        if need_auto_scheduler_layout:
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_clip

def wrap_compute_xm_matmul(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap matmul topi compute"""
    def _compute_matmul(attrs, inputs, out_type):
        args = [x for x in inputs]
        args.append(attrs.o_shape)
        args.append(attrs.out_dtype)
        args.append(attrs.transpose_a)
        args.append(attrs.transpose_b)
        args.append(attrs.i1_zp)
        args.append(attrs.i2_zp)
        args.append(attrs.o_zp)
        args.append(attrs.quant_mode)
        args.append(attrs.f_multiplier)
        quant_coeff = ( (int(attrs.multiplier[0]),), (int(attrs.multiplier[1]),) )
        args.append(quant_coeff)
        if need_auto_scheduler_layout:
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_matmul

def wrap_compute_xm_reduce_mean(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap reduce_mean topi compute"""
    
    def _compute_reduce_mean(attrs, inputs, out_type):
        axis = attrs.axis
        args = [inputs[0], axis]
        if need_auto_scheduler_layout:
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_reduce_mean

def wrap_compute_xm_scale(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap scale topi compute"""
    def _compute_scale(attrs, inputs, out_type):
        out_dtype = attrs.out_dtype
        out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
        args = [x for x in inputs]
        if attrs.using_bias == 0:
            args[2] = None
        args.append(attrs.output_scale.data.asnumpy().tolist())
        args.append(0)              # TODO quantmode for perchanel
        args.append((attrs.input_zero_point, attrs.kernel_zero_point, attrs.output_zero_point))
        args.append(attrs.using_bias)
        args.append(attrs.relu_type)
        args.append(out_dtype)
        if need_auto_scheduler_layout:
            assert 0
            args.append(get_auto_scheduler_rewritten_layout(attrs))
        return [topi_compute(*args)]

    return _compute_scale

def wrap_compute_xm_xconv2d(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap conv2d topi compute"""
    def _compute_xconv2d(attrs, inputs, out_type):
        conv_num = len(attrs) - 2
        has_pool = attrs["pool_type"]
        if has_pool == 0:
            assert (conv_num * 2 + 1) == len(inputs)
        else:
            conv_num -= 1
            assert (conv_num * 2 + 1) == len(inputs)
        attrs_list = []
        args = []
        for i in range(0, conv_num):
            dict_key = "xm.conv2d" + str(i)
            attrs_list.append(attrs[dict_key])
            padding = get_const_tuple(attrs_list[i].padding)
            strides = get_const_tuple(attrs_list[i].strides)
            dilation = get_const_tuple(attrs_list[i].dilation)
            ins = get_const_tuple(attrs_list[i].ins)
            data_layout = attrs_list[i].get_str("data_layout")
            out_layout = attrs_list[i].get_str("out_layout")
            out_dtype = attrs_list[i].out_dtype
            out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
            args.append([])
            if i == 0:
                args[i].append(inputs[0])
            else:
                args[i].append(None)
            args[i].append(inputs[i * 2 + 1])
            args[i].append(inputs[i * 2 + 2])
            if attrs_list[i].using_bias == 0:
                args[i][2] = None
            if len(inputs[i * 2 + 1].shape) == 1:     # scale
                args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[i].append(0)              # TODO quantmode for perchanel
                args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[i].append(attrs_list[i].using_bias)
                args[i].append(attrs_list[i].relu_type)
                args[i].append(out_dtype)
            else:
                args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[i].append(0)              # TODO quantmode for perchanel
                args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[i].append(strides)
                args[i].append(padding)
                args[i].append(dilation)
                args[i].append(ins)
                args[i].append(attrs_list[i].using_bias)
                args[i].append(attrs_list[i].relu_type)
                args[i].append(attrs_list[i].groups) 
                args[i].append(out_dtype)

            if need_data_layout:
                assert 0
                args[i].append(data_layout)
            if need_out_layout:
                assert 0
                args[i].append(out_layout)
            if need_auto_scheduler_layout:
                assert 0
                args[i].append(get_auto_scheduler_rewritten_layout(attrs_list[i]))
       
        i += 1
        if has_pool == 1:
            dict_key = "xm.pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            data_layout = attrs[dict_key].get_str("layout")
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            strides = get_const_tuple(attrs[dict_key].strides)
            padding = get_const_tuple(attrs[dict_key].padding)
            args.append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            args[i].append(pool_size)
            args[i].append(strides)
            args[i].append(padding)
            args[i].append(attrs[dict_key].pool_type)
        elif has_pool == 2:
            dict_key = "xm.global_avg_pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            args.append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            args[i].append(pool_size)

        return [topi_compute(*args)]

    return _compute_xconv2d

def wrap_compute_xm_4conv2dadd(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap resnet topi compute"""
    def _compute_4conv2dadd(attrs, inputs, out_type):
        conv_num = 4
        has_pool = attrs["pool_type"]
        attrs_list = []
        args = []
        for i in range(0, conv_num):
            if i == 0:
                dict_key = "xm.conv2d" + str(1)
            elif i == 1:
                dict_key = "xm.conv2d" + str(2)
            elif i == 2:
                dict_key = "xm.conv2d" + str(3)
            else:
                dict_key = "xm.conv2d" + str(0)
            attrs_list.append(attrs[dict_key])
            padding = get_const_tuple(attrs_list[i].padding)
            strides = get_const_tuple(attrs_list[i].strides)
            dilation = get_const_tuple(attrs_list[i].dilation)
            ins = get_const_tuple(attrs_list[i].ins)
            data_layout = attrs_list[i].get_str("data_layout")
            out_layout = attrs_list[i].get_str("out_layout")
            out_dtype = attrs_list[i].out_dtype
            out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
            args.append([])
            if i == 0:
                args[i].append(inputs[0])
                args[i].append(inputs[3])
                args[i].append(inputs[4])
                shape_len = len(inputs[3].shape)
            elif i == 1:
                args[i].append(None)
                args[i].append(inputs[5])
                args[i].append(inputs[6])
                shape_len = len(inputs[5].shape)
            elif i == 2:
                args[i].append(None)
                args[i].append(inputs[7])
                args[i].append(inputs[8])
                shape_len = len(inputs[7].shape)
            else:
                args[i].append(inputs[0])
                args[i].append(inputs[1])
                args[i].append(inputs[2])
                shape_len = len(inputs[1].shape)

            if attrs_list[i].using_bias == 0:
               args[i][2] = None
        
            if shape_len == 1:     # scale
               args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
               args[i].append(0)              # TODO quantmode for perchanel
               args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
               args[i].append(attrs_list[i].using_bias)
               args[i].append(attrs_list[i].relu_type)
               args[i].append(out_dtype)
            else:
               args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
               args[i].append(0)              # TODO quantmode for perchanel
               args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
               args[i].append(strides)
               args[i].append(padding)
               args[i].append(dilation)
               args[i].append(ins)
               args[i].append(attrs_list[i].using_bias)
               args[i].append(attrs_list[i].relu_type)
               args[i].append(attrs_list[i].groups)
               args[i].append(out_dtype)

            if need_data_layout:
               assert 0
               args[i].append(data_layout)
            if need_out_layout:
               assert 0
               args[i].append(out_layout)
            if need_auto_scheduler_layout:
               assert 0
               args[i].append(get_auto_scheduler_rewritten_layout(attrs_list[i]))

        i += 1
        dict_key = "xm.eltwise_add" + str(i)
        args.append([])
        args[i].append(None)
        args[i].append(None)
        args[i].append(attrs[dict_key].lhs_scale.data.asnumpy().tolist())
        args[i].append(attrs[dict_key].rhs_scale.data.asnumpy().tolist())
        args[i].append(attrs[dict_key].lhs_zero_point)
        args[i].append(attrs[dict_key].rhs_zero_point)
        args[i].append(attrs[dict_key].output_zero_point)
        i += 1
        if has_pool == 1:
            dict_key = "xm.pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            data_layout = attrs[dict_key].get_str("layout")
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            strides = get_const_tuple(attrs[dict_key].strides)
            padding = get_const_tuple(attrs[dict_key].padding)
            args.append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            args[i].append(pool_size)
            args[i].append(strides)
            args[i].append(padding)
            pool_type = attrs[dict_key].pool_type
            args[i].append(pool_type)
        elif has_pool == 2:
            dict_key = "xm.global_avg_pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            args[i].append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            args[i].append(pool_size)

        return [topi_compute(*args)]
    return _compute_4conv2dadd


def wrap_compute_xm_3convpooladd(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap resnet topi compute"""
    def _compute_3convpooladd(attrs, inputs, out_type):
        conv_num = 3
        has_pool = attrs["pool_type"]
        attrs_list = []
        args = []
        for i in range(1, conv_num + 1):
            dict_key = "xm.conv2d" + str(i)
            j = i - 1
            attrs_list.append(attrs[dict_key])
            padding = get_const_tuple(attrs_list[j].padding)
            strides = get_const_tuple(attrs_list[j].strides)
            dilation = get_const_tuple(attrs_list[j].dilation)
            ins = get_const_tuple(attrs_list[j].ins)
            data_layout = attrs_list[j].get_str("data_layout")
            out_layout = attrs_list[j].get_str("out_layout")
            out_dtype = attrs_list[j].out_dtype
            out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
            args.append([])
            if i == 1:
                args[j].append(inputs[0])
                args[j].append(inputs[1])
                args[j].append(inputs[2])
                shape_len = len(inputs[1].shape)
            elif i == 2:
                args[j].append(None)
                args[j].append(inputs[3])
                args[j].append(inputs[4])
                shape_len = len(inputs[3].shape)
            elif i == 3:
                args[j].append(None)
                args[j].append(inputs[5])
                args[j].append(inputs[6])
                shape_len = len(inputs[5].shape)

            if attrs_list[j].using_bias == 0:
               args[j][2] = None
        
            if shape_len == 1:     # scale
               args[j].append(attrs_list[j].output_scale.data.asnumpy().tolist())
               args[j].append(0)              # TODO quantmode for perchanel
               args[j].append((attrs_list[j].input_zero_point, attrs_list[j].kernel_zero_point, attrs_list[j].output_zero_point))
               args[j].append(attrs_list[j].using_bias)
               args[j].append(attrs_list[j].relu_type)
               args[j].append(out_dtype)
            else:
               args[j].append(attrs_list[j].output_scale.data.asnumpy().tolist())
               args[j].append(0)              # TODO quantmode for perchanel
               args[j].append((attrs_list[j].input_zero_point, attrs_list[j].kernel_zero_point, attrs_list[j].output_zero_point))
               args[j].append(strides)
               args[j].append(padding)
               args[j].append(dilation)
               args[j].append(ins)
               args[j].append(attrs_list[j].using_bias)
               args[j].append(attrs_list[j].relu_type)
               args[j].append(attrs_list[j].groups)
               args[j].append(out_dtype)

            if need_data_layout:
               assert 0
               args[j].append(data_layout)
            if need_out_layout:
               assert 0
               args[j].append(out_layout)
            if need_auto_scheduler_layout:
               assert 0
               args[j].append(get_auto_scheduler_rewritten_layout(attrs_list[j]))
        
        i = 3
        dict_key = "xm.pool2d" + str(0)
        #attrs_list.append(attrs[dict_key])
        data_layout = attrs[dict_key].get_str("layout")
        pool_size = get_const_tuple(attrs[dict_key].pool_size)
        strides = get_const_tuple(attrs[dict_key].strides)
        padding = get_const_tuple(attrs[dict_key].padding)
        args.append([])
        args[i].append(inputs[0])
        args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
        args[i].append(pool_size)
        args[i].append(strides)
        args[i].append(padding)
        pool_type = attrs[dict_key].pool_type
        args[i].append(pool_type)
        
        i += 1
        dict_key = "xm.eltwise_add" + str(i)
        args.append([])
        args[i].append(None)
        args[i].append(None)
        args[i].append(attrs[dict_key].lhs_scale.data.asnumpy().tolist())
        args[i].append(attrs[dict_key].rhs_scale.data.asnumpy().tolist())
        args[i].append(attrs[dict_key].lhs_zero_point)
        args[i].append(attrs[dict_key].rhs_zero_point)
        args[i].append(attrs[dict_key].output_zero_point)
        i += 1
        if len(attrs) < 8:
            return [topi_compute(*args)]
        if has_pool == 1:
            dict_key = "xm.pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            data_layout = attrs[dict_key].get_str("layout")
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            strides = get_const_tuple(attrs[dict_key].strides)
            padding = get_const_tuple(attrs[dict_key].padding)
            args.append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            args[i].append(pool_size)
            args[i].append(strides)
            args[i].append(padding)
            pool_type = attrs[dict_key].pool_type
            args[i].append(pool_type)
        elif has_pool == 2:
            dict_key = "xm.global_avg_pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            args[i].append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            args[i].append(pool_size)

        return [topi_compute(*args)]
    return _compute_3convpooladd




def wrap_compute_xm_xconv2dadd(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap resnet topi compute"""
    def _compute_xconv2dadd(attrs, inputs, out_type):
        conv_num = len(attrs) - 3
        has_pool = attrs["pool_type"]
        if has_pool == 0:
            assert (conv_num * 2 + 1) == len(inputs)
        else:
            conv_num -= 1
            assert (conv_num * 2 + 1) == len(inputs)
        attrs_list = []
        args = []
        for i in range(0, conv_num):
            dict_key = "xm.conv2d" + str(i)
            attrs_list.append(attrs[dict_key])
            padding = get_const_tuple(attrs_list[i].padding)
            strides = get_const_tuple(attrs_list[i].strides)
            dilation = get_const_tuple(attrs_list[i].dilation)
            ins = get_const_tuple(attrs_list[i].ins)
            data_layout = attrs_list[i].get_str("data_layout")
            out_layout = attrs_list[i].get_str("out_layout")
            out_dtype = attrs_list[i].out_dtype
            out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
            args.append([])
            
            if i == 0:
               args[i].append(inputs[0])
            else:
               args[i].append(None)
            args[i].append(inputs[i * 2 + 1])
            args[i].append(inputs[i * 2 + 2])
            if attrs_list[i].using_bias == 0:
               args[i][2] = None
        
            if len(inputs[i * 2 + 1].shape) == 1:     # scale
               args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
               args[i].append(0)              # TODO quantmode for perchanel
               args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
               args[i].append(attrs_list[i].using_bias)
               args[i].append(attrs_list[i].relu_type)
               args[i].append(out_dtype)
            else:
               args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
               args[i].append(0)              # TODO quantmode for perchanel
               args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
               args[i].append(strides)
               args[i].append(padding)
               args[i].append(dilation)
               args[i].append(ins)
               args[i].append(attrs_list[i].using_bias)
               args[i].append(attrs_list[i].relu_type)
               args[i].append(attrs_list[i].groups)
               args[i].append(out_dtype)

            if need_data_layout:
               assert 0
               args[i].append(data_layout)
            if need_out_layout:
               assert 0
               args[i].append(out_layout)
            if need_auto_scheduler_layout:
               assert 0
               args[i].append(get_auto_scheduler_rewritten_layout(attrs_list[i]))

        i += 1
        dict_key = "xm.eltwise_add" + str(i)
        args.append([])
        args[i].append(inputs[0])
        args[i].append(None)
        args[i].append(attrs[dict_key].lhs_scale.data.asnumpy().tolist())
        args[i].append(attrs[dict_key].rhs_scale.data.asnumpy().tolist())
        args[i].append(attrs[dict_key].lhs_zero_point)
        args[i].append(attrs[dict_key].rhs_zero_point)
        args[i].append(attrs[dict_key].output_zero_point)
        i += 1
        if has_pool == 1:
            dict_key = "xm.pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            data_layout = attrs[dict_key].get_str("layout")
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            strides = get_const_tuple(attrs[dict_key].strides)
            padding = get_const_tuple(attrs[dict_key].padding)
            args.append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            args[i].append(pool_size)
            args[i].append(strides)
            args[i].append(padding)
            pool_type = attrs[dict_key].pool_type
            args[i].append(pool_type)
        elif has_pool == 2:
            dict_key = "xm.global_avg_pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            args.append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            args[i].append(pool_size)

        return [topi_compute(*args)]
    return _compute_xconv2dadd


def wrap_compute_xm_mobinet(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap resnet topi compute"""
    def _compute_mobinet(attrs, inputs, out_type):
        if len(attrs) >= 6:
            conv_num = 3
            has_eltadd = 1
        else:
            conv_num = len(attrs) - 2
            has_eltadd = 0

        has_pool = attrs["pool_type"]
        if has_pool != 0:
            assert (has_eltadd == 1)

        if has_eltadd == 1:
            assert (conv_num * 2 + 1) == len(inputs)
        else:
            assert (conv_num * 2 + 1) == len(inputs)
        attrs_list = []
        args = []
        for i in range(0, conv_num):
            dict_key = "xm.conv2d" + str(i)
            attrs_list.append(attrs[dict_key])
            padding = get_const_tuple(attrs_list[i].padding)
            strides = get_const_tuple(attrs_list[i].strides)
            dilation = get_const_tuple(attrs_list[i].dilation)
            ins = get_const_tuple(attrs_list[i].ins)
            data_layout = attrs_list[i].get_str("data_layout")
            out_layout = attrs_list[i].get_str("out_layout")
            out_dtype = attrs_list[i].out_dtype
            out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
            args.append([])
            
            if i == 0:
               args[i].append(inputs[0])
            else:
               args[i].append(None)
            args[i].append(inputs[i * 2 + 1])
            args[i].append(inputs[i * 2 + 2])
            if attrs_list[i].using_bias == 0:
               args[i][2] = None
        
            if len(inputs[i * 2 + 1].shape) == 1:     # scale
               args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
               args[i].append(0)              # TODO quantmode for perchanel
               args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
               args[i].append(attrs_list[i].using_bias)
               args[i].append(attrs_list[i].relu_type)
               args[i].append(out_dtype)
            else:
               args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
               args[i].append(0)              # TODO quantmode for perchanel
               args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
               args[i].append(strides)
               args[i].append(padding)
               args[i].append(dilation)
               args[i].append(ins)
               args[i].append(attrs_list[i].using_bias)
               args[i].append(attrs_list[i].relu_type)
               args[i].append(attrs_list[i].groups)
               args[i].append(out_dtype)

            if need_data_layout:
               assert 0
               args[i].append(data_layout)
            if need_out_layout:
               assert 0
               args[i].append(out_layout)
            if need_auto_scheduler_layout:
               assert 0
               args[i].append(get_auto_scheduler_rewritten_layout(attrs_list[i]))

        if has_eltadd == 1:
            i += 1
            dict_key = "xm.eltwise_add" + str(i)
            args.append([])
            args[i].append(inputs[0])
            args[i].append(None)
            args[i].append(attrs[dict_key].lhs_scale.data.asnumpy().tolist())
            args[i].append(attrs[dict_key].rhs_scale.data.asnumpy().tolist())
            args[i].append(attrs[dict_key].lhs_zero_point)
            args[i].append(attrs[dict_key].rhs_zero_point)
            args[i].append(attrs[dict_key].output_zero_point)
        i += 1
        if has_pool == 1:
            dict_key = "xm.pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            data_layout = attrs[dict_key].get_str("layout")
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            strides = get_const_tuple(attrs[dict_key].strides)
            padding = get_const_tuple(attrs[dict_key].padding)
            args.append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            args[i].append(pool_size)
            args[i].append(strides)
            args[i].append(padding)
            pool_type = attrs[dict_key].pool_type
            args[i].append(pool_type)
        elif has_pool == 2:
            dict_key = "xm.global_avg_pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            args.append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            args[i].append(pool_size)

        return [topi_compute(*args)]
    return _compute_mobinet


def wrap_compute_xm_triplepoolconcat(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap conv2d topi compute"""
    def _compute_triplepoolconcat(attrs, inputs, out_type):
        pool_num = 3
        """
        has_pool = attrs["pool_type"]
        if has_pool == 0:
            assert (conv_num * 2 + 1) == len(inputs)
        else:
            conv_num -= 1
            assert (conv_num * 2 + 1) == len(inputs)
        attrs_list = []
        """
        args = []
        for i in range(0, pool_num):
            dict_key = "xm.pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            data_layout = attrs[dict_key].get_str("layout")
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            strides = get_const_tuple(attrs[dict_key].strides)
            padding = get_const_tuple(attrs[dict_key].padding)
            args.append([])
            if i == 0:
                args[i].append(inputs[0])
            else:
                args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            args[i].append(pool_size)
            args[i].append(strides)
            args[i].append(padding)
            args[i].append(attrs[dict_key].pool_type)

        return [topi_compute(*args)]

    return _compute_triplepoolconcat


def wrap_compute_xm_xconv2d_upsample(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap conv2d topi compute"""
    def _compute_xconv2d_upsample(attrs, inputs, out_type):
        conv_num = len(attrs) - 3
        """
        has_pool = attrs["pool_type"]
        if has_pool == 0:
            assert (conv_num * 2 + 1) == len(inputs)
        else:
            conv_num -= 1
            assert (conv_num * 2 + 1) == len(inputs)
        """
        attrs_list = []
        args = []
        for i in range(0, conv_num):
            dict_key = "xm.conv2d" + str(i)
            attrs_list.append(attrs[dict_key])
            padding = get_const_tuple(attrs_list[i].padding)
            strides = get_const_tuple(attrs_list[i].strides)
            dilation = get_const_tuple(attrs_list[i].dilation)
            ins = get_const_tuple(attrs_list[i].ins)
            data_layout = attrs_list[i].get_str("data_layout")
            out_layout = attrs_list[i].get_str("out_layout")
            out_dtype = attrs_list[i].out_dtype
            out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
            args.append([])
            if i == 0:
                args[i].append(inputs[0])
            else:
                args[i].append(None)
            args[i].append(inputs[i * 2 + 1])
            args[i].append(inputs[i * 2 + 2])
            if attrs_list[i].using_bias == 0:
                args[i][2] = None
            if len(inputs[i * 2 + 1].shape) == 1:     # scale
                args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[i].append(0)              # TODO quantmode for perchanel
                args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[i].append(attrs_list[i].using_bias)
                args[i].append(attrs_list[i].relu_type)
                args[i].append(out_dtype)
            else:
                args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[i].append(0)              # TODO quantmode for perchanel
                args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[i].append(strides)
                args[i].append(padding)
                args[i].append(dilation)
                args[i].append(ins)
                args[i].append(attrs_list[i].using_bias)
                args[i].append(attrs_list[i].relu_type)
                args[i].append(attrs_list[i].groups) 
                args[i].append(out_dtype)

            if need_data_layout:
                assert 0
                args[i].append(data_layout)
            if need_out_layout:
                assert 0
                args[i].append(out_layout)
            if need_auto_scheduler_layout:
                assert 0
                args[i].append(get_auto_scheduler_rewritten_layout(attrs_list[i]))
       
        i += 1
        dict_key = "nn.upsampling" + str(i)
        scale_h = int(attrs[dict_key].scale_h)
        scale_w = int(attrs[dict_key].scale_w)
        args.append([])
        args[i].append(None)
        args[i].append(scale_h)
        args[i].append(scale_w)

        return [topi_compute(*args)]

    return _compute_xconv2d_upsample


def wrap_compute_xm_convpooldoubleconv(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap conv2d topi compute"""
    def _compute_convpooldoubleconv(attrs, inputs, out_type):
        conv_num = 3
        """
        has_pool = attrs["pool_type"]
        if has_pool == 0:
            assert (conv_num * 2 + 1) == len(inputs)
        else:
            conv_num -= 1
            assert (conv_num * 2 + 1) == len(inputs)
        """
        attrs_list = []
        args = []
        for i in range(0, conv_num):
            if i == 1:
                args.append([]) #for pool
            if i == 0:
                j = i
            else:
                j = i + 1
            dict_key = "xm.conv2d" + str(j)
            attrs_list.append(attrs[dict_key])

            padding = get_const_tuple(attrs[dict_key].padding)
            strides = get_const_tuple(attrs[dict_key].strides)
            dilation = get_const_tuple(attrs[dict_key].dilation)
            ins = get_const_tuple(attrs[dict_key].ins)
            data_layout = attrs[dict_key].get_str("data_layout")
            out_layout = attrs[dict_key].get_str("out_layout")
            out_dtype = attrs[dict_key].out_dtype
            out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
            args.append([])
            if i == 0:
                args[j].append(inputs[0])
            else:
                args[j].append(None)
            args[j].append(inputs[i * 2 + 1])
            args[j].append(inputs[i * 2 + 2])
            if attrs[dict_key].using_bias == 0:
                args[j][2] = None
            if len(inputs[i * 2 + 1].shape) == 1:     # scale
                args[j].append(attrs[dict_key].output_scale.data.asnumpy().tolist())
                args[j].append(0)              # TODO quantmode for perchanel
                args[j].append((attrs[dict_key].input_zero_point, attrs[dict_key].kernel_zero_point, attrs[dict_key].output_zero_point))
                args[j].append(attrs[dict_key].using_bias)
                args[j].append(attrs[dict_key].relu_type)
                args[j].append(out_dtype)
            else:
                args[j].append(attrs[dict_key].output_scale.data.asnumpy().tolist())
                args[j].append(0)              # TODO quantmode for perchanel
                args[j].append((attrs[dict_key].input_zero_point, attrs[dict_key].kernel_zero_point, attrs[dict_key].output_zero_point))
                args[j].append(strides)
                args[j].append(padding)
                args[j].append(dilation)
                args[j].append(ins)
                args[j].append(attrs[dict_key].using_bias)
                args[j].append(attrs[dict_key].relu_type)
                args[j].append(attrs[dict_key].groups) 
                args[j].append(out_dtype)
       
        dict_key = "xm.pool2d" + str(1)
        #attrs_list.append(attrs[dict_key])
        data_layout = attrs[dict_key].get_str("layout")
        pool_size = get_const_tuple(attrs[dict_key].pool_size)
        strides = get_const_tuple(attrs[dict_key].strides)
        padding = get_const_tuple(attrs[dict_key].padding)
        args[1].append(None)
        args[1].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
        args[1].append(pool_size)
        args[1].append(strides)
        args[1].append(padding)
        args[1].append(attrs[dict_key].pool_type)

        return [topi_compute(*args)]

    return _compute_convpooldoubleconv


def wrap_compute_xm_3conv2dconcat(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap conv2d topi compute"""
    def _compute_3conv2dconcat(attrs, inputs, out_type):
        conv_num = 3
        has_pool = attrs["pool_type"]
        assert (conv_num * 2 + 1) == len(inputs)
        attrs_list = []
        args = []
        for i in range(0, conv_num):
            dict_key = "xm.conv2d" + str(i)
            attrs_list.append(attrs[dict_key])
            padding = get_const_tuple(attrs_list[i].padding)
            strides = get_const_tuple(attrs_list[i].strides)
            dilation = get_const_tuple(attrs_list[i].dilation)
            ins = get_const_tuple(attrs_list[i].ins)
            data_layout = attrs_list[i].get_str("data_layout")
            out_layout = attrs_list[i].get_str("out_layout")
            out_dtype = attrs_list[i].out_dtype
            out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
            args.append([])
            if i == 0:
                args[i].append(inputs[0])
            else:
                args[i].append(None)
            args[i].append(inputs[i * 2 + 1])
            args[i].append(inputs[i * 2 + 2])
            if attrs_list[i].using_bias == 0:
                args[i][2] = None
            if len(inputs[i * 2 + 1].shape) == 1:     # scale
                args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[i].append(0)              # TODO quantmode for perchanel
                args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[i].append(attrs_list[i].using_bias)
                args[i].append(attrs_list[i].relu_type)
                args[i].append(out_dtype)
            else:
                args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[i].append(0)              # TODO quantmode for perchanel
                args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[i].append(strides)
                args[i].append(padding)
                args[i].append(dilation)
                args[i].append(ins)
                args[i].append(attrs_list[i].using_bias)
                args[i].append(attrs_list[i].relu_type)
                args[i].append(attrs_list[i].groups) 
                args[i].append(out_dtype)

            if need_data_layout:
                assert 0
                args[i].append(data_layout)
            if need_out_layout:
                assert 0
                args[i].append(out_layout)
            if need_auto_scheduler_layout:
                assert 0
                args[i].append(get_auto_scheduler_rewritten_layout(attrs_list[i]))
       
        i += 2 #skip concat
        if has_pool == 1:
            dict_key = "xm.pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            data_layout = attrs[dict_key].get_str("layout")
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            strides = get_const_tuple(attrs[dict_key].strides)
            padding = get_const_tuple(attrs[dict_key].padding)
            args.append([])
            args[i - 1].append(None)
            args[i - 1].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            args[i - 1].append(pool_size)
            args[i - 1].append(strides)
            args[i - 1].append(padding)
            args[i - 1].append(attrs[dict_key].pool_type)
        elif has_pool == 2:
            dict_key = "xm.global_avg_pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            args.append([])
        return [topi_compute(*args)]

    return _compute_3conv2dconcat


def wrap_compute_xm_dwdoubleconvconcat(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap dwdoubleconcat topi compute"""
    def _compute_dwdoubleconvconcat(attrs, inputs, out_type):
        conv_num = len(attrs) - 3
        has_pool = attrs["pool_type"]
        assert(has_pool == 0)
        assert (conv_num * 2 + 1) == len(inputs)
        attrs_list = []
        args = []
        for i in range(0, conv_num):
            dict_key = "xm.conv2d" + str(i)
            attrs_list.append(attrs[dict_key])
            padding = get_const_tuple(attrs_list[i].padding)
            strides = get_const_tuple(attrs_list[i].strides)
            dilation = get_const_tuple(attrs_list[i].dilation)
            ins = get_const_tuple(attrs_list[i].ins)
            data_layout = attrs_list[i].get_str("data_layout")
            out_layout = attrs_list[i].get_str("out_layout")
            out_dtype = attrs_list[i].out_dtype
            out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
            args.append([])
            if i == 0:
                args[i].append(inputs[0])
            else:
                args[i].append(None)
            args[i].append(inputs[i * 2 + 1])
            args[i].append(inputs[i * 2 + 2])
            if attrs_list[i].using_bias == 0:
                args[i][2] = None
            if len(inputs[i * 2 + 1].shape) == 1:     # scale
                args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[i].append(0)              # TODO quantmode for perchanel
                args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[i].append(attrs_list[i].using_bias)
                args[i].append(attrs_list[i].relu_type)
                args[i].append(out_dtype)
            else:
                args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[i].append(0)              # TODO quantmode for perchanel
                args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[i].append(strides)
                args[i].append(padding)
                args[i].append(dilation)
                args[i].append(ins)
                args[i].append(attrs_list[i].using_bias)
                args[i].append(attrs_list[i].relu_type)
                args[i].append(attrs_list[i].groups) 
                args[i].append(out_dtype)

            if need_data_layout:
                assert 0
                args[i].append(data_layout)
            if need_out_layout:
                assert 0
                args[i].append(out_layout)
            if need_auto_scheduler_layout:
                assert 0
                args[i].append(get_auto_scheduler_rewritten_layout(attrs_list[i]))
        return [topi_compute(*args)]

    return _compute_dwdoubleconvconcat


def wrap_compute_xm_dw2convdwconvconcat(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap dw2convdwconvconcat topi compute"""
    def _compute_dw2convdwconvconcat(attrs, inputs, out_type):
        conv_num = 5
        has_pool = attrs["pool_type"]
        assert(has_pool == 0)
        assert (conv_num * 2 + 1) == len(inputs)
        attrs_list = []
        args = []
        for i in range(0, conv_num):
            dict_key = "xm.conv2d" + str(i)
            attrs_list.append(attrs[dict_key])
            padding = get_const_tuple(attrs_list[i].padding)
            strides = get_const_tuple(attrs_list[i].strides)
            dilation = get_const_tuple(attrs_list[i].dilation)
            ins = get_const_tuple(attrs_list[i].ins)
            data_layout = attrs_list[i].get_str("data_layout")
            out_layout = attrs_list[i].get_str("out_layout")
            out_dtype = attrs_list[i].out_dtype
            out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
            args.append([])
            if i == 0:
                args[i].append(inputs[0])
            else:
                args[i].append(None)
            index = i * 2 + 1
            args[i].append(inputs[index])
            args[i].append(inputs[index + 1])
            if attrs_list[i].using_bias == 0:
                args[i][2] = None
            if len(inputs[index].shape) == 1:     # scale
                args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[i].append(0)              # TODO quantmode for perchanel
                args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[i].append(attrs_list[i].using_bias)
                args[i].append(attrs_list[i].relu_type)
                args[i].append(out_dtype)
            else:
                args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[i].append(0)              # TODO quantmode for perchanel
                args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[i].append(strides)
                args[i].append(padding)
                args[i].append(dilation)
                args[i].append(ins)
                args[i].append(attrs_list[i].using_bias)
                args[i].append(attrs_list[i].relu_type)
                args[i].append(attrs_list[i].groups) 
                args[i].append(out_dtype)

            if need_data_layout:
                assert 0
                args[i].append(data_layout)
            if need_out_layout:
                assert 0
                args[i].append(out_layout)
            if need_auto_scheduler_layout:
                assert 0
                args[i].append(get_auto_scheduler_rewritten_layout(attrs_list[i]))
        return [topi_compute(*args)]

    return _compute_dw2convdwconvconcat


def wrap_compute_xm_3conv2daddtype2(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap 3convaddtype2 topi compute"""
    def _compute_3conv2daddtype2(attrs, inputs, out_type):
        conv_num = 3
        has_pool = attrs["pool_type"]
        if has_pool == 0:
            assert (conv_num * 2 + 1) == len(inputs)
        attrs_list = []
        args = []
        for i in range(0, conv_num):
            dict_key = "xm.conv2d" + str(i)
            attrs_list.append(attrs[dict_key])
            padding = get_const_tuple(attrs_list[i].padding)
            strides = get_const_tuple(attrs_list[i].strides)
            dilation = get_const_tuple(attrs_list[i].dilation)
            ins = get_const_tuple(attrs_list[i].ins)
            data_layout = attrs_list[i].get_str("data_layout")
            out_layout = attrs_list[i].get_str("out_layout")
            out_dtype = attrs_list[i].out_dtype
            out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
            args.append([])
            if i == 0:
                args[i].append(inputs[0])
            else:
                args[i].append(None)
            index = 0
            if i == 0:
                args[i].append(inputs[5])
                args[i].append(inputs[6])
                index = 5
            elif i == 1:
                args[i].append(inputs[1])
                args[i].append(inputs[2])
                index = 1
            else:
                args[i].append(inputs[3])
                args[i].append(inputs[4])
                index = 3

            if attrs_list[i].using_bias == 0:
               args[i][2] = None
        
            if len(inputs[index].shape) == 1:     # scale
               args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
               args[i].append(0)              # TODO quantmode for perchanel
               args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
               args[i].append(attrs_list[i].using_bias)
               args[i].append(attrs_list[i].relu_type)
               args[i].append(out_dtype)
            else:
               args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
               args[i].append(0)              # TODO quantmode for perchanel
               args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
               args[i].append(strides)
               args[i].append(padding)
               args[i].append(dilation)
               args[i].append(ins)
               args[i].append(attrs_list[i].using_bias)
               args[i].append(attrs_list[i].relu_type)
               args[i].append(attrs_list[i].groups)
               args[i].append(out_dtype)

            if need_data_layout:
               assert 0
               args[i].append(data_layout)
            if need_out_layout:
               assert 0
               args[i].append(out_layout)
            if need_auto_scheduler_layout:
               assert 0
               args[i].append(get_auto_scheduler_rewritten_layout(attrs_list[i]))

        i += 1
        dict_key = "xm.eltwise_add" + str(i)
        args.append([])
        args[i].append(None)
        args[i].append(None)
        args[i].append(attrs[dict_key].lhs_scale.data.asnumpy().tolist())
        args[i].append(attrs[dict_key].rhs_scale.data.asnumpy().tolist())
        args[i].append(attrs[dict_key].lhs_zero_point)
        args[i].append(attrs[dict_key].rhs_zero_point)
        args[i].append(attrs[dict_key].output_zero_point)
        i += 1
        if has_pool == 1:
            dict_key = "xm.pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            data_layout = attrs[dict_key].get_str("layout")
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            strides = get_const_tuple(attrs[dict_key].strides)
            padding = get_const_tuple(attrs[dict_key].padding)
            args.append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            args[i].append(pool_size)
            args[i].append(strides)
            args[i].append(padding)
            pool_type = attrs[dict_key].pool_type
            args[i].append(pool_type)
        elif has_pool == 2:
            dict_key = "xm.global_avg_pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            args.append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            args[i].append(pool_size)

        return [topi_compute(*args)]
    return _compute_3conv2daddtype2


def wrap_compute_xm_quadconvpoolconcat(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap quadconvpoolconcat topi compute"""
    def _compute_quadconvpoolconcat(attrs, inputs, out_type):
        conv_num = 4
        has_pool = attrs["pool_type"]
        assert(has_pool != 0)
        assert (conv_num * 2 + 1) == len(inputs)
        attrs_list = []
        args = []
        for i in range(0, conv_num):
            dict_key = "xm.conv2d" + str(i)
            attrs_list.append(attrs[dict_key])
            padding = get_const_tuple(attrs_list[i].padding)
            strides = get_const_tuple(attrs_list[i].strides)
            dilation = get_const_tuple(attrs_list[i].dilation)
            ins = get_const_tuple(attrs_list[i].ins)
            data_layout = attrs_list[i].get_str("data_layout")
            out_layout = attrs_list[i].get_str("out_layout")
            out_dtype = attrs_list[i].out_dtype
            out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
            args.append([])
            if i == 0:
                args[i].append(inputs[0])
            else:
                args[i].append(None)
            index = i * 2 + 1
            args[i].append(inputs[index])
            args[i].append(inputs[index + 1])
            if attrs_list[i].using_bias == 0:
                args[i][2] = None
            if len(inputs[index].shape) == 1:     # scale
                args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[i].append(0)              # TODO quantmode for perchanel
                args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[i].append(attrs_list[i].using_bias)
                args[i].append(attrs_list[i].relu_type)
                args[i].append(out_dtype)
            else:
                args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[i].append(0)              # TODO quantmode for perchanel
                args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[i].append(strides)
                args[i].append(padding)
                args[i].append(dilation)
                args[i].append(ins)
                args[i].append(attrs_list[i].using_bias)
                args[i].append(attrs_list[i].relu_type)
                args[i].append(attrs_list[i].groups) 
                args[i].append(out_dtype)

            if need_data_layout:
                assert 0
                args[i].append(data_layout)
            if need_out_layout:
                assert 0
                args[i].append(out_layout)
            if need_auto_scheduler_layout:
                assert 0
                args[i].append(get_auto_scheduler_rewritten_layout(attrs_list[i]))

        i += 1
        if has_pool == 1:
            dict_key = "xm.pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            data_layout = attrs[dict_key].get_str("layout")
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            strides = get_const_tuple(attrs[dict_key].strides)
            padding = get_const_tuple(attrs[dict_key].padding)
            args.append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            args[i].append(pool_size)
            args[i].append(strides)
            args[i].append(padding)
            pool_type = attrs[dict_key].pool_type
            args[i].append(pool_type)
        elif has_pool == 2:
            dict_key = "xm.global_avg_pool2d" + str(i)
            #attrs_list.append(attrs[dict_key])
            args.append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            args[i].append(pool_size)

        return [topi_compute(*args)]

    return _compute_quadconvpoolconcat


def wrap_compute_xm_dw3convlpooladd(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap dw3convlpooladd topi compute"""
    def _compute_dw3convlpooladd(attrs, inputs, out_type):
        conv_num = 4
        has_pool = attrs["pool_type"]
        assert (conv_num * 2 + 1) == len(inputs)
        attrs_list = []
        args = []
        for i in range(0, conv_num):
            dict_key = "xm.conv2d" + str(i + 1)
            attrs_list.append(attrs[dict_key])
            padding = get_const_tuple(attrs_list[i].padding)
            strides = get_const_tuple(attrs_list[i].strides)
            dilation = get_const_tuple(attrs_list[i].dilation)
            ins = get_const_tuple(attrs_list[i].ins)
            data_layout = attrs_list[i].get_str("data_layout")
            out_layout = attrs_list[i].get_str("out_layout")
            out_dtype = attrs_list[i].out_dtype
            out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
            args.append([])
            if i == 0:
                args[i].append(inputs[0])
            else:
                args[i].append(None)
            args[i].append(inputs[i * 2 + 1])
            args[i].append(inputs[i * 2 + 2])
            if attrs_list[i].using_bias == 0:
                args[i][2] = None
            if len(inputs[i * 2 + 1].shape) == 1:     # scale
                args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[i].append(0)              # TODO quantmode for perchanel
                args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[i].append(attrs_list[i].using_bias)
                args[i].append(attrs_list[i].relu_type)
                args[i].append(out_dtype)
            else:
                args[i].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[i].append(0)              # TODO quantmode for perchanel
                args[i].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[i].append(strides)
                args[i].append(padding)
                args[i].append(dilation)
                args[i].append(ins)
                args[i].append(attrs_list[i].using_bias)
                args[i].append(attrs_list[i].relu_type)
                args[i].append(attrs_list[i].groups) 
                args[i].append(out_dtype)

            if need_data_layout:
                assert 0
                args[i].append(data_layout)
            if need_out_layout:
                assert 0
                args[i].append(out_layout)
            if need_auto_scheduler_layout:
                assert 0
                args[i].append(get_auto_scheduler_rewritten_layout(attrs_list[i]))
       
        i += 1
        dict_key = "xm.pool2d" + str(0)
        #attrs_list.append(attrs[dict_key])
        data_layout = attrs[dict_key].get_str("layout")
        pool_size = get_const_tuple(attrs[dict_key].pool_size)
        strides = get_const_tuple(attrs[dict_key].strides)
        padding = get_const_tuple(attrs[dict_key].padding)
        args.append([])
        args[i].append(None)
        args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
        args[i].append(pool_size)
        args[i].append(strides)
        args[i].append(padding)
        args[i].append(attrs[dict_key].pool_type)
        
        i += 1
        dict_key = "xm.eltwise_add" + str(5)
        args.append([])
        args[i].append(None)
        args[i].append(None)
        args[i].append(attrs[dict_key].lhs_scale.data.asnumpy().tolist())
        args[i].append(attrs[dict_key].rhs_scale.data.asnumpy().tolist())
        args[i].append(attrs[dict_key].lhs_zero_point)
        args[i].append(attrs[dict_key].rhs_zero_point)
        args[i].append(attrs[dict_key].output_zero_point)
        if len(attrs) < 9:
            return [topi_compute(*args)]

        i += 1
        if has_pool == 1:
            dict_key = "xm.pool2d" + str(6)
            #attrs_list.append(attrs[dict_key])
            data_layout = attrs[dict_key].get_str("layout")
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            strides = get_const_tuple(attrs[dict_key].strides)
            padding = get_const_tuple(attrs[dict_key].padding)
            args.append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            args[i].append(pool_size)
            args[i].append(strides)
            args[i].append(padding)
            args[i].append(attrs[dict_key].pool_type)
        elif has_pool == 2:
            dict_key = "xm.global_avg_pool2d" + str(6)
            #attrs_list.append(attrs[dict_key])
            args.append([])
            args[i].append(None)
            args[i].append((attrs[dict_key].input_zero_point, attrs[dict_key].output_zero_point))
            pool_size = get_const_tuple(attrs[dict_key].pool_size)
            args[i].append(pool_size)

        return [topi_compute(*args)]

    return _compute_dw3convlpooladd


def wrap_compute_xm_spconvdwconvconcat(
    topi_compute,
    need_data_layout=False,
    need_out_layout=False,
    has_groups=False,
    need_auto_scheduler_layout=False):
    """Wrap dw2convdwconvconcat topi compute"""
    def _compute_spconvdwconvconcat(attrs, inputs, out_type):
        conv_num = 3
        has_pool = attrs["pool_type"]
        assert(has_pool == 0)
        assert (conv_num * 2 + 1) == len(inputs)
        attrs_list = []
        args = []
        dict_key = "split" + str(0)
        split_idx = attrs[dict_key].indices_or_sections
        array_len = len(split_idx)
        axis = attrs[dict_key].axis
        args.append([])
        args[0].append(inputs[0])
        args[0].append(array_len)
        args[0].append(split_idx)
        args[0].append(axis)
        if need_auto_scheduler_layout:
            assert 0
            args.append(get_auto_scheduler_rewritten_layout(attrs))

        for i in range(0, conv_num):
            j = i + 1
            dict_key = "xm.conv2d" + str(j)
            attrs_list.append(attrs[dict_key])
            padding = get_const_tuple(attrs_list[i].padding)
            strides = get_const_tuple(attrs_list[i].strides)
            dilation = get_const_tuple(attrs_list[i].dilation)
            ins = get_const_tuple(attrs_list[i].ins)
            data_layout = attrs_list[i].get_str("data_layout")
            out_layout = attrs_list[i].get_str("out_layout")
            out_dtype = attrs_list[i].out_dtype
            out_dtype = inputs[0].dtype if out_dtype in ("same", "") else out_dtype
            args.append([])
            args[j].append(None)
            index = i * 2 + 1
            args[j].append(inputs[index])
            args[j].append(inputs[index + 1])
            if attrs_list[i].using_bias == 0:
                args[j][2] = None
            if len(inputs[index].shape) == 1:     # scale
                args[j].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[j].append(0)              # TODO quantmode for perchanel
                args[j].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[j].append(attrs_list[i].using_bias)
                args[j].append(attrs_list[i].relu_type)
                args[j].append(out_dtype)
            else:
                args[j].append(attrs_list[i].output_scale.data.asnumpy().tolist())
                args[j].append(0)              # TODO quantmode for perchanel
                args[j].append((attrs_list[i].input_zero_point, attrs_list[i].kernel_zero_point, attrs_list[i].output_zero_point))
                args[j].append(strides)
                args[j].append(padding)
                args[j].append(dilation)
                args[j].append(ins)
                args[j].append(attrs_list[i].using_bias)
                args[j].append(attrs_list[i].relu_type)
                args[j].append(attrs_list[i].groups) 
                args[j].append(out_dtype)

            if need_data_layout:
                assert 0
                args[j].append(data_layout)
            if need_out_layout:
                assert 0
                args[j].append(out_layout)
            if need_auto_scheduler_layout:
                assert 0
                args[j].append(get_auto_scheduler_rewritten_layout(attrs_list[i]))
        return [topi_compute(*args)]

    return _compute_spconvdwconvconcat



@xm_transpose_strategy.register("cpu")
def xm_transpose_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_transpose(xm_transpose_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_transpose.x86"
    )
    return strategy

@xm_lut_strategy.register("cpu")
def xm_lut_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_lut(xm_lut_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_lut.x86"
    )
    return strategy

@xm_conv2d_strategy.register("cpu")
def xm_conv2d_strategy_cpu(attrs, inputs, out_type, target):
    """conv2d x86 strategy"""
    #from .. import op as _op
    strategy = _op.OpStrategy()
    group_pattern = ""
    if isinstance(attrs, tvm.ir.DictAttrs):
        group_pattern = attrs["GroupPattern"]
    else:
        assert len(inputs) == 3
        data, kernel, bias = inputs
        stride_h, stride_w = get_const_tuple(attrs.strides)
        dilation_h, dilation_w = get_const_tuple(attrs.dilation)
        groups = attrs.groups
        layout = attrs.data_layout
        kernel_layout = attrs.kernel_layout
        if dilation_h < 1 or dilation_w < 1:
            raise ValueError("dilation should be positive value")

    if group_pattern == "conv2d_pool2d":
            strategy.add_implementation(
                wrap_compute_xm_xconv2d(xm_1conv2d_compute),
                wrap_topi_schedule(xm_schedule),
                name="xm_conv2d_pool2d_nchw.x86",
            )
    elif group_pattern == "2conv2d":
            strategy.add_implementation(
                wrap_compute_xm_xconv2d(xm_2conv2d_compute),
                wrap_topi_schedule(xm_schedule),
                name="xm_2conv2d_nchw.x86",
            )
    elif group_pattern == "convdw":
            strategy.add_implementation(
                wrap_compute_xm_mobinet(xm_2conv2d_compute), #TODO
                wrap_topi_schedule(xm_schedule),
                name="xm_conv2d_dw_nchw.x86",
            )
    elif group_pattern == "dwconv":
            strategy.add_implementation(
                wrap_compute_xm_xconv2d(xm_dw_conv2d),
                wrap_topi_schedule(xm_schedule),
                name="xm.dw_conv2d_nchw.x86",
            )
    elif group_pattern == "3conv2d":
            strategy.add_implementation(
                wrap_compute_xm_xconv2d(xm_3conv2d_compute),
                wrap_topi_schedule(xm_schedule),
                name="xm_3conv2d_nchw.x86",
            )
    elif group_pattern == "convdwconv":
            strategy.add_implementation(
                wrap_compute_xm_mobinet(xm_conv2d_dw_conv2d),
                wrap_topi_schedule(xm_schedule),
                name="xm_conv2d_dw_conv2d_nchw.x86",
            )
    elif group_pattern == "4conv2d":
            strategy.add_implementation(
                wrap_compute_xm_xconv2d(xm_4conv2d_compute),
                wrap_topi_schedule(xm_schedule),
                name="xm_4conv2d_nchw.x86",
            )
    elif group_pattern == "3conv2d_add":  
           strategy.add_implementation(
                wrap_compute_xm_xconv2dadd(xm_3conv2dadd_compute),
                wrap_topi_schedule(xm_schedule),
                name="xm_3conv2dadd_nchw.x86",
            )
    elif group_pattern == "dwtripleconvadd":
           strategy.add_implementation(
                wrap_compute_xm_xconv2dadd(xm_4dwtripleconv2dadd_compute),
                wrap_topi_schedule(xm_schedule),
                name="xm_dwtripleconvadd_nchw.x86",
            )
    elif group_pattern == "doubleconvrightadd":
           strategy.add_implementation(
                wrap_compute_xm_xconv2dadd(xm_2conv2dadd_compute),
                wrap_topi_schedule(xm_schedule),
                name="xm.doubleconvrightadd.x86",
            )
    elif group_pattern == "convdwconv_add":
           strategy.add_implementation(
                wrap_compute_xm_mobinet(xm_conv2d_dw_conv2d_eltadd_compute),
                wrap_topi_schedule(xm_schedule),
                name="xm_conv2d_dw_conv2d_eltadd_nchw.x86",
            )
    elif group_pattern == "dwdoubleconvadd":
           strategy.add_implementation(
                wrap_compute_xm_xconv2dadd(xm_3dwdoubleconv2dadd_compute),
                wrap_topi_schedule(xm_schedule),
                name="xm_3dwdoubleconv2dadd_nchw.x86",
            )
    elif group_pattern == "4conv2d_add":
             strategy.add_implementation(
                wrap_compute_xm_4conv2dadd(xm_4conv2d_eltadd_compute),
                wrap_topi_schedule(xm_schedule),
                name="xm_4conv2dadd_nchw.x86",
            )
    elif group_pattern == "convupsample":
            strategy.add_implementation(
                wrap_compute_xm_xconv2d_upsample(xm_conv2dupsp_compute),
                wrap_topi_schedule(xm_schedule),
                name="convupsample_nchw.x86",
            )
    elif group_pattern == "doubleconvupsample":
            strategy.add_implementation(
                wrap_compute_xm_xconv2d_upsample(xm_2conv2dupsp_compute),
                wrap_topi_schedule(xm_schedule),
                name="doubleconvupsample_nchw.x86",
            )
    elif group_pattern == "convpooldoubleconv":
            strategy.add_implementation(
                wrap_compute_xm_convpooldoubleconv(xm_conv2d_pool2d_2conv2d),
                wrap_topi_schedule(xm_schedule),
                name="convpooldoubleconv_nchw.x86",
            )
    elif group_pattern == "tripleconvconcat":
            strategy.add_implementation(
                wrap_compute_xm_3conv2dconcat(xm_3conv2d_concat_compute),
                wrap_topi_schedule(xm_schedule),
                name="3convconvconcat_nchw.x86",
           )
    elif group_pattern == "dwdoubleconvconcat":
           strategy.add_implementation(
                wrap_compute_xm_dwdoubleconvconcat(xm_3dwconvconvconcat_compute),
                wrap_topi_schedule(xm_schedule),
                name="dwconvconvconcat_nchw.x86",
           )
    elif group_pattern == "dw2convdwconvconcat":
           strategy.add_implementation(
                wrap_compute_xm_dw2convdwconvconcat(xm_dw_2conv2d_dw_conv2d_concat_compute),
                wrap_topi_schedule(xm_schedule),
                name="dw2convdwconvconcat.x86",
           )
    elif group_pattern == "tripleconvaddtype2":
           strategy.add_implementation(
                wrap_compute_xm_3conv2daddtype2(xm_3conv2d_eltadd_type2_compute),
                wrap_topi_schedule(xm_schedule),
                name="tripleconvaddtype2.x86",
           )
    elif group_pattern == "quadconvpoolconcat":
           strategy.add_implementation(
                wrap_compute_xm_quadconvpoolconcat(xm_4conv2d_pool_concat_compute),
                wrap_topi_schedule(xm_schedule),
                name="quadconvpoolconcat.x86",
           )
    elif groups == 1:
        if layout == "NCHW":
            assert kernel_layout == "OIHW"
            strategy.add_implementation(
                wrap_compute_xm_conv2d(xm_conv2d_compute),
                wrap_topi_schedule(xm_schedule),
                name="xm_conv2d_nchw.x86",
            )
        else:
            raise RuntimeError("Unsupported conv2d layout {} for x86".format(layout))
    elif is_depthwise_conv2d(data.shape, layout, kernel.shape, kernel_layout, groups):
        if layout == "NCHW":
            assert kernel_layout == "OIHW"
            strategy.add_implementation(
                wrap_compute_xm_conv2d(xm_conv2d_compute),
                wrap_topi_schedule(xm_schedule),
                name="xm_depthwise_conv2d_nchw.x86",
            )
        else:
            raise RuntimeError("Unsupported depthwise_conv2d layout {}".format(layout))
    else:  # group_conv2d
        if layout == "NCHW":
            assert kernel_layout == "OIHW"
            strategy.add_implementation(
                wrap_compute_xm_conv2d(xm_conv2d_compute),
                wrap_topi_schedule(xm_schedule),
                name="xm_conv2d_nchw.x86",
            )
        else:
            raise RuntimeError("Unsupported group conv2d layout {} for x86".format(layout))
    return strategy

@xm_reduce_mean_strategy.register("cpu")
def xm_reduce_mean_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_reduce_mean(xm_reduce_mean_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_reduce_mean_nchw.x86",
    )
    return strategy

@xm_pool2d_strategy.register("cpu")
def xm_pool2d_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()
    group_pattern = ""
    if isinstance(attrs, tvm.ir.DictAttrs):
        group_pattern = attrs["GroupPattern"]
    else:
        layout = attrs.layout

    if group_pattern == "triplepoolconcat":
        strategy.add_implementation(
            wrap_compute_xm_triplepoolconcat(xm_3poolconcat_compute),
            wrap_topi_schedule(xm_schedule),
            name="xm_triplepoolconcat_nchw.x86",
        )
    elif group_pattern == "3convpool_add":
        strategy.add_implementation(
            wrap_compute_xm_3convpooladd(xm_3conv2dpooladd_compute),
            wrap_topi_schedule(xm_schedule),
            name="xm_3convpooladd_nchw.x86",
        )
    elif group_pattern == "dwtripleconvlpooladd":
        strategy.add_implementation(
            wrap_compute_xm_dw3convlpooladd(xm_4dwtripleconv2dlpooladd_compute),
            wrap_topi_schedule(xm_schedule),
            name="dwtripleconvlpooladd.x86",
        )
    else:
        assert layout == "NCHW"
        strategy.add_implementation(
            wrap_compute_xm_pool2d(xm_pool2d_compute),
            wrap_topi_schedule(xm_schedule),
            name="xm_pool2d_nchw.x86",
        )
    return strategy

@xm_eltwiseadd_strategy.register("cpu")
def xm_eltwiseadd_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_eltwiseadd(xm_eltwiseadd_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_pool2d_nchw.x86",
    )
    return strategy

@xm_scale_strategy.register("cpu")
def xm_scale_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_scale(xm_scale_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_scale_nchw.x86",
    )
    return strategy

@xm_dense_strategy.register("cpu")
def xm_dense_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_dense(xm_dense_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_pool2d_nchw.x86",
    )
    return strategy

@xm_yuv2rgb_strategy.register("cpu")
def xm_yuv2rgb_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_yuv2rgb(xm_yuv2rgb_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_yuv2rgb_nchw.x86",
    )
    return strategy

@xm_global_avg_pool2d_strategy.register("cpu")
def xm_global_avg_pool2d_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_global_avg_pool2d(xm_global_avg_pool2d_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_global_avg_pool2d_nchw.x86",
    )
    return strategy

@xm_concat_strategy.register("cpu")
def xm_concat_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_concat(xm_concat_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_concat_nchw.x86",
    )
    return strategy

@xm_upsample_strategy.register("cpu")
def xm_upsample_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_upsample(xm_upsample_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_upsample_nchw.x86",
    )
    return strategy

@xm_space_to_depth_strategy.register("cpu")
def xm_space_to_depth_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_space_to_depth(xm_space_to_depth_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_space_to_depth_nchw.x86",
    )
    return strategy

@xm_depth_to_space_strategy.register("cpu")
def xm_depth_to_space_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_depth_to_space(xm_depth_to_space_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_depth_to_space_nchw.x86",
    )
    return strategy

@xm_strided_slice_strategy.register("cpu")
def xm_strided_slice_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_strided_slice(xm_strided_slice_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_strided_slice_nchw.x86",
    )
    return strategy

@xm_tile_strategy.register("cpu")
def xm_tile_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_tile(xm_tile_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_tile_nchw.x86",
    )
    return strategy

@xm_neg_strategy.register("cpu")
def xm_neg_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_neg(xm_neg_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_neg_nchw.x86",
    )
    return strategy

@xm_batch_to_space_nd_strategy.register("cpu")
def xm_batch_to_space_strategy_nd_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_batch_to_space_nd(xm_batch_to_space_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_batch_to_space_nchw.x86",
    )
    return strategy

@xm_space_to_batch_nd_strategy.register("cpu")
def xm_space_to_batch_strategy_nd_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_space_to_batch_nd(xm_space_to_batch_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_space_to_batch_nchw.x86",
    )
    return strategy

@xm_split_strategy.register("cpu")
def xm_split_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()
    group_pattern = ""
    if isinstance(attrs, tvm.ir.DictAttrs):
        group_pattern = attrs["GroupPattern"]
    else:
        layout = "NCHW"
    
    if group_pattern == "spconvdwconvconcat":
        strategy.add_implementation(
            wrap_compute_xm_spconvdwconvconcat(xm_3spconvdwconvconcat_compute),
            wrap_topi_schedule(xm_schedule),
            name="xm_spconvdwconvconcat_nchw.x86",
        )
    else:
        assert layout == "NCHW"
        strategy.add_implementation(
            wrap_compute_xm_split(xm_split_compute),
            wrap_topi_schedule(xm_schedule),
            name="xm_split_nchw.x86",
        )
    return strategy

@xm_clip_strategy.register("cpu")
def xm_clip_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()

    strategy.add_implementation(
        wrap_compute_xm_clip(xm_clip_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_clip_nchw.x86",
    )
    return strategy

@xm_matmul_strategy.register("cpu")
def xm_matmul_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_matmul(xm_matmul_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_matmul_nchw.x86",
    )
    return strategy

@xm_channel_shuffle_strategy.register("cpu")
def xm_channel_shuffle_strategy_cpu(attrs, inputs, out_type, target):
    strategy = _op.OpStrategy()
    strategy.add_implementation(
        wrap_compute_xm_channel_shuffle(xm_channel_shuffle_compute),
        wrap_topi_schedule(xm_schedule),
        name="xm_channel_shuffle.x86"
    )
    return strategy
