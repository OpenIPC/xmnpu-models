# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
# pylint: disable=unused-argument
"""The register functions for the QNN dialect."""

import numpy as np

import tvm.ir
from tvm import topi
from ..relay.register import *
from tvm.relay.op import op as _op
from tvm.relay.op import OpPattern
from tvm.topi.nn.utils import get_pad_tuple
from tvm.relay.op.nn.utils import get_pad_tuple2d
from tvm.topi.utils import get_const_tuple
from tvm.target import generic_func, override_native_generic_func
from tvm.relay.op.strategy.generic import *
from .x86_normal import *

from xmnpu.environment import get_env
env = get_env()


################################################
#Group OP
################################################
def xm_1conv2d_compute(conv1_attr, pool_attr, conv_res=0, 
        unique_id=0, opt_config=0):

    conv1_args = [x for x in conv1_attr]
    output1 = xm_conv2d_compute(*conv1_args)

    if pool_attr is not None:
        pool_args    = [x for x in pool_attr]
        pool_args[0] = output1
        output1     = xm_pool2d_compute(*pool_args)

    return output1

def xm_conv2dupsp_compute(conv1_attr, upsp_attr=None, conv_res=0, 
        unique_id=0, opt_config=0):

    conv1_args = [x for x in conv1_attr]
    output1 = [xm_conv2d_compute(*conv1_args)]

    upsp_args    = [x for x in upsp_attr]
    upsp_args[0] = output1[0]
    output_p     = xm_upsample_compute(*upsp_args)
    if conv_res:
        output1 = [output1[0], output_p]
    else:
        output1 = output_p
    return output1

def xm_2conv2d_compute(conv1_attr, conv2_attr, pool_attr=None,
        unique_id=0, opt_config=0):
    '''
    input1  = conv1_attr[0]
    kernel1 = conv1_attr[1]
    bias1   = conv1_attr[2]
    quant_coeff = conv1_attr[3]
    zero_point  = conv1_attr[4]
    strides     = conv1_attr[5]
    padding     = conv1_attr[6]
    dilation    = conv1_attr[7]
    ins         = conv1_attr[8]
    using_bias  = conv1_attr[9]
    relu_type   = conv1_attr[10]
    groups      = conv1_attr[11]
    out_dtype   = conv1_attr[12]

    input2  = conv2_attr[0]
    ...
    '''
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]

    output1 = xm_conv2d_compute(*conv1_args)

    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)

    if pool_attr is not None:
        pool_args    = [x for x in pool_attr]
        pool_args[0] = output2
        output2      = xm_pool2d_compute(*pool_args)

    return output2

def xm_2conv2dupsp_compute(conv1_attr, conv2_attr, upsp_attr=None,
        unique_id=0, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]

    output1 = xm_conv2d_compute(*conv1_args)

    conv2_args[0] = output1
    output2       = xm_conv2d_compute(*conv2_args)

    upsp_args     = [x for x in upsp_attr]
    upsp_args[0]  = output2
    output2       = xm_upsample_compute(*upsp_args)

    return output2

def xm_3conv2d_compute(conv1_attr, conv2_attr, conv3_attr,
        pool_attr=None, unique_id=0, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]

    output1 = xm_conv2d_compute(*conv1_args)

    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)

    conv3_args[0] = output2
    output3 = xm_conv2d_compute(*conv3_args)

    if pool_attr is not None:
        pool_args    = [x for x in pool_attr]
        pool_args[0] = output3
        output3      = xm_pool2d_compute(*pool_args)

    return output3

def xm_3conv2d_concat_compute(conv0_attr, conv1_attr, conv2_attr, pool_attr=None, unique_id=-1, opt_config=0):
    conv0_args = [x for x in conv0_attr]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    
    output0 = xm_conv2d_compute(*conv0_args)
    conv1_args[0] = output0
    output1 = xm_conv2d_compute(*conv1_args)
    conv2_args[0] = output0
    output2 = xm_conv2d_compute(*conv2_args)
    output3 = xm_concat_compute((output1, output2), 1)
    if pool_attr:
        pool_args = [x for x in pool_attr]
        pool_args[0] = output3
        output3 = xm_pool2d_compute(*pool_args)
    return output3

def xm_4conv2d_concat_compute(conv0_attr, conv1_attr, conv2_attr, conv3_attr, unique_id=-1, opt_config=0):
    conv0_args = [x for x in conv0_attr]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    
    output0 = xm_conv2d_compute(*conv0_args)
    conv1_args[0] = output0
    output1 = xm_conv2d_compute(*conv1_args)
    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)
    conv3_args[0] = output1
    output3 = xm_conv2d_compute(*conv3_args)
    output4 = xm_concat_compute((output2, output3), 1)
    return output4

def xm_4conv2d_pool_concat_compute(conv0_attr, conv1_attr, conv2_attr, conv3_attr, 
                                    pool_attr=None, unique_id=0, opt_config=0):
    conv0_args = [x for x in conv0_attr]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]

    output0 = xm_conv2d_compute(*conv0_args)

    conv1_args[0] = conv0_args[0]
    output1 = xm_conv2d_compute(*conv1_args)
    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)
    conv3_args[0] = output2
    output3 = xm_conv2d_compute(*conv3_args)

    pool_args = [x for x in pool_attr]
    pool_args[0] = conv0_args[0]
    output4 = xm_pool2d_compute(*pool_args)
    out = xm_concat_compute((output0, output3, output4), 1)
    return out

def xm_4conv2d_compute(conv1_attr, conv2_attr, conv3_attr, conv4_attr, pool_attr=None, unique_id=0, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    conv4_args = [x for x in conv4_attr]

    output1 = xm_conv2d_compute(*conv1_args)

    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)

    conv3_args[0] = output2
    output3 = xm_conv2d_compute(*conv3_args)

    conv4_args[0] = output3
    output4 = xm_conv2d_compute(*conv4_args)
    # return output3
    if pool_attr:
        pool_args    = [x for x in pool_attr]
        pool_args[0] = output4
        output4      = xm_pool2d_compute(*pool_args)
    return output4

def xm_conv2d_pool2d_2conv2d(conv0_attr, pool_attr, conv1_attr, conv2_attr, unique_id=0, opt_config=0):
    conv0_args = [x for x in conv0_attr]
    pool_args  = [x for x in pool_attr]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    c0_out = xm_conv2d_compute(*conv0_args)
    pool_args[0] = c0_out
    p_out = xm_pool2d_compute(*pool_args)
    conv1_args[0] = p_out
    c1_out = xm_conv2d_compute(*conv1_args)
    conv2_args[0] = c1_out
    c2_out = xm_conv2d_compute(*conv2_args)
    # return c1_out
    return c2_out

def xm_conv2d_dw_conv2d(conv0_attr, conv1_attr, conv2_attr, unique_id=0, opt_config=0):
    conv0_args = [x for x in conv0_attr]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    c0_out = xm_conv2d_compute(*conv0_args)
    conv1_args[0] = c0_out
    c1_out = xm_conv2d_compute(*conv1_args)
    conv2_args[0] = c1_out
    c2_out = xm_conv2d_compute(*conv2_args)
    return c2_out

def xm_conv2d_dw_conv2d_eltadd_compute(conv1_attr, conv2_attr, conv3_attr, eltadd_attr, 
        pool_attr=None, unique_id=0, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = xm_conv2d_compute(*conv1_args)

    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)

    conv3_args[0] = output2
    output3 = xm_conv2d_compute(*conv3_args)
    # return output3

    eltadd_args[1] = output3
    output4 = xm_eltwiseadd_compute(*eltadd_args)
    if pool_attr is not None:
        pool_args    = [x for x in pool_attr]
        pool_args[0] = output4
        output4      = xm_pool2d_compute(*pool_args)
    return output4

def xm_dw_2conv2d_dw_conv2d_concat_compute(conv0_attr, conv1_attr, conv2_attr, conv3_attr, conv4_attr, 
                                                unique_id=-1, opt_config=0):
    conv0_args = [x for x in conv0_attr]                                           
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    conv4_args = [x for x in conv4_attr]

    output0 = xm_conv2d_compute(*conv0_args)
    conv1_args[0] = output0
    output1 = xm_conv2d_compute(*conv1_args)
    # return output0

    conv2_args[0] = conv0_args[0]
    output2 = xm_conv2d_compute(*conv2_args)

    conv3_args[0] = output2
    output3 = xm_conv2d_compute(*conv3_args)

    conv4_args[0] = output3
    output4 = xm_conv2d_compute(*conv4_args)

    out = xm_concat_compute((output1, output4), 1)
    return out

def xm_3conv2dadd_compute(conv1_attr, conv2_attr, conv3_attr, eltadd_attr, 
        pool_attr=None, unique_id=0, opt_config=0):
    input_data = conv1_attr[0]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = xm_conv2d_compute(*conv1_args)

    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)

    conv3_args[0] = output2
    output3 = xm_conv2d_compute(*conv3_args)

    eltadd_args[1] = output3
    output4 = xm_eltwiseadd_compute(*eltadd_args)
    if pool_attr is not None:
        if len(pool_attr) != 3:
            pool_args    = [x for x in pool_attr]
            pool_args[0] = output4
            output4      = xm_pool2d_compute(*pool_args)
        else:
            pool_args    = [x for x in pool_attr]
            pool_args[0] = output4
            output4      = xm_global_avg_pool2d_compute(*pool_args)

    return output4

def xm_4conv2d_eltadd_compute(conv1_attr, conv2_attr, conv3_attr, conv4_attr, 
            eltadd_attr, pool_attr=None, unique_id=0, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    conv4_args = [x for x in conv4_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = xm_conv2d_compute(*conv1_args)
    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)
    conv3_args[0] = output2
    output3 = xm_conv2d_compute(*conv3_args)
    output4 = xm_conv2d_compute(*conv4_args)
    eltadd_args[0] = output4
    eltadd_args[1] = output3
    output5 = xm_eltwiseadd_compute(*eltadd_args)
    if pool_attr is not None:
        pool_args    = [x for x in pool_attr]
        pool_args[0] = output5
        output5      = xm_pool2d_compute(*pool_args)
    return output5

def xm_tiling_schedule(outs):
    """Create schedule for tensors"""
    outs =  [outs] if isinstance(outs, te.tensor.Tensor) else outs
    outs = outs[-1] if isinstance(outs[0], list) else outs          # last tensor is output
    #print(outs[0])
    #print(type(outs), type(outs[0]))
    s = te.create_schedule([x.op for x in outs])

    '''

    if isinstance(outs, list):
        if isinstance(outs[0], list):
            outs = outs[0]
    elif isinstance(outs, te.tensor.Tensor):
        outs = [outs]
    
    s = te.create_schedule([x.op for x in outs])
    '''

    #print([outs[-1].op])
    #s = te.create_schedule([outs[-1].op])

    return s
    
def xm_3poolconcat_compute(pool1_attr, pool2_attr, pool3_attr,
        unique_id=0, opt_config=0):

    pool1_args = [x for x in pool1_attr]
    input = pool1_args[0]
    output1 = xm_pool2d_compute(*pool1_args)
    pool2_args = [x for x in pool2_attr]
    pool2_args[0] = output1
    output2 = xm_pool2d_compute(*pool2_args)
    pool3_args = [x for x in pool3_attr]
    pool3_args[0] = output2
    output3 = xm_pool2d_compute(*pool3_args)

    concat_input = (input, output1, output2, output3)
    output4 = xm_concat_compute(concat_input, 1)

    return output4

def xm_3conv2dpooladd_compute(conv1_attr, conv2_attr, conv3_attr, pool1_attr, 
        eltadd_attr, pool2_attr=None, unique_id=0, opt_config=0):
    input_data = conv1_attr[0]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    pool1_args = [x for x in pool1_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = xm_conv2d_compute(*conv1_args)

    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)

    conv3_args[0] = output2
    output3 = xm_conv2d_compute(*conv3_args)

    pool1_args[0] = input_data
    pool1_out = xm_pool2d_compute(*pool1_args)

    eltadd_args[0] = pool1_out
    eltadd_args[1] = output3
    output4 = xm_eltwiseadd_compute(*eltadd_args)
    if pool2_attr:
        pool2_args    = [x for x in pool2_attr]
        pool2_args[0] = output4
        output4       = xm_pool2d_compute(*pool2_args)

    return output4

def xm_dw_conv2d(conv0_attr, conv1_attr, pool_attr=None, unique_id=0, opt_config=0):
    conv0_args = [x for x in conv0_attr]
    conv1_args = [x for x in conv1_attr]
    c0_out = xm_conv2d_compute(*conv0_args)
    conv1_args[0] = c0_out
    c1_out = xm_conv2d_compute(*conv1_args)
    if pool_attr is not None:
        pool_args    = [x for x in pool_attr]
        pool_args[0] = c1_out
        if len(pool_attr) != 3:
            c1_out = xm_pool2d_compute(*pool_args)
        else:
            c1_out = xm_global_avg_pool2d_compute(*pool_args)
    return c1_out

def xm_3dwconvconvconcat_compute(conv1_attr, conv2_attr, conv3_attr, unique_id=0, opt_config=0):
    input_data = conv1_attr[0]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]

    output1 = xm_conv2d_compute(*conv1_args)

    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)

    conv3_args[0] = output2
    output3 = xm_conv2d_compute(*conv3_args)


    concat_input = (input_data, output3)
    output4 = xm_concat_compute(concat_input, 1)

    return output4

def xm_2conv2dadd_compute(conv1_attr, conv2_attr, eltadd_attr, 
        pool_attr=None, unique_id=0, opt_config=0):
    input_data = conv1_attr[0]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = xm_conv2d_compute(*conv1_args)

    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)

    eltadd_args[0] = conv1_args[0]
    eltadd_args[1] = output2
    output3 = xm_eltwiseadd_compute(*eltadd_args)
    if pool_attr:
        pool_args    = [x for x in pool_attr]
        pool_args[0] = output3
        output3      = xm_pool2d_compute(*pool_args)

    return output3

def xm_4dwtripleconv2dadd_compute(conv1_attr, conv2_attr, conv3_attr, conv4_attr, eltadd_attr, 
        pool_attr=None, unique_id=0, opt_config=0):
    input_data = conv1_attr[0]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    conv4_args = [x for x in conv4_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = xm_conv2d_compute(*conv1_args)
    #return output1

    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)
    #return output2

    conv3_args[0] = output2
    output3 = xm_conv2d_compute(*conv3_args)
    #return output3

    conv4_args[0] = output3
    output4 = xm_conv2d_compute(*conv4_args)
    #return output4

    eltadd_args[1] = output4
    output5 = xm_eltwiseadd_compute(*eltadd_args)
    if pool_attr is not None:
        if len(pool_attr) != 3:
            pool_args    = [x for x in pool_attr]
            pool_args[0] = output5
            output5      = xm_pool2d_compute(*pool_args)
        else:
            pool_args    = [x for x in pool_attr]
            pool_args[0] = output5
            output5      = xm_global_avg_pool2d_compute(*pool_args)

    return output5

def xm_3conv2d_eltadd_type2_compute(conv1_attr, conv2_attr, conv3_attr, eltadd_attr, 
        pool_attr=None, unique_id=0, opt_config=0):
    input_data = conv1_attr[0]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = xm_conv2d_compute(*conv1_args)
    conv2_args[0] = input_data
    output2 = xm_conv2d_compute(*conv2_args)
    conv3_args[0] = output2
    output3 = xm_conv2d_compute(*conv3_args)

    eltadd_args[0] = output1
    eltadd_args[1] = output3
    output4 = xm_eltwiseadd_compute(*eltadd_args)
    if pool_attr:
        pool_args    = [x for x in pool_attr]
        pool_args[0] = output4
        output4      = xm_pool2d_compute(*pool_args)

    return output4

def xm_4dwtripleconv2dlpooladd_compute(conv1_attr, conv2_attr, conv3_attr, conv4_attr, pool1_attr, 
        eltadd_attr, pool2_attr=None, unique_id=0, opt_config=0):
    input_data = conv1_attr[0]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    conv4_args = [x for x in conv4_attr]
    pool1_args = [x for x in pool1_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = xm_conv2d_compute(*conv1_args)

    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)

    conv3_args[0] = output2
    output3 = xm_conv2d_compute(*conv3_args)

    conv4_args[0] = output3
    output4 = xm_conv2d_compute(*conv4_args)

    pool1_args[0] = input_data
    pool1_out = xm_pool2d_compute(*pool1_args)

    eltadd_args[0] = pool1_out
    eltadd_args[1] = output4
    output5 = xm_eltwiseadd_compute(*eltadd_args)
    if pool2_attr:
        pool2_args    = [x for x in pool2_attr]
        pool2_args[0] = output5
        output5       = xm_pool2d_compute(*pool2_args)

    return output5

def xm_3dwdoubleconv2dadd_compute(conv1_attr, conv2_attr, conv3_attr, eltadd_attr, 
        pool_attr=None, unique_id=0, opt_config=0):
    input_data = conv1_attr[0]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = xm_conv2d_compute(*conv1_args)
    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)
    conv3_args[0] = output2
    output3 = xm_conv2d_compute(*conv3_args)

    eltadd_args[0] = input_data
    eltadd_args[1] = output3
    output4 = xm_eltwiseadd_compute(*eltadd_args)
    if pool_attr is not None:
        pool_args    = [x for x in pool_attr]
        pool_args[0] = output4
        output4      = xm_pool2d_compute(*pool_args)

    return output4

def xm_3spconvdwconvconcat_compute(split_attr, conv1_attr, conv2_attr, conv3_attr,
        unique_id=0, opt_config=0):
    input_data = split_attr[0]
    split_args = [x for x in split_attr]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]

    output_spt = xm_split_compute(*split_args)
    spt0 = output_spt[0]
    spt1 = output_spt[1]

    conv1_args[0] = spt1
    output1 = xm_conv2d_compute(*conv1_args)

    conv2_args[0] = output1
    output2 = xm_conv2d_compute(*conv2_args)

    conv3_args[0] = output2
    output3 = xm_conv2d_compute(*conv3_args)

    concat_input = (spt0, output3)
    output4 = xm_concat_compute(concat_input, 1)

    return output4
