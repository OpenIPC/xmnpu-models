# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
"""Broadcast operators"""
from __future__ import absolute_import as _abs
#from . import cpp as _cpp
from . import _make


#def arith
#def lut


def conv2d(
        data,
        kernel,
        bias,
        quant_mul,
        quant_shift,
        quant_mode,
        i_zp,
        k_zp,
        o_zp,
        kh,
        kw,
        kh_stride=1,
        kw_stride=1,
        pad_h_t=0,
        pad_h_b=0,
        pad_w_l=0,
        pad_w_r=0,
        dilation_h=1,
        dilation_w=1,
        ins_h=0,
        ins_w=0,
        using_bias=1,
        relu_type=0,     #0:no relu;1:relu;2/3:leaky_relu(0.1/0.01);
        groups=1,
        in_shape=None,
        out_shape=None,
        out_dtype="uint8"):

    return _make.conv2d(
                data,
                kernel,
                bias,
                quant_mul,
                quant_shift,
                quant_mode,
                i_zp,
                k_zp,
                o_zp,
                kh,
                kw,
                kh_stride,
                kw_stride,
                pad_h_t,
                pad_h_b,
                pad_w_l,
                pad_w_r,
                dilation_h,
                dilation_w,
                ins_h,
                ins_w,
                using_bias,
                relu_type,
                groups,
                in_shape,
                out_shape,
                out_dtype)


def scale(
        data,
        kernel,
        bias,
        quant_mul,
        quant_shift,
        quant_mode,
        i_zp,
        k_zp,
        o_zp,
        using_bias=1,
        relu_type=0,     #0:no relu;1:relu;2/3:leaky_relu(0.1/0.01);
        shape=None,
        out_dtype="uint8"):

    return _make.scale(
                data,
                kernel,
                bias,
                quant_mul,
                quant_shift,
                quant_mode,
                i_zp,
                k_zp,
                o_zp,
                using_bias,
                relu_type,
                shape,
                out_dtype)

def dense(
        data,
        kernel,
        bias,
        quant_mul,
        quant_shift,
        quant_mode,
        i_zp,
        k_zp,
        o_zp,
        using_bias,
        out_dtype="uint8"):

    return _make.dense(
                data,
                kernel,
                bias,
                quant_mul,
                quant_shift,
                quant_mode,
                i_zp,
                k_zp,
                o_zp,
                using_bias,
                out_dtype)


def eltwiseadd(lhs, rhs,
        lhs_mul,
        lhs_shift,
        rhs_mul,
        rhs_shift,
        lhs_zp,
        rhs_zp,
        o_zp):

    return _make.eltwiseadd(
               lhs, rhs,
               lhs_mul,
               lhs_shift,
               rhs_mul,
               rhs_shift,
               lhs_zp,
               rhs_zp,
               o_zp)

def yuv2rgb(
    y_data,
    uv_data,
    input_h,
    input_w,
    input_wptch,
    pic_format_e,
    btfmt_e,
    range_e,
    output_dtype,
    input_mtype):

    return _make.yuv2rgb(
               y_data,
               uv_data,
               input_h,
               input_w,
               input_wptch,
               pic_format_e,
               btfmt_e,
               range_e,
               output_dtype,
               input_mtype)

def global_avg_pool2d(
    data,
    zero_point,
    kh,
    kw):

    return _make.global_avg_pool2d(
            data,
            zero_point,
            kh,
            kw)

def pool2d(
        data,
        zero_point,
        kh,
        kw,
        kh_stride,
        kw_stride,
        pad_h_t=0,
        pad_h_b=0,
        pad_w_l=0,
        pad_w_r=0,
        pool_type=0, # 0:max, 1:avg
        in_shape=None,
        out_shape=None):

    return _make.pool2d(
                data,
                zero_point,
                kh,
                kw,
                kh_stride,
                kw_stride,
                pad_h_t,
                pad_h_b,
                pad_w_l,
                pad_w_r,
                pool_type,
                in_shape,
                out_shape)

def concat(a_tuple, axis = 0):
    return _make.concat(
                a_tuple,
                axis)

def upsample(data,
           scale_h=2,
           scale_w=2):
    return _make.upsample(
                data,
                scale_h,
                scale_w)





