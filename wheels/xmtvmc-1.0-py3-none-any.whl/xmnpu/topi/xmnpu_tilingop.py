# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

from types import coroutine
import numpy as np

import tvm
from tvm import te
from tvm import autotvm
from tvm import topi
from tvm.relay.op.nn.utils import get_pad_tuple2d
from tvm.topi.nn.conv2d import conv

from .utils import is_packed_layout
from ..environment import get_env
from xmnpu.topi.xmnpu_normalop import *
import xmnpu

#from . import topi
#from . import tir

env = get_env()


def compute_1conv2d(conv1_attr, pool_attr, conv_res=0,
        unique_id=-1, opt_config=0):

    conv1_args = [x for x in conv1_attr]
    output1 = compute_conv2d(*conv1_args)

    if pool_attr is not None:
        pool_args = [x for x in pool_attr]
        pool_args[0] = output1
        output1 = compute_pool2d(*pool_args)

    new_op = combine_new_op(output1.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output1 = outputs[0] if num == 1 else outputs
    return output1

def schedule_1conv2d(outs):
    """Schedule packed conv2d"""
    # debug
    assert len(outs) == 1
    outs   = outs[0] if isinstance(outs[0], list) else outs
    output = outs[-1]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value


    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    assert conv2d_tensor[0] == output

    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)

    for i in range(op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        if op_num == 2 and i == 0:
            s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.pool2d(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    return s

def compute_conv2dupsp(conv1_attr, upsp_attr, conv_res=0,
        unique_id=-1, opt_config=0):

    conv1_args = [x for x in conv1_attr]
    output1 = [compute_conv2d(*conv1_args)]

    upsp_args    = [x for x in upsp_attr]
    upsp_args[0] = output1[-1]
    output_p     = compute_upsample(*upsp_args)
    if conv_res:
        output1 = [output1[-1], output_p]
    else:
        output1 = output_p

    new_op = combine_new_op(output1.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    outputs = outputs[0] if num == 1 else outputs
    output1 = outputs
    return output1

def schedule_conv2dupsp(outs):
    """Schedule packed conv2d"""
    # debug
    assert len(outs) == 1
    outs   = outs[0] if isinstance(outs[0], list) else outs
    output = outs[-1]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and (len(reduce_ops) + 1) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    assert conv2d_tensor[0] == output

    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)

    s[conv2d_reduce[0]].compute_at(s[conv2d_tensor[1]], conv2d_tensor[1].op.axis[3])

    s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.upsample(1))
    s[conv2d_tensor[1]].pragma(conv2d_tensor[1].op.axis[0], env.conv2d(1))

    return s

def compute_2conv2d(conv1_attr, conv2_attr, pool_attr=None,
        unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]

    output1 = compute_conv2d(*conv1_args)

    conv2_args[0] = output1
    output2 = compute_conv2d(*conv2_args)

    if pool_attr is not None:
        pool_args = [x for x in pool_attr]
        pool_args[0] = output2
        output2 = compute_pool2d(*pool_args)

    new_op = combine_new_op(output2.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output2 = outputs[0] if num == 1 else outputs
    return output2

def schedule_2conv2d(outs):
    """Schedule packed conv2d"""
    #debug
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    assert conv2d_tensor[0] == output

    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)

    for i in range(op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        if op_num == 3 and i == 0:
            s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.pool2d(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    return s

def compute_2conv2dupsp(conv1_attr, conv2_attr, upsp_attr,
        unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]

    output1 = compute_conv2d(*conv1_args)

    conv2_args[0] = output1
    output2       = compute_conv2d(*conv2_args)

    upsp_args = [x for x in upsp_attr]
    upsp_args[0] = output2
    output2 = compute_upsample(*upsp_args)

    new_op = combine_new_op(output2.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output2 = outputs[0] if num == 1 else outputs
    return output2

def schedule_2conv2dupsp(outs):
    """Schedule packed conv2d"""
    #debug
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and (len(reduce_ops) + 1) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    assert conv2d_tensor[0] == output

    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)

    s[conv2d_reduce[0]].compute_at(s[conv2d_tensor[1]], conv2d_tensor[1].op.axis[3])
    s[conv2d_reduce[1]].compute_at(s[conv2d_tensor[2]], conv2d_tensor[2].op.axis[3])

    s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.upsample(1))
    s[conv2d_tensor[1]].pragma(conv2d_tensor[1].op.axis[0], env.conv2d(1))
    s[conv2d_tensor[2]].pragma(conv2d_tensor[2].op.axis[0], env.conv2d(1))

    return s


def compute_3conv2d(conv1_attr, conv2_attr, conv3_attr,
        pool_attr=None, unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]

    output1 = compute_conv2d(*conv1_args)

    conv2_args[0] = output1
    output2 = compute_conv2d(*conv2_args)

    conv3_args[0] = output2
    output3 = compute_conv2d(*conv3_args)

    if pool_attr is not None:
        pool_args = [x for x in pool_attr]
        pool_args[0] = output3
        output3 = compute_pool2d(*pool_args)

    new_op = combine_new_op(output3.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output3 = outputs[0] if num == 1 else outputs
    return output3


def schedule_3conv2d(outs):
    """Schedule packed conv2d"""
    #debug
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    assert conv2d_tensor[0] == output

    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)

    for i in range(op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        if op_num == 4 and i == 0:
            s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.pool2d(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    return s

def compute_3conv2d_concat(conv0_attr, conv1_attr, conv2_attr, pool_attr=None, unique_id=-1, opt_config=0):
    conv0_args = [x for x in conv0_attr]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    
    output0 = compute_conv2d(*conv0_args)
    conv1_args[0] = output0
    output1 = compute_conv2d(*conv1_args)
    conv2_args[0] = output0
    output2 = compute_conv2d(*conv2_args)
    output3 = compute_concat((output1, output2), 1)
    if pool_attr:
        pool_args = [x for x in pool_attr]
        pool_args[0] = output3
        output3 = compute_pool2d(*pool_args)

    new_op = combine_new_op(output3.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    out = outputs[0] if num == 1 else outputs
    return out
def schedule_3conv2d_concat(outs):
    """Schedule packed conv2d"""
    #debug
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs = []
    reduce_ops = []
    conv2d_ops = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        else:
            conv2d_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 
    assert len(reduce_ops) + 1 == len(conv2d_ops), "reduce_ops: {}\tconv2d_ops: {}\n".format(len(reduce_ops), 
                                len(conv2d_ops))
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        if i == len(reduce_ops) - 3:
            continue 
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        if i == len(conv2d_ops) - 3:
            continue
        conv2d_tensor.append(conv2d_ops[i].output(0))

    # print("conv2d_reduce  \n", conv2d_reduce, "\nconv2d_tensor  \n", conv2d_tensor)
    # print(output.op)
    # import pdb; pdb.set_trace()
    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)
    for i in range(op_num - 1):
        if 4 == op_num:  
            s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i + 1]], conv2d_tensor[i + 1].op.axis[3])
        if 5 == op_num:
            if 0 == i:
                s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
            else:
                s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i + 1]], conv2d_tensor[i + 1].op.axis[3])

    for i in range(op_num):
        if 5 == op_num and i == 0:
            s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.pool2d(1))
        elif 5 == op_num and i == 1:
            s[conv2d_tensor[1]].pragma(conv2d_tensor[1].op.axis[0], env.concat(1))
        elif 4 == op_num and 0 == i:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.concat(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    return s

def compute_4conv2d_concat(conv0_attr, conv1_attr, conv2_attr, conv3_attr=None, unique_id=-1, opt_config=0):
    conv0_args = [x for x in conv0_attr]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    
    output0 = compute_conv2d(*conv0_args)
    conv1_args[0] = output0
    output1 = compute_conv2d(*conv1_args)
    conv2_args[0] = output1
    output2 = compute_conv2d(*conv2_args)
    conv3_args[0] = output1
    output3 = compute_conv2d(*conv3_args)

    output4 = compute_concat((output2, output3), 1)

    new_op = combine_new_op(output4.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    out = outputs[0] if num == 1 else outputs
    return out

def schedule_4conv2d_concat(outs):
    """Schedule packed conv2d"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs = []
    reduce_ops = []
    conv2d_ops = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        else:
            conv2d_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 
    assert len(reduce_ops) + 1 == len(conv2d_ops), "reduce_ops: {}\tconv2d_ops: {}\n".format(len(reduce_ops), 
                                    len(conv2d_ops))
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        if i in [1, 2]:
            continue 
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        if i in [2, 3]:
            continue
        conv2d_tensor.append(conv2d_ops[i].output(0))

    # print("conv2d_reduce  \n", conv2d_reduce, "\nconv2d_tensor  \n", conv2d_tensor)
    # print(output.op)
    # import pdb; pdb.set_trace()
    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)
    for i in range(op_num - 1):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i + 1]], conv2d_tensor[i + 1].op.axis[3])

    for i in range(op_num):
        if i == 0:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.concat(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    return s

def compute_dw_2conv2d_dw_conv2d_concat(conv0_attr, conv1_attr, conv2_attr, conv3_attr,
                                        conv4_attr, unique_id=-1, opt_config=0):
    conv0_args = [x for x in conv0_attr]                                           
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    conv4_args = [x for x in conv4_attr]

    output0 = compute_conv2d(*conv0_args)
    conv1_args[0] = output0
    output1 = compute_conv2d(*conv1_args)

    conv2_args[0] = conv0_args[0]
    output2 = compute_conv2d(*conv2_args)
    conv3_args[0] = output2
    output3 = compute_conv2d(*conv3_args)
    conv4_args[0] = output3
    output4 = compute_conv2d(*conv4_args)
    
    out = compute_concat((output1, output4), 1)
    new_op = combine_new_op(out.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    out = outputs[0] if num == 1 else outputs
    return out

def schedule_dw_2conv2d_dw_conv2d_concat(outs):
    """Schedule packed conv2d"""
    #debug
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs = []
    reduce_ops = []
    conv2d_ops = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        else:
            conv2d_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 
    assert len(reduce_ops) + 1 == len(conv2d_ops), "reduce_ops: {}\tconv2d_ops: {}\n".format(len(reduce_ops), 
                                len(conv2d_ops))
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    # print("conv2d_reduce  \n", conv2d_reduce, "\nconv2d_tensor  \n", conv2d_tensor)
    # import pdb; pdb.set_trace()
    op_num = len(conv2d_tensor)
    s[conv2d_tensor[3]].npu_id_config(conv2d_tensor[3].op.axis[0], unique_id, opt_config)
    for i in range(op_num - 1):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i + 1]], conv2d_tensor[i + 1].op.axis[3])

    for i in range(op_num):
        if i == 0:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.concat(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    return s

def compute_4conv2d_pool_concat(conv0_attr, conv1_attr, conv2_attr, conv3_attr, 
                                pool_attr, unique_id=-1, opt_config=0):
    conv0_args = [x for x in conv0_attr]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]

    out0 = compute_conv2d(*conv0_args)
    conv1_args[0] = conv0_args[0]
    out1 = compute_conv2d(*conv1_args)
    conv2_args[0] = out1
    out2 = compute_conv2d(*conv2_args)
    conv3_args[0] = out2
    out3 = compute_conv2d(*conv3_args)

    pool_args = [x for x in pool_attr]
    pool_args[0] = conv0_args[0]
    out4 = compute_pool2d(*pool_args)
    inputs = (out0, out3, out4)
    out = compute_concat(inputs, 1)

    new_op = combine_new_op(out.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    out = outputs[0] if num == 1 else outputs
    return out
def schedule_4conv2d_pool_concat(outs):
    """Schedule packed conv2d"""
    #debug
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs = []
    reduce_ops = []
    conv2d_ops = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        else:
            conv2d_ops.append(op)
        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 
    assert len(reduce_ops) + 1 == len(conv2d_ops), "reduce_ops: {}\tconv2d_ops: {}\n".format(len(reduce_ops), 
                                len(conv2d_ops))
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    # print("conv2d_reduce  \n", conv2d_reduce, "\nconv2d_tensor  \n", conv2d_tensor)
    # import pdb; pdb.set_trace()

    op_num = len(conv2d_tensor)
    s[conv2d_tensor[1]].npu_id_config(conv2d_tensor[1].op.axis[0], unique_id, opt_config)

    for i in range(op_num):
        if i > 0:  
            s[conv2d_reduce[i-1]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        if i == 0:
            s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.concat(1))
        elif i == 1:
            s[conv2d_tensor[1]].pragma(conv2d_tensor[1].op.axis[0], env.pool2d(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))

    return s

def compute_4conv2d(conv1_attr, conv2_attr, conv3_attr, conv4_attr, pool_attr=None, unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    conv4_args = [x for x in conv4_attr]

    out1 = compute_conv2d(*conv1_args)
    conv2_args[0] = out1
    out2 = compute_conv2d(*conv2_args)
    conv3_args[0] = out2
    out3 = compute_conv2d(*conv3_args)
    conv4_args[0] = out3
    out4 = compute_conv2d(*conv4_args)

    if pool_attr is not None:
        pool_args = [x for x in pool_attr]
        pool_args[0] = out4
        out4 = compute_pool2d(*pool_args)

    new_op = combine_new_op(out4.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    out = outputs[0] if num == 1 else outputs
    return out
def schedule_4conv2d(outs):
    """Schedule packed conv2d"""
    #debug
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 
    assert len(reduce_ops) == len(conv2d_ops), "reduce_ops: {}\tconv2d_ops: {}\n".format(len(reduce_ops), len(conv2d_ops))
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    assert conv2d_tensor[0] == output

    # print(conv2d_reduce, "\n", conv2d_tensor)

    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)

    for i in range(op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        if op_num == 5 and i == 0:
            s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.pool2d(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))

    return s

def compute_conv2d_pool2d_2conv2d(conv0_attr, pool_attr, conv1_attr, conv2_attr, unique_id=0, opt_config=0):
    conv0_args = [x for x in conv0_attr]
    pool_args  = [x for x in pool_attr]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    c0_out = compute_conv2d(*conv0_args)
    pool_args[0] = c0_out
    p_out = compute_pool2d(*pool_args)
    conv1_args[0] = p_out
    c1_out = compute_conv2d(*conv1_args)
    conv2_args[0] = c1_out
    c2_out = compute_conv2d(*conv2_args)

    new_op = combine_new_op(c2_out.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    out = outputs[0] if num == 1 else outputs
    return out
def schedule_conv2d_pool2d_2conv2d(outs):
    """Schedule packed conv2d"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype
    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []
    eltadd_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        elif op.tag == "elemwise" and op.name.find("eltadd") != -1:
            eltadd_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))
    assert conv2d_tensor[0] == output
    # print(conv2d_reduce, "\n", conv2d_tensor)
    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)

    for i in range(op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        if op_num == 4 and i == 2:
            s[conv2d_tensor[2]].pragma(conv2d_tensor[2].op.axis[0], env.pool2d(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    return s        

def compute_conv2d_dw_conv2d(conv0_attr, conv1_attr, conv2_attr, unique_id=0, opt_config=0):
    conv0_args = [x for x in conv0_attr]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    c0_out = compute_conv2d(*conv0_args)
    conv1_args[0] = c0_out
    c1_out = compute_conv2d(*conv1_args)
    conv2_args[0] = c1_out
    c2_out = compute_conv2d(*conv2_args)
    new_op = combine_new_op(c2_out.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    out = outputs[0] if num == 1 else outputs
    return out
def schedule_conv2d_dw_conv2d(outs):
    """Schedule packed conv2d"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype
    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []
    eltadd_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        elif op.tag == "elemwise" and op.name.find("eltadd") != -1:
            eltadd_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))
    assert conv2d_tensor[0] == output
    # print(conv2d_reduce, "\n", conv2d_tensor)
    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)

    for i in range(op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    return s        

def compute_conv2d_dw_conv2d_add(conv1_attr, conv2_attr, conv3_attr, eltadd_attr, 
                            pool_attr=None, unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = compute_conv2d(*conv1_args)

    conv2_args[0] = output1
    output2 = compute_conv2d(*conv2_args)

    conv3_args[0] = output2
    output3 = compute_conv2d(*conv3_args)

    eltadd_args[1] = output3
    out = compute_eltwiseadd(*eltadd_args)

    if pool_attr is not None:
        pool_args = [x for x in pool_attr]
        pool_args[0] = out
        out = compute_pool2d(*pool_args)

    new_op = combine_new_op(out.op, unique_id, opt_config)
    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output4 = outputs[0] if num == 1 else outputs
    return output4

def schedule_conv2d_dw_conv2d_add(outs):
    """Schedule packed conv2d"""
    #debug
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []
    eltadd_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        elif op.tag == "elemwise" and op.name.find("eltadd") != -1:
            eltadd_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    conv_op_num = len(conv2d_tensor) #include conv,pool,fc and gap
    s[conv2d_tensor[conv_op_num - 1]].npu_id_config(conv2d_tensor[conv_op_num - 1].op.axis[0], unique_id, opt_config) 
    for i in range(conv_op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        if i == 0 and conv_op_num == 4:
            s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.pool2d(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    assert len(eltadd_ops) == 1
    s[eltadd_ops[0].output(0)].pragma(eltadd_ops[0].output(0).op.axis[0], env.eltwiseadd(1))
    return s

def compute_3conv2d_add(conv1_attr, conv2_attr, conv3_attr, eltadd_attr, pool_attr=None, unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = compute_conv2d(*conv1_args)

    conv2_args[0] = output1
    output2 = compute_conv2d(*conv2_args)

    conv3_args[0] = output2
    output3 = compute_conv2d(*conv3_args)

    eltadd_args[1] = output3
    output4 = compute_eltwiseadd(*eltadd_args)

    if pool_attr is not None:
        if len(pool_attr) != 3:
            pool_args = [x for x in pool_attr]
            pool_args[0] = output4
            output4 = compute_pool2d(*pool_args)
        else:
            pool_args = [x for x in pool_attr]
            pool_args[0] = output4
            output4 = compute_gap(*pool_args)

    new_op = combine_new_op(output4.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output4 = outputs[0] if num == 1 else outputs
    return output4

def schedule_3conv2d_add(outs):
    """Schedule packed conv2d"""
    #debug
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []
    eltadd_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        elif op.tag == "elemwise" and op.name.find("eltadd") != -1:
            eltadd_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    conv_op_num = len(conv2d_tensor) #include conv,pool,fc and gap
    s[conv2d_tensor[conv_op_num - 1]].npu_id_config(conv2d_tensor[conv_op_num - 1].op.axis[0], unique_id, opt_config) # input
    for i in range(conv_op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        if i == 0 and conv_op_num == 4:
            if conv2d_tensor[0].op.name != "GAP":
                s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.pool2d(1))
            else:
                s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.gap(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    assert len(eltadd_ops) == 1
    s[eltadd_ops[0].output(0)].pragma(eltadd_ops[0].output(0).op.axis[0], env.eltwiseadd(1))
    return s

def compute_4conv2d_eltadd(conv1_attr, conv2_attr, conv3_attr, conv4_attr, 
        eltadd_attr, pool_attr=None, unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    conv4_args = [x for x in conv4_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = compute_conv2d(*conv1_args)
    conv2_args[0] = output1
    output2 = compute_conv2d(*conv2_args)
    conv3_args[0] = output2
    output3 = compute_conv2d(*conv3_args)
    output4 = compute_conv2d(*conv4_args)
    eltadd_args[0] = output4
    eltadd_args[1] = output3
    output5 = compute_eltwiseadd(*eltadd_args)

    if pool_attr is not None:
        pool_args = [x for x in pool_attr]
        pool_args[0] = output5
        output5 = compute_pool2d(*pool_args)

    new_op = combine_new_op(output5.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output5 = outputs[0] if num == 1 else outputs
    return output5

def schedule_4conv2d_eltadd(outs):
    """Schedule packed conv2d"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []
    eltadd_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        elif op.tag == "elemwise":
            eltadd_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    eltadd_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))
    for i in range(len(eltadd_ops)):
        eltadd_tensor.append(eltadd_ops[i].output(0))

    op_num = len(conv2d_reduce)

    s[conv2d_tensor[op_num - 4]].npu_id_config(conv2d_tensor[op_num - 4].op.axis[0], unique_id, opt_config) # conv4's output

    op_num_reduce = len(conv2d_reduce)
    for i in range(op_num_reduce):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])

    s[eltadd_tensor[0]].pragma(eltadd_tensor[0].op.axis[0], env.eltwiseadd(1))

    op_num_conv2d = len(conv2d_tensor)
    for i in range(op_num_reduce):
        if op_num_conv2d == 5 and i == 0:
            s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.pool2d(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    return s

def compute_3pool_concat(pool1_attr, pool2_attr, pool3_attr,
        unique_id=-1, opt_config=0):
    pool1_args = [x for x in pool1_attr]
    pool2_args = [x for x in pool2_attr]
    pool3_args = [x for x in pool3_attr]

    input = pool1_args[0]
    output1 = compute_pool2d(*pool1_args)
    pool2_args[0] = output1
    output2 = compute_pool2d(*pool2_args)
    pool3_args[0] = output2
    output3 = compute_pool2d(*pool3_args)
    input_concat = (input, output1, output2, output3)
    output4  = compute_concat(input_concat, 1)

    new_op = combine_new_op(output4.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output4 = outputs[0] if num == 1 else outputs
    return output4

def schedule_3pool_concat(outs):
    """Schedule packed conv2d"""
    #debug
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []
    concat_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        elif op.tag == "injective":
            concat_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    concat_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))
    for i in range(len(concat_ops)):
        concat_tensor.append(concat_ops[i].output(0))

    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)
    s[concat_tensor[0]].pragma(concat_tensor[0].op.axis[0], env.concat(1))

    for i in range(0, 3):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.pool2d(1))
    return s

def compute_3conv2d_pool_add(conv1_attr, conv2_attr, conv3_attr, pool1_attr, 
        eltadd_attr, pool2_attr=None, unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    pool1_args = [x for x in pool1_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = compute_conv2d(*conv1_args)

    conv2_args[0] = output1
    output2 = compute_conv2d(*conv2_args)

    conv3_args[0] = output2
    output3 = compute_conv2d(*conv3_args)

    pool1_args[0] = conv1_args[0]
    pool1_out = compute_pool2d(*pool1_args)

    eltadd_args[0] = pool1_out
    eltadd_args[1] = output3
    output4 = compute_eltwiseadd(*eltadd_args)

    if pool2_attr is not None:
        pool2_args = [x for x in pool2_attr]
        pool2_args[0] = output4
        output4 = compute_pool2d(*pool2_args)

    new_op = combine_new_op(output4.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output4 = outputs[0] if num == 1 else outputs
    return output4

def schedule_3conv2d_pool_add(outs):
    """Schedule packed conv2d"""
    #debug
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []
    eltadd_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        elif op.tag == "elemwise" and op.name.find("eltadd") != -1:
            eltadd_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    conv_op_num = len(conv2d_tensor) #include conv,pool,fc and gap
    s[conv2d_tensor[conv_op_num - 4]].npu_id_config(conv2d_tensor[conv_op_num - 4].op.axis[0], unique_id, opt_config) # input
    for i in range(conv_op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        if conv2d_tensor[i].op.name.find("pool2d") != -1 and \
           conv2d_tensor[i].op.name.find("GAP") == -1:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.pool2d(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    assert len(eltadd_ops) == 1
    s[eltadd_ops[0].output(0)].pragma(eltadd_ops[0].output(0).op.axis[0], env.eltwiseadd(1))
    return s

def compute_dwconv2d(conv1_attr, conv2_attr, pool_attr=None,
        unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]

    output1 = compute_conv2d(*conv1_args)

    conv2_args[0] = output1
    output2 = compute_conv2d(*conv2_args)

    if pool_attr is not None:
        pool_args = [x for x in pool_attr]
        pool_args[0] = output2
        if len(pool_attr) != 3:
            output2 = compute_pool2d(*pool_args)
        else:
            output2 = compute_gap(*pool_args)

    new_op = combine_new_op(output2.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output2 = outputs[0] if num == 1 else outputs
    return output2

def schedule_dwconv2d(outs):
    """Schedule packed conv2d"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    assert conv2d_tensor[0] == output

    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)

    for i in range(op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        if op_num == 3 and i == 0:
            if conv2d_tensor[0].op.name != "GAP":
                s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.pool2d(1))
            else:
                s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.gap(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    return s

def compute_3dwconvconv_concat(conv1_attr, conv2_attr, conv3_attr,
        unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]

    input = conv1_attr[0]
    output1 = compute_conv2d(*conv1_args)
    conv2_args[0] = output1
    output2 = compute_conv2d(*conv2_args)
    conv3_args[0] = output2
    output3 = compute_conv2d(*conv3_args)
    input_concat = (input, output3)
    output4  = compute_concat(input_concat, 1)

    new_op = combine_new_op(output4.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output4 = outputs[0] if num == 1 else outputs
    return output4

def schedule_3dwconvconv_concat(outs):
    """Schedule packed conv2d"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []
    concat_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        elif op.tag == "injective":
            concat_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    concat_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))
    for i in range(len(concat_ops)):
        concat_tensor.append(concat_ops[i].output(0))

    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)
    s[concat_tensor[0]].pragma(concat_tensor[0].op.axis[0], env.concat(1))

    for i in range(op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    return s

def compute_2conv2d_add(conv1_attr, conv2_attr, eltadd_attr, pool_attr=None, unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = compute_conv2d(*conv1_args)

    conv2_args[0] = output1
    output2 = compute_conv2d(*conv2_args)

    eltadd_args[0] = conv1_args[0]
    eltadd_args[1] = output2
    output3 = compute_eltwiseadd(*eltadd_args)

    if pool_attr is not None:
        pool_args = [x for x in pool_attr]
        pool_args[0] = output3
        output3 = compute_pool2d(*pool_args)
        
    new_op = combine_new_op(output3.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output4 = outputs[0] if num == 1 else outputs
    return output4

def schedule_2conv2d_add(outs):
    """Schedule packed conv2d"""
    #debug
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []
    eltadd_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        elif op.tag == "elemwise" and op.name.find("eltadd") != -1:
            eltadd_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    conv_op_num = len(conv2d_tensor) #include conv,pool,fc and gap
    s[conv2d_tensor[conv_op_num - 1]].npu_id_config(conv2d_tensor[conv_op_num - 1].op.axis[0], unique_id, opt_config) # input
    for i in range(conv_op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        if i == 0 and conv_op_num == 3:
            s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.pool2d(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    assert len(eltadd_ops) == 1
    s[eltadd_ops[0].output(0)].pragma(eltadd_ops[0].output(0).op.axis[0], env.eltwiseadd(1))
    return s

def compute_4dwtripleconv2d_add(conv1_attr, conv2_attr, conv3_attr, conv4_attr, eltadd_attr, pool_attr=None,
        unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    conv4_args = [x for x in conv4_attr]
    eltadd_args = [x for x in eltadd_attr]

    input = conv1_attr[0]
    output1 = compute_conv2d(*conv1_args)

    conv2_args[0] = output1
    output2 = compute_conv2d(*conv2_args)

    conv3_args[0] = output2
    output3 = compute_conv2d(*conv3_args)

    conv4_args[0] = output3
    output4 = compute_conv2d(*conv4_args)

    eltadd_args[1] = output4
    output5 = compute_eltwiseadd(*eltadd_args)

    if pool_attr is not None:
        if len(pool_attr) != 3:
            pool_args = [x for x in pool_attr]
            pool_args[0] = output5
            output5 = compute_pool2d(*pool_args)
        else:
            pool_args = [x for x in pool_attr]
            pool_args[0] = output5
            output5 = compute_gap(*pool_args)

    new_op = combine_new_op(output5.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output5 = outputs[0] if num == 1 else outputs
    return output5

def schedule_4dwtripleconv2d_add(outs):
    """Schedule packed conv2d"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []
    eltadd_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        elif op.tag == "elemwise" and op.name.find("eltadd") != -1:
            eltadd_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)
    for i in range(op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        if i == 0 and op_num == 5:
            if conv2d_tensor[0].op.name != "GAP":
                s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.pool2d(1))
            else:
                s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.gap(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    assert len(eltadd_ops) == 1
    s[eltadd_ops[0].output(0)].pragma(eltadd_ops[0].output(0).op.axis[0], env.eltwiseadd(1))
    return s

def compute_3conv2d_eltadd_type2(conv1_attr, conv2_attr, conv3_attr, 
        eltadd_attr, pool_attr=None, unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = compute_conv2d(*conv1_args)
    conv2_args[0] = conv1_args[0]
    output2 = compute_conv2d(*conv2_args)
    conv3_args[0] = output2
    output3 = compute_conv2d(*conv3_args)

    eltadd_args[0] = output1
    eltadd_args[1] = output3
    output4 = compute_eltwiseadd(*eltadd_args)

    if pool_attr is not None:
        pool_args = [x for x in pool_attr]
        pool_args[0] = output4
        output4 = compute_pool2d(*pool_args)

    new_op = combine_new_op(output4.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output4 = outputs[0] if num == 1 else outputs
    return output4

def schedule_3conv2d_eltadd_type2(outs):
    """Schedule packed conv2d"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []
    eltadd_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        elif op.tag == "elemwise":
            eltadd_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    eltadd_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))
    for i in range(len(eltadd_ops)):
        eltadd_tensor.append(eltadd_ops[i].output(0))

    op_num = len(conv2d_reduce)

    s[conv2d_tensor[op_num - 3]].npu_id_config(conv2d_tensor[op_num - 3].op.axis[0], unique_id, opt_config) # conv4's output

    op_num_reduce = len(conv2d_reduce)
    for i in range(op_num_reduce):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])

    s[eltadd_tensor[0]].pragma(eltadd_tensor[0].op.axis[0], env.eltwiseadd(1))

    op_num_conv2d = len(conv2d_tensor)
    for i in range(op_num_reduce):
        if op_num_conv2d == 4 and i == 0:
            s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.pool2d(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    return s

def compute_4dwtripleconv2d_lpool_add(conv1_attr, conv2_attr, conv3_attr, conv4_attr, pool1_attr, 
        eltadd_attr, pool2_attr=None, unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    conv4_args = [x for x in conv4_attr]
    pool1_args = [x for x in pool1_attr]
    eltadd_args = [x for x in eltadd_attr]

    output1 = compute_conv2d(*conv1_args)

    conv2_args[0] = output1
    output2 = compute_conv2d(*conv2_args)

    conv3_args[0] = output2
    output3 = compute_conv2d(*conv3_args)

    conv4_args[0] = output3
    output4 = compute_conv2d(*conv4_args)

    pool1_args[0] = conv1_args[0]
    pool1_out = compute_pool2d(*pool1_args)

    eltadd_args[0] = pool1_out
    eltadd_args[1] = output4
    output5 = compute_eltwiseadd(*eltadd_args)

    if pool2_attr is not None:
        pool2_args = [x for x in pool2_attr]
        pool2_args[0] = output5
        output5 = compute_pool2d(*pool2_args)

    new_op = combine_new_op(output5.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output5 = outputs[0] if num == 1 else outputs
    return output5

def schedule_4dwtripleconv2d_lpool_add(outs):
    """Schedule packed conv2d"""
    #debug
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []
    eltadd_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        elif op.tag == "elemwise" and op.name.find("eltadd") != -1:
            eltadd_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))

    conv_op_num = len(conv2d_tensor) #include conv,pool,fc and gap
    s[conv2d_tensor[conv_op_num - 5]].npu_id_config(conv2d_tensor[conv_op_num - 5].op.axis[0], unique_id, opt_config) # input

    for i in range(conv_op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        if conv2d_tensor[i].op.name.find("pool2d") != -1 and conv2d_tensor[i].op.name.find("GAP") == -1:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.pool2d(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    assert len(eltadd_ops) == 1
    s[eltadd_ops[0].output(0)].pragma(eltadd_ops[0].output(0).op.axis[0], env.eltwiseadd(1))
    return s

def compute_3dwdoubleconv2d_add(conv1_attr, conv2_attr, conv3_attr, eltadd_attr, pool_attr=None,
        unique_id=-1, opt_config=0):
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]
    eltadd_args = [x for x in eltadd_attr]

    input = conv1_attr[0]
    output1 = compute_conv2d(*conv1_args)
    conv2_args[0] = output1
    output2 = compute_conv2d(*conv2_args)
    conv3_args[0] = output2
    output3 = compute_conv2d(*conv3_args)

    eltadd_args[0] = input
    eltadd_args[1] = output3
    output4 = compute_eltwiseadd(*eltadd_args)

    if pool_attr is not None:
        pool_args = [x for x in pool_attr]
        pool_args[0] = output4
        output4 = compute_pool2d(*pool_args)

    new_op = combine_new_op(output4.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output4 = outputs[0] if num == 1 else output4
    return output4
    
def schedule_3dwdoubleconv2d_add(outs):
    """Schedule packed conv2d"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []
    eltadd_ops    = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        elif op.tag == "elemwise":
            eltadd_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    eltadd_tensor = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))
    for i in range(len(eltadd_ops)):
        eltadd_tensor.append(eltadd_ops[i].output(0))

    op_num = len(conv2d_reduce)

    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config) # conv4's output

    op_num_reduce = len(conv2d_reduce)
    for i in range(op_num_reduce):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])

    s[eltadd_tensor[0]].pragma(eltadd_tensor[0].op.axis[0], env.eltwiseadd(1))

    op_num_conv2d = len(conv2d_tensor)
    for i in range(op_num_reduce):
        if op_num_conv2d == 4 and i == 0:
            s[conv2d_tensor[0]].pragma(conv2d_tensor[0].op.axis[0], env.pool2d(1))
        else:
            s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    return s

def compute_3spconvdwconv_concat(split_attr, conv1_attr, conv2_attr, conv3_attr,
        unique_id=-1, opt_config=0):
    split_args = [x for x in split_attr]
    conv1_args = [x for x in conv1_attr]
    conv2_args = [x for x in conv2_attr]
    conv3_args = [x for x in conv3_attr]

    input = split_args[0]
    output_spt = compute_split(*split_args)
    spt0 = output_spt[0]
    spt1 = output_spt[1]

    conv1_args[0] = spt1
    output1 = compute_conv2d(*conv1_args)
    conv2_args[0] = output1
    output2 = compute_conv2d(*conv2_args)
    conv3_args[0] = output2
    output3 = compute_conv2d(*conv3_args)
    input_concat = (spt0, output3)
    output4  = compute_concat(input_concat, 1)

    new_op = combine_new_op(output4.op, unique_id, opt_config)

    num = new_op.num_outputs
    outputs = tuple(new_op.output(i) for i in range(num))
    output4 = outputs[0] if num == 1 else outputs
    return output4

def schedule_3spconvdwconv_concat(outs):
    """Schedule packed conv2d"""
    assert len(outs) == 1
    output = outs[0]
    assert "int8" in output.dtype

    ewise_inputs  = []
    reduce_ops    = []
    conv2d_ops    = []
    concat_ops    = []
    split_ops    = []
    spli_redu_ops = []

    def _traverse(op):
        if "sum" in op.tag:
            reduce_ops.append(op)
        elif op.tag == "injective":
            if op.name.find("concat") != -1:
                concat_ops.append(op)
            elif op.name.find("split") != -1:
                split_ops.append(op)
        elif op.tag == "elemwise":
            spli_redu_ops.append(op)
        else:
            conv2d_ops.append(op)

        for tensor in op.input_tensors:
            if isinstance(tensor.op, tvm.te.PlaceholderOp):
                ewise_inputs.append((op, tensor))
            else:
                _traverse(tensor.op)
    _traverse(output.op)

    s = te.create_schedule(output.op)
    unique_id  = output.op.attrs["unique_id"].value
    opt_config = output.op.attrs["opt_config"].value

    assert len(reduce_ops) >= 1 and len(reduce_ops) == len(conv2d_ops)
    conv2d_reduce = []
    conv2d_tensor = []
    concat_tensor = []
    split_tensor = []
    split_reduce = []
    for i in range(len(reduce_ops)):
        conv2d_reduce.append(reduce_ops[i].output(0))
    for i in range(len(conv2d_ops)):
        conv2d_tensor.append(conv2d_ops[i].output(0))
    for i in range(len(concat_ops)):
        concat_tensor.append(concat_ops[i].output(0))
    for i in range(len(split_ops)):
        split_tensor.append(split_ops[i].output(0))
    for i in range(len(spli_redu_ops)):
        split_reduce.append(spli_redu_ops[i].output(0))

    op_num = len(conv2d_tensor)
    s[conv2d_tensor[op_num - 1]].npu_id_config(conv2d_tensor[op_num - 1].op.axis[0], unique_id, opt_config)
    s[concat_tensor[0]].pragma(concat_tensor[0].op.axis[0], env.concat(1))

    for i in range(len(split_tensor)):
        s[split_reduce[i]].compute_inline()
        s[split_tensor[i]].pragma(split_tensor[i].op.axis[0], env.split(1))
    for i in range(op_num):
        s[conv2d_reduce[i]].compute_at(s[conv2d_tensor[i]], conv2d_tensor[i].op.axis[3])
        s[conv2d_tensor[i]].pragma(conv2d_tensor[i].op.axis[0], env.conv2d(1))
    return s
