# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.

import copy
import copyreg
import ctypes
import functools
import logging
import os
import platform
import shutil
import sys
import time
import pickle
import pytest
import numpy as np
import random
from collections import namedtuple

import tvm
from tvm import te
from tvm import topi
import xmnpu
from xmnpu.topi.xmnpu_normalop import compute_load, compute_store
from xmnpu.topi.xmnpu_normalop import schedule_load, schedule_store
env = xmnpu.get_env()

conv2d_tuple = namedtuple("conv", ["ic", "ih", "iw", "oc", "k_hw", "k_s",
                "pad_h", "pad_w", "izp", "ozp", "u_b", "relu", "itype", "otype"])
pool2d_tuple = namedtuple("pool", ["ic", "ih", "iw", "k_hw", "k_s",
                "pad_h", "pad_w", "pool2d_type", "type"])
eltadd_tuple = namedtuple("elt", ["ic", "ih", "iw", "l_zp", "r_zp", "o_zp", "dtype", ])
scale_tuple = namedtuple("scale", ["ic", "ih", "iw", "i_scale", "k_scale", "o_scale",
                "i_zp", "k_zp", "o_zp", "u_bias", "relu", "itype", "ktype", "btype", "otype"])
dense_tuple = namedtuple("dense", ["ic", "ih", "iw", "oc", 
                "izp", "ozp", "u_b", "itype", "otype"])
global_avg_pool_tuple = namedtuple("gap", ["ic", "ih", "iw", "type"])

upsample_tuple = namedtuple("upsample", ["ic", "ih", "iw", "factor", "dtype"])

yuv2rgb_tuple = namedtuple("yuv2rgb", ["ic", "ih", "iw", "pic_format", "btfmt", "range",
                "input_mtype", "dtype"])
concat_tuple = namedtuple("concat", ["ic", "ih", "iw", "num", "axis", "dtype"])
split_tuple = namedtuple("split", ["ic", "ih", "iw", "len", "axis", "idx0", "idx1", "idx2", "idx3", "dtype"])
tdata_type = ["int8", "uint8", "int32"]
shape_faster_ci = (
    (4096, 64, 64, 64),
    (64, 1920, 64, 64),
    (64, 64, 1920, 64),
    (64, 64, 64, 4096)
)

class conv2d_params:
    def __init__(self):
        self.n  = 1
        self.ic = 1
        self.ih = 1
        self.iw = 1
        self.oc = 1
        self.oh = 1
        self.ow = 1
        self.groups = 1
        self.k_hw = 1
        self.k_stride = 1
        self.dilation = 1
        self.ins = 0
        self.pad_h_t = 1
        self.pad_h_b = 1
        self.pad_w_l = 1
        self.pad_w_r = 1
        self.i_scale = 1.0
        self.k_scale = 0.05
        self.o_scale = 1.0
        self.quant_mode = 0
        self.i_zp = 1
        self.k_zp = 0
        self.o_zp = 1
        self.using_bias = 1
        self.relu_type  = 1
        self.i_dtype = "uint8"
        self.k_dtype = "int8"
        self.b_dtype = "int32"
        self.o_dtype = "uint8"

    def __repr__(self):
        return "conv2d(ishape=[N*C*H*W], oshape=[C*H*W],"\
               " g, k_hw, k_s, d, ins, pading, " \
               " u_bias, relu, Qmode, i/k/b/o_dtype)" \
               "\nC: [%1s*%4s*%4s*%4s], [%4s*%4s*%4s],"    \
               " %s    %s   %s    %s   %s  (%s,%s,%s,%s)"   \
               "    %s     %s      %s   %s/%s/%s/%s"    \
               %(self.n, self.ic, self.ih, self.iw, self.oc, self.oh, self.ow, \
                   self.groups, self.k_hw, self.k_stride, self.dilation, self.ins, \
                   self.pad_h_t, self.pad_h_b, self.pad_w_l, self.pad_w_r, \
                   self.using_bias, self.relu_type, self.quant_mode, \
                   self.i_dtype, self.k_dtype, self.b_dtype, self.o_dtype)

    def show_all_params(self):
        print("ishape=[%s*%s*%s*%s], oshape=[%s*%s*%s], " \
                "group=%s, k=%s, k_s=%s, d=%s, ins=%s, " \
                "pading=(%s,%s,%s,%s) scale(iko)=(%s,%s,%s),quant_mode=%s " \
                "zp(iko)=(%s,%s,%s) u_b=%s, relu=%s," \
                "type(%s,%s,%s,%s)"
            %(self.n, self.ic, self.ih, self.iw, self.oc, self.oh, self.ow, \
              self.groups, self.k_hw, self.k_stride, self.dilation, self.ins, \
              self.pad_h_t, self.pad_h_b, self.pad_w_l, self.pad_w_r, \
              self.i_scale, self.k_scale, self.o_scale, self.quant_mode, \
              self.i_zp, self.k_zp, self.o_zp, self.using_bias, self.relu_type, \
              self.i_dtype, self.k_dtype, self.b_dtype, self.o_dtype
            ))

    def _update_ishape(self, oh=0, ow=0):
        def _get_ishape(ohw, k, k_s, ins, d, pad_t_l, pad_b_r):
            khw_ext = (k - 1) * d + 1
            ihw_ext = (ohw - 1) * k_s + khw_ext - pad_t_l - pad_b_r
            ihw = 1 + ((ihw_ext - 1) // (ins + 1))
            return ihw

        self.oh = self.oh if oh == 0 else oh
        self.ow = self.ow if ow == 0 else ow
        self.ih = _get_ishape(self.oh, self.k_hw, self.k_stride, \
                        self.ins, self.dilation, self.pad_h_t, self.pad_h_b)
        self.iw = _get_ishape(self.ow, self.k_hw, self.k_stride, \
                        self.ins, self.dilation, self.pad_w_l, self.pad_w_r)

    def _update_oshape(self):
        def _get_oshape(ihw, k, k_s, ins, d, pad_t_l, pad_b_r):
            ihw_ext = (ihw - 1) * (ins + 1) + 1
            khw_ext = (k - 1) * d + 1
            o_hw = 1 + ((ihw_ext + pad_t_l + pad_b_r - khw_ext) // k_s)
            o_hw = 1 if o_hw <= 1 else o_hw
            return o_hw

        self.oh = _get_oshape(self.ih, self.k_hw, self.k_stride, \
                            self.ins, self.dilation, self.pad_h_t, self.pad_h_b)
        self.ow = _get_oshape(self.iw, self.k_hw, self.k_stride, \
                            self.ins, self.dilation, self.pad_w_l, self.pad_w_r)

    def set_params_random(self, ic=0, ih=0, iw=0, i_dtype=None):
        max_value = shape_faster_ci[random.randint(1, len(shape_faster_ci)) - 1]
        self.ic = random.randint(1, max_value[0]) if ic == 0 else ic
        self.ih = random.randint(1, max_value[1]) if ih == 0 else ih
        self.iw = random.randint(1, max_value[2]) if iw == 0 else iw
        self.oc = random.randint(1, max_value[3])
        self.groups = random.randint(0, 1)
        self.groups = 1 #params.oc if (params.groups == 0) else 1
        self.k_hw  = (1 + 2 * random.randint(0, 3))
        self.k_stride = random.randint(1, 2)
        self.dilation = 1
        self.ins      = 0
        self.pad_h_t = (((self.k_hw-1)>>1) * random.randint(0, 1))
        self.pad_h_b = (((self.k_hw-1)>>1) * random.randint(0, 1))
        self.pad_w_l = (((self.k_hw-1)>>1) * random.randint(0, 1))
        self.pad_w_r = (((self.k_hw-1)>>1) * random.randint(0, 1))
        self.k_scale = random.uniform(0, 1)
        self.i_zp = random.randint(0, 10)
        self.k_zp = 0
        self.o_zp = random.randint(0, 10)
        self.using_bias = random.randint(0, 1)
        self.relu_type  = random.randint(0, 3)
        self.i_dtype = tdata_type[random.randint(0, 1)] if i_dtype is None else i_dtype
        self.k_dtype = tdata_type[0]
        self.o_dtype = tdata_type[random.randint(0, 1)]
        if self.relu_type == 1:
            self.o_dtype = "uint8"

        def _min_hw_need(hw, pad_t_r, khw):
            value = hw + pad_t_r - khw
            return 0 if value > 0 else (0 - value)
        self.ih += _min_hw_need(self.ih, self.pad_h_t, self.k_hw)
        self.iw += _min_hw_need(self.iw, self.pad_w_l, self.k_hw)

        self._update_oshape()

    def set_params_config(self, tp, ic=0, ih=0, iw=0):
        self.set_params_random()
        self.ic = tp.ic if ic == 0 else ic
        self.ih = tp.ih if ih == 0 else ih
        self.iw = tp.iw if iw == 0 else iw
        self.oc = tp.oc
        self.k_hw = tp.k_hw
        self.k_stride = tp.k_s
        self.pad_h_t = tp.pad_h
        self.pad_h_b = tp.pad_h
        self.pad_w_l = tp.pad_w
        self.pad_w_r = tp.pad_w
        self.i_zp = tp.izp
        self.o_zp = tp.ozp
        self.using_bias = tp.u_b
        self.relu_type  = tp.relu
        self.i_dtype  = tp.itype
        self.o_dtype  = tp.otype

        self._update_oshape()

    def get_tensor_size(self, withi = 0, witho = 0):
        total_size  = self.oc * self.k_hw * self.k_hw * (self.ic if self.groups == 1 else 1)
        max_tensor_size = total_size
        total_size += ((self.n * self.ic * self.ih * self.iw) if withi else 0)
        max_tensor_size = max(max_tensor_size, (self.n * self.ic * self.ih * self.iw))
        total_size += ((self.n * self.oc * self.oh * self.ow) if witho else 0)
        max_tensor_size = max(max_tensor_size, (self.n * self.oc * self.oh * self.ow))
        return total_size, max_tensor_size

    def get_macc(self):
        if 1 == self.groups:
            return self.k_hw * self.k_hw * self.ic * self.oc * self.oh * self.ow * 2
        elif self.groups == self.ic and self.groups == self.oc:
            return self.k_hw * self.k_hw * self.ic * self.oh * self.ow * 2
        else:
            assert 0, "Un-supported conv2d type."

class pool2d_params:
    def __init__(self):
        self.n  = 1
        self.ic = 1
        self.ih = 1
        self.iw = 1
        self.oh = 1
        self.ow = 1
        self.k_hw = 1
        self.k_stride = 1
        self.pad_h_t = 1
        self.pad_h_b = 1
        self.pad_w_l = 1
        self.pad_w_r = 1
        self.i_zp = 1
        self.o_zp = 1
        self.pool2d_type = 1
        self.i_dtype = "uint8"
        self.o_dtype = "uint8"

    def __repr__(self):
        return "pool2d(ishape=[N*C*H*W], oshape=[C*H*W],"\
               " k_hw, k_s, pading, " \
               " p_type, dtype)" \
               "\nP: [%1s*%4s*%4s*%4s], [%4s*%4s*%4s],"    \
               "   %s   %s   (%s,%s,%s,%s)"   \
               "    %s    %s"    \
               %(self.n, self.ic, self.ih, self.iw, self.ic, self.oh, self.ow, \
                   self.k_hw, self.k_stride, \
                   self.pad_h_t, self.pad_h_b, self.pad_w_l, self.pad_w_r, \
                   self.pool2d_type, self.o_dtype)

    def show_all_params(self):
        print("ishape=[%s*%s*%s*%s], oshape=[%s*%s*%s], " \
                "k=%s, k_s=%s, " \
                "pading=(%s,%s,%s,%s), " \
                "zp(io)=(%s,%s) pool2d_type=%s, " \
                "type(%s,%s)"
            %(self.n, self.ic, self.ih, self.iw, self.ic, self.oh, self.ow, \
              self.k_hw, self.k_stride, \
              self.pad_h_t, self.pad_h_b, self.pad_w_l, self.pad_w_r, \
              self.i_zp, self.o_zp, self.pool2d_type, \
              self.i_dtype, self.o_dtype
            ))

    def _update_oshape(self):
        def _get_oshape(ihw, k, k_s, pad_t_l, pad_b_r):
            o_hw = 1 + ((ihw + pad_t_l + pad_b_r - k) // k_s)
            o_hw = 1 if o_hw <= 1 else o_hw
            return o_hw

        self.oh = _get_oshape(self.ih, self.k_hw, self.k_stride, self.pad_h_t, self.pad_h_b)
        self.ow = _get_oshape(self.iw, self.k_hw, self.k_stride, self.pad_w_l, self.pad_w_r)

    def _update_ishape(self, oh=0, ow=0):
        def _get_ishape(ohw, k, k_s, pad_t_l, pad_b_r):
            ihw = (ohw - 1) * k_s + k - pad_t_l - pad_b_r
            return ihw
        self.oh = self.oh if oh == 0 else oh
        self.ow = self.ow if ow == 0 else ow

        self.ih = _get_ishape(self.oh, self.k_hw, self.k_stride, self.pad_h_t, self.pad_h_b)
        self.iw = _get_ishape(self.ow, self.k_hw, self.k_stride, self.pad_w_l, self.pad_w_r)
    
    def set_params_random(self, ic=0, ih=0, iw=0, i_dtype=None):
        max_value = shape_faster_ci[random.randint(1, len(shape_faster_ci)) - 1]
        self.ic = random.randint(1, max_value[0]) if ic == 0 else ic
        self.ih = random.randint(1, max_value[1]) if ih == 0 else ih
        self.iw = random.randint(1, max_value[2]) if iw == 0 else iw
        self.k_hw  = random.randint(2, 3)
        self.k_stride = random.randint(1, self.k_hw)
        self.pad_h_t = (((self.k_hw-1)>>1) * random.randint(0, 1))
        self.pad_h_b = (((self.k_hw-1)>>1) * random.randint(0, 1))
        self.pad_w_l = (((self.k_hw-1)>>1) * random.randint(0, 1))
        self.pad_w_r = (((self.k_hw-1)>>1) * random.randint(0, 1))
        self.i_zp = random.randint(0, 10)
        self.o_zp = self.i_zp
        self.pool2d_type = random.randint(0, 1)
        self.i_dtype = tdata_type[random.randint(0, 1)] if i_dtype is None else i_dtype
        self.o_dtype = self.i_dtype

        def _min_hw_need(hw, pad_t_r, khw):
            value = hw + pad_t_r - khw
            return 0 if value > 0 else (0 - value)
        self.ih += _min_hw_need(self.ih, self.pad_h_t, self.k_hw)
        self.iw += _min_hw_need(self.iw, self.pad_w_l, self.k_hw)

        self._update_oshape()

    def set_params_config(self, tp, ic=0, ih=0, iw=0):
        self.set_params_random()
        self.ic = tp.ic if ic == 0 else ic
        self.ih = tp.ih if ih == 0 else ih
        self.iw = tp.iw if iw == 0 else iw
        self.k_hw = tp.k_hw
        self.k_stride = tp.k_s
        self.pad_h_t  = tp.pad_h
        self.pad_h_b  = tp.pad_h
        self.pad_w_l  = tp.pad_w
        self.pad_w_r  = tp.pad_w
        self.pool2d_type  = tp.pool2d_type
        self.i_dtype  = tp.type
        self.o_dtype  = self.i_dtype

        self._update_oshape()

class eltwise_params:
    def __init__(self):
        self.n  = 1
        self.ic = 1
        self.ih = 1
        self.iw = 1
        self.l_scale = 1.0
        self.r_scale = 1.0
        self.o_scale = 1.0
        self.l_zp = 1
        self.r_zp = 1
        self.o_zp = 1
        self.l_dtype = "uint8"
        self.r_dtype = "uint8"
        self.o_dtype = "uint8"

    def __repr__(self):
        return "eltwise(shape=[N*C*H*W],"\
               " scale(lhs/rhs/out), zp(lhs/rhs/out), " \
               " dtype(lhs/rhs/out))" \
               "\nE: [%1s*%4s*%4s*%4s],"    \
               " (%.5s,%.5s,%.5s), \t (%s,%s,%s), \t (%s,%s,%s)"   \
               %(self.n, self.ic, self.ih, self.iw, \
                   self.l_scale, self.r_scale, self.o_scale, \
                   self.l_zp, self.r_zp, self.o_zp, \
                   self.l_dtype, self.r_dtype, self.o_dtype)

    def show_all_params(self):
        print("shape=[%s*%s*%s*%s], " \
                "scale(lro)=(%s,%s,%s), " \
                "zp(lro)=(%s,%s,%s) pool2d_type=%s, " \
                "type(%s,%s)"
            %(self.n, self.ic, self.ih, self.iw, \
              self.l_scale, self.r_scale, self.o_scale, \
              self.l_zp, self.r_zp, self.o_zp, \
              self.l_dtype, self.r_dtype, self.o_dtype
            ))

    def _update_ishape(self, ih=0, iw=0):
        self.ih = self.ih if ih == 0 else ih
        self.iw = self.iw if iw == 0 else iw
        
    def set_params_random(self, ic=0, ih=0, iw=0, i_dtype=None):
        max_value = shape_faster_ci[random.randint(1, len(shape_faster_ci)) - 1]
        self.ic = random.randint(1, max_value[0]) if ic == 0 else ic
        self.ih = random.randint(1, max_value[1]) if ih == 0 else ih
        self.iw = random.randint(1, max_value[2]) if iw == 0 else iw
        self.l_scale = random.uniform(0, 1)
        self.r_scale = random.uniform(0, 1)
        self.l_zp = random.randint(0, 10)
        self.r_zp = random.randint(0, 10)
        self.o_zp = random.randint(0, 10)
        self.l_dtype = tdata_type[random.randint(0, 1)] if i_dtype is None else i_dtype
        self.r_dtype = self.l_dtype
        self.o_dtype = self.l_dtype

    def set_params_config(self, tp, ic=0, ih=0, iw=0):
        self.set_params_random()
        self.ic = tp.ic if ic == 0 else ic
        self.ih = tp.ih if ih == 0 else ih
        self.iw = tp.iw if iw == 0 else iw
        self.l_zp  = tp.l_zp
        self.r_zp  = tp.r_zp
        self.o_zp  = tp.o_zp
        self.l_dtype  = tp.dtype
        self.r_dtype  = tp.dtype
        self.o_dtype  = tp.dtype

class scale_params:
    def __init__(self):
        self.n  = 1
        self.ic = 1
        self.ih = 1
        self.iw = 1
        self.i_scale = 1.0
        self.k_scale = 1.0
        self.o_scale = 1.0
        self.i_zp = 1
        self.k_zp = 1
        self.o_zp = 1
        self.using_bias = 1
        self.relu_type = 1
        self.i_dtype = "uint8"
        self.k_dtype = "uint8"
        self.b_dtype = "int32"
        self.o_dtype = "uint8"

    def __repr__(self):
        return "scale(ishape=[N*C*H*W], oshape=[C*H*W],"\
               " i/k/o_scale, i_zp, k_zp, o_zp, " \
               " u_bias, relu_type, i/k/b/o_dtype)" \
               "\nS: [%1s*%4s*%4s*%4s], [%4s*%4s*%4s],"    \
               " %s/%s/%s   %s %s %s  "   \
               " %s  %s   %s/%s/%s/%s"    \
               %(self.n, self.ic, self.ih, self.iw, self.ic, self.ih, self.iw, \
                   self.i_scale, self.k_scale, self.o_scale, self.i_zp, self.k_zp, \
                   self.o_zp, self.using_bias, self.relu_type, \
                   self.i_dtype, self.k_dtype, self.b_dtype, self.o_dtype)

    def show_all_params(self):
        print("ishape=[%s*%s*%s*%s], oshape=[%s*%s*%s], " \
                "scale(iko)=(%s,%s,%s), zp(iko)=(%s,%s,%s), " \
                "u_b=%s, relu=%s, i/k/b/o_dtype(%s,%s,%s,%s)"
            %(self.n, self.ic, self.ih, self.iw, self.ic, self.ih, self.iw, \
              self.i_scale, self.k_scale, self.o_scale, self.i_zp, self.k_zp, \
              self.o_zp, self.using_bias, self.relu_type, \
              self.i_dtype, self.k_dtype, self.b_dtype, self.o_dtype
            ))

    def _update_ishape(self, ih=0, iw=0):
        self.ih = self.ih if ih == 0 else ih
        self.iw = self.iw if iw == 0 else iw

    def set_params_random(self, ic=0, ih=0, iw=0, i_dtype=None):
        max_value = shape_faster_ci[random.randint(1, len(shape_faster_ci)) - 1]
        self.ic = random.randint(1, max_value[0]) if ic == 0 else ic
        self.ih = random.randint(1, max_value[1]) if ih == 0 else ih
        self.iw = random.randint(1, max_value[2]) if iw == 0 else iw
        self.k_scale = random.uniform(0, 1)
        self.i_zp = random.randint(0, 10)
        self.k_zp = 0
        self.o_zp = random.randint(0, 10)
        self.using_bias = random.randint(0, 1)
        self.relu_type  = 0  #random.randint(0, 3)
        self.i_dtype = tdata_type[random.randint(0, 1)] if i_dtype is None else i_dtype
        self.k_dtype = tdata_type[0]
        self.o_dtype = tdata_type[random.randint(0, 1)]
        if self.relu_type == 1:
            self.o_dtype = "uint8"

    def set_params_config(self, tp, ic=0, ih=0, iw=0):
        self.set_params_random()
        self.ic = tp.ic if ic == 0 else ic
        self.ih = tp.ih if ih == 0 else ih
        self.iw = tp.iw if iw == 0 else iw
        self.i_scale = tp.i_scale
        self.k_scale = tp.k_scale
        self.o_scale = tp.o_scale
        self.i_zp = tp.i_zp
        self.k_zp = tp.k_zp
        self.o_zp = tp.o_zp
        self.using_bias = tp.u_bias
        self.relu_type  = tp.relu
        self.i_dtype  = tp.itype
        self.k_dtype  = tp.ktype
        self.b_dtype  = tp.btype
        self.o_dtype  = tp.otype

class dense_params:
    def __init__(self):
        self.n  = 1
        self.ic = 1
        self.ih = 1
        self.iw = 1
        self.oc = 1
        self.i_scale = 1.0
        self.k_scale = 1.0
        self.o_scale = 1.0
        self.i_zp = 1
        self.k_zp = 1
        self.o_zp = 1
        self.using_bias = 1
        self.input_4d = 0
        self.i_dtype = "uint8"
        self.k_dtype = "uint8"
        self.b_dtype = "int32"
        self.o_dtype = "uint8"

    def __repr__(self):
        if self.input_4d:
            return "dense(ishape=[N*C*H*W], oshape=[W]," \
                " u_bias, i/k/b/o_dtype)"  \
                "\nF: [%1s*%4s*%4s*%4s], [%4s]," \
               "    %s     %s/%s/%s/%s"     \
                %(self.n, self.ic, self.ih, self.iw, self.oc, \
                    self.using_bias, \
                    self.i_dtype, self.k_dtype, self.b_dtype, self.o_dtype)
        else:
            return "dense(ishape=[N*W], oshape=[W]," \
                " u_bias, i/k/b/o_dtype)"  \
                "\nF: [%1s*%4s], [%4s]," \
               "    %s     %s/%s/%s/%s"     \
                %(self.n, self.ic, self.oc, self.using_bias, \
                    self.i_dtype, self.k_dtype, self.b_dtype, self.o_dtype)

    def show_all_params(self):
        print("dense_params(shape=[%s,%s,%s,%s], oc=%s," \
                " i_scale=%s, k_scale=%s, o_scale=%s," \
                " i_zp=%s, k_zp=%s, o_zp=%s, using_bias=%s, " \
                " i_dtype=%s, k_dtype=%s, b_dtype=%s, o_dtype=%s)" \
                %(self.n, self.ic, self.ih, self.iw, self.oc, \
                    self.i_scale, self.k_scale, self.o_scale, \
                    self.i_zp, self.k_zp, self.o_zp, self.using_bias, \
                    self.i_dtype, self.k_dtype, self.b_dtype, self.o_dtype
                ))

    def set_params_random(self, ic=0, ih=0, iw=0, oc=0, i_dtype=None):
        max_value = shape_faster_ci[random.randint(1, 2) - 1]
        self.ic = random.randint(1, max_value[0]) if ic == 0 else ic
        self.oc = random.randint(1, max_value[1]) if oc == 0 else oc
        self.k_scale = random.uniform(0, 1)
        self.i_zp = random.randint(0, 10)
        self.k_zp = 0
        self.o_zp = random.randint(0, 10)
        self.using_bias = random.randint(0, 1)
        self.input_4d   = random.randint(0, 2)
        self.i_dtype = tdata_type[random.randint(0, 1)]
        self.k_dtype = tdata_type[0]
        self.o_dtype = tdata_type[random.randint(0, 1)]
        if self.input_4d == 2:
            self.ih = random.randint(1, 7) if ih == 0 else ih
            self.iw = random.randint(1, 7) if ih == 0 else ih

    def set_params_config(self, tp, ic=0, ih=0, iw=0, oc=0):
        self.set_params_random()
        self.ic = tp.ic if ic == 0 else ic
        self.ih = tp.ih if ih == 0 else ih
        self.iw = tp.iw if iw == 0 else iw
        self.oc = tp.oc if oc == 0 else oc
        self.i_zp = tp.izp
        self.o_zp = tp.ozp
        self.input_4d = not (ic == ih and ic == 1)
        self.using_bias = tp.u_b
        self.i_dtype  = tp.itype
        self.o_dtype  = tp.otype

class global_avg_pool_params:
    def __init__(self):
        self.n  = 1
        self.ic = 1
        self.ih = 1
        self.iw = 1
        self.oh = 1
        self.ow = 1
        self.i_zp = 1
        self.o_zp = 1
        self.i_dtype = "uint8"
        self.o_dtype = "uint8"

    def __repr__(self):
        return "global_avg_pool(ishape=[N*C*H*W], oshape=[C*H*W], dtype)" \
               "\nG: [%1s*%4s*%4s*%4s], [%4s*%4s*%4s],"    \
               "    %s"    \
               %(self.n, self.ic, self.ih, self.iw, self.ic, self.oh, self.ow, \
                   self.o_dtype)

    def show_all_params(self):
        print("ishape=[%s*%s*%s*%s], oshape=[%s*%s*%s], " \
                "zp(io)=(%s,%s), type(%s,%s)"
            %(self.n, self.ic, self.ih, self.iw, self.ic, self.oh, self.ow, \
              self.i_zp, self.o_zp, self.i_dtype, self.o_dtype
            ))

    def _update_oshape(self):
        self.oh = 1
        self.ow = 1

    def _update_ishape(self, oh=0, ow=0):
        """def _get_ishape(ohw, k, k_s, pad_t_l, pad_b_r):
            ihw = (ohw - 1) * k_s + k - pad_t_l - pad_b_r
            return ihw
        self.oh = self.oh if oh == 0 else oh
        self.ow = self.ow if ow == 0 else ow

        self.ih = _get_ishape(self.oh, self.k_hw, self.k_stride, self.pad_h_t, self.pad_h_b)
        self.iw = _get_ishape(self.ow, self.k_hw, self.k_stride, self.pad_w_l, self.pad_w_r)"""
        print("do nothing!!!")
    
    def set_params_random(self, ic=0, ih=0, iw=0, i_dtype=None):
        max_value = shape_faster_ci[random.randint(1, len(shape_faster_ci)) - 1]
        self.ic = random.randint(1, max_value[0]) if ic == 0 else ic
        self.ih = random.randint(1, max_value[1]) if ih == 0 else ih
        self.iw = random.randint(1, max_value[2]) if iw == 0 else iw
        self.i_zp = random.randint(0, 10)
        self.o_zp = self.i_zp
        self.i_dtype = tdata_type[random.randint(0, 1)] if i_dtype is None else i_dtype
        self.o_dtype = self.i_dtype

        self._update_oshape()

    def set_params_config(self, tp, ic=0, ih=0, iw=0):
        self.set_params_random()
        self.ic = tp.ic if ic == 0 else ic
        self.ih = tp.ih if ih == 0 else ih
        self.iw = tp.iw if iw == 0 else iw
        self.i_dtype  = tp.type
        self.o_dtype  = self.i_dtype

        self._update_oshape()

class upsample_params:
    def __init__(self):
        self.n  = 1
        self.ic = 1
        self.ih = 1
        self.iw = 1
        self.oh = 1
        self.ow = 1
        self.factor = 2
        self.dtype = "uint8"

    def __repr__(self):
        return "upsample(ishape=[N*C*H*W], oshape=[C*H*W], factor, dtype)" \
               "\nU: [%1s*%4s*%4s*%4s], [%4s*%4s*%4s],"    \
               "       %s    %s"  \
               %(self.n, self.ic, self.ih, self.iw, \
                self.ic, self.oh , self.ow , \
                   self.factor, self.dtype)

    def show_all_params(self):
        print("ishape=[%s*%s*%s*%s], oshape=[%s*%s*%s], " \
                "factor=(%s), type(%s)" 
            %(self.n, self.ic, self.ih, self.iw, \
                self.ic , self.oh, self.ow, \
              self.factor, self.dtype
            ))

    def _update_oshape(self):
        self.oh = self.ih * self.factor
        self.ow = self.iw * self.factor

    def set_params_random(self, ic=0, ih=0, iw=0, i_dtype=None):
        max_value = shape_faster_ci[random.randint(1, len(shape_faster_ci)) - 1]
        self.ic = random.randint(1, max_value[0]) if ic == 0 else ic
        self.ih = random.randint(1, max_value[1]) if ih == 0 else ih
        self.iw = random.randint(1, max_value[2]) if iw == 0 else iw
        self.factor = 2
        self.dtype = tdata_type[random.randint(0, 1)] if i_dtype is None else i_dtype

        self._update_oshape()

    def set_params_config(self, tp, ic=0, ih=0, iw=0):
        self.set_params_random()
        self.ic = tp.ic if ic == 0 else ic
        self.ih = tp.ih if ih == 0 else ih
        self.iw = tp.iw if iw == 0 else iw
        self.factor = 2
        self.dtype  = tp.dtype

        self._update_oshape()

class yuv2rgb_params:
    class yuv_pic_format_e:
        YUV_422SP = 0,
        YUV_420SP = 1,
    class yuv_btfmt_e:
        YUV_BT601 = 0,
        YUV_BT709 = 1,
    class yuv_range_e:
        YUV_RANGE_FULL = 0,
        YUV_RANGE_TV = 1,
    class mem_type_e:
        SRAM_MEM = 0,
        DDR_MEM = 1,
        DYN_DDR_MEM = 2,
    def __init__(self):
        self.n = 1
        self.ic = 1
        self.ih = 1
        self.iw = 1
        self.input_wptch = 1
        self.oh = 1
        self.ow = 1

        self.dtype = "uint8"
        self.pic_format_e = self.yuv_pic_format_e.YUV_422SP
        self.btfmt_e = self.yuv_btfmt_e.YUV_BT601
        self.range_e = self.yuv_range_e.YUV_RANGE_FULL
        self.input_mtype = self.mem_type_e.DDR_MEM

    def __repr__(self):
        return "yuv2rgb(ishape=[N*C*H*W], oshape=[C*H*W],"\
               " pic_format, btfmt, range, input_mtype, dtype)" \
               "\nY: [%1s*%4s*%4s*%4s], [%4s*%4s*%4s]," \
               "   %s   %s   %s   %s   %s" \
               %(self.n, self.ic, self.ih, self.iw, 3*self.ic, self.oh, self.ow, \
                   self.pic_format_e, self.btfmt_e, self.range_e, self.input_mtype, self.dtype)

    def show_all_params(self):
        print("ishape=[%s*%s*%s*%s], oshape=[%s*%s*%s], " \
                "pic_format=%s, btfmt=%s, range=%s, input_mtype=%s, dtype=%s"
            %(self.n, self.ic, self.ih, self.iw, 3*self.ic, self.oh, self.ow, \
              self.pic_format_e, self.btfmt_e, self.range_e, self.input_mtype, self.dtype
            ))

    def _update_oshape(self):
        self.oh = self.ih
        self.ow = self.iw

    def set_params_random(self, ic=0, ih=0, iw=0, i_dtype=None):
        shape_faster_yuv2rgb = (
            (256, 256, 512),
            (3000, 512, 1024),
            (512, 3000, 1024),
            (224, 224, 3000)
        )
        max_value = shape_faster_yuv2rgb[random.randint(1, len(shape_faster_yuv2rgb)) - 1]
        self.ic = 1 if ic == 0 else ic
        self.ih = random.randint(1, max_value[0]) if ih == 0 else ih
        self.iw = random.randint(2, max_value[1]) if iw == 0 else iw
        self.iw = self.iw & 0xFFFFFFFE
        self.input_wptch = random.randint(self.iw, self.iw + max_value[2])
        self.pic_format_e = random.randint(0, 1)
        self.btfmt_e = random.randint(0, 1)
        self.range_e = random.randint(0, 1)
        self.input_mtype = 1      # cmodel don't support DYN_DDR_MEM
        self.dtype = tdata_type[1]
        if self.pic_format_e == 1:
            self.ih += self.ih & 0x1
        self.oh = self.ih
        self.ow = self.iw

        self._update_oshape()

    def set_params_config(self, tp, ic=0, ih=0, iw=0):
        self.set_params_random()
        self.ic = tp.ic if ic == 0 else ic
        self.ih = tp.ih if ih == 0 else ih
        self.iw = tp.iw if iw == 0 else iw
        self.pic_format_e = tp.pic_format
        self.btfmt_e  = tp.btfmt
        self.range_e  = tp.range
        self.input_mtype  = tp.input_mtype
        self.dtype  = tp.dtype

        self._update_oshape()

class concat_params:
    def __init__(self):
        self.shape = [1, 1, 1, 1]
        self.concat_shape = [1, 1]
        self.num  = 1
        self.axis = 1
        self.dtype = "uint8"

    def __repr__(self):
        if self.axis == 1:
            return "concat_params(shape=[%s,%s,%s,%s], num=%s, axis=%s, dtype=%s)" \
                %(self.shape[0], self.concat_shape, self.shape[2], self.shape[3], \
                    self.num, self.axis, self.dtype)
        elif self.axis == 2:
            return "concat_params(shape=[%s,%s,%s,%s], num=%s, axis=%s, dtype=%s)" \
                %(self.shape[0], self.shape[1], self.concat_shape, self.shape[3], \
                    self.num, self.axis, self.dtype)
        elif self.axis == 3:
            return "concat_params(shape=[%s,%s,%s,%s], num=%s, axis=%s, dtype=%s)" \
                %(self.shape[0], self.shape[1], self.shape[2], self.concat_shape, \
                    self.num, self.axis, self.dtype)
        else:
            return "concat_params(shape=[%s,%s,%s,%s], num=%s, axis=%s, dtype=%s)" \
                %(self.concat_shape, self.shape[1], self.shape[2], self.shape[3], \
                    self.num, self.axis, self.dtype)

    def set_params_random(self, ic=0, ih=0, iw=0, i_dtype=None):
        max_value = shape_faster_ci[random.randint(1, len(shape_faster_ci)) - 1]
        self.shape[1] = random.randint(1, max_value[0])
        self.shape[2] = random.randint(1, max_value[1]) 
        self.shape[3] = random.randint(1, max_value[2]) 
        self.num  = random.randint(2, 4) 
        self.axis = random.randint(1, 3) 
        self.concat_shape = []
        for _ in range(self.num):
            axis = self.axis
            size = random.randint(1, self.shape[axis])
            self.concat_shape.append(size)
        self.dtype = tdata_type[random.randint(0, 1)]
        final_concat = sum(self.concat_shape)
        if final_concat > max_value[self.axis - 1]:
            for i in range(self.num):
                self.concat_shape[i] = int(self.concat_shape[i] / (final_concat / max_value[self.axis - 1]))

    def set_params_config(self, tp, ic=0, ih=0, iw=0):
        self.set_params_random()
        self.shape[1] = tp.ic if ic == 0 else ic
        self.shape[2] = tp.ih if ih == 0 else ih
        self.shape[3] = tp.iw if iw == 0 else iw
        self.num = tp.num
        self.axis = tp.axis
        self.concat_shape = []
        for _ in range(self.num):
            axis = self.axis
            size = self.shape[axis]
            self.concat_shape.append(size)
        self.dtype = tp.dtype

class split_params:
    def __init__(self):
        self.shape = [1, 1, 1, 1]
        self.array_len = 1
        self.axis = 1
        self.split_idx = [1,]
        self.dtype = "uint8"

    def __repr__(self):
        if self.axis == 1:
            return "split_params(shape=%s, array_len=%d, axis=%d, split_idx=%s, dtype=%s)" \
              % (str(self.shape), self.array_len, self.axis, str(self.split_idx), self.dtype)
        else:
            return "split axis current support 1 only!!!"

    def set_params_random(self, ic=0, ih=0, iw=0, dtype=None):
        max_value = shape_faster_ci[random.randint(1, len(shape_faster_ci)) - 1]
        self.shape[1] = random.randint(1, max_value[0])
        self.shape[2] = random.randint(1, max_value[1])
        self.shape[3] = random.randint(1, max_value[2])
        self.array_len = random.randint(1, min(2, self.shape[1]))
        self.split_idx = []
        for i in range(self.array_len):
            if i == 0:
                v = self.shape[1] >> 1
                if v == 0:
                    self.split_idx.append(0)
                else:
                    self.split_idx.append(random.randint(1, v))
            else:
                remain_len = self.shape[1] - self.split_idx[i-1] - 1
                if remain_len >= 1:                                                                                     
                    self.split_idx.append(self.split_idx[i-1] + random.randint(1, remain_len))
                else:
                    self.split_idx.append(self.split_idx[-1])

    def set_params_config(self, tp, ic=0, ih=0, iw=0):
        self.set_params_random()
        self.shape[1] = tp.ic if ic == 0 else ic
        self.shape[2] = tp.ih if ih == 0 else ih
        self.shape[3] = tp.iw if iw == 0 else iw
        self.array_len = tp.len
        self.axis = tp.axis
        self.split_idx = []
        if tp.idx0:
            self.split_idx.append(tp.idx0)
        if tp.idx1:
            self.split_idx.append(tp.idx1)
        if tp.idx2:
            self.split_idx.append(tp.idx2)
        if tp.idx3:
            self.split_idx.append(tp.idx3)
        self.dtype = tp.dtype

def set_idata2sram(input_np, reverse_ram = 0, align1d = 0):
    i_shape = input_np.shape
    i_dtype = str(input_np.dtype)
    reverse_ram = int(reverse_ram)
    align1d     = int(align1d)
    opt_config  = (int(align1d) << 0) + (int(reverse_ram) << 2)

    input = te.placeholder(i_shape, name="input", dtype=i_dtype)

    res = compute_load(input, opt_config=opt_config)
    s   = schedule_load([res])

    f = xmnpu.build(
        s, [input, res], target=env.target, name="load"
    )
    dev = tvm.ext_dev(0)
    input_arr   = tvm.nd.array(input_np, dev)

    res_np      = np.zeros(topi.utils.get_const_tuple(i_shape)).astype(i_dtype)
    res_arr     = tvm.nd.array(res_np, dev)
    f(input_arr, res_arr)

    input_np *= 0
    return 0

def get_odata_from_sram(output_np, reverse_ram = 0, align1d = 0):
    o_shape = output_np.shape
    o_dtype = str(output_np.dtype)
    input = te.placeholder(o_shape, name="input", dtype=o_dtype)
    reverse_ram = int(reverse_ram)
    align1d     = int(align1d)
    opt_config  = (int(align1d) << 0) + (int(reverse_ram) << 2)

    res = compute_store(input, opt_config=opt_config)
    s   = schedule_store([res])

    f = xmnpu.build(
        s, [input, res], target=env.target, name="store"
    )
    dev = tvm.ext_dev(0)

    o_np        = np.zeros(output_np.shape).astype(o_dtype)
    input_arr   = tvm.nd.array(o_np, dev)
    res_np      = np.zeros(topi.utils.get_const_tuple(o_shape)).astype(o_dtype)
    res_arr     = tvm.nd.array(res_np, dev)
    f(input_arr, res_arr)

    return res_arr.asnumpy()

