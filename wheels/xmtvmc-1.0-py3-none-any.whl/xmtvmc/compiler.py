import json
import re

import tvm
import xmnpu
from tvm import relay

from .hooks import (
    BUILD_QNN_RUNNER,
    BUILD_RELAY_RUNNER,
    XMIR_RUNNER,
    _running_hook,
)
from .quantize import get_tensor_info, is_qnn_mod

__env__ = xmnpu.get_env()


def build(
    mod,
    params,
    target=None,
    config=None,
    **kwargs,
):
    """
    params:
        mod: tvm.IRModules
            input build tvm module
        params: Optional[dict]
            input params
        target: str or tvm.target.Target
            build target ; if str choice of ['llvm','xmcpu','xmnpu']
    return:
        build lib
    """

    def qnn2xmir(mod, params):
        # convert qnn to xmir
        mod = xmnpu.relay.pattern.opt_model(mod)
        mod = xmnpu.relay.pattern.create_xmir(mod, params)
        mod = xmnpu.relay.pattern.ReWriteRelayLayout(mod, "NCHW")
        mod = tvm.relay.transform.InferType()(mod)
        # xmir hook in build
        mod, params = _running_hook(XMIR_RUNNER, mod, params, **kwargs)
        return mod, params

    is_qnn = is_qnn_mod(mod)
    # check qnn or relay
    if is_qnn:
        # qnn hook in build
        mod, params = _running_hook(BUILD_QNN_RUNNER, mod, params, **kwargs)
    else:
        # relay hook in build
        mod, params = _running_hook(BUILD_RELAY_RUNNER, mod, params, **kwargs)

    # mod convert and build target
    if isinstance(target, str):
        if target == "xmnpu" or target == "xmnpu_npu":
            target = __env__.target
            mod, params = qnn2xmir(mod, params)
        elif target == "xmcpu" or target == "xmnpu_x86":
            target = tvm.target.Target("llvm")
            mod, params = qnn2xmir(mod, params)
        elif target == "x86":
            target = tvm.target.Target("llvm")
        else:
            target = tvm.target.Target(target)
    else:
        if target.device_name == "xmnpu":
            mod, params = qnn2xmir(mod, params)

    # build
    with tvm.transform.PassContext(opt_level=2):
        if target.device_name != "xmnpu":
            with tvm.transform.PassContext(
                opt_level=3,
                disabled_pass={"AlterOpLayout"},
                config=config,
            ):
                lib = relay.build(mod, target=target, params=params)
        else:
            assert (
                is_qnn
            ), "build xmnpu target must be qnn mod but input relay mod"
            with xmnpu.build_config(
                opt_level=3,
                disabled_pass={"AlterOpLayout"},
                build_mode=0xF,
                config=config,
            ):
                lib = relay.build(mod, target=target, params=None)

    # extract quantize params , will used to covnert result to float
    tensor_info = get_tensor_info(mod)

    return lib, tensor_info
