import os
import numpy as np
import cv2


class ImageLoader:
    """加载转换图像数据"""
    def __init__(self, data, input_shape, input_fmt):
        """构造函数

        Args:
            data: np.array
                输入数据, shape=(N,)
            input_shape: list
                输入图像shape, [w, h]
            input_fmt: str
                输入数据格式, 如 RGB, BGR, NV21_BT601_FULL, NV21_BT709_TV 等
        """
        self.data = data
        self.input_shape = input_shape
        self.input_fmt, self.input_bt_format, self.input_range = self._parse_format(input_fmt)

    def _parse_format(self, fmt):
        fmt = fmt.lower()
        if fmt in ["rgb", "bgr"]:
            rgb_fmt = fmt
            bt_format = None
            yuv_range = None
            return rgb_fmt, bt_format, yuv_range
        else:
            assert len(fmt.split("_")) == 3, f"wrong format {fmt}"
            yuv_format, bt_format, yuv_range = fmt.split("_")
            assert bt_format and bt_format.lower() in ["bt601", "bt709"], \
                f"input bt_format {bt_format} not supported"
            assert yuv_range and yuv_range.lower() in ["tv", "full"], \
                f"input yuv range {yuv_range} not supported"
            return yuv_format, bt_format, yuv_range

    def _yuv2rgb(self, y, u, v, bt_format, yuv_range):
        dtype = y.dtype
        y = y.astype("float64")
        u = u.astype("float64")
        v = v.astype("float64")

        # convert tv range to full range
        if yuv_range == "tv":
            y = 1.0 * (y - 16) * 255 / 219
            u = 1.0 * (u - 128) * 255 / 224 + 128
            v = 1.0 * (v - 128) * 255 / 224 + 128

        if bt_format == "bt601":
            c0, c1, c2, c3 = 1.403, -0.343, -0.714, 1.770
        else:
            c0, c1, c2, c3 = 1.575, -0.187, -0.468, 1.856

        r = 1.0 * y + c0 * (v - 128)
        g = 1.0 * y + c1 * (u - 128) + c2 * (v - 128)
        b = 1.0 * y + c3 * (u - 128)

        r = np.around(np.clip(r, 0, 255))
        g = np.around(np.clip(g, 0, 255))
        b = np.around(np.clip(b, 0, 255))
        r = r.astype(dtype)
        g = g.astype(dtype)
        b = b.astype(dtype)
        return r, g, b

    def _rgb2yuv(self, r, g, b, bt_format, yuv_range):
        dtype = r.dtype
        r = r.astype("float64")
        g = g.astype("float64")
        b = b.astype("float64")

        if bt_format == "bt601":
            if yuv_range == "tv":
                y = 16 + 0.257 * r + 0.504 * g + 0.098 * b
                u = 128 - 0.148 * r - 0.291 * g + 0.439 * b
                v = 128 + 0.439 * r - 0.368 * g - 0.071 * b
            else:  # full
                y = 0.299 * r + 0.587 * g + 0.114 * b
                u = 128 - 0.169 * r - 0.331 * g + 0.500 * b
                v = 128 + 0.500 * r - 0.419 * g - 0.081 * b
        else:  # bt709
            if yuv_range == "tv":
                y = 16 + 0.183 * r + 0.614 * g + 0.062 * b
                u = 128 - 0.101 * r - 0.339 * g + 0.439 * b
                v = 128 + 0.439 * r - 0.399 * g - 0.040 * b
            else:  # full
                y = 0.213 * r + 0.715 * g + 0.072 * b
                u = 128 - 0.115 * r - 0.385 * g + 0.500 * b
                v = 128 + 0.500 * r - 0.454 * g - 0.046 * b

        y = np.around(np.clip(y, 0, 255))
        u = np.around(np.clip(u, 0, 255))
        v = np.around(np.clip(v, 0, 255))

        y = y.astype(dtype)
        u = u.astype(dtype)
        v = v.astype(dtype)
        return y, u, v

    def _upsample_420(self, c_in):
        h = c_in.shape[0]
        w = c_in.shape[1]
        
        c_out = np.zeros(shape=[h*2, w*2], dtype=c_in.dtype)
        c_out[::2,::2] = c_in
        c_out[1::2,::2] = c_in
        c_out[::2,1::2] = c_in
        c_out[1::2,1::2] = c_in
        return c_out

    def _upsample_422(self, c_in):
        h = c_in.shape[0]
        w = c_in.shape[1]

        c_out = np.zeros(shape=[h, w*2], dtype=c_in.dtype)
        c_out[:,::2] = c_in
        c_out[:,1::2] = c_in
        return c_out

    def _sampling_420(self, c_in):
        h = c_in.shape[0]
        w = c_in.shape[1]
        assert h % 2 == 0 and w % 2 == 0, f"shape [{h}, {w}] can not fit 420 sampling"

        c_out = c_in[::2, ::2]
        return c_out

    def _sampling_422(self, c_in):
        h = c_in.shape[0]
        w = c_in.shape[1]
        assert w % 2 == 0, f"shape [{h}, {w}] can not fit 422 sampling"

        c_out = c_in[:, ::2]
        return c_out

    def _input2rgb(self, c0, c1, c2):
        """将输入图像转换为rgb格式"""
        if self.input_fmt == "rgb":
            return c0, c1, c2
        elif self.input_fmt == "bgr":
            return c2, c1, c0
        elif self.input_fmt in ["nv12", "nv21", "i420", "yv12"]:
            u = self._upsample_420(c1)
            v = self._upsample_420(c2)
            r, g, b = self._yuv2rgb(c0, u, v, self.input_bt_format, self.input_range)
            return r, g, b
        elif self.input_fmt in ["nv16", "nv61", "i422", "yv16"]:
            u = self._upsample_422(c1)
            v = self._upsample_422(c2)
            r, g, b = self._yuv2rgb(c0, u, v, self.input_bt_format, self.input_range)
            return r, g, b
        else:
            raise NotImplementedError(f"input format {self.input_fmt} not supported")

    def _rgb2output(self, r, g, b):
        """将rgb图像转换为output fmt设定格式"""
        if self.output_fmt == "rgb":
            return r, g, b
        elif self.output_fmt == "bgr":
            return b, g, r
        elif self.output_fmt in ["nv12", "nv21", "i420", "yv12"]:
            y, u, v = self._rgb2yuv(r, g, b, self.output_bt_format, self.output_range)
            u = self._sampling_420(u)
            v = self._sampling_420(v)
            return y, u, v
        elif self.output_fmt in ["nv16", "nv61", "i422", "yv16"]:
            y, u, v = self._rgb2yuv(r, g, b, self.output_bt_format, self.output_range)
            u = self._sampling_422(u)
            v = self._sampling_422(v)
            return y, u, v
        else:
            raise NotImplementedError(f"output format {self.output_fmt} not supported")

    def _parse_base_planar(self, data, size_y, size_uv):
        """按照基本的planar格式加载数据
            data: np.array, 图像数据
            size_y: int, Y通道数据大小
            size_uv: int, U(或者V)通道数据大小
        """
        assert size_y + 2 * size_uv == data.size, \
            f"y size {size_y}, u/v size {size_uv} cannot match data size {data.size}"
        channel_0 = data[:size_y]
        channel_1 = data[size_y:size_y+size_uv]
        channel_2 = data[size_y+size_uv:]
        return channel_0, channel_1, channel_2

    def _parse_base_semiplanar(self, data, size_y, size_uv):
        """按照基本的semi planar格式加载数据
            data: np.array, 图像数据
            size_y: int, Y通道数据大小
            size_uv: int, U(或者V)通道数据大小
        """
        assert size_y + 2 * size_uv == data.size, \
            f"y size {size_y}, u/v size {size_uv} cannot match data size {data.size}"
        channel_0 = data[:size_y]
        channel_1 = data[size_y::2]
        channel_2 = data[size_y+1::2]
        return channel_0, channel_1, channel_2

    def _parse_422(self, data, w, h, fmt="sp"):
        """创建 YUV422 格式的Loader"""
        assert w % 2 == 0, \
            f"sampling 422 width {w} should be even number"
        size_y = w * h
        size_uv = (w // 2) * h

        if fmt == "sp":
            c0, c1, c2 = self._parse_base_semiplanar(data, size_y, size_uv)
        elif fmt == "p":
            c0, c1, c2 = self._parse_base_planar(data, size_y, size_uv)
        else:
            raise NotImplementedError(f"format {fmt} not supported")
        
        c0 = c0.reshape([h, w])
        c1 = c1.reshape([h, w//2])
        c2 = c2.reshape([h, w//2])
        return c0, c1, c2

    def _parse_420(self, data, w, h, fmt="sp"):
        """创建 YUV420 格式的Loader"""
        assert w % 2 == 0 and h % 2 == 0, \
            f"sampling 420 width {w} and hight {h} should be even number"
        size_y = w * h
        size_uv = (w // 2) * (h // 2)

        if fmt == "sp":
            c0, c1, c2 = self._parse_base_semiplanar(data, size_y, size_uv)
        elif fmt == "p":
            c0, c1, c2 = self._parse_base_planar(data, size_y, size_uv)

        c0 = c0.reshape([h, w])
        c1 = c1.reshape([h//2, w//2])
        c2 = c2.reshape([h//2, w//2])
        return c0, c1, c2

    def _parse_rgb(self, data, w, h):
        """将rgb/bgr 数据分解为 r g b 三个通道"""
        assert data.size == 3 * w * h, \
            f"data size {data.size} not match height {h} width {w}"
        c0 = data[::3]
        c1 = data[1::3]
        c2 = data[2::3]

        c0 = c0.reshape([h, w])
        c1 = c1.reshape([h, w])
        c2 = c2.reshape([h, w])
        return c0, c1, c2

    def _compact_rgb(self, c0, c1, c2):
        """将三个通道进行合并 3*[h,w] ==> [h,w,3]"""
        assert c0.shape == c1.shape == c2.shape, \
            f"c0 shape {c0.shape}, c1 shape {c1.shape}, c2 shape {c2.shape} should equal"
        assert len(c0.shape) == 2, \
            f"input shape {c0.shape} dimension should equal 2"

        h = c0.shape[0]
        w = c0.shape[1]

        c0 = c0[np.newaxis]
        c1 = c1[np.newaxis]
        c2 = c2[np.newaxis]

        c = np.concatenate([c0, c1, c2])
        return c

    def _split_channel(self):
        """将输入数据分离为三个通道"""
        assert isinstance(self.input_shape, list), "raw data should set image shape"
        assert len(self.input_shape) == 2, "shape dimension should equal 2"

        w = self.input_shape[0]
        h = self.input_shape[1]
        data = self.data
        if self.input_fmt == "nv12":
            # YUV420SP UV
            y, u, v = self._parse_420(data, w, h, "sp")
            return y, u, v 
        elif self.input_fmt == "nv21":
            # YUV420SP VU
            y, v, u = self._parse_420(data, w, h, "sp")
            return y, u, v 
        elif self.input_fmt == "i420":
            # YUV420P UV
            y, u, v = self._parse_420(data, w, h, "p")
            return y, u, v 
        elif self.input_fmt == "yv12":
            # YUV420P VU
            y, v, u = self._parse_420(data, w, h, "p")
            return y, u, v 
        elif self.input_fmt == "nv16":
            # YUV422SP UV
            y, u, v = self._parse_422(data, w, h, "sp")
            return y, u, v 
        elif self.input_fmt == "nv61":
            # YUV422SP VU
            y, v, u = self._parse_422(data, w, h, "sp")
            return y, u, v 
        elif self.input_fmt == "i422":
            # YUV422P UV
            y, u, v = self._parse_422(data, w, h, "p")
            return y, u, v 
        elif self.input_fmt == "yv16":
            # YUV422P VU
            y, v, u = self._parse_422(data, w, h, "p")
            return y, u, v 
        elif self.input_fmt == "rgb":
            # [r g b r g b r g b ...]
            r, g, b = self._parse_rgb(data, w, h)
            return r, g, b
        elif self.input_fmt == "bgr":
            # [b g r b g r b g r ...]
            b, g, r = self._parse_rgb(data, w, h)
            return b, g, r
        else:
            raise NotImplementedError(f"input format {self.input_fmt} not supported")

    def _resize(self, shape, c0, c1, c2):
        """对每个通道进行resize"""
        scale_h = shape[1] / c0.shape[0]
        scale_w = shape[0] / c0.shape[1]

        c0 = cv2.resize(c0, None, fx=scale_w, fy=scale_h)
        c1 = cv2.resize(c1, None, fx=scale_w, fy=scale_h)
        c2 = cv2.resize(c2, None, fx=scale_w, fy=scale_h)
        return c0, c1, c2

    def _crop_region(self, array, w, h):
        """截取二维数组左上角部分,不足的区域补零"""
        assert len(array.shape) == 2
        if w <= array.shape[1] and h <= array.shape[0]:
            return array[:h, :w]
        else:
            crop_array = np.zeros(shape=[h, w], dtype=array.dtype)
            h = min(h, array.shape[0])
            w = min(w, array.shape[1])
            crop_array[:h, :w] = array[:h, :w]

            return crop_array

    def _crop(self, shape, c0, c1, c2):
        """截取每个通道左上角部分,不足的区域补零"""
        scale_h = shape[1] / c0.shape[0]
        scale_w = shape[0] / c0.shape[1]

        c0 = self._crop_region(c0, shape[0], shape[1])
        c1 = self._crop_region(c1, round(scale_w*c1.shape[1]), round(scale_h*c1.shape[0]))
        c2 = self._crop_region(c2, round(scale_w*c2.shape[1]), round(scale_h*c2.shape[0]))
        return c0, c1, c2

    def _cvt_format(self, c0, c1, c2):
        """转换data格式"""
        if self.input_fmt == self.output_fmt \
            and self.input_bt_format == self.output_bt_format \
            and self.input_range == self.output_range:
            #无需转换
            return c0, c1, c2
        
        # 将输入转换为rgb格式
        r, g, b = self._input2rgb(c0, c1, c2)
        # 将rgb转换为输出格式
        c0, c1, c2 = self._rgb2output(r, g, b)
        return c0, c1, c2

    def load(self, fmt=None, shape=None, mode="resize"):
        """加载数据

        Args:
            fmt: [str]
                输出数据格式, 如 RGB, BGR, NV21_BT601_FULL, NV21_BT709_TV 等; 若为None,不进行格转换
            shape: [list]
                输出图像shape, [w, h]; 若为None,加载原始尺寸
            mode: str
                reshape模式, resize 或者 crop
        Return:
            yuv format 分别返回 y, u, v 三个通道的np.array
            rgb/bgr format 返回一个 np.array, shape=[3, h, w]
        """
        if fmt:
            self.output_fmt, self.output_bt_format, self.output_range = self._parse_format(fmt)
        else:
            self.output_fmt = self.input_fmt
            self.output_bt_format = self.input_bt_format 
            self.output_range = self.input_range

        c0, c1, c2 = self._split_channel()

        shape = shape if shape else self.input_shape
        if mode == "resize":
            c0, c1, c2 = self._resize(shape, c0, c1, c2)
        elif mode == "crop":
            c0, c1, c2 = self._crop(shape, c0, c1, c2)
        else:
            raise NotImplementedError(f"resize mode format {mode} not supported")

        c0, c1, c2 =  self._cvt_format(c0, c1, c2)

        if self.output_fmt in ["nv12", "nv21", "i420", "yv12", "nv16", "nv61", "i422", "yv16"]:
            return c0, c1, c2
        elif self.output_fmt in ["rgb", "bgr"]:
            return self._compact_rgb(c0, c1, c2)
        else:
            raise NotImplementedError(f"format {self.output_fmt} not supported")

    @staticmethod
    def PackedCannel(a, b):
        """拼接两个通道的数据
        [a a a a] [b b b b] ==> [a b a b a b a b]
        """
        assert a.shape == b.shape, f"shape {a.shape} not match shape {b.shape}"
        w = a.shape[1]
        h = a.shape[0]
        a = a[np.newaxis]
        b = b[np.newaxis]
        c = np.concatenate([a, b])
        c = np.transpose(c, (1,2,0))
        c = c.reshape([h, w*2])
        return c

    @classmethod
    def FromRawData(cls, path, shape, fmt, dtype="uint8"):
        """加载raw data"""
        data = np.fromfile(path, dtype=dtype)
        return cls(data, shape, fmt)

    @classmethod
    def FromImage(cls, path):
        """加载图像数据"""
        data = cv2.imread(path)
        assert len(data.shape) == 3 and data.shape[2] == 3, \
            "image shape {} not support"
        h = data.shape[0]
        w = data.shape[1]
        data = data.flatten()
        return cls(data, [w, h], "bgr")


def test_yuv2rgb():
    def check_yuv2rgb(fmt, bt_format, yuv_range):
        shape=[720, 576]
        if fmt == "nv21":
            dir = "/goke/sw/data/yuv_test_data/pic_nv21_from_tw/420"
        else:
            dir = "/goke/sw/data/yuv_test_data/pic_nv21_from_tw/422"

        if yuv_range == "tv":
            rgb_path = os.path.join(dir, f"{bt_format}_limited.rgb")
            yuv_path = os.path.join(dir, f"{bt_format}_limited.yuv")
        else:
            rgb_path = os.path.join(dir, f"{bt_format}_full.rgb")
            yuv_path = os.path.join(dir, f"{bt_format}_full.yuv")

        loader_yuv = ImageLoader.FromRawData(yuv_path, shape=shape, fmt=f"{fmt}_bt{bt_format}_{yuv_range}")
        rgb = loader_yuv.load(fmt="rgb")

        loader_rgb = ImageLoader.FromRawData(rgb_path, shape=shape, fmt="rgb")
        rgb_gt = loader_rgb.load(fmt="rgb")

        np.testing.assert_allclose(rgb, rgb_gt, atol=1)
        print(f"yuv2rgb convert : {fmt} bt{bt_format} {yuv_range}  PASS!!")

    for fmt in ["nv21", "nv61"]:
        for bt_format in ["709", "601"]:
            for yuv_range in ["full", "tv"]:
                check_yuv2rgb(fmt, bt_format, yuv_range)


def test_rgb2yuv():
    def check_rgb2yuv(fmt, bt_format, yuv_range):
        rgb_path = "/goke/sw/data/yuv_test_data/gloden.rgb"
        shape = [720, 576]
        if fmt == "nv21":
            dir = "/goke/sw/data/yuv_test_data/pic_nv21_from_tw/420"
        else:
            dir = "/goke/sw/data/yuv_test_data/pic_nv21_from_tw/422"

        if yuv_range == "tv":
            yuv_path = os.path.join(dir, f"{bt_format}_limited.yuv")
        else:
            yuv_path = os.path.join(dir, f"{bt_format}_full.yuv")

        loader_rgb = ImageLoader.FromRawData(rgb_path, shape=shape, fmt="rgb")
        y, u, v = loader_rgb.load(fmt=f"{fmt}_bt{bt_format}_{yuv_range}")

        loader_yuv = ImageLoader.FromRawData(yuv_path, shape=shape, fmt=f"{fmt}_bt{bt_format}_{yuv_range}")
        y_gt, u_gt, v_gt = loader_yuv.load(fmt=f"{fmt}_bt{bt_format}_{yuv_range}")

        np.testing.assert_allclose(y, y_gt, atol=1)
        np.testing.assert_allclose(u, u_gt, atol=1)
        np.testing.assert_allclose(v, v_gt, atol=1)

        print(f"rgb2yuv convert : {fmt} bt{bt_format} {yuv_range}  PASS!!")

    for fmt in ["nv21", "nv61"]:
        for bt_format in ["709", "601"]:
            for yuv_range in ["full", "tv"]:
                check_rgb2yuv(fmt, bt_format, yuv_range)


if __name__ == "__main__":
    test_yuv2rgb()
    test_rgb2yuv()