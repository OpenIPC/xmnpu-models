import xmtvmc.compiler as compiler
import xmtvmc.io as io
from xmtvmc.main import register_parser
from xmtvmc.utils import (
    get_logger,
    parse_and_check_arguments,
    parse_output,
    set_level,
)


# 装饰器，将subparser append 到 main.py 中的 REGISTERED_PARSER 列表中
@register_parser
def add_compile_parser(subparsers, *args):
    """Include parser for 'compile' subcommand"""
    parser = subparsers.add_parser(
        "compile",
        help=(
            "compile the IRModule, output binary executables "
            "which can run on the targets machine."
        ),
    )
    parser.set_defaults(func=driver_compile)
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="path of IRModule (.json) to compile",
    )
    parser.add_argument(
        "--weight",
        required=True,
        type=str,
        help="path of weight (.params) to compile",
    )
    parser.add_argument(
        "--target",
        default="x86",
        choices=["x86", "xmnpu_x86", "xmnpu_npu"],
        type=str,
        help="target machine, choice ['x86', 'xmnpu_x86', 'xmnpu_npu']",
    )
    parser.add_argument(
        "--output-prefix",
        default="./",
        type=str,
        help="path prefix for compiled binaries, e.g. /path/to/module/",
    )
    parser.add_argument(
        "--output-name",
        default="",
        type=str,
        help=(
            "filename for compiled binaries, e.g. exported_module ; "
            "if not specified, use IRModule filename by default"
        ),
    )
    parser.add_argument(
        "--config-file",
        default="",
        type=str,
        required=True,
        help="config file in YAML format, which contains compiling details",
    )
    parser.add_argument(
        "--log-level",
        default="error",
        type=str,
        choices=["debug", "info", "warn", "error"],
        help="to specify log level: debug, info, warn or error",
    )


def driver_compile(args):
    set_level(args.log_level)

    args.command = "compile"
    args = parse_and_check_arguments(args)

    lib, params = compile_module(args)

    dump_lib(args, lib, params)


def compile_module(args):
    logger = get_logger()
    logger.info("compiling the model ...........")

    mod = io.load_json(args.model)
    params = io.load_param_dict(args.weight)

    lib, params = compiler.build(
        mod=mod, params=params, target=args.target, config=args.compile
    )

    return lib, params


def dump_lib(args, lib, params):
    filename = parse_output(args)
    io.export_library(lib, f"{filename}.{args.target}.so")
    io.save_tensor_info(params, f"{filename}.{args.target}.so.params")
