import onnx
from caffe.proto import caffe_pb2 as pb
from google.protobuf import text_format

import xmtvmc.frontends as frontends
import xmtvmc.io as io
from xmtvmc.main import register_parser
from xmtvmc.utils import (
    get_logger,
    parse_and_check_arguments,
    parse_output,
    set_level,
)


# 装饰器，将 subparser append 到 main.py 中的 REGISTERED_PARSER 列表中
@register_parser
def add_import_parser(subparsers, *args):
    """Include parser for 'import' subcommand"""
    parser = subparsers.add_parser(
        "import",
        help=(
            "import models (support onnx-float, onnx-int8, caffe), "
            "export as IRModule files (.params and .json)"
        ),
    )
    parser.set_defaults(func=driver_import)
    parser.add_argument(
        "--model",
        default="",
        type=str,
        required=True,
        help="path of model(.onnx or .prototxt)",
    )
    parser.add_argument(
        "--weight",
        default="",
        type=str,
        help="path of model weights, for caffe only (.caffemodel)",
    )
    parser.add_argument(
        "--framework",
        choices=["onnx-float", "onnx-int8", "caffe"],
        type=str,
        required=True,
        help="framework of model to import",
    )
    parser.add_argument(
        "--output-prefix",
        default="./",
        type=str,
        help="path prefix for exported IRModule files, e.g. /path/to/module/",
    )
    parser.add_argument(
        "--output-name",
        default="",
        type=str,
        help=(
            "filename for exported IRModule files, e.g. exported_module ; "
            "if not specified, use imported filename by default"
        ),
    )
    parser.add_argument(
        "--config-file",
        default="",
        type=str,
        required=True,
        help=(
            "config file in YAML format, "
            "which contains preprocessing, quantization and output details"
        ),
    )
    parser.add_argument(
        "--log-level",
        default="error",
        type=str,
        choices=["debug", "info", "warn", "error"],
        help="to specify log level: debug, info, warn or error",
    )


def driver_import(args):
    set_level(args.log_level)

    args.command = "import"
    args = parse_and_check_arguments(args)

    if args.framework == "onnx-float":  # load onnx-float
        mod, params = import_onnx(args)
    elif args.framework == "onnx-int8":  # load onnx-int8
        raise NotImplementedError("onnx int8 model is not supported yet")
    else:  # load caffe
        mod, params = import_caffe(args)

    # dump IRModule and parameters
    dump_module(args, mod, params)


def import_onnx(args):
    logger = get_logger()
    logger.info("import the onnx model ...........")

    onnx_model = onnx.load(args.model)
    mod, params = frontends.from_onnx(
        model=onnx_model,
        shape_dict=args.input_shape,
        dtype_dict=args.input_dtype,
        input_layout=args.input_layout,
        input_format=args.input_format,
        normalize=args.input_normalize,
        output=args.outputs,
        extra_output=args.extra_outputs,
        model_format=args.model_format,
    )

    return mod, params


def upgrade_network(predict_net):
    # upgrade
    #   input: "data"
    #   input_shape { dim: 1 dim: 3 dim: 227 dim: 227 }
    # to
    #   layer {
    #     name: "data"
    #     type: "Input"
    #     top: "data"
    #     input_param { shape: { dim: 1 dim: 3 dim: 227 dim: 227 } }
    #   }

    if len(predict_net.input) == 1:
        input_name = predict_net.input.pop()

        if len(predict_net.input_shape) == 1:
            input_shape = predict_net.input_shape.pop()
        elif len(predict_net.input_dim) == 4:
            input_shape = pb.BlobShape()
            input_shape.dim.extend(predict_net.input_dim)
        else:
            raise ValueError("Cannot find shape info in prototxt")

        input_layer = pb.LayerParameter()
        input_layer.name = input_name
        input_layer.type = "Input"
        input_layer.top.append(input_name)
        input_layer.input_param.shape.append(input_shape)

        predict_net.layer.insert(0, input_layer)

    return predict_net


def import_caffe(args):
    logger = get_logger()
    logger.info("import caffe the model ...........")

    # load blob
    init_net = pb.NetParameter()
    with open(args.weight, "rb") as fin:
        init_net.ParseFromString(fin.read())

    # load model
    predict_net = pb.NetParameter()
    with open(args.model, "r") as fin:
        text_format.Merge(fin.read(), predict_net, allow_unknown_field=True)

    mod, params = frontends.from_caffe(
        init_net=init_net,
        predict_net=upgrade_network(predict_net),
        shape_dict=args.input_shape,
        dtype_dict=args.input_dtype,
        input_layout=args.input_layout,
        input_format=args.input_format,
        normalize=args.input_normalize,
        model_format=args.model_format,
    )
    return mod, params


def dump_module(args, mod, params):
    filename = parse_output(args)

    io.save_param_dict(params, filename + ".params")
    io.save_json(mod, filename + ".json")
