import logging

import tvm
from tvm import relay
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import RELAY_HOOK_PRIORITY
from xmtvmc.hooks.runner import RELAY_RUNNER
from xmtvmc.utils import get_logger

logger = get_logger()


@RELAY_RUNNER.register_hook(
    "remove_special_postprocess", RELAY_HOOK_PRIORITY["remove_special_postprocess"]
)
class RemoveSpecialPostprocessHook(Hook):
    """
    """
    def transform(self, mod, params, **kwargs):
        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod
        assert isinstance(func, relay.function.Function)
        body = func.body

        if not isinstance(body, relay.Call):
            logger.debug("multiple-output model, without regard to remove softmax")
            return mod, params

        body_list = dir(body)
        if 'args' in body_list and len(body.args) > 0:
            pre_expr = body.args[0]
            pre_expr_list = dir(pre_expr)
            # remove flatten
            if (
                isinstance(body, relay.Call) and body.op.name == "nn.batch_flatten" 
                and isinstance(pre_expr, relay.Call) and pre_expr.op.name == "nn.global_avg_pool2d"
            ):
                body = pre_expr
                func = relay.function.Function(relay.analysis.free_vars(body), body)
                mod = tvm.IRModule.from_expr(func)
            elif 'args' in pre_expr_list and len(pre_expr.args) > 0:
                pre_expr1 = pre_expr.args[0]
                pre_expr1_list = dir(pre_expr1)
                # remove squeeze and softmax
                if (
                    isinstance(body, relay.Call) and body.op.name == "nn.softmax" 
                    and isinstance(pre_expr, relay.Call) and pre_expr.op.name == "squeeze" 
                    and isinstance(pre_expr1, relay.Call) and pre_expr1.op.name == "nn.bias_add"
                ):
                    body = pre_expr1
                    func = relay.function.Function(relay.analysis.free_vars(body), body)
                    mod = tvm.IRModule.from_expr(func)
                elif 'args' in pre_expr1_list and len(pre_expr1.args) > 0:
                    pre_expr2 = pre_expr1.args[0]
                    # remove softmax
                    if (
                        isinstance(body, relay.Call) and body.op.name == "divide" 
                        and isinstance(pre_expr, relay.Call) and pre_expr.op.name == "exp" 
                        and isinstance(pre_expr1, relay.Call) and pre_expr1.op.name == "subtract" 
                        and isinstance(pre_expr2, relay.Call) and pre_expr2.op.name == "nn.global_avg_pool2d"
                    ):
                        body = pre_expr2
                        func = relay.function.Function(relay.analysis.free_vars(body), body)
                        mod = tvm.IRModule.from_expr(func)

        return mod, params
