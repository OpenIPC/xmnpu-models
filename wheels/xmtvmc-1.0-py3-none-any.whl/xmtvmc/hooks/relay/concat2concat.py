import numpy as np

import tvm
from tvm import relay
from tvm.relay import expr as _expr
from tvm.relay.quantize.quantize import _bind_params

from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import RELAY_HOOK_PRIORITY
from xmtvmc.hooks.runner import RELAY_RUNNER


class Concat2ConcatPatternRewriter(relay.expr_functor.ExprMutator):
    def __init__(self, ):
        super().__init__()

    def visit_call(self, call):
        new_fn   = self.visit(call.op)
        new_args = []

        if call.op.name == "concatenate" and isinstance(call.args[0], _expr.Tuple):

            for arg in call.args[0]:
                if isinstance(arg, _expr.Call):
                    
                    channels = 0

                    if arg.op.name == "concatenate":
                        for type in arg.type_args:
                            for field in type.fields:
                                channels += field.shape[1].value
                    elif arg.op.name == "add":
                        channels = arg.type_args[0].shape[1].value
                    else:
                        if len(arg.type_args) == 0:
                            channels = arg.args[0].type_args[0].shape[1].value
                        elif len(arg.type_args) == 1:
                            channels = arg.type_args[0].shape[1].value
                        elif len(arg.type_args) == 2:
                            channels = arg.type_args[1].shape[0].value

              
                    weight  = np.ones((channels, 1, 1))
                    kernel  = relay.const(np.expand_dims(weight, axis=1), "float32")
                    arg     = relay.nn.conv2d(
                                arg,
                                kernel,
                                groups      = channels, 
                                channels    = channels,
                                kernel_size = (1, 1),
                            )

                    new_args.append(self.visit(arg))
                else:
                    new_args.append(self.visit(arg))
            new_args =  [_expr.Tuple(new_args, call.args[0].span)]
            return relay.Call(new_fn, new_args, call.attrs, call.type_args, call.span)
        else:
            for arg in call.args:
                new_args.append(self.visit(arg))
            return relay.Call(new_fn, new_args, call.attrs, call.type_args, call.span)



@RELAY_RUNNER.register_hook(
    "concat2concat_pattern", RELAY_HOOK_PRIORITY["concat2concat_pattern"]
)
class Concat2ConcatPatten(Hook):
    def transform(self, mod, params, **kwargs):
        if params:
            mod["main"] = _bind_params(mod["main"], params)
        
        func    = mod["main"]
        visitor = Concat2ConcatPatternRewriter()
        func    = visitor.visit(func)
        mod     = tvm.IRModule.from_expr(func)

        with tvm.transform.PassContext(opt_level=3):
            f = relay.build_module.bind_params_by_name(mod["main"], params)
            mod = tvm.IRModule()
            mod["main"] = f
            mod = relay.transform.InferType()(mod)

        return mod, params
