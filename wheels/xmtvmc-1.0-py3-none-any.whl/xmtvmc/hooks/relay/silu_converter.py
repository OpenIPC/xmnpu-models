import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import DFPatternCallback, is_op, wildcard
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import RELAY_HOOK_PRIORITY
from xmtvmc.hooks.runner import RELAY_RUNNER
from xmtvmc.utils import get_logger

logger = get_logger()


class SiluConverterPattern(DFPatternCallback):
    def __init__(self,):
        super(SiluConverterPattern, self).__init__()
        pattern = is_op("sigmoid")(None)
        pattern = is_op("multiply")(pattern, wildcard()) | is_op("multiply")(wildcard(), pattern)
        self.pattern = pattern

    def callback(self, pre, post, node_map):
        if post.args[0].op.name == "sigmoid":
            sigm_inputs = post.args[0]
            data = post.args[1]
        else:
            sigm_inputs = post.args[1]
            data = post.args[0]

        if data == sigm_inputs.args[0]:
            logger.debug("convert sigmoid and multiply to silu")
            return relay.nn.silu(data)
        else:
            return post


@RELAY_RUNNER.register_hook("silu_converter", RELAY_HOOK_PRIORITY["silu_converter"])
class SiluConverter(Hook):
    def transform(self, mod, params,**kwargs):
        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod

        rewrite_func = SiluConverterPattern().rewrite(func)
        mod = relay.Function(relay.analysis.free_vars(
            rewrite_func.body), rewrite_func.body)
        mod = tvm.IRModule.from_expr(mod)
        return mod, params
