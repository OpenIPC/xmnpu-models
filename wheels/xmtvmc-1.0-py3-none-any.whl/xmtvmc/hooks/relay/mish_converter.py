import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import DFPatternCallback, is_op, wildcard
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import BEFORE_QNN_HOOK_PRIORITY
from xmtvmc.hooks.runner import BEFORE_QNN_RUNNER


class MishConverterPattern(DFPatternCallback):
    def __init__(
        self,
    ):
        super(MishConverterPattern, self).__init__()

        pattern = is_op("exp")(None)
        pattern = is_op("add")(pattern,wildcard())
        pattern = is_op("log")(pattern)
        pattern = is_op("tanh")(pattern)
        pattern = is_op("multiply")(wildcard(),pattern) | is_op("multiply")(pattern,wildcard())
        self.pattern = pattern

    def callback(self, pre, post, node_map):
        input_op = post.args[0]
        return  tvm.relay.nn.mish(input_op)


@BEFORE_QNN_RUNNER.register_hook(
    "mish_converter", BEFORE_QNN_HOOK_PRIORITY["mish_converter"]
)
class MishConverter(Hook):
    def transform(self, mod, params):
        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod

        rewrite_func = MishConverterPattern().rewrite(func)

        mod = relay.Function(relay.analysis.free_vars(rewrite_func.body),
                             rewrite_func.body)
        mod = tvm.IRModule.from_expr(mod)
        return mod, params
