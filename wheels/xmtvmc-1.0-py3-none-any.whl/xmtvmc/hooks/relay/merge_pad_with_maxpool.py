from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import RELAY_HOOK_PRIORITY
from xmtvmc.hooks.runner import RELAY_RUNNER
from xmtvmc.utils import get_logger

import numpy as np
import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import *
from tvm.relay.quantize.quantize import _bind_params


class RewriteMaxPool2DPad(DFPatternCallback):
    def __init__(self, rewrite_once):
        """
        %x = nn.pad(%y, 0, pad_width=[[0, 0], [0, 0], [0, 0], [0, 0]]);
        nn.max_pool2d(%x, pool_size=[2, 2], strides=[2, 2], padding=[0, 0, 0, 0])
        """
        super().__init__(rewrite_once=rewrite_once)
        _pattern_ = is_op("nn.pad")(wildcard(), wildcard())
        self.pattern = is_op("nn.max_pool2d")(_pattern_)

    def callback(self, pre, post, node_map):

        logger = get_logger()

        maxpool_call = post
        assert len(maxpool_call.args) == 1
        assert maxpool_call.attrs.layout == "NCHW"

        pad_call = post.args[0]
        for argument in pad_call.args:
            if is_constant().match(argument):
                pad_val = argument.data.numpy()
                try:
                    np.testing.assert_allclose(pad_val, 0, atol=1e-5)
                except AssertionError:
                    logger.warning(f"expects padding with 0, but got {pad_val}")
            else:
                input = argument

        # top, left, bottom, right
        padding = (
            maxpool_call.attrs.padding[0] + pad_call.attrs.pad_width[2][0],
            maxpool_call.attrs.padding[1] + pad_call.attrs.pad_width[3][0],
            maxpool_call.attrs.padding[2] + pad_call.attrs.pad_width[2][1],
            maxpool_call.attrs.padding[3] + pad_call.attrs.pad_width[3][1],
        )

        return relay.nn.max_pool2d(
            input,
            maxpool_call.attrs.pool_size,
            maxpool_call.attrs.strides,
            maxpool_call.attrs.dilation,
            padding,
            maxpool_call.attrs.layout,
            maxpool_call.attrs.out_layout,
            maxpool_call.attrs.ceil_mode,
        )


@RELAY_RUNNER.register_hook(
    "merge_pad_with_maxpool", RELAY_HOOK_PRIORITY["merge_pad_with_maxpool"]
)
class MergeMaxPool2DPadHook(Hook):
    """ """

    def transform(self, mod, params, **kwargs):
        if params:
            mod["main"] = _bind_params(mod["main"], params)

        func = mod["main"]
        func = RewriteMaxPool2DPad(False).rewrite(func)
        func = relay.Function(relay.analysis.free_vars(func.body), func.body)
        mod = tvm.IRModule.from_expr(func)

        return mod, params
