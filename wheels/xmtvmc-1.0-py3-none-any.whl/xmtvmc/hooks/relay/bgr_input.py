import tvm
from tvm import relay
from tvm.relay import expr as _expr
from tvm.relay.quantize.quantize import _bind_params

from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import RELAY_HOOK_PRIORITY
from xmtvmc.hooks.runner import RELAY_RUNNER

class BGRInputVisitor(relay.expr_functor.ExprMutator):
    """
    """
    def __init__(self, normalize):
        super().__init__()
        self._normalize = normalize

    def has_normalize_op(self, call):
        """
        fused normalize before bgr hook
        """
        is_modify = False
        weight_new = None
        if call.op.name == "nn.conv2d":
            if isinstance(call.args[0], _expr.Call)\
            and call.args[0].op.name in ("add", "nn.bias_add"):
                if isinstance(call.args[0].args[0], _expr.Call) \
                and call.args[0].args[0].op.name == "nn.conv2d":
                    if isinstance(call.args[0].args[0].args[0], _expr.Var):
                        weight = call.args[1] 
                        weight_array = weight.data.asnumpy()
                        weight_array = weight_array[:,::-1,:,:]
                        weight_new = relay.Constant(tvm.nd.array(weight_array))
                        is_modify = True
        return is_modify, weight_new

    def no_normalize_op(self, call):
        """
        not fused normalize before bgr hook
        """
        is_modify = False
        weight_new = None
        if call.op.name == "nn.conv2d" and isinstance(call.args[0], _expr.Var):
            weight = call.args[1]
            weight_array = weight.data.asnumpy()
            weight_array = weight_array[:,::-1,:,:]
            weight_new = relay.Constant(tvm.nd.array(weight_array))
            is_modify = True
        return is_modify, weight_new

    def visit_call(self, call):
        new_fn = self.visit(call.op)
        new_args = []

        if self._normalize:
            is_modify, weight_new = self.has_normalize_op(call)
        else:
            is_modify, weight_new = self.no_normalize_op(call)

        for arg in call.args:
            new_args.append(self.visit(arg))
        if is_modify:
            new_args[1] = weight_new
        return relay.Call(new_fn, new_args, call.attrs, call.type_args, call.span)

@RELAY_RUNNER.register_hook("bgr_input", RELAY_HOOK_PRIORITY["bgr_input"])
class BGRInputHook(Hook):
    """
    """
    def transform(self, mod, params, **kwargs):
        input_format = kwargs.get('input_format', None)
        model_format = kwargs.get('model_format', None)
        normalize = kwargs.get('normalize', None)
        #normalize = None
        if (input_format == "BGR" and model_format == "BGR") or \
            (input_format != "BGR" and model_format != "BGR"):
            return mod, params
        if normalize:
            assert len(normalize) == 1, "bgr input only support one input"
            for key in normalize:
                mean, _ = normalize[key]
            if (0 == mean[0] == mean[1] ==mean[2]):
                normalize = False

        if params:
            mod["main"] = _bind_params(mod["main"], params)
        func = mod["main"]
        visitor = BGRInputVisitor(normalize)
        func = visitor.visit(func)
        mod = tvm.IRModule.from_expr(func)

        return mod, params

