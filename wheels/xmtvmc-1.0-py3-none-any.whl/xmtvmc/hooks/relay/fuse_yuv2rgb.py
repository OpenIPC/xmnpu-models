import tvm
import xmnpu
from tvm import relay
from tvm.relay import expr as _expr
from tvm.relay.quantize.quantize import _bind_params
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import RELAY_HOOK_PRIORITY
from xmtvmc.hooks.runner import RELAY_RUNNER


class FuseYUV2RGBVisitor(relay.expr_functor.ExprMutator):
    def __init__(self, yuv_format, bt_format, range, height, width):
        super().__init__()

        yuv_format = {
            "NV21": "YUV_420SP",
            "YUV420SP": "YUV_420SP",
            "NV61": "YUV_422SP",
            "YUV422SP": "YUV_422SP",
        }[yuv_format]

        Y_shape = (height, width)
        if yuv_format == "YUV_420SP":
            VU_shape = (height // 2, width)
        else:
            VU_shape = (height, width)

        self.yuv_format = yuv_format
        self.bt_format = bt_format
        self.range = range
        self.Y_shape = Y_shape
        self.VU_shape = VU_shape

    def visit_call(self, call):
        new_fn = self.visit(call.op)
        new_args = []

        for arg in call.args:
            if isinstance(arg, _expr.Var):
                y = tvm.relay.var("Y", shape=self.Y_shape, dtype="uint8")
                vu = tvm.relay.var("UV", shape=self.VU_shape, dtype="uint8")

                func = xmnpu.relay.yuv2rgb(
                    y,
                    vu,
                    self.yuv_format,
                    self.bt_format,
                    self.range,
                    dtype="uint8",
                )

                func = relay.cast(func, "float32")
                new_args.append(func)
            else:
                new_args.append(self.visit(arg))

        return relay.Call(
            new_fn, new_args, call.attrs, call.type_args, call.span
        )


@RELAY_RUNNER.register_hook("fuse_yuv2rgb", RELAY_HOOK_PRIORITY["fuse_yuv2rgb"])
class FuseYUV2RGBHook(Hook):
    """
    insert yuv2rgb operator to model input
    according to input_format configuration
    """

    def parse_input_format(self, input_format):
        valid_format = (
            "RGB",
            "BGR",
            "NV21_BT601_FULL",
            "NV21_BT709_FULL",
            "NV21_BT601_TV",
            "NV21_BT709_TV",
            "NV61_BT601_FULL",
            "NV61_BT709_FULL",
            "NV61_BT601_TV",
            "NV61_BT709_TV",
            "YUV420SP_BT601_FULL",
            "YUV420SP_BT709_FULL",
            "YUV420SP_BT601_TV",
            "YUV420SP_BT709_TV",
            "YUV422SP_BT601_FULL",
            "YUV422SP_BT709_FULL",
            "YUV422SP_BT601_TV",
            "YUV422SP_BT709_TV",
        )
        if input_format not in valid_format:
            raise ValueError(
                f"expects input_format in {valid_format}, but got {input_format}"
            )

        formats = input_format.split("_")
        if len(formats) == 3:  # YUV
            return formats
        else:
            return formats[0], None, None

    def parse_input_shape(self, input_shape):
        if not isinstance(input_shape, dict):
            raise ValueError(
                f"expects input_shape as input_name: (N, C, H, W), but got {input_shape}"
            )
        if len(input_shape) != 1:
            raise NotImplementedError("only one input is supported yet")

        input_shape = list(input_shape.values())[0]
        if len(input_shape) != 4:
            raise ValueError(
                f"expects input_shape as input_name: (N, C, H, W), but got {input_shape}"
            )

        _, _, height, width = input_shape
        return height, width

    def transform(self, mod, params, **kwargs):
        input_format = kwargs.get("input_format", "RGB")
        color, bt_format, range = self.parse_input_format(input_format)

        # TODO: support other YUV formats
        if color not in ("RGB", "BGR"):
            input_shape = kwargs.get("shape_dict", None)
            height, width = self.parse_input_shape(input_shape)
            visitor = FuseYUV2RGBVisitor(
                color, bt_format, range, height, width
            )

            func = mod["main"]
            if params:
                func = _bind_params(func, params)

            func = visitor.visit(func)
            func = tvm.relay.Function(
                tvm.relay.analysis.free_vars(func.body), func.body
            )
            mod = tvm.IRModule.from_expr(func)

        return mod, params
