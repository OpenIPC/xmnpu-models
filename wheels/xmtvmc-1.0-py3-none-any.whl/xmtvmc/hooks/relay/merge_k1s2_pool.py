import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import DFPatternCallback, is_op
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import BEFORE_QNN_HOOK_PRIORITY
from xmtvmc.hooks.runner import BEFORE_QNN_RUNNER


class MergeK1S2PoolPattern(DFPatternCallback):
    def __init__(
        self,
        pool_type="max",
    ):
        super(MergeK1S2PoolPattern, self).__init__()

        self.pattern = is_op(f"nn.{pool_type}_pool2d")(None).has_attr({
            "pool_size": (1, 1),
            "strides": (2, 2)
        })
        self.pool_inout_dict = {}

    def callback(self, pre, post, node_map):
        input_op = post.args[0]

        if input_op not in self.pool_inout_dict:
            self.pool_inout_dict[input_op] = post

        return self.pool_inout_dict[input_op]


@BEFORE_QNN_RUNNER.register_hook(
    "merge_k1s2_pool", BEFORE_QNN_HOOK_PRIORITY["merge_k1s2_pool"]
)
class MergeK1S2Pool(Hook):
    def transform(self, mod, params):
        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod

        rewrite_func = MergeK1S2PoolPattern().rewrite(func)
        rewrite_func = MergeK1S2PoolPattern("avg").rewrite(rewrite_func)

        mod = relay.Function(relay.analysis.free_vars(rewrite_func.body),
                             rewrite_func.body)
        mod = tvm.IRModule.from_expr(mod)
        return mod, params
