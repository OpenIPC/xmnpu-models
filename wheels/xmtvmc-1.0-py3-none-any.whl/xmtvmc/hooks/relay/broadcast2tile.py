import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import DFPatternCallback, is_op, wildcard
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import BEFORE_QNN_HOOK_PRIORITY
from xmtvmc.hooks.runner import BEFORE_QNN_RUNNER


class Broadcast2TilePattern(DFPatternCallback):
    def __init__(
        self,
    ):
        super(Broadcast2TilePattern, self).__init__()

        self.pattern = is_op("broadcast_to")(None)

    def callback(self, pre, post, node_map):
        input_op = post.args[0]
        mod = tvm.IRModule.from_expr(input_op)
        mod = relay.transform.InferType()(mod)
        input_shape = mod["main"].ret_type.shape

        attrs = post.attrs
        target_shape = attrs.shape

        assert len(target_shape) == len(input_shape)

        reps=[]
        for i in range(len(target_shape)):
            reps.append(int(target_shape[i]-input_shape[i])+1)

        print("target shape",target_shape)
        print("input shape",input_shape)
        print(reps)

        return relay.tile(input_op,reps)

        # return  post


@BEFORE_QNN_RUNNER.register_hook(
    "broadcast2tile", BEFORE_QNN_HOOK_PRIORITY["broadcast2tile"]
)
class Broadcast2Tile(Hook):
    def transform(self, mod, params):
        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod

        rewrite_func = Broadcast2TilePattern().rewrite(func)

        mod = relay.Function(relay.analysis.free_vars(rewrite_func.body),
                             rewrite_func.body)
        mod = tvm.IRModule.from_expr(mod)
        return mod, params
