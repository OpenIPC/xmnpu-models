import numpy as np

import tvm
from tvm import relay
from tvm.relay import expr as _expr
from tvm.relay.quantize.quantize import _bind_params

from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import RELAY_HOOK_PRIORITY
from xmtvmc.hooks.runner import RELAY_RUNNER

class FuseNormlizeVisitor(relay.expr_functor.ExprMutator):
    """
    """
    def __init__(self, normlize: dict, input_format, model_format):
        super().__init__()
        self._normalize = normlize
        self._input_format = input_format
        self._model_format = model_format

    def visit_call(self, call):
        new_fn = self.visit(call.op)
        new_args = []

        for arg in call.args:
            if isinstance(arg, _expr.Var):
                name = arg.name_hint
                mean, std = self._normalize[name]
                mean_ = np.expand_dims(np.array(mean),(1, 2))
                std_ = np.expand_dims(np.array(std),(1, 2))

                scale = 1 / np.array(std_)
                bias = -(np.array(mean_) / np.array(std_))
                if (self._input_format != "BGR" and self._model_format == "BGR") or \
                    (self._input_format == "BGR" and self._model_format != "BGR"):
                    scale = scale[::-1, :, :]
                    bias  = bias[::-1, :, :]

                mean_not_equal_0 = False
                if not (0 == mean[0] == mean[1] ==mean[2]):
                    mean_not_equal_0 = True
                if (not (1 == std[0] == std[1] == std[2])) or mean_not_equal_0:
                    arg = relay.multiply(arg, relay.const(scale, "float32"))
                if mean_not_equal_0:
                    arg = relay.add(arg, relay.const(bias, "float32"))
                new_args.append(arg)
            else:
                new_args.append(self.visit(arg))
        return relay.Call(new_fn, new_args, call.attrs, call.type_args, call.span)

@RELAY_RUNNER.register_hook("fuse_normalize", RELAY_HOOK_PRIORITY["fuse_normalize"])
class FuseNormalizeHook(Hook):
    """
    """
    def transform(self, mod, params, **kwargs):
        normalize = kwargs.get('normalize', None)
        input_format = kwargs.get('input_format', None)
        model_format = kwargs.get('model_format', None)
        if normalize:
            if params:
                mod["main"] = _bind_params(mod["main"], params)

            func = mod["main"]
            visitor = FuseNormlizeVisitor(normalize, input_format, model_format)
            func = visitor.visit(func)
            mod = tvm.IRModule.from_expr(func)
        return mod, params
