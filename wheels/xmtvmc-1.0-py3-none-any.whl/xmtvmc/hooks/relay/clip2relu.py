import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import DFPatternCallback, is_op
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import BEFORE_QNN_HOOK_PRIORITY
from xmtvmc.hooks.runner import BEFORE_QNN_RUNNER
from xmtvmc.utils import get_logger

logger = get_logger()


class Clip2ReluPattern(DFPatternCallback):
    def __init__(self):
        super(Clip2ReluPattern, self).__init__()
        self.pattern = is_op("clip")(None)

    def callback(self, pre, post, node_map):
        in_expr = post.args[0]
        a_min = post.attrs.a_min
        a_max = post.attrs.a_max

        if (
            in_expr.op.name == "nn.conv2d"
            or (
                in_expr.op.name == "nn.bias_add"
                and in_expr.args[0].op.name == "nn.conv2d"
            )
        ) and a_min == 0:
            logger.debug("convert clip to relu")
            return tvm.relay.nn.relu(in_expr)
        else:
            return tvm.relay.clip(in_expr, a_min, a_max)


@BEFORE_QNN_RUNNER.register_hook("clip2relu", BEFORE_QNN_HOOK_PRIORITY["clip2relu"])
class Clip2Relu(Hook):
    def transform(self, mod, params):
        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod

        rewrite_func = Clip2ReluPattern().rewrite(func)
        mod = relay.Function(relay.analysis.free_vars(
            rewrite_func.body), rewrite_func.body)
        mod = tvm.IRModule.from_expr(mod)
        return mod, params

