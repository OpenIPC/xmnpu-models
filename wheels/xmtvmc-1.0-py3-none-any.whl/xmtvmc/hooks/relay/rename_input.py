import logging

import tvm
from tvm import relay
from tvm.relay.quantize.quantize import _bind_params
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import RELAY_HOOK_PRIORITY
from xmtvmc.hooks.runner import RELAY_RUNNER
from xmtvmc.utils import get_logger

logger = get_logger()


class RenameInputVisitor(relay.expr_functor.ExprMutator):
    """
    """

    def __init__(self, rename="data"):
        super().__init__()
        self.name = rename

    def visit_var(self, var):
        if var.name_hint not in ["Y", "UV", self.name]:
            type_annotation = var.type_annotation
            shape = type_annotation.shape
            dtype = type_annotation.dtype

            new_var = tvm.relay.var(self.name, shape=shape, dtype=dtype)
            logger.debug("rename input variable {} to {}".format(var.name_hint, self.name))
            return new_var
        else:
            return var


@RELAY_RUNNER.register_hook("RenameInput", RELAY_HOOK_PRIORITY["rename_input"])
class RenameInput(Hook):
    """
    """

    def transform(self, mod, params, **kwargs):
        if "rename_input" not in kwargs or not kwargs["rename_input"]:
            return mod, params

        if params:
            mod["main"] = _bind_params(mod["main"], params)

        func = mod["main"]
        visitor = RenameInputVisitor()
        func = visitor.visit(func)
        func = tvm.relay.Function(
            tvm.relay.analysis.free_vars(func.body), func.body)
        mod = tvm.IRModule.from_expr(func)
        return mod, params
