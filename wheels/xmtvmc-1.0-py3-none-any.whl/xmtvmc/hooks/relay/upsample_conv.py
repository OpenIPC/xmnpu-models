import numpy as np
import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import DFPatternCallback, is_op
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import BEFORE_QNN_HOOK_PRIORITY
from xmtvmc.hooks.runner import BEFORE_QNN_RUNNER


class InsertConvAfterUpsamplePattern(DFPatternCallback):
    def __init__(
        self,
    ):
        super(InsertConvAfterUpsamplePattern, self).__init__()

        self.pattern = is_op("concatenate")(None)

    def callback(self, pre, post, node_map):

        in_tuple = post.args[0]
        in_up = None
        new_tuple = []

        for i in range(len(in_tuple)):
            in_expr = in_tuple[i]
            if in_expr.op.name == "nn.upsampling":

                in_up = in_expr
                mod = tvm.IRModule.from_expr(in_up)
                mod = relay.transform.InferType()(mod)
                ret_type = mod["main"].ret_type

                channel = int(ret_type.shape[1])
                dtype = ret_type.dtype

                weight = np.ones([channel, 1, 1, 1], dtype=dtype)
                weight = relay.Constant(tvm.nd.array(weight))
                conv_out = relay.nn.conv2d(
                    in_up,
                    weight,
                    groups=channel,
                    channels=channel,
                )

                new_tuple.append(conv_out)
            else:
                new_tuple.append(in_expr)

        return relay.concatenate(new_tuple, post.attrs.axis)


# @BEFORE_QNN_RUNNER.register_hook(
#     "InsertConvAfterUpsample",
#     BEFORE_QNN_HOOK_PRIORITY["insert_conv_before_upsample"],
# )
class InsertConvAfterUpsample(Hook):
    def transform(self, mod, params):
        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod

        rewrite_func = InsertConvAfterUpsamplePattern().rewrite(func)
        mod = relay.Function(
            relay.analysis.free_vars(rewrite_func.body), rewrite_func.body
        )
        mod = tvm.IRModule.from_expr(mod)
        return mod, params
