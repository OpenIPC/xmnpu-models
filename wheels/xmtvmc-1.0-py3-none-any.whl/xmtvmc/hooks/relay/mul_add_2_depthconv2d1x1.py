import numpy as np

import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import *
from tvm.relay.quantize.quantize import _bind_params

from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import RELAY_HOOK_PRIORITY
from xmtvmc.hooks.runner import RELAY_RUNNER


class Multiply2DepthConv2d1x1Rewriter(DFPatternCallback):
    def __init__(self, rewrite_once):
        super().__init__(rewrite_once=rewrite_once)
        _pattern = is_op("multiply")(wildcard(), is_constant())
        self.pattern = is_op("add")(_pattern, is_constant())

    def callback(self, pre, post, node_map):
        # 两种可能性：
        # add(%x, meta[relay.Constant][i])
        # add(meta[relay.Constant][i]， %x)
        for argument in post.args:
            if is_constant().match(argument):
                bias = argument
            else:
                multiply_call = argument

        # 两种可能性：
        # multiply(%x, meta[relay.Constant][i])
        # multiply(meta[relay.Constant][i]， %x)
        for argument in multiply_call.args:
            if is_constant().match(argument):
                weight = argument.data.numpy()
                _shape = weight.shape
            else:
                input = argument

        if weight.shape == (1,):
            weight = np.ones_like(bias.data.numpy()) * weight
            _shape = weight.shape

        if len(_shape) == 3 and _shape[-1] == 1 and _shape[-2] == 1:
            kernel = relay.const(np.expand_dims(weight, axis=1), "float32")
            bias = relay.const(bias.data.numpy().flatten(), "float32")
            f = relay.nn.conv2d(
                input,
                kernel,
                groups=_shape[0],
                channels=_shape[0],
                kernel_size=(1, 1),
            )
            return relay.nn.bias_add(f, bias)
        else:
            return post


@RELAY_RUNNER.register_hook(
    "mul_add_2_depthconv2d1x1", RELAY_HOOK_PRIORITY["mul_add_2_depthconv2d1x1"]
)
class MulAdd2DepthConv2d1X1Hook(Hook):
    """ """

    def transform(self, mod, params, **kwargs):
        """ convert
                add(multiply(x, const), const)
            -->
                depthconv2d with 1x1 kernel, bias_add
            for xmedia NPU scale-bias_add comput-flow """
        if params:
            mod["main"] = _bind_params(mod["main"], params)

        func = mod["main"]
        func = Multiply2DepthConv2d1x1Rewriter(False).rewrite(func)
        func = relay.Function(relay.analysis.free_vars(func.body), func.body)
        mod = tvm.IRModule.from_expr(func)

        with tvm.transform.PassContext(opt_level=3):
            mod = relay.transform.FoldScaleAxis()(mod)
        return mod, params
