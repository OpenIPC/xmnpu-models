import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import DFPatternCallback, is_op
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import RELAY_HOOK_PRIORITY
from xmtvmc.hooks.runner import RELAY_RUNNER


class Resize2UpsamplePattern(DFPatternCallback):
    def __init__(self):
        super(Resize2UpsamplePattern, self).__init__()
        self.pattern = is_op("image.resize2d")(None)

    def callback(self, pre, post, node_map):
        in_expr = post.args[0]
        layout = post.attrs.layout

        input_shape = in_expr.checked_type.shape
        assert len(input_shape) == 4, "input_dim != 4"
        if layout == "NCHW":
            input_h = input_shape[2].value
            input_w = input_shape[3].value
        elif layout == "NHWC":
            input_h = input_shape[1].value
            input_w = input_shape[2].value
        else:
            # TODO: support other layout
            raise ValueError("not support this layout {} yet".format(layout))
        
        output_shape = post.attrs.size
        output_h = output_shape[0].value
        output_w = output_shape[1].value

        scale_h = output_h / input_h
        scale_w = output_w / input_w

        return tvm.relay.nn.upsampling(
            in_expr, 
            scale_h = scale_h,
            scale_w = scale_w,
            layout=layout,
            method=post.attrs.method,
            align_corners=False,
        )


@RELAY_RUNNER.register_hook("resize2upsample", RELAY_HOOK_PRIORITY["resize2upsample"])
class Resize2Upsample(Hook):
    def transform(self, mod, params, **kwargs):
        mod = relay.transform.InferType()(mod)
        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod

        rewrite_func = Resize2UpsamplePattern().rewrite(func)
        mod = relay.Function(relay.analysis.free_vars(
            rewrite_func.body), rewrite_func.body)
        mod = tvm.IRModule.from_expr(mod)
        return mod, params
