import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import DFPatternCallback, is_op
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import BEFORE_QNN_HOOK_PRIORITY
from xmtvmc.hooks.runner import BEFORE_QNN_RUNNER


class ReduceLargeKernelPoolPattern(DFPatternCallback):
    def __init__(
        self,
    ):
        super(ReduceLargeKernelPoolPattern, self).__init__()
        self.pattern = is_op("nn.max_pool2d")(None).has_attr({
            "dilation": (1, 1),
        })

    def callback(self, pre, post, node_map):

        pool_size = post.attrs.pool_size
        pool_stride = post.attrs.strides
        padding = post.attrs.padding

        if (
            pool_size[0] == pool_size[1] > 3 
            and pool_size[0] % 2 == 1
            and padding[0] == padding[1] == padding[2] == padding[3] <= pool_size[0] // 2
        ):
            pad_count = padding[0]
            out = post.args[0]

            for i in range(0,int(pool_size[0])//2):

                if pad_count>0:
                    pad = 1
                    pad_count-=1
                else:
                    pad = 0

                if i == int(pool_size[0])//2-1:
                    strides = pool_stride
                else:
                    strides = 1

                out = relay.nn.max_pool2d(
                    out,
                    pool_size=(3,3),
                    strides=strides,
                    padding=pad,
                )

            return out
        else:
            return post


@BEFORE_QNN_RUNNER.register_hook(
    "reduce_large_kernel_pool", BEFORE_QNN_HOOK_PRIORITY["reduce_large_kernel_pool"]
)
class ReduceLargeKernelPool(Hook):
    def transform(self, mod, params):
        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod

        rewrite_func = ReduceLargeKernelPoolPattern().rewrite(func)
        mod = relay.Function(
            relay.analysis.free_vars(rewrite_func.body), rewrite_func.body
        )
        mod = tvm.IRModule.from_expr(mod)
        return mod, params
