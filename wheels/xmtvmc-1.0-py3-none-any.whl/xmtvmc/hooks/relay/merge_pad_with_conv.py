from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import RELAY_HOOK_PRIORITY
from xmtvmc.hooks.runner import RELAY_RUNNER
from xmtvmc.utils import get_logger

import numpy as np
import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import *
from tvm.relay.quantize.quantize import _bind_params


class RewriteConv2DPad(DFPatternCallback):
    def __init__(self, rewrite_once):
        """
        %1 = nn.pad(%0, 0f , pad_width=[[0, 0], [0, 0], [1, 1], [1, 1]]) ;
        %2 = nn.conv2d(%1, meta[relay.Constant][1] , padding=[0, 0, 0, 0], channels=16, kernel_size=[3, 3]) ;
        """
        super().__init__(rewrite_once=rewrite_once)
        _pattern_ = is_op("nn.pad")(wildcard(), wildcard())
        self.pattern = is_op("nn.conv2d")(_pattern_, wildcard())

    def callback(self, pre, post, node_map):
        logger = get_logger()

        conv_call = post
        assert len(conv_call.args) == 2
        assert conv_call.attrs.data_layout == "NCHW"

        pad_call = post.args[0]
        for argument in pad_call.args:
            if is_constant().match(argument):
                pad_val = argument.data.numpy()
                try:
                    np.testing.assert_allclose(pad_val, 0, atol=1e-5)
                except AssertionError:
                    logger.warning(f"expects padding with 0, but got {pad_val}")
            else:
                input = argument

        # top, left, bottom, right
        padding = (
            conv_call.attrs.padding[0] + pad_call.attrs.pad_width[2][0],
            conv_call.attrs.padding[1] + pad_call.attrs.pad_width[3][0],
            conv_call.attrs.padding[2] + pad_call.attrs.pad_width[2][1],
            conv_call.attrs.padding[3] + pad_call.attrs.pad_width[3][1],
        )

        return relay.nn.conv2d(
            input,
            conv_call.args[1],
            conv_call.attrs.strides,
            padding,
            conv_call.attrs.dilation,
            conv_call.attrs.groups,
            conv_call.attrs.channels,
            conv_call.attrs.kernel_size,
            conv_call.attrs.data_layout,
            conv_call.attrs.kernel_layout,
            conv_call.attrs.out_layout,
            conv_call.attrs.out_dtype,
        )


@RELAY_RUNNER.register_hook(
    "merge_pad_with_conv", RELAY_HOOK_PRIORITY["merge_pad_with_conv"]
)
class MergeConv2DPadHook(Hook):
    """ """

    def transform(self, mod, params, **kwargs):
        if params:
            mod["main"] = _bind_params(mod["main"], params)

        func = mod["main"]
        func = RewriteConv2DPad(False).rewrite(func)
        func = relay.Function(relay.analysis.free_vars(func.body), func.body)
        mod = tvm.IRModule.from_expr(func)

        return mod, params
