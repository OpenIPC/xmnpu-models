import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import DFPatternCallback, is_op
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import BEFORE_QNN_HOOK_PRIORITY
from xmtvmc.hooks.runner import BEFORE_QNN_RUNNER


class ConvK1S2Pattern(DFPatternCallback):
    def __init__(
        self,
    ):
        super(ConvK1S2Pattern, self).__init__()
        self.pattern = is_op("nn.conv2d")(None)

    def callback(self, pre, post, node_map):
        assert post.attrs.kernel_layout == "OIHW"

        kernel = post.args[1]
        if isinstance(kernel, relay.Var):
            kernel_size = kernel.type_annotation.shape
        elif isinstance(kernel, relay.Constant):
            kernel_size = kernel.data.shape
        else:
            raise ValueError(
                "invalid conv2d kernel weight data type {}".format(type(kernel))
            )

        kernel_height, kernel_width = kernel_size[2], kernel_size[3]
        strides = post.attrs.strides

        if kernel_height == kernel_width == 1 and strides[0] == strides[1] == 2:
            out = relay.nn.max_pool2d(post.args[0], (1, 1), (2, 2))
            out = relay.nn.conv2d(
                out,
                kernel,
                (1, 1),
                post.attrs.padding,
                post.attrs.dilation,
                post.attrs.groups,
                post.attrs.channels,
                post.attrs.kernel_size,
                post.attrs.data_layout,
                post.attrs.kernel_layout,
                post.attrs.out_layout,
                post.attrs.out_dtype,
            )
            return out
        else:
            return post


@BEFORE_QNN_RUNNER.register_hook(
    "conv_k1s2", BEFORE_QNN_HOOK_PRIORITY["conv_k1s2"]
)
class ConvK1S2(Hook):
    def transform(self, mod, params):
        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod

        rewrite_func = ConvK1S2Pattern().rewrite(func)
        mod = relay.Function(
            relay.analysis.free_vars(rewrite_func.body), rewrite_func.body
        )
        mod = tvm.IRModule.from_expr(mod)
        return mod, params
