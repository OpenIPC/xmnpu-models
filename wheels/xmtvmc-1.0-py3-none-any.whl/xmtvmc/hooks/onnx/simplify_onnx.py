import onnxsim

from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import ONNX_HOOK_PRIORITY
from xmtvmc.hooks.runner import ONNX_RUNNER


@ONNX_RUNNER.register_hook(
    "simplify_onnx", ONNX_HOOK_PRIORITY["simplify_onnx"]
)
class SimplifyONNXHook(Hook):
    def transform(self, mod, params, **kwargs):
        mod, check = onnxsim.simplify(mod)
        assert check, "onnxsim.simplify(mod) failed!"

        return mod, params
