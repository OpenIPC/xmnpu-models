from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import ONNX_HOOK_PRIORITY
from xmtvmc.hooks.runner import ONNX_RUNNER
from xmtvmc.utils import get_logger

import onnx.helper


@ONNX_RUNNER.register_hook("extra_outputs", ONNX_HOOK_PRIORITY["extra_outputs"])
class ExtraOutputHook(Hook):
    def transform(self, mod, params, **kwargs):
        extra_output_names = kwargs.get("extra_output", None)
        if not extra_output_names:
            return mod, params

        logger = get_logger()

        found = {name: False for name in extra_output_names}
        for node in mod.graph.node:
            for output_name in node.output:
                if output_name in extra_output_names:
                    found[output_name] = True

        for output_name in found:
            if not found[output_name]:
                logger.warning(
                    f"cannot find {output_name} in onnx.graph.node.output"
                )
                existing_output_names.remove(output_name)

        existing_output_names = [output.name for output in mod.graph.output]
        for name in extra_output_names:
            if name in existing_output_names:
                logger.warning(f"{name} is already among onnx.graph.output")
                continue

            output = onnx.helper.make_tensor_value_info(
                name, onnx.TensorProto.FLOAT, None
            )
            mod.graph.output.append(output)

        return mod, params
