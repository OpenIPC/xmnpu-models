import onnx

from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import ONNX_HOOK_PRIORITY
from xmtvmc.hooks.runner import ONNX_RUNNER


@ONNX_RUNNER.register_hook(
    "modify_dropout", ONNX_HOOK_PRIORITY["modify_dropout"]
)
class ModifyDropoutHook(Hook):
    def transform(self, mod, params, **kwargs):
        graph = mod.graph

        initializer_map = dict()
        for initializer in graph.initializer:
            if len(initializer.float_data) == 1:
                initializer_map[initializer.name] = initializer.float_data

        for node in graph.node:
            if node.op_type == "Dropout" and len(node.input) > 1:
                for initializer_index in range(len(node.input)):
                    initializer_name = node.input[initializer_index]
                    if initializer_name in initializer_map:
                        attr = onnx.helper.make_attribute("ratio", *initializer_map[initializer_name])
                        node.attribute.append(attr)

                        del node.input[initializer_index]
                        break

        return mod, params
