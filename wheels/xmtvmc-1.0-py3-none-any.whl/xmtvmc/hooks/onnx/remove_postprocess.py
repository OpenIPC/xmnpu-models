from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import ONNX_HOOK_PRIORITY
from xmtvmc.hooks.runner import ONNX_RUNNER
from xmtvmc.utils import get_logger

import onnx
import onnx.helper
import onnx.shape_inference


class Graph:
    def __init__(self, onnx_model):
        self.graph = onnx_model.graph
        self.opset_version = onnx_model.opset_import[0].version

        self.nodes = {}
        for node in self.graph.node:
            for output_name in node.output:
                self.nodes[output_name] = node

        self.input_names = [input.name for input in self.graph.input]
        for initializer in self.graph.initializer:
            if initializer.name in self.input_names:
                self.input_names.remove(initializer.name)

        self.cache = {}

    def is_input_node(self, node):
        for input_name in node.input:
            if input_name in self.input_names:
                return True

        return False

    def find_output(self, output_name):
        outputs = []
        for output in self.graph.output:
            if output_name == output.name:
                outputs.append(output)
        return outputs

    def find_previous(self, node):
        for input_name in node.input:
            if input_name in self.nodes:
                yield self.nodes[input_name]

    def backward_search_until(self, node_names, node=None, depth=0):
        if node is None:
            for output in self.graph.output:
                if self.backward_search_until(node_names, output.name):
                    self.cache[output.name] = True
                else:
                    return False

            return True

        if not isinstance(node, onnx.NodeProto):
            node = self.nodes[node]

        if node.name in self.cache:
            return self.cache[node.name]

        # This is wanted node
        if node.name in node_names:
            self.cache[node.name] = True
            return True
        # This is input node
        if self.is_input_node(node):
            return False

        for previous_node in self.find_previous(node):
            if self.backward_search_until(node_names, previous_node, depth + 1):
                self.cache[previous_node.name] = True
            else:
                return False
        return True

    def backward_remove_until(self, node_names, node=None, depth=0):
        if node is None:
            output_names = [output.name for output in self.graph.output]
            for output_name in output_names:
                self.backward_remove_until(node_names, output_name)

            return

        if not isinstance(node, onnx.NodeProto):
            if node not in self.nodes:
                return
            node = self.nodes[node]

        if node.name in node_names:
            return

        for output_name in node.output:
            # remove node from dict
            if output_name in self.nodes:
                del self.nodes[output_name]

            # remove output_name from onnx.graph.output
            for output in self.find_output(output_name):
                self.graph.output.remove(output)

        # remove node from onnx.graph.node
        self.graph.node.remove(node)

        # add output of previous nodes to onnx.graph.output
        for previous_node in self.find_previous(node):
            for output_name in previous_node.output:
                if len(self.find_output(output_name)) == 0:
                    output = onnx.helper.make_tensor_value_info(
                        output_name, onnx.TensorProto.FLOAT, None
                    )
                    self.graph.output.append(output)

            self.backward_remove_until(node_names, previous_node, depth + 1)

    def make_model(self):
        model = onnx.helper.make_model(self.graph)
        model.opset_import[0].version = self.opset_version
        return onnx.shape_inference.infer_shapes(model)


@ONNX_RUNNER.register_hook(
    "remove_postprocess", ONNX_HOOK_PRIORITY["remove_postprocess"]
)
class RemovePostprocessHook(Hook):
    def transform(self, mod, params, **kwargs):
        node_names = kwargs.get("output", None)
        if not node_names:
            return mod, params

        logger = get_logger()

        graph = Graph(mod)
        if not graph.backward_search_until(node_names):
            raise ValueError(
                f"not all branches from inputs have at least one of these nodes {node_names}"
            )

        graph.backward_remove_until(node_names)
        model = graph.make_model()
        if hasattr(onnx.checker, "check_model"):
            try:
                onnx.checker.check_model(model)
            except Exception as e:
                logger.warning(e)

        return model, params
