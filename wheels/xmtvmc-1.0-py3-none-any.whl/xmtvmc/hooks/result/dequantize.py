import numpy as np
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import POSTPROCESS_HOOK_PRIORITY
from xmtvmc.hooks.runner import POSTPROCESS_RUNNER
from xmtvmc.utils import get_logger


@POSTPROCESS_RUNNER.register_hook(
    "dequantize", POSTPROCESS_HOOK_PRIORITY["dequantize"]
)
class Dequantize(Hook):
    def transform(self, result, params, **kwargs):
        if kwargs.get("output_dtype", None) != "float":
            return result, params

        params = params["output"]

        for i, tensor_info in enumerate(params):

            n = tensor_info["n"]
            c = tensor_info["c"]
            h = tensor_info["h"]
            w = tensor_info["w"]

            assert (len(result[i].shape) == 2 and result[i].shape == (n, c) and h == 1 and w == 1) or \
                (len(result[i].shape) == 4 and result[i].shape == (n, c, h, w)), \
                f"result shape {result[i].shape} not match [{n},{c},{h},{w}]"

            scale = tensor_info["scale"]
            zp = tensor_info["zp"]
            result[i] = scale * (result[i].astype(np.float32) - zp)

        return result, params
