import logging

import tvm
from tvm import relay
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import QNN_HOOK_PRIORITY
from xmtvmc.hooks.runner import QNN_RUNNER
from xmtvmc.utils import get_logger

logger = get_logger()


@QNN_RUNNER.register_hook(
    "remove_softmax", QNN_HOOK_PRIORITY["remove_softmax"]
)
class RemoveSoftmaxHook(Hook):
    """
    """
    def transform(self, mod, params, **kwargs):
        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod
        assert isinstance(func, relay.function.Function)
        body = func.body

        if not isinstance(body, relay.Call):
            logger.debug("multiple-output model, without regard to remove softmax")
            return mod, params

        pre_expr = body.args[0]
        if isinstance(body, relay.Call) and body.op.name == "qnn.quantize" and \
           isinstance(pre_expr, relay.Call) and pre_expr.op.name == "nn.softmax" and \
           isinstance(pre_expr.args[0], relay.Call) and pre_expr.args[0].op.name == "qnn.dequantize":
            body = pre_expr.args[0].args[0]
        if isinstance(body, relay.Call) and body.op.name == "nn.softmax" and \
           isinstance(pre_expr, relay.Call) and pre_expr.op.name == "qnn.dequantize":
            body = pre_expr.args[0]

        func = relay.function.Function(relay.analysis.free_vars(body), body)
        mod = tvm.IRModule.from_expr(func)

        return mod, params
