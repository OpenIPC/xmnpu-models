# 模型从onnx/caffe到最后编译运行各阶段的优先级设置
ONNX_HOOK_PRIORITY = {
    "remove_postprocess": 1,
    "extra_outputs": 2,
    "simplify_onnx": 3,
    "modify_dropout": 4,
}
RELAY_HOOK_PRIORITY = {
    "merge_pad_with_conv": 0,
    "merge_pad_with_maxpool": 1,
    "fuse_normalize": 2,
    "mul_add_2_depthconv2d1x1": 3,
    "bgr_input": 4,
    "fuse_yuv2rgb": 5,
    "rename_input": 6,
    "silu_converter": 7,
    "resize2upsample": 8,
    "remove_special_postprocess": 9,
    "concat2concat_pattern": 10,
}
BEFORE_QNN_HOOK_PRIORITY = {
    "clip2relu": 0,
    "conv_k1s2": 1,
    "insert_conv_before_upsample":2,
    "merge_k1s2_pool": 3,
    "reduce_large_kernel_pool": 4,
    "mish_converter": 5,
    "broadcast2tile": 6,
}
QNN_HOOK_PRIORITY = {
    'remove_softmax': 0
}
XMIR_HOOK_PRIORITY = {
    "left_right_swap_on_add": 0,
    "conv_kernel_nn": 1,
    "conv_k1p1_gap": 2,
    "fuse_leakyrelu_to_conv": 3,
}
BUILD_HOOK_PRIORITY = {}
POSTPROCESS_HOOK_PRIORITY = {
    "dequantize": 0,
}
QUANTIZE_HOOK_PRIORITY = {}
BUILD_QNN_HOOK_PRIORITY = {
}
BUILD_RELAY_HOOK_PRIORITY = {}
