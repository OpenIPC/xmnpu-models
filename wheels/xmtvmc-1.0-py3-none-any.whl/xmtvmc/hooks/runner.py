from xmtvmc.utils import get_logger


class Runner:
    """用来注册、保存和触发Hook"""

    def __init__(self, name):
        self._name = name
        self._hooks = []  # 保存注册的Hook

    def register_hook(self, name, priority):
        """用列表存储注册的Hook，priority数值越大的Hook注册后
           在列表中的位置越靠后，顺序遍历执行时越晚被执行到。
           对于相同优先级Hook，被触发的顺序和它们注册的顺序一致。
        Parameters
        ----------
        name: str
            注册的hook昵称
        priority: int
            注册的hook优先级

        Returns
        -------
        _register_hook: function
            以hook类型为参数的hook注册函数
        """

        def _register_hook(hook_cls):
            """为了能够使用装饰器来注册Hook实例"""

            hook_instance = hook_cls(name)
            hook_instance.priority = priority

            registered = False
            for i in range(len(self._hooks) - 1, -1, -1):
                if priority >= self._hooks[i].priority:
                    self._hooks.insert(i + 1, hook_instance)
                    registered = True
                    break

            if not registered:
                self._hooks.insert(0, hook_instance)

        return _register_hook

    def call(self, mod, params, function_name, **kwargs):
        """注册的hook实例触发, 调用call时指定function_name，在遍历self_hooks时，
           会调用遍历到的hook类的function_name接口。因为transform功能的hook一定
           要在validat ehook前被触发，所以通多先指定function_name为transorfm再
           指定为validate的方式来实现。
        Parameters
        ----------
        mod: IRMoudle
            待处理的模型
        params: tvm.ir.container.Map
            待处理的模型参数
        function_name: str
            注册的Hook待执行函数
        """

        for hook in self._hooks:
            mod, params = getattr(hook, function_name)(mod, params, **kwargs)

        return mod, params


ONNX_RUNNER = Runner("onnx_runner")
RELAY_RUNNER = Runner("relay_runner")
BEFORE_QNN_RUNNER = Runner("before_qnn_runner")
QUANTIZE_RUNNER = Runner("quantize_runner")
QNN_RUNNER = Runner("qnn_runner")
BUILD_QNN_RUNNER = Runner("build_qnn_runner")
BUILD_RELAY_RUNNER = Runner("build_relay_runner")
XMIR_RUNNER = Runner("xmir_runner")
BUILD_RUNNER = Runner("build_runner")
POSTPROCESS_RUNNER = Runner("postprocess_runner")


def _running_hook(Hook, mod, params, **kwargs):
    logger = get_logger()
    logger.debug("running hook {} transform".format(Hook._name))
    mod, params = Hook.call(mod, params, "transform", **kwargs)

    logger.debug("running hook {} validate".format(Hook._name))
    mod, params = Hook.call(mod, params, "validate", **kwargs)

    return mod, params
