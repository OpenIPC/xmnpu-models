import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import DFPatternCallback, is_op

from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import XMIR_HOOK_PRIORITY
from xmtvmc.hooks.runner import XMIR_RUNNER
import xmnpu

class ConvK1P1GapPattern(DFPatternCallback):
    def __init__(self,):
        super(ConvK1P1GapPattern, self).__init__()
        self.conv = is_op("xm.conv2d")(None).has_attr(
            {"kernel_size": [1, 1], "padding": [1, 1, 1, 1]})
        self.pattern = is_op("xm.global_avg_pool2d")(self.conv)

    def callback(self, pre, post, node_map):
        conv = node_map[self.conv][0]
        assert conv.attrs.kernel_layout == "OIHW"

        padding_new = [0,0,0,0]
        conv_new = xmnpu.relay.conv2d(
            conv.args[0],
            conv.args[1],
            conv.args[2],
            conv.attrs.input_scale,
            conv.attrs.kernel_scale,
            conv.attrs.output_scale,
            conv.attrs.input_zero_point,
            conv.attrs.kernel_zero_point,
            conv.attrs.output_zero_point,
            conv.attrs.kernel_size,
            conv.attrs.strides,
            padding_new,
            conv.attrs.dilation,
            conv.attrs.ins,
            conv.attrs.using_bias,
            conv.attrs.relu_type,
            conv.attrs.groups,
            conv.attrs.data_layout,
            conv.attrs.kernel_layout,
            conv.attrs.out_layout,
            conv.attrs.out_dtype,
        )
        new_pool_size = [post.attrs.pool_size[0] - 2, 
                         post.attrs.pool_size[1] - 2]
        gap_new = xmnpu.relay.global_avg_pool2d(
            conv_new,
            post.attrs.input_zero_point,
            post.attrs.output_zero_point,
            new_pool_size,
            post.attrs.layout,
            post.attrs.out_dtype,
        )
        return gap_new


@XMIR_RUNNER.register_hook("ConvK1P1Gap", XMIR_HOOK_PRIORITY["conv_k1p1_gap"])
class ConvK1P1Gap(Hook):
    def transform(self, mod, params):
        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod

        rewrite_func = ConvK1P1GapPattern().rewrite(func)
        mod = relay.Function(
            relay.analysis.free_vars(rewrite_func.body), 
            rewrite_func.body)

        mod = tvm.IRModule.from_expr(mod)
        return mod, params
