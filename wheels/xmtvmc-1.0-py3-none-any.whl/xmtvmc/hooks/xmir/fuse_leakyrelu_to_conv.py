import math

import xmnpu
import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import DFPatternCallback, is_op
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import XMIR_HOOK_PRIORITY
from xmtvmc.hooks.runner import XMIR_RUNNER
from xmtvmc.utils import get_logger

logger = get_logger()


class FuseLeakyRelu2ConvPattern(DFPatternCallback):
    def __init__(self):
        super(FuseLeakyRelu2ConvPattern, self).__init__()
        pattern = is_op("xm.conv2d")(None)
        self.pattern = is_op("nn.leaky_relu")(pattern)

    def callback(self, pre, post, node_map):
        alpha = post.attrs.alpha

        if math.isclose(alpha, 26.0 / 256, abs_tol=1e-5):
            relu_type = 2
        elif math.isclose(alpha, 3.0 / 256, abs_tol=1e-5):
            relu_type = 3
        elif math.isclose(alpha, 0.1, abs_tol=1e-5):
            relu_type = 2
            logger.warning(
                f"leaky_relu's alpha expects 26/256, but got {alpha}"
            )
        elif math.isclose(alpha, 0.01, abs_tol=1e-5):
            relu_type = 3
            logger.warning(
                f"leaky_relu's alpha expects 3/256, but got {alpha}"
            )
        else:
            raise ValueError(
                f"leaky_relu's alpha expects 3/256(≈0.01) or 26/256(≈0.1), but got {alpha}"
            )

        conv_body = post.args[0]

        return xmnpu.relay.conv2d(
            conv_body.args[0],
            conv_body.args[1],
            conv_body.args[2],
            conv_body.attrs.input_scale,
            conv_body.attrs.kernel_scale,
            conv_body.attrs.output_scale,
            conv_body.attrs.input_zero_point,
            conv_body.attrs.kernel_zero_point,
            conv_body.attrs.output_zero_point,
            conv_body.attrs.kernel_size,
            conv_body.attrs.strides,
            conv_body.attrs.padding,
            conv_body.attrs.dilation,
            conv_body.attrs.ins,
            conv_body.attrs.using_bias,
            relu_type,
            conv_body.attrs.groups,
            conv_body.attrs.data_layout,
            conv_body.attrs.kernel_layout,
            conv_body.attrs.out_layout,
            conv_body.attrs.out_dtype,
        )


@XMIR_RUNNER.register_hook(
    "FuseLeakyRelu2Conv", XMIR_HOOK_PRIORITY["fuse_leakyrelu_to_conv"]
)
class FuseLeakyRelu2Conv(Hook):
    def transform(self, mod, params):
        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod

        rewrite_func = FuseLeakyRelu2ConvPattern().rewrite(func)
        mod = relay.Function(
            relay.analysis.free_vars(rewrite_func.body), rewrite_func.body
        )
        mod = tvm.IRModule.from_expr(mod)
        return mod, params
