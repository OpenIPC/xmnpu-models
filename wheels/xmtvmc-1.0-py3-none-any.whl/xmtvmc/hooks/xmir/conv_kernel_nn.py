import math

import numpy as np
import tvm
import xmnpu
from tvm import relay
from tvm.relay.dataflow_pattern import DFPatternCallback, is_op
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import XMIR_HOOK_PRIORITY
from xmtvmc.hooks.runner import XMIR_RUNNER


class ConvKernelNNPattern(DFPatternCallback):
    """
    convert conv 1x5 to conv 5x5
            conv 6x6 to conv 7x7 
            conv 3x4 to conv 5x5
    """
    def __init__(self):
        super(ConvKernelNNPattern, self).__init__()
        self.pattern = is_op("xm.conv2d")(None)

        # TODO: 按芯片型号设置
        self.valid_kernel_sizes = [1, 3, 5, 7]

    def closest_kernel(self, kernel_h, kernel_w):
        kernel = max(kernel_h, kernel_w)
        
        diff = np.array(self.valid_kernel_sizes) - kernel
        matched_kernel = np.argsort(diff)[diff >= 0][0]
        matched_kernel = self.valid_kernel_sizes[matched_kernel]

        return matched_kernel, min(kernel_h, kernel_w) != matched_kernel

    def callback(self, pre, post, node_map):
        assert post.attrs.kernel_layout == "OIHW"

        kernel = post.args[1]
        kernel_size = kernel.data.shape
        kernel_height, kernel_width = kernel_size[2], kernel_size[3]

        matched_kernel, to_update = self.closest_kernel(kernel_height, kernel_width)

        if to_update:
            t_pad = math.ceil((matched_kernel - kernel_height) / 2)
            b_pad = math.floor((matched_kernel - kernel_height) / 2)
            l_pad = math.ceil((matched_kernel - kernel_width) / 2)
            r_pad = math.floor((matched_kernel - kernel_width) / 2)

            kernel_np = kernel.data.asnumpy()
            kernel_np = np.pad(kernel_np, ((
                0, 0), (0, 0), (t_pad, b_pad), (l_pad, r_pad)), "constant", constant_values=0)
            kernel = relay.Constant(tvm.nd.array(kernel_np))

            padding = [(matched_kernel - 1) // 2] * 4

            return xmnpu.relay.conv2d(
                post.args[0],
                kernel,
                post.args[2],
                post.attrs.input_scale,
                post.attrs.kernel_scale,
                post.attrs.output_scale,
                post.attrs.input_zero_point,
                post.attrs.kernel_zero_point,
                post.attrs.output_zero_point,
                (matched_kernel, matched_kernel),
                post.attrs.strides,
                padding,
                post.attrs.dilation,
                post.attrs.ins,
                post.attrs.using_bias,
                post.attrs.relu_type,
                post.attrs.groups,
                post.attrs.data_layout,
                post.attrs.kernel_layout,
                post.attrs.out_layout,
                post.attrs.out_dtype,
            )
        else:
            return post


@XMIR_RUNNER.register_hook("ConvKernelNN", XMIR_HOOK_PRIORITY["conv_kernel_nn"])
class ConvKernelNN(Hook):
    def transform(self, mod, params):
        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod

        rewrite_func = ConvKernelNNPattern().rewrite(func)
        mod = relay.Function(relay.analysis.free_vars(
            rewrite_func.body), rewrite_func.body)
        mod = tvm.IRModule.from_expr(mod)
        return mod, params
