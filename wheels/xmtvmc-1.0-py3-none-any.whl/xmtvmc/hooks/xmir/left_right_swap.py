import tvm
from tvm import relay
from tvm.relay.dataflow_pattern import DFPatternCallback, is_op, wildcard
from xmtvmc.hooks.hook import Hook
from xmtvmc.hooks.priority import XMIR_HOOK_PRIORITY
from xmtvmc.hooks.runner import XMIR_RUNNER
import xmnpu


class LeftRightSwapOnAddPattern(DFPatternCallback):
    """ """

    def __init__(self):
        super(LeftRightSwapOnAddPattern, self).__init__()

        # TODO: 还要处理 concat
        self.pattern = is_op("xm.eltwise_add")(None)

    def callback(self, pre, post, node_map):
        lhs, rhs = post.args[0], post.args[1]
        if self.graph_size(lhs) > self.graph_size(rhs):
            return xmnpu.relay.eltwise_add(
                rhs,
                lhs,
                post.attrs.rhs_scale,
                post.attrs.lhs_scale,
                post.attrs.out_scale,
                post.attrs.rhs_zero_point,
                post.attrs.lhs_zero_point,
                post.attrs.output_zero_point,
                post.attrs.layout,
                post.attrs.out_dtype,
            )
        else:
            return post

    def graph_size(self, node):
        size = 0
        while isinstance(node, relay.Call):
            size += 1
            found_previous = False
            for argument in node.args:
                if isinstance(argument, relay.Call):
                    found_previous = True
                    break
            node = argument if found_previous else None

        return size


@XMIR_RUNNER.register_hook(
    "LeftRightSwapOnAdd", XMIR_HOOK_PRIORITY["left_right_swap_on_add"]
)
class LeftRightSwapOnAdd(Hook):
    """ """

    def transform(self, mod, params, **kwargs):

        func = mod["main"] if isinstance(mod, tvm.ir.module.IRModule) else mod

        rewrite_func = LeftRightSwapOnAddPattern().rewrite(func)
        mod = relay.Function(
            relay.analysis.free_vars(rewrite_func.body), rewrite_func.body
        )
        mod = tvm.IRModule.from_expr(mod)
        return mod, params
