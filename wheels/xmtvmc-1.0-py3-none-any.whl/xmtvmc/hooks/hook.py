class Hook:
    """所有Hook实现因该继承此类，不同实现类基于自己的功能来选择实现transorm或validate"""

    def __init__(self, name=None):
        self._name = name

    def transform(self, mod, params, **kwargs):
        """继承的子类在此处实现针对模型的转换功能
        Parameters
        ----------
        mod: IRModule
            待转换的模型结构
        params: tvm.ir.container.Map
            模型参数

        Returns
        -------
        mod: IRModule
            转换后的模型
        params: tvm.ir.container.Map
            转换后的模型参数
        """
        return mod, params

    def validate(self, mod, params, **kwargs):
        """继承的子类在此处实现针对模型的验证功能
        Parameters
        ----------
        mod: IRModule
            待验证的模型
        params: tvm.ir.container.Map
            模型参数

        Returns
        -------
        mod: IRModule
            验证后的模型
        params: tvm.ir.container.Map
            验证后的模型参数
        """
        return mod, params
