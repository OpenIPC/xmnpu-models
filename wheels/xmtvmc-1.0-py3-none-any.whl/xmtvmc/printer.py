import re

import xmtvmc.io as io
from xmtvmc.main import register_parser
from xmtvmc.utils import get_logger, parse_output, set_level


# 装饰器，将subparser append 到 main.py 中的 REGISTERED_PARSER 列表中
@register_parser
def add_print_parser(subparsers, *args):
    """Include parser for 'print' subcommand"""
    parser = subparsers.add_parser("print", help="print IRModule")
    parser.set_defaults(func=driver_print)
    parser.add_argument(
        "--model",
        default="",
        type=str,
        required=True,
        help="path of IRModule (.json) to print",
    )
    parser.add_argument(
        "--output-prefix",
        default="./",
        type=str,
        help="path prefix for exported IRModule files, e.g. /path/to/module/",
    )
    parser.add_argument(
        "--output-name",
        default="",
        type=str,
        help=(
            "filename for exported IRModule files, e.g. exported_module ; "
            "if not specified, use imported filename by default"
        ),
    )
    parser.add_argument(
        "--log-level",
        default="error",
        type=str,
        choices=["debug", "info", "warn", "error"],
        help="to specify log level: debug, info, warn or error",
    )


def driver_print(args):
    set_level(args.log_level)
    print_graph(args)


def print_graph(args):
    logger = get_logger()
    logger.info("print the model ...........")

    mod = io.load_json(args.model)
    pattern = re.compile(r"/\*.*?\*/", re.DOTALL | re.MULTILINE)
    graph = re.sub(pattern, "", mod.astext(show_meta_data=False)).strip()

    print(graph)

    filename = parse_output(args)
    with open(filename + ".txt", "w") as fout:
        fout.write(graph)
