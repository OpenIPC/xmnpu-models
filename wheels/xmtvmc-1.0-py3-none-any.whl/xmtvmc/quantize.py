import tvm
from tvm import relay
from tvm.relay.quantize import relay2qnn
from tvm.relay.quantize.quantize import _bind_params

from .hooks import BEFORE_QNN_RUNNER, QNN_RUNNER, QUANTIZE_RUNNER, _running_hook


def first_call_node(mod):

    mod = mod["main"] if isinstance(mod, tvm.IRModule) else mod
    call_node = mod

    def _visit_node(node):
        nonlocal call_node
        if isinstance(node, relay.Call) and isinstance(node.args[0], relay.Var):
            call_node = node

    relay.analysis.post_order_visit(mod, _visit_node)
    return call_node


def is_qnn_mod(mod):
    is_qnn = False
    mod = mod["main"] if isinstance(mod, tvm.IRModule) else mod

    def _visit_node(node):
        nonlocal is_qnn
        if isinstance(node, relay.Call):
            name = node.op.name
            if name.startswith("qnn"):
                is_qnn = True

    relay.analysis.post_order_visit(mod, _visit_node)
    return is_qnn


def input_shape(call):
    assert isinstance(call, relay.expr.Call)

    op_name = call.op.name

    if op_name in (
        "xm.conv2d",
        "xm.dense",
        "xm.scale",
        "xm.pool2d",
        "xm.global_avg_pool2d",
        "nn.conv2d",
        "nn.dense",
        "qnn.conv2d",
        "qnn.dense"
    ):
        input_op = call.args[0]
        if isinstance(input_op, relay.Var):
            shape = list(map(int, input_op.type_annotation.shape))
        elif isinstance(input_op, relay.expr.Call):
            shape = output_shape(input_op)

        assert len(shape) == 4, f"shape {shape} is not NCHW format"
        n, c, h, w = shape
        return [(n, c, h, w)]

    if op_name == "xm.eltwise_add":
        shapes = []
        for i in range(2):
            input_op = call.args[0]
            if isinstance(input_op, relay.Var):
                shape = list(map(int, input_op.type_annotation.shape))
            elif isinstance(input_op, relay.expr.Call):
                shape = output_shape(input_op)

            assert len(shape) == 4, f"shape {shape} is not NCHW format"
            n, c, h, w = shape
            shapes.append((n, c, h, w))
        return shapes

    if op_name == "xm.yuv2rgb":
        shapes = []
        for i in range(2):
            input_op = call.args[i]
            assert isinstance(input_op, relay.Var)
            shape = list(map(int, input_op.type_annotation.shape))

            assert len(shape) == 2, f"shape {shape} is not HW format"
            h, w = shape
            shapes.append((1, 1, h, w))
        return shapes

    raise NotImplementedError(f"cannot get input shape for op {op_name}")


def input_scale_and_zp(call):
    assert isinstance(call, relay.expr.Call)

    op_name = call.op.name
    attrs = call.attrs

    if op_name in ("xm.conv2d", "xm.dense", "xm.scale"):
        scale = float(attrs.input_scale.data.numpy())
        zp = attrs.input_zero_point

        return [(scale, zp)]

    if op_name in ("xm.pool2d", "xm.global_avg_pool2d"):
        return input_scale_and_zp(call.args[0])

    if op_name == "xm.eltwise_add":
        lhs_scale = float(attrs.lhs_scale.data.numpy())
        lhs_zp = attrs.lhs_zero_point

        rhs_scale = float(attrs.rhs_scale.data.numpy())
        rhs_zp = attrs.rhs_zero_point
        return [(lhs_scale, lhs_zp), (rhs_scale, rhs_zp)]

    if op_name in ("add", "xm.yuv2rgb"):
        return [(1., 0), (1., 0)]

    if op_name in ("nn.conv2d", "nn.dense"):
        return [(1., 0)]

    if op_name in ("qnn.conv2d", "qnn.dense"):
        scale = float(call.args[4].data.numpy())
        zp = int(call.args[2].data.numpy())
        return [(scale, zp)]

    raise NotImplementedError(
        f"cannot get input scale and zero point for op {op_name}"
    )


def output_shape(call):
    assert isinstance(call, relay.expr.Call)
    op_name = call.op.name

    mod = tvm.IRModule.from_expr(call)
    mod = relay.transform.InferType()(mod)

    shape = mod["main"].ret_type.shape
    if len(shape) == 4:
        n, c, h, w = map(int, mod["main"].ret_type.shape)
    # TODO: check operate
    # elif len(shape) == 2 and op_name in ("nn.dense", "add", "qnn.requantize", "xm.dense", "nn.softmax"):
    elif len(shape) == 2:
        n, c = map(int, mod["main"].ret_type.shape)
        h = 1
        w = 1
    else:
        raise NotImplementedError(
            f"output op {op_name} with shape {shape} not supported"
        )
    return n, c, h, w


def output_scale_and_zp(call):
    assert isinstance(call, relay.expr.Call)

    op_name = call.op.name
    attrs = call.attrs

    if op_name in ("xm.conv2d", "xm.dense", "xm.scale"):
        input_scale = attrs.input_scale.data.numpy()
        kernel_scale = attrs.kernel_scale.data.numpy()
        output_scale = attrs.output_scale.data.numpy()

        significand, exponent = output_scale[0, 0], output_scale[1, 0]
        multiplier = significand / 2**exponent

        scale = (input_scale * kernel_scale) / multiplier
        zp = attrs.output_zero_point

        return scale, zp

    if op_name in ("xm.pool2d", "xm.global_avg_pool2d"):
        scale, _ = output_scale_and_zp(call.args[0])
        zp = attrs.output_zero_point

        return scale, zp

    # TODO: 为什么只用 lhs_scale ?
    if op_name == "xm.eltwise_add":
        lhs_scale = attrs.lhs_scale
        output_scale = attrs.out_scale

        significand, exponent = output_scale[0, 0], output_scale[1, 0]
        multiplier = significand / 2**exponent

        scale = lhs_scale / multiplier
        zp = attrs.output_zero_point

        return scale, zp

    if op_name == "qnn.requantize":
        scale = float(call.args[3].data.numpy())
        zp = int(call.args[4].data.numpy())
        return scale, zp

    if op_name == "qnn.add":
        scale = float(call.args[6].data.numpy())
        zp = int(call.args[7].data.numpy())
        return scale, zp

    # for others use default scale = 1, zp = 0
    return 1., 0


def get_tensor_info(mod):
    input_node = first_call_node(mod)

    tensor_info = {"input": [], "output": []}

    for (scale, zp), (n, c, h, w) in zip(
        input_scale_and_zp(input_node), input_shape(input_node)
    ):
        tensor_info["input"].append(
            {
                "n": n,
                "c": c,
                "h": h,
                "w": w,
                "n_pch": n,
                "c_pch": h * w,
                "h_pch": h,
                "w_pch": w,
                "data_type": 1,
                "scale": scale,
                "zp": zp,
            }
        )

    output_nodes = mod["main"].body if isinstance(mod, tvm.IRModule) else mod.body
    if isinstance(output_nodes, relay.expr.Call):
        output_nodes = [output_nodes]

    for output_node in output_nodes:
        n, c, h, w = output_shape(output_node)
        scale, zp = output_scale_and_zp(output_node)

        tensor_info["output"].append(
            {
                
                "n": n,
                "c": c,
                "h": h,
                "w": w,
                "n_pch": n,
                "c_pch": h * w,
                "h_pch": h,
                "w_pch": w,
                "data_type": 1,
                "scale": scale,
                "zp": zp,
            }
        )

    return tensor_info


def quantize(
    mod, params, datasets=None, dtype_input="uint8", config=None, **kwargs
):
    """
    params:
        mod:
            input relay mod ;
        params: Dict
            module params dict ;
        datasets: List
            list of calibration datasets ;
        config: dict
            dict of quantize config

    return:
        mod: tvm.IRModule
            relay module
    """
    # relay hook in quantize
    mod, params = _running_hook(BEFORE_QNN_RUNNER, mod, params)

    if config is None:
        config = {
            "calibrate_mode": "emd",
            "weight_scale": "max",
            "do_hBC": False,
            "do_SQuant": False,
        }
    with relay.quantize.qconfig(**config):
        mod = relay.quantize.quantize_v2(mod, params, datasets)

    # quantize hook in quantize
    mod, params = _running_hook(QUANTIZE_RUNNER, mod, params)

    # quantize relay to qnn
    # q_cfg = relay.quantize.current_qconfig()
    qnn_mod, qnn_params = relay2qnn.from_relay(mod, dtype_input)
    qnn_mod["main"] = _bind_params(qnn_mod["main"], qnn_params)

    # qnn hook in quantize
    qnn_mod, qnn_params = _running_hook(
        QNN_RUNNER, qnn_mod, qnn_params, **kwargs
    )

    return qnn_mod, qnn_params
