import argparse
import logging
import sys

REGISTERED_PARSER = []


def register_parser(make_subparser):
    """
    Utility function to register a subparser for tvmc.
    """
    REGISTERED_PARSER.append(make_subparser)
    return make_subparser


def _main(argv):
    """XMTVMC command line interface."""

    parser = argparse.ArgumentParser(
        prog="XMTVMC",
        # formatter_class=argparse.RawDescriptionHelpFormatter,
        # description="TVM compiler driver",
        # epilog=__doc__,
        # # Help action will be added later, after all subparsers are created,
        # # so it doesn't interfere with the creation of the dynamic subparsers.
        add_help=False,
    )

    # parser.add_argument("--config", default="default", help="configuration json file")
    config_arg, argv = parser.parse_known_args(argv)

    parser.add_argument(
        "--version", action="store_true", help="print the version and exit"
    )

    subparser = parser.add_subparsers(title="commands")
    for make_subparser in REGISTERED_PARSER:
        make_subparser(subparser, parser, None)

    parser.add_argument(
        "-h", "--help", action="help", help="show help message and exit"
    )
    args = parser.parse_args(argv)

    if args.version:
        __version__ = "0.0.0.0"
        sys.stdout.write("%s\n" % __version__)
        return 0
    if not hasattr(args, "func"):
        # In case no valid subcommand is provided, show usage and exit
        parser.print_help(sys.stderr)
        return 1
    args = parser.parse_args(argv)

    print("xx", args)
    args.func(args)


def main():
    sys.exit(_main(sys.argv[1:]))


if __name__ == "__main__":
    main()
