import os.path as osp

import numpy as np

import xmtvmc.executable as exec
import xmtvmc.io as io
import xmtvmc.runner as runner
from xmtvmc.main import register_parser
from xmtvmc.utils import (
    get_logger,
    parse_and_check_arguments,
    parse_output,
    read_image,
    set_level,
)


# 装饰器，将 subparser append 到 main.py 中的 REGISTERED_PARSER 列表中
@register_parser
def add_run_parser(subparsers, *args):
    """Include parser for 'run' subcommand"""
    parser = subparsers.add_parser(
        "run",
        help=(
            "run compiled model given input dataset, "
            "and output the results as .npy format"
        ),
    )
    parser.set_defaults(func=driver_run)
    parser.add_argument(
        "--lib",
        type=str,
        required=True,
        help="compiled model (.so) to execute",
    )
    parser.add_argument(
        "--params",
        type=str,
        required=True,
        help="compiled model params (.so.params) to execute",
    )
    parser.add_argument(
        "--input-data",
        required=True,
        type=str,
        help=(
            "path of input file or "
            "folder containing input files (.jpg or .png)"
        ),
    )
    parser.add_argument(
        "--target",
        default="x86",
        choices=["x86", "xmnpu_x86", "xmnpu_npu"],
        type=str,
        help="target machine, choice ['x86', 'xmnpu_x86', 'xmnpu_npu']",
    )
    parser.add_argument(
        "--output-prefix",
        default="./",
        type=str,
        help="path prefix for inference results, e.g. /path/to/numpy/",
    )
    parser.add_argument(
        "--config-file",
        default="",
        type=str,
        required=True,
        help="config file in YAML format, which contains input details",
    )
    parser.add_argument(
        "--log-level",
        default="error",
        type=str,
        choices=["debug", "info", "warn", "error"],
        help="to specify log level: debug, info, warn or error",
    )


def driver_run(args):
    set_level(args.log_level)

    args.command = "compile"
    args = parse_and_check_arguments(args)

    inference_and_dump(args)


def inference_and_dump(args):
    logger = get_logger()
    logger.info("running model .....")

    if osp.isfile(args.input_data):
        input_dataset = [
            read_image(args.input_data, args.input_shape, args.input_format)
        ]
        input_filenams = [args.input_data]
    else:
        message = f"{args.input_data} not exists"
        logger.error(message)
        raise FileNotFoundError(message)

    lib = io.load_module(args.lib)
    tensor_info = io.load_tensor_info(args.params)

    for input_data, filename in zip(input_dataset, input_filenams):
        result = runner.run(
            lib=lib,
            params=tensor_info,
            input_data=input_data,
            target=args.target,
            output_dtype="float",
        )

        # Cannot dump list of np.ndarray with different shapes
        data_dict = {}
        for i in range(len(result)):
            output_name = "output_{}".format(i)
            data_dict[output_name] = result[i]

        args.output_name = osp.basename(filename)
        filename = f"{parse_output(args)}.{args.target}.npy"
        with open(filename, "wb") as fout:
            np.save(fout, data_dict)

    if args.target == "xmnpu_npu":
        args.output_name = osp.splitext(osp.basename(args.lib))[0]
        executable_filename = f"{parse_output(args)}.zip"
        exec.generate_executable_and_data(executable_filename, tensor_info)
