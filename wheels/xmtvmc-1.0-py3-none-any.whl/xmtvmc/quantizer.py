import xmtvmc.io as io
import xmtvmc.quantize as quantizer
from xmtvmc.main import register_parser
from xmtvmc.utils import (
    get_logger,
    parse_and_check_arguments,
    parse_dataset,
    parse_output,
    set_level,
)


# 装饰器，将 subparser append 到 main.py 中的 REGISTERED_PARSER 列表中
@register_parser
def add_quantize_parser(subparsers, *args):
    """Include parser for 'quantize' subcommand"""
    parser = subparsers.add_parser(
        "quantize",
        help="quatize the float IRModule as QNN IRModule.",
    )
    parser.set_defaults(func=driver_quantize)
    parser.add_argument(
        "--model",
        type=str,
        required=True,
        help="path of IRModule (.json) to quantize",
    )
    parser.add_argument(
        "--weight",
        required=True,
        type=str,
        help="path of weight (.params) to quantize",
    )
    parser.add_argument(
        "--calibrate-dataset",
        required=True,
        type=str,
        help=(
            "path of folder containing calibrate data files " "(*.jpg, *.png)"
        ),
    )
    parser.add_argument(
        "--output-prefix",
        default="./",
        type=str,
        help="path prefix for QNN IRModule, e.g. /path/to/module/",
    )
    parser.add_argument(
        "--output-name",
        default="",
        type=str,
        help=(
            "filename for QNN IRModule, e.g. qnn_module ; "
            "if not specified, use IRModule filename by default"
        ),
    )
    parser.add_argument(
        "--config-file",
        default="",
        type=str,
        required=True,
        help=(
            "config file in YAML format, " "which contains quantization details"
        ),
    )
    parser.add_argument(
        "--log-level",
        default="error",
        type=str,
        choices=["debug", "info", "warn", "error"],
        help="to specify log level: debug, info, warn or error",
    )


def driver_quantize(args):
    set_level(args.log_level)

    args.command = "quantize"
    args = parse_and_check_arguments(args)

    mod, params = module_quantize(args)

    dump_module(args, mod, params)


def module_quantize(args):
    logger = get_logger()
    logger.info("quantize the model ...........")

    mod = io.load_json(args.model)
    params = io.load_param_dict(args.weight)
    calibrate_dataset, _ = parse_dataset(
        args.calibrate_dataset, args.input_shape, args.input_format
    )

    # TODO: use different hBC dataset
    mod, params = quantizer.quantize(
        mod=mod, params=params, datasets=[calibrate_dataset] * 2
    )
    return mod, params


def dump_module(args, mod, params):
    filename = parse_output(args)

    io.save_param_dict(params, filename + ".qnn.params")
    io.save_json(mod, filename + ".qnn.json")
