import tvm

from .hooks import POSTPROCESS_RUNNER, _running_hook


def run(lib, target, params=None, input_data=None, **kwargs):
    """
    params:
        lib:
            input lib
        target: str or tvm.target.Target
            build target ; if str choice of ['llvm','xmcpu','xmnpu']
        params: dict
            final layer quantize params, use for convert result to float;
        input_data: dict of node name to tensor or numpy tensor
            input data;
    retrun:
        run result
    """

    assert isinstance(target, str)

    if target in ("llvm", "xmcpu", "xmnpu_x86", "x86"):
        device = tvm.cpu(0)
    else:
        device = tvm.ext_dev(0)
        func = tvm.get_global_func("xm7205v500.free_memory", True)
        if func:
            func()

    lib = lib["default"](device)
    mod = tvm.contrib.graph_executor.GraphModule(lib)

    if isinstance(input_data, dict):
        for index, k in enumerate(input_data):
            mod.set_input(k, input_data[k])
            if target == "xmnpu_npu":
                shape = "x".join(map(str, input_data[k].shape))
                input_data[k].tofile(f"input_data{index}_{shape}.bin")
    else:
        mod.set_input("data", input_data)
        if target == "xmnpu_npu":
            shape = "x".join(map(str, input_data.shape))
            input_data.tofile(f"input_data0_{shape}.bin")

    mod.run()

    output_nums = mod.get_num_outputs()
    outputs = []
    for index in range(output_nums):
        outputs.append(mod.get_output(index).asnumpy())
        if target == "xmnpu_npu":
            shape = "x".join(map(str, outputs[-1].shape))
            outputs[-1].tofile(f"output_data{index}_{shape}.bin")

    outputs, _ = _running_hook(POSTPROCESS_RUNNER, outputs, params, **kwargs)

    return outputs
