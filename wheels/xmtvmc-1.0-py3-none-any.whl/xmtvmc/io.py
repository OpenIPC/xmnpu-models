import re

import tvm


def save_json(mod, path):
    """
    params:
        mod: tvm.IRModule
            relay module
    """
    with open(path, "w") as f:
        f.write(tvm.ir.save_json(mod))


def save_param_dict(params, path):
    """
    params:
        params: dict
            dict of module params;
    """
    with open(path, "wb") as f:
        f.write(tvm.runtime.save_param_dict(params))


def save_txt(mod, path):
    """
    params:
        mod: tvm.IRModule
            relay module
    """
    pattern = re.compile(r"/\*.*?\*/", re.DOTALL | re.MULTILINE)
    with open(path, "w") as fout:
        fout.write(
            re.sub(pattern, "", mod.astext(show_meta_data=False)).strip()
        )


def load_json(path):
    """
    params:
        str_mod: str or bytes
            json str;
    return:
        ret: relay module;
    """
    with open(path, "r") as f:
        str_mod = f.read()
        return tvm.ir.load_json(str_mod)


def load_param_dict(path):
    """
    params:
        str_param: str or bytes
            params bytes stream;
    return:
        ret:  dict of module params;
    """
    with open(path, "rb") as f:
        str_param = f.read()
    return tvm.runtime.load_param_dict(str_param)


def export_library(lib, path):
    """
    params:
        lib:
            save lib;
        path: str
            lib save path;
    """
    lib.export_library(path)


def load_module(path_lib):
    """
    params:
        path_lib: str
            lib save path;
    return:
        ret:  tvm runtime lib;
    """
    return tvm.runtime.load_module(path_lib)


def save_tensor_info(tensor_info, path):
    import pickle

    with open(path, "wb") as f:
        pickle.dump(tensor_info, f)


def load_tensor_info(path):
    import pickle

    with open(path, "rb") as f:
        tensor_info = pickle.load(f)
    return tensor_info
