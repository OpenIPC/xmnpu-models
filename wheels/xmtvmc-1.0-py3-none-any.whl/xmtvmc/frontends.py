import tvm
from tvm import relay

from .hooks import ONNX_RUNNER, RELAY_RUNNER, _running_hook


def from_onnx(
    model,
    shape_dict=None,
    dtype_dict="float32",
    opset=None,
    **convert_config,
):
    """onnx model to tvm.relay
    params:
        model:
            input onnx model;
        shape_dict: dict
            dict of input shapes;
            e.g. {"input":[1,3,224,224]} ;
        dtype_dict: str or dict
            input types;
        opset: int
            onnx opset;
        convert_config: Dict
            extra convert config dict;
    return:
        mod: tvm.IRModule
            relay module
        params: dict of str to tvm.NDArray
            module params dict
    """
    if "rename_input" not in convert_config:
        convert_config["rename_input"] = "data"
    convert_config["shape_dict"] = shape_dict

    model, _ = _running_hook(ONNX_RUNNER, model, None, **convert_config)

    mod, params = relay.frontend.from_onnx(
        model=model, shape=shape_dict, dtype=dtype_dict, opset=opset
    )

    # relay hook in import
    mod, params = _running_hook(RELAY_RUNNER, mod, params, **convert_config)

    return mod, params


def from_caffe(
    init_net, predict_net, shape_dict, dtype_dict={}, **convert_config
):
    """
    params:
        init_net:
            input caffe model;
        predict_net: Dict
            input caffe prototxt;
        shape_dict: dict
            dict of input shapes;
        dtype_dict: dict
            dict of input types;
        convert_config: Dict
            extra convert config dict;
    return:
        mod: tvm.IRModule
            relay module
        params: dict of str to tvm.NDArray
            module params dict
    """
    mod, params = relay.frontend.from_caffe(
        init_net=init_net,
        predict_net=predict_net,
        shape_dict=shape_dict,
        dtype_dict=dtype_dict,
    )

    if "rename_input" not in convert_config:
        convert_config["rename_input"] = "data"
    convert_config["shape_dict"] = shape_dict

    # relay hook in import
    mod, params = _running_hook(RELAY_RUNNER, mod, params, **convert_config)

    return mod, params
