import glob
import logging
import os
import os.path as osp
import numpy as np

import yaml

from xmtvmc.image_loader import ImageLoader

logger = logging.getLogger("XMNPU")


def get_logger(log_level=None):
    global logger
    if log_level:
        logger.setLevel(log_level.upper())
    return logger


def set_level(log_level):
    global logger
    logger.setLevel(log_level.upper())


def parse_config(config_file):
    try:
        with open(config_file) as f:
            return yaml.safe_load(f)
    except Exception as error:
        global logger
        logger.error(error)
        raise error


def parse_and_check_arguments(args):
    global logger

    config = parse_config(args.config_file)
    logger.debug(config)

    # parse configurations to arguments
    args.input_normalize = config.pop("input_normalize", None)
    args.input_format = config.pop("input_format", "RGB").upper()
    args.input_dtype = config.pop("input_dtype", "float32").upper()
    args.input_layout = config.pop("input_layout", "NCHW").upper()
    args.input_shape = config.pop("input_shape", None)
    args.model_format = config.pop("model_format", "RGB").upper()
    args.outputs = config.pop("outputs", None)
    args.extra_outputs = config.pop("extra_outputs", None)
    args.quantize = config.pop("quantize", None)
    args.compile = config.pop("compile", None)

    # check required configuration keys
    if args.command == "import":
        for key in (
            "input_normalize",
            "input_dtype",
            "input_format",
            "input_layout",
            "input_shape",
            "model_format"
        ):
            if getattr(args, key, None) is None:
                message = f"missing {key} in configuration"
                logger.error(message)
                raise ValueError(message)

        if args.framework == "caffe" and not getattr(args, "weight", ""):
            message = f"missing weight (.caffemodel) in arguments"
            logger.error(message)
            raise ValueError(message)

        # TODO: check import configuration values

    if args.command == "quantize":
        for key in ("input_shape", "quantize"):
            if getattr(args, key, None) is None:
                message = f"missing {key} in configuration"
                logger.error(message)
                raise ValueError(message)

        for key in ("calibrate_mode", "weight_scale", "do_hBC", "do_SQuant"):
            if args.quantize.get(key, None) is None:
                message = f"missing {key} in quantize configuration"
                logger.error(message)
                raise ValueError(message)

        # TODO: check quantize configuration values

    if args.command == "compile":
        if args.target == "xmnpu_npu" and args.compile is not None:
            assert type(args.compile) == dict

            if "group_partition" in args.compile:
                group_partition = args.compile["group_partition"]
                if type(group_partition) is not bool:
                    message = (
                        "group_partition expects True or False, "
                        f"but got {group_partition}"
                    )
                    logger.error(message)
                    raise ValueError(message)

            if "memory_mode" in args.compile:
                memory_mode = args.compile["memory_mode"]
                if not memory_mode in (0, 1, 2):
                    message = (
                        "memory_mode expects 0, 1 or 2, "
                        f"but got {memory_mode}"
                    )
                    logger.error(message)
                    raise ValueError(message)

    if args.command == "run":
        for key in "input_shape":
            if getattr(args, key, None) is None:
                message = f"missing {key} in configuration"
                logger.error(message)
                raise ValueError(message)

        if not args.params.endswith(".so.params"):
            logger.warn(
                f"{args.params} is not endswith .so.params"
                "make sure don't use IRModule .params."
            )

    # check unnecessary keys
    for key in config:
        logger.warn(f"{key} is an unnecessary configuration")

    logger.debug(args)
    return args


def parse_output(args):
    global logger
    if not args.output_name:
        args.output_name = osp.splitext(osp.basename(args.model))[0]
        logger.info(
            "--output-name is not specified, "
            f"will use {args.output_name} instead."
        )

    if not osp.exists(args.output_prefix):
        logger.warning(
            f"{args.output_prefix} not exists, a new folder will be created."
        )
        os.makedirs(args.output_prefix)

    return osp.join(args.output_prefix, args.output_name)


def read_image(path, input_shape, input_format):
    assert len(input_shape) == 1
    height, width = list(input_shape.values())[0][2:]
    suffix = osp.splitext(path)[-1]

    # load image
    if suffix in (".jpg", ".JPG", ".JPEG", ".png", ".PNG"):
        image_loader = ImageLoader.FromImage(path)
        image_data = image_loader.load(shape=[width, height], fmt=input_format)
    # load raw data
    else:
        image_loader = ImageLoader.FromRawData(path=path, shape=[width, height], fmt=input_format)
        image_data = image_loader.load(shape=[width, height], fmt=input_format)
    
    # process RGB(or BGR)
    if input_format in {"RGB", "BGR"}:
        return {"data": image_data[np.newaxis]}
    # process YUV
    else:
        y, u, v = image_data
        vu = ImageLoader.PackedCannel(v, u)
        return {"Y": y, "UV": vu}


def parse_dataset(dataset_path, input_shape, input_format):
    if not osp.isdir(dataset_path):
        message = f"{dataset_path} is not a folder"
        logger.error(message)
        raise ValueError(message)

    dataset, filenames = [], []
    for filename in glob.glob(osp.join(dataset_path, "*")):
        image = read_image(filename, input_shape, input_format)
        filenames.append(filename)
        dataset.append(image)

    if len(dataset) == 0:
        message = f"{dataset_path} is empty"
        logger.error(message)
        raise IOError(message)

    return dataset, filenames
