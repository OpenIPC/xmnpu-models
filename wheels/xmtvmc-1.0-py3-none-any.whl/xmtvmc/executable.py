import glob
import json
import os
import os.path as osp
import re
import stat
import subprocess
import zipfile

from xmtvmc.utils import get_logger


def export_tensor_info(tensor_info, export_path):

    tensor_info = json.dumps(tensor_info, indent=4, separators=(";", " = "))
    tensor_info = tensor_info.replace('"', "")
    tensor_info = tensor_info.replace("[", "(")
    tensor_info = tensor_info.replace("};", "},")
    tensor_info = tensor_info.replace("]", ")")

    pattern = re.compile(r"\n[ ]+}")
    for match in list(pattern.finditer(tensor_info))[::-1]:
        pos = match.start()
        tensor_info = tensor_info[:pos] + ";" + tensor_info[pos:]

    pattern = re.compile(r"\n[ ]*\)")
    for match in list(pattern.finditer(tensor_info))[::-1]:
        pos = match.start()
        tensor_info = tensor_info[:pos] + "," + tensor_info[pos:]

    tensor_info = (
        'name = "the information of input and output tensor";\n\n'
        + "tensor_info =\n"
        + tensor_info
    )

    with open(export_path, "w") as fout:
        fout.write(tensor_info)


def match_address_by_memory_size(tensor_info):
    logger = get_logger()

    addr_file = "info_file.txt"
    if not osp.isfile(addr_file):
        message = f"Executable generated failed: cannot find {addr_file}"
        logger.error(message)
        raise FileNotFoundError(message)

    # match input address and size
    inputs = []
    with open(addr_file) as fin:
        addr = None
        for line in fin:
            key, value = line.strip().split("=")
            key = key[1:-1].strip()
            if key == "addr":
                addr = value
            if key == "size" and addr is not None:
                size = int(value, base=16)
                inputs.append((size, addr))
                addr = None

    for j, tensor in enumerate(tensor_info["input"]):
        size = tensor["n"] * tensor["c"] * tensor["c_pch"]
        for i in range(len(inputs)):
            if inputs[i][0] == size:
                tensor["addr"] = inputs.pop(i)[1]
                break
        if "addr" not in tensor:
            message = f"Executable generated failed: cannot match addr with input tensor {j}"
            logger.error(message)
            raise IOError(message)

    # match output address and size
    outputs = []
    with open(addr_file) as fin:
        addr = None
        for line in fin:
            key, value = line.strip().split("=")
            key = key[1:-1].strip()
            if key == "output addr":
                addr = value
            if key == "output size" and addr is not None:
                size = int(value, base=16)
                outputs.append((size, addr))
                addr = None

    for j, tensor in enumerate(tensor_info["output"]):
        size = tensor["n"] * tensor["c"] * tensor["c_pch"]
        for i in range(len(outputs)):
            if outputs[i][0] == size:
                tensor["addr"] = outputs.pop(i)[1]
                break
        if "addr" not in tensor:
            message = f"Executable generated failed: cannot match addr with output tensor {j}"
            logger.error(message)
            raise IOError(message)

    return tensor_info


def find_executable_generator():
    logger = get_logger()

    generator = osp.abspath(osp.join(osp.dirname(__file__), "bin/convert"))
    if not osp.isfile(generator):
        message = f"Executable generated failed: cannot find {generator}"
        logger.error(message)
        raise FileNotFoundError(message)

    try:
        os.chmod(generator, stat.S_IEXEC)
    except:
        logger.warning("Executable generated warning: chmod +x {generator}")

    return generator


def generate_executable(tensor_info):
    logger = get_logger()

    export_tensor_info(tensor_info, "inout_tensor.cfg")
    input_fnams = ["inout_tensor.cfg", "code_data_model.bin"]

    for input_fname in input_fnams:
        if not osp.isfile(input_fname):
            message = f"Executable generated failed: cannot find {input_fname}"
            logger.error(message)
            raise FileNotFoundError(message)

    generator = find_executable_generator()
    try:
        subprocess.run([generator, "-g"], check=True)
    except subprocess.CalledProcessError as error:
        message = f"Executable generated failed: {generator} -g"
        logger.error(message)
        raise error


def filenames_by_regex(regex):
    filenames = []
    for r in regex:
        filenames.extend(glob.glob(r))
    return filenames


def generate_executable_and_data(path, tensor_info):
    logger = get_logger()

    # compress generated test data
    regex = ["input_data*.bin", "output_data*.bin"]
    with zipfile.ZipFile(path, "w") as fout:
        for filename in filenames_by_regex(regex):
            if not osp.isfile(filename):
                logger.warning(f"cannot open {filename}")
                continue
            fout.write(filename)

    # generate inout_tensor.cfg
    tensor_info = match_address_by_memory_size(tensor_info)
    generate_executable(tensor_info)

    # compress generated executable
    with zipfile.ZipFile(path, "a") as fout:
        filename = "neuron_network.xmm"
        if not osp.isfile(filename):
            message = f"Executable generated failed: cannot open {filename}"
            logger.error(message)
            raise FileNotFoundError(message)
        fout.write(filename)

    # remove all temporary files
    regex = [
        "code_file.bin",
        "code_file.asm",
        "data_file.bin",
        "cycle_bin_file.bin",
        "cycle_char_file.txt",
        "info_file.txt",
        "info_file_again.txt",
        "code_data_model.bin",
        "code_data_model_no_header.bin",
        "code_data_model_no_copy.bin",
        "inout_tensor.cfg",
        "npu_profiling_theoretical.txt",
        "input_data*.bin",
        "output_data*.bin",
        "neuron_network.xmm",
    ]
    for filename in filenames_by_regex(regex):
        if osp.isfile(filename):
            os.remove(filename)
