import xmtvmc

if __name__ == "__main__":
    xmtvmc.main.main()
